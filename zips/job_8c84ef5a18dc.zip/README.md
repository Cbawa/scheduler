# Startup News Monitor

A lightweight [Streamlit](https://streamlit.io/) dashboard that helps founders and
teams keep an eye on press coverage of their (and their competitors') startups. Type in
one or more startup names, and the app fetches the latest news mentions from the
[newsdata.io](https://newsdata.io/) news API and lays them out in a clean, filterable feed.

> Built as a showcase for the **newsdata.io** REST API. It runs end-to-end on the
> **free tier** — no paid plan required.

![Built with Streamlit](https://img.shields.io/badge/Built%20with-Streamlit-FF4B4B)
![Powered by newsdata.io](https://img.shields.io/badge/Powered%20by-newsdata.io-1f6feb)

## Features

- 🔍 **Track multiple startups at once** — enter a comma-separated watchlist of company names.
- 📰 **Latest mentions feed** — each result shows the headline, source, publish date, snippet and a link to the article.
- 🌍 **Filters** — narrow by language and country using newsdata.io free-tier parameters.
- 📄 **Pagination** — "Load more" uses the API's `nextPage` token to pull additional pages.
- 📈 **At-a-glance metrics** — total mentions and a per-startup mention count.
- 📥 **CSV export** — download the current results for sharing or reporting.
- 🛡️ **Free-tier safe** — gracefully handles invalid keys, rate limits, empty results and paid-only upgrade prompts.

## How it works

The app calls the newsdata.io **Latest news** endpoint:

```
GET https://newsdata.io/api/1/news?apikey=YOUR_KEY&q="Acme Robotics"&language=en
```

For each startup name in your watchlist it runs a phrase query (`q="<name>"`), then merges,
de-duplicates and sorts the results by publish date.

## Getting started

### 1. Get a free API key

Sign up at [newsdata.io](https://newsdata.io/register) and copy your API key from the dashboard.
The free plan is all you need for this app.

### 2. Install dependencies

```bash
git clone https://github.com/your-username/startup-news-monitor.git
cd startup-news-monitor
python -m venv .venv
source .venv/bin/activate        # on Windows: .venv\Scripts\activate
pip install -r requirements.txt
```

### 3. Set your API key

The app reads your key from the `NEWSDATA_API_KEY` environment variable. **Never hardcode it.**

```bash
export NEWSDATA_API_KEY="pub_xxxxxxxxxxxxxxxxxxxxxxxxxxxx"   # macOS / Linux
```

```powershell
setx NEWSDATA_API_KEY "pub_xxxxxxxxxxxxxxxxxxxxxxxxxxxx"      # Windows PowerShell (reopen shell after)
```

If the variable is not set, the app shows a clear message and stops.

### 4. Run it

```bash
streamlit run app.py
```

Streamlit opens the dashboard in your browser (usually at http://localhost:8501).

## Usage

1. Enter one or more startup names in the sidebar, separated by commas
   (e.g. `Acme Robotics, Nimbus Health, Forge AI`).
2. Optionally pick a language and/or country.
3. Click **Search** to load the latest mentions.
4. Use **Load more results** to page through additional articles.
5. Click **Download results as CSV** to export.

## Free vs. paid features

This project is intentionally built around endpoints and parameters available on the
**free** newsdata.io plan (`q`, `language`, `country`, `category`, and `page` pagination
via the `nextPage` token).

The following newsdata.io capabilities require a **paid plan** and are therefore **not**
used in the core flow. If you upgrade, you could extend the app to use them:

- Sentiment analysis (`sentiment`)
- AI-enriched fields (`ai_tag`, `ai_region`, `ai_org`, `ai_summary`)
- The historical `/archive` endpoint and long date ranges
- Advanced full-text query operators

If the API ever responds with a paid-only "upgrade your plan" error (HTTP 403/422),
the app detects it, skips the unavailable feature and keeps working.

## Project structure

```
startup-news-monitor/
├─ app.py               # Streamlit UI
├─ newsdata_client.py   # Thin newsdata.io API client (free-tier safe)
├─ requirements.txt
├─ .gitignore
└─ README.md
```

## Troubleshooting

| Symptom | Cause | Fix |
| --- | --- | --- |
| `NEWSDATA_API_KEY environment variable is not set` | Key not exported | Set the env var (step 3) and restart the app |
| `Invalid API key` | Wrong/expired key | Re-copy your key from the newsdata.io dashboard |
| `Rate limit reached` | Too many requests on the free plan | Wait a moment and try again |
| No results | No recent coverage for that name | Try a broader or differently-spelled name |

## License

MIT — see below. Provided as a community example for the newsdata.io API.
