"""Startup News Monitor — a Streamlit dashboard powered by newsdata.io.

Track press coverage of early-stage startups by name. Built to run on the
newsdata.io FREE tier.

Run with:
    streamlit run app.py

Requires the NEWSDATA_API_KEY environment variable.
"""

from __future__ import annotations

import csv
import io
from typing import Any, Dict, List

import streamlit as st

from newsdata_client import (
    MissingApiKeyError,
    NewsDataError,
    PaidFeatureError,
    dedupe_articles,
    get_api_key,
    search_startup,
)

# --- A short list of free-tier supported filter values -----------------------
LANGUAGES = {
    "Any": None,
    "English": "en",
    "Spanish": "es",
    "French": "fr",
    "German": "de",
    "Portuguese": "pt",
    "Hindi": "hi",
}

COUNTRIES = {
    "Any": None,
    "United States": "us",
    "United Kingdom": "gb",
    "India": "in",
    "Canada": "ca",
    "Australia": "au",
    "Germany": "de",
}


def parse_watchlist(raw: str) -> List[str]:
    """Split the comma-separated watchlist input into clean names."""
    names = [part.strip() for part in raw.split(",")]
    # De-duplicate (case-insensitive) while keeping order.
    seen = set()
    result = []
    for name in names:
        if not name:
            continue
        key = name.lower()
        if key in seen:
            continue
        seen.add(key)
        result.append(name)
    return result


def article_to_row(art: Dict[str, Any]) -> Dict[str, str]:
    """Flatten an article dict into a CSV-friendly row."""
    source = art.get("source_id") or art.get("source_name") or ""
    return {
        "startup": art.get("_startup", ""),
        "title": art.get("title", "") or "",
        "source": source,
        "published": art.get("pubDate", "") or "",
        "link": art.get("link", "") or "",
        "description": (art.get("description") or "").replace("\n", " ").strip(),
    }


def build_csv(articles: List[Dict[str, Any]]) -> str:
    buffer = io.StringIO()
    fieldnames = ["startup", "title", "source", "published", "link", "description"]
    writer = csv.DictWriter(buffer, fieldnames=fieldnames)
    writer.writeheader()
    for art in articles:
        writer.writerow(article_to_row(art))
    return buffer.getvalue()


def run_search(
    names: List[str], language: str | None, country: str | None
) -> Dict[str, Any]:
    """Search every startup once, merge and de-duplicate the results.

    Returns a dict with the merged articles, per-startup counts and the
    nextPage tokens (one per startup) for pagination.
    """
    api_key = get_api_key()
    all_articles: List[Dict[str, Any]] = []
    counts: Dict[str, int] = {}
    next_tokens: Dict[str, str] = {}

    for name in names:
        data = search_startup(
            name, api_key=api_key, language=language, country=country
        )
        articles = data.get("results", [])
        counts[name] = len(articles)
        all_articles.extend(articles)
        token = data.get("nextPage")
        if token:
            next_tokens[name] = token

    merged = dedupe_articles(all_articles)
    merged.sort(key=lambda a: a.get("pubDate", ""), reverse=True)
    return {"articles": merged, "counts": counts, "next_tokens": next_tokens}


def load_more(
    next_tokens: Dict[str, str], language: str | None, country: str | None
) -> Dict[str, Any]:
    """Fetch one more page for every startup that still has a nextPage token."""
    api_key = get_api_key()
    more_articles: List[Dict[str, Any]] = []
    new_tokens: Dict[str, str] = {}

    for name, token in next_tokens.items():
        data = search_startup(
            name,
            api_key=api_key,
            language=language,
            country=country,
            page=token,
        )
        more_articles.extend(data.get("results", []))
        new_token = data.get("nextPage")
        if new_token:
            new_tokens[name] = new_token

    return {"articles": more_articles, "next_tokens": new_tokens}


def render_article(art: Dict[str, Any]) -> None:
    title = art.get("title") or "(untitled)"
    link = art.get("link") or ""
    source = art.get("source_id") or art.get("source_name") or "unknown source"
    published = art.get("pubDate") or ""
    startup = art.get("_startup", "")
    description = art.get("description") or ""

    if link:
        st.markdown(f"#### [{title}]({link})")
    else:
        st.markdown(f"#### {title}")

    meta = f"🏷️ **{startup}** · 📰 {source}"
    if published:
        meta += f" · 🕒 {published}"
    st.caption(meta)

    if description:
        st.write(description)
    st.divider()


def main() -> None:
    st.set_page_config(
        page_title="Startup News Monitor",
        page_icon="📰",
        layout="wide",
    )

    st.title("📰 Startup News Monitor")
    st.write(
        "Track press coverage of early-stage startups by name, powered by "
        "[newsdata.io](https://newsdata.io/)."
    )

    # --- Sidebar controls ----------------------------------------------------
    with st.sidebar:
        st.header("Watchlist")
        raw_watchlist = st.text_area(
            "Startup names (comma-separated)",
            value="Acme Robotics, Nimbus Health",
            help="Enter one or more company names, separated by commas.",
            height=100,
        )
        language_label = st.selectbox("Language", list(LANGUAGES.keys()), index=1)
        country_label = st.selectbox("Country", list(COUNTRIES.keys()), index=0)
        search_clicked = st.button("🔍 Search", type="primary", use_container_width=True)
        st.caption(
            "Free-tier safe: this app only uses newsdata.io parameters available "
            "on the free plan."
        )

    language = LANGUAGES[language_label]
    country = COUNTRIES[country_label]

    # --- Verify the API key is present before doing anything -----------------
    try:
        get_api_key()
    except MissingApiKeyError as exc:
        st.error(str(exc))
        st.stop()

    # --- Handle a new search -------------------------------------------------
    if search_clicked:
        names = parse_watchlist(raw_watchlist)
        if not names:
            st.warning("Please enter at least one startup name in the sidebar.")
            st.stop()

        with st.spinner("Fetching the latest mentions…"):
            try:
                result = run_search(names, language, country)
            except PaidFeatureError as exc:
                st.warning(f"Skipping a paid-only feature: {exc}")
                st.stop()
            except NewsDataError as exc:
                st.error(str(exc))
                st.stop()

        st.session_state["articles"] = result["articles"]
        st.session_state["counts"] = result["counts"]
        st.session_state["next_tokens"] = result["next_tokens"]
        st.session_state["language"] = language
        st.session_state["country"] = country

    # --- Render whatever is in session state ---------------------------------
    articles: List[Dict[str, Any]] = st.session_state.get("articles", [])
    counts: Dict[str, int] = st.session_state.get("counts", {})

    if not articles and not counts:
        st.info(
            "👈 Add some startup names in the sidebar and click **Search** to begin."
        )
        return

    # Metrics row.
    total = len(articles)
    cols = st.columns(max(len(counts), 1) + 1)
    cols[0].metric("Total mentions", total)
    for i, (name, count) in enumerate(counts.items(), start=1):
        if i < len(cols):
            cols[i].metric(name, count)

    if total == 0:
        st.info(
            "No recent news mentions found for your watchlist. Try different names, "
            "or broaden the language/country filters."
        )
        return

    # Download button.
    st.download_button(
        "⬇️ Download results as CSV",
        data=build_csv(articles),
        file_name="startup_mentions.csv",
        mime="text/csv",
    )

    st.subheader(f"Latest mentions ({total})")
    for art in articles:
        render_article(art)

    # --- Pagination ----------------------------------------------------------
    next_tokens: Dict[str, str] = st.session_state.get("next_tokens", {})
    if next_tokens:
        if st.button("📄 Load more results", use_container_width=True):
            with st.spinner("Loading more…"):
                try:
                    more = load_more(
                        next_tokens,
                        st.session_state.get("language"),
                        st.session_state.get("country"),
                    )
                except PaidFeatureError as exc:
                    st.warning(f"Skipping a paid-only feature: {exc}")
                    more = None
                except NewsDataError as exc:
                    st.error(str(exc))
                    more = None

            if more:
                combined = dedupe_articles(articles + more["articles"])
                combined.sort(key=lambda a: a.get("pubDate", ""), reverse=True)
                st.session_state["articles"] = combined
                st.session_state["next_tokens"] = more["next_tokens"]
                st.rerun()
    else:
        st.caption("No more pages available for the current search.")


if __name__ == "__main__":
    main()
