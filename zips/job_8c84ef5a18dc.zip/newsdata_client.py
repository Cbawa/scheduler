"""A small, free-tier-safe client for the newsdata.io REST API.

Docs: https://newsdata.io/documentation

This client deliberately sticks to parameters available on the FREE plan
(``q``, ``language``, ``country``, ``category`` and ``page`` pagination via the
``nextPage`` token). Paid-only features (sentiment, ai_* fields, /archive, advanced
query operators) are never required, and the client degrades gracefully if the API
returns an "upgrade your plan" error.
"""

from __future__ import annotations

import os
from typing import Any, Dict, List, Optional

import requests

BASE_URL = "https://newsdata.io/api/1"
NEWS_ENDPOINT = f"{BASE_URL}/news"

# Network timeout (seconds) for every request.
REQUEST_TIMEOUT = 20


class NewsDataError(Exception):
    """Raised for any user-facing problem talking to newsdata.io."""


class MissingApiKeyError(NewsDataError):
    """Raised when the NEWSDATA_API_KEY environment variable is not set."""


class PaidFeatureError(NewsDataError):
    """Raised when the API rejects a request because it needs a paid plan."""


def get_api_key() -> str:
    """Return the API key from the environment or raise a clear error."""
    key = os.environ.get("NEWSDATA_API_KEY", "").strip()
    if not key:
        raise MissingApiKeyError(
            "NEWSDATA_API_KEY environment variable is not set. "
            "Get a free key at https://newsdata.io/register and export it, e.g.\n"
            '    export NEWSDATA_API_KEY="pub_xxxxxxxx"'
        )
    return key


def _looks_like_paid_error(message: str) -> bool:
    msg = (message or "").lower()
    needles = ("upgrade", "paid", "not available in your plan", "subscription", "premium")
    return any(n in msg for n in needles)


def _handle_error_response(resp: requests.Response) -> None:
    """Translate a non-200 response into a friendly NewsDataError."""
    # Try to extract the API's own error message.
    api_message = ""
    try:
        payload = resp.json()
        if isinstance(payload, dict):
            results = payload.get("results")
            if isinstance(results, dict):
                api_message = results.get("message") or results.get("code") or ""
            api_message = api_message or payload.get("message", "")
    except ValueError:
        api_message = resp.text[:300]

    status = resp.status_code
    if status == 401:
        raise NewsDataError("Invalid API key. Check your NEWSDATA_API_KEY value.")
    if status == 429:
        raise NewsDataError(
            "Rate limit reached for your newsdata.io plan. Please wait and try again."
        )
    if status in (403, 422) and _looks_like_paid_error(api_message):
        raise PaidFeatureError(
            "This request used a feature that requires a paid newsdata.io plan: "
            f"{api_message or 'upgrade required'}"
        )
    raise NewsDataError(
        f"newsdata.io request failed (HTTP {status}). {api_message}".strip()
    )


def fetch_news(
    query: str,
    *,
    api_key: Optional[str] = None,
    language: Optional[str] = None,
    country: Optional[str] = None,
    category: Optional[str] = None,
    page: Optional[str] = None,
) -> Dict[str, Any]:
    """Fetch one page of latest news for ``query`` from the /news endpoint.

    Returns the parsed JSON dict: ``{status, totalResults, results, nextPage}``.
    Raises a subclass of :class:`NewsDataError` on any failure.
    """
    key = api_key or get_api_key()

    params: Dict[str, str] = {"apikey": key, "q": query}
    if language:
        params["language"] = language
    if country:
        params["country"] = country
    if category:
        params["category"] = category
    if page:
        params["page"] = page

    try:
        resp = requests.get(NEWS_ENDPOINT, params=params, timeout=REQUEST_TIMEOUT)
    except requests.exceptions.Timeout as exc:
        raise NewsDataError("The request to newsdata.io timed out. Try again.") from exc
    except requests.exceptions.RequestException as exc:
        raise NewsDataError(f"Network error contacting newsdata.io: {exc}") from exc

    if resp.status_code != 200:
        _handle_error_response(resp)

    try:
        data = resp.json()
    except ValueError as exc:
        raise NewsDataError("Could not parse the response from newsdata.io.") from exc

    if data.get("status") == "error":
        # Some errors are returned with HTTP 200 and status=error.
        results = data.get("results")
        message = ""
        if isinstance(results, dict):
            message = results.get("message", "")
        if _looks_like_paid_error(message):
            raise PaidFeatureError(message or "This feature requires a paid plan.")
        raise NewsDataError(message or "newsdata.io returned an error.")

    # Normalise: results should always be a list for the caller.
    if not isinstance(data.get("results"), list):
        data["results"] = []
    return data


def search_startup(
    name: str,
    *,
    api_key: Optional[str] = None,
    language: Optional[str] = None,
    country: Optional[str] = None,
    page: Optional[str] = None,
) -> Dict[str, Any]:
    """Search mentions of a single startup name (exact phrase) and tag each article.

    The returned dict mirrors :func:`fetch_news` but each item in ``results`` gets a
    ``_startup`` field so the UI can show which watchlist entry matched.
    """
    name = name.strip()
    if not name:
        return {"status": "success", "totalResults": 0, "results": [], "nextPage": None}

    # Wrap in quotes so multi-word names are treated as a phrase.
    phrase = f'"{name}"' if " " in name else name
    data = fetch_news(
        phrase,
        api_key=api_key,
        language=language,
        country=country,
        page=page,
    )
    for article in data.get("results", []):
        if isinstance(article, dict):
            article["_startup"] = name
    return data


def dedupe_articles(articles: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    """Remove duplicate articles (same link) while preserving order."""
    seen = set()
    unique: List[Dict[str, Any]] = []
    for art in articles:
        link = (art.get("link") or art.get("article_id") or art.get("title") or "").strip()
        if link and link in seen:
            continue
        seen.add(link)
        unique.append(art)
    return unique
