package newsdata

import "context"

// Paginator iterates over pages of /news results using the API's nextPage token.
//
//	pg := client.NewsPaginator(newsdata.NewsParams{Query: "bitcoin"})
//	for pg.Next(ctx) {
//		for _, a := range pg.Page().Results { ... }
//	}
//	if err := pg.Err(); err != nil { ... }
type Paginator struct {
	client   *Client
	params   NewsParams
	nextPage string
	started  bool
	done     bool
	err      error
	page     *NewsResponse
}

// NewsPaginator creates a Paginator for the given query parameters.
func (c *Client) NewsPaginator(p NewsParams) *Paginator {
	return &Paginator{client: c, params: p}
}

// Next fetches the next page. It returns false when there are no more pages or
// when an error occurs (inspect Err). The fetched page is available via Page.
func (pg *Paginator) Next(ctx context.Context) bool {
	if pg.done || pg.err != nil {
		return false
	}

	p := pg.params
	if pg.started {
		p.Page = pg.nextPage
	}
	pg.started = true

	resp, err := pg.client.GetNews(ctx, p)
	if err != nil {
		pg.err = err
		return false
	}

	pg.page = resp
	if resp.NextPage == "" {
		pg.done = true
	} else {
		pg.nextPage = resp.NextPage
	}
	return true
}

// Page returns the most recently fetched page (nil before the first Next call).
func (pg *Paginator) Page() *NewsResponse { return pg.page }

// Err returns the first error encountered while paginating, if any.
func (pg *Paginator) Err() error { return pg.err }
