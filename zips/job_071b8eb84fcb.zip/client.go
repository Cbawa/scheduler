// Package newsdata is an unofficial, typed Go client for the newsdata.io news API.
//
// It targets the FREE plan: only free endpoints and parameters are used in the core
// flow. Paid-only response fields are exposed but never required, and paid-only
// errors (403/422) are surfaced cleanly via APIError.IsPaidOnly().
package newsdata

import (
	"context"
	"encoding/json"
	"fmt"
	"io"
	"net/http"
	"net/url"
	"strconv"
	"strings"
	"time"
)

// DefaultBaseURL is the production newsdata.io REST base URL.
const DefaultBaseURL = "https://newsdata.io/api/1"

// Client is a reusable, concurrency-safe newsdata.io API client.
type Client struct {
	apiKey     string
	baseURL    string
	httpClient *http.Client
	maxRetries int
	userAgent  string
}

// Option customises a Client at construction time.
type Option func(*Client)

// WithHTTPClient sets a custom *http.Client (e.g. for proxies or custom timeouts).
func WithHTTPClient(h *http.Client) Option {
	return func(c *Client) {
		if h != nil {
			c.httpClient = h
		}
	}
}

// WithBaseURL overrides the API base URL.
func WithBaseURL(u string) Option {
	return func(c *Client) {
		if u != "" {
			c.baseURL = strings.TrimRight(u, "/")
		}
	}
}

// WithMaxRetries sets how many times a 429 / transient network error is retried.
func WithMaxRetries(n int) Option {
	return func(c *Client) {
		if n >= 0 {
			c.maxRetries = n
		}
	}
}

// NewClient returns a Client for the given API key. The key must be non-empty; it
// is sent as the `apikey` query parameter on every request and is never logged.
func NewClient(apiKey string, opts ...Option) *Client {
	c := &Client{
		apiKey:     apiKey,
		baseURL:    DefaultBaseURL,
		httpClient: &http.Client{Timeout: 30 * time.Second},
		maxRetries: 3,
		userAgent:  "newsdata-go-client/1.0 (+https://github.com/newsdata-io/newsdata-go-client)",
	}
	for _, o := range opts {
		o(c)
	}
	return c
}

// NewsParams holds free-tier query parameters for the /news endpoint.
type NewsParams struct {
	Query    string // q: keywords or phrase
	Country  string // country: comma-separated 2-letter codes, e.g. "us,gb"
	Language string // language: comma-separated codes, e.g. "en"
	Category string // category: e.g. "technology,business"
	Domain   string // domain: restrict to specific source domains
	Page     string // page: the nextPage token from a previous response
}

func (p NewsParams) values() url.Values {
	v := url.Values{}
	if p.Query != "" {
		v.Set("q", p.Query)
	}
	if p.Country != "" {
		v.Set("country", p.Country)
	}
	if p.Language != "" {
		v.Set("language", p.Language)
	}
	if p.Category != "" {
		v.Set("category", p.Category)
	}
	if p.Domain != "" {
		v.Set("domain", p.Domain)
	}
	if p.Page != "" {
		v.Set("page", p.Page)
	}
	return v
}

// SourcesParams holds free-tier query parameters for the /sources endpoint.
type SourcesParams struct {
	Country  string
	Language string
	Category string
}

func (p SourcesParams) values() url.Values {
	v := url.Values{}
	if p.Country != "" {
		v.Set("country", p.Country)
	}
	if p.Language != "" {
		v.Set("language", p.Language)
	}
	if p.Category != "" {
		v.Set("category", p.Category)
	}
	return v
}

// GetNews fetches a single page of latest news from /news.
func (c *Client) GetNews(ctx context.Context, p NewsParams) (*NewsResponse, error) {
	var out NewsResponse
	if err := c.get(ctx, "/news", p.values(), &out); err != nil {
		return nil, err
	}
	return &out, nil
}

// GetSources fetches available news sources from /sources.
func (c *Client) GetSources(ctx context.Context, p SourcesParams) (*SourcesResponse, error) {
	var out SourcesResponse
	if err := c.get(ctx, "/sources", p.values(), &out); err != nil {
		return nil, err
	}
	return &out, nil
}

// AllNews walks pagination automatically and returns the collected articles.
// maxPages <= 0 means "follow nextPage until exhausted" (use with care on free keys).
func (c *Client) AllNews(ctx context.Context, p NewsParams, maxPages int) ([]Article, error) {
	var all []Article
	pg := c.NewsPaginator(p)
	pages := 0
	for pg.Next(ctx) {
		all = append(all, pg.Page().Results...)
		pages++
		if maxPages > 0 && pages >= maxPages {
			break
		}
	}
	return all, pg.Err()
}

func (c *Client) get(ctx context.Context, path string, v url.Values, out interface{}) error {
	if c.apiKey == "" {
		return fmt.Errorf("newsdata: API key is empty (set NEWSDATA_API_KEY)")
	}
	v.Set("apikey", c.apiKey)
	endpoint := c.baseURL + path + "?" + v.Encode()

	var lastErr error
	for attempt := 0; attempt <= c.maxRetries; attempt++ {
		req, err := http.NewRequestWithContext(ctx, http.MethodGet, endpoint, nil)
		if err != nil {
			return err
		}
		req.Header.Set("User-Agent", c.userAgent)
		req.Header.Set("Accept", "application/json")

		resp, err := c.httpClient.Do(req)
		if err != nil {
			lastErr = err
			if attempt < c.maxRetries && sleep(ctx, backoffDuration(attempt)) {
				continue
			}
			return err
		}

		body, readErr := io.ReadAll(resp.Body)
		resp.Body.Close()
		if readErr != nil {
			lastErr = readErr
			if attempt < c.maxRetries && sleep(ctx, backoffDuration(attempt)) {
				continue
			}
			return readErr
		}

		switch {
		case resp.StatusCode == http.StatusOK:
			if err := json.Unmarshal(body, out); err != nil {
				return fmt.Errorf("newsdata: decode response: %w", err)
			}
			return nil

		case resp.StatusCode == http.StatusTooManyRequests:
			lastErr = parseAPIError(resp.StatusCode, body)
			if attempt < c.maxRetries {
				wait := retryAfter(resp.Header)
				if wait <= 0 {
					wait = backoffDuration(attempt)
				}
				if sleep(ctx, wait) {
					continue
				}
				return ctx.Err()
			}
			return lastErr

		default:
			return parseAPIError(resp.StatusCode, body)
		}
	}
	if lastErr == nil {
		lastErr = fmt.Errorf("newsdata: request failed after retries")
	}
	return lastErr
}

func retryAfter(h http.Header) time.Duration {
	if ra := strings.TrimSpace(h.Get("Retry-After")); ra != "" {
		if secs, err := strconv.Atoi(ra); err == nil && secs >= 0 {
			return time.Duration(secs) * time.Second
		}
	}
	return 0
}

func backoffDuration(attempt int) time.Duration {
	d := time.Duration(1<<uint(attempt)) * time.Second
	if d > 30*time.Second {
		d = 30 * time.Second
	}
	return d
}

// sleep waits for d or until ctx is cancelled. Returns true if the wait completed.
func sleep(ctx context.Context, d time.Duration) bool {
	if d <= 0 {
		return true
	}
	t := time.NewTimer(d)
	defer t.Stop()
	select {
	case <-ctx.Done():
		return false
	case <-t.C:
		return true
	}
}
