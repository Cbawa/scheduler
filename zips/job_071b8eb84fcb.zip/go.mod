module github.com/newsdata-io/newsdata-go-client

go 1.21
