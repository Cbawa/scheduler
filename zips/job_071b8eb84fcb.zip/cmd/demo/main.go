// Command demo is a small CLI showcasing the newsdata-go-client library.
//
// Usage:
//
//	export NEWSDATA_API_KEY=your_key_here
//	go run ./cmd/demo -q "technology" -country us -language en -pages 2
package main

import (
	"context"
	"errors"
	"flag"
	"fmt"
	"os"
	"time"

	newsdata "github.com/newsdata-io/newsdata-go-client"
)

func main() {
	query := flag.String("q", "", "search query (keywords)")
	country := flag.String("country", "", "country code(s), e.g. us or us,gb")
	language := flag.String("language", "en", "language code(s), e.g. en")
	category := flag.String("category", "", "category, e.g. technology")
	maxPages := flag.Int("pages", 1, "max pages to fetch (follows nextPage)")
	flag.Parse()

	apiKey := os.Getenv("NEWSDATA_API_KEY")
	if apiKey == "" {
		fmt.Fprintln(os.Stderr, "error: NEWSDATA_API_KEY environment variable is not set.")
		fmt.Fprintln(os.Stderr, "Get a free key at https://newsdata.io and run:")
		fmt.Fprintln(os.Stderr, "  export NEWSDATA_API_KEY=your_key_here")
		os.Exit(1)
	}

	client := newsdata.NewClient(apiKey)

	ctx, cancel := context.WithTimeout(context.Background(), 60*time.Second)
	defer cancel()

	params := newsdata.NewsParams{
		Query:    *query,
		Country:  *country,
		Language: *language,
		Category: *category,
	}

	articles, err := client.AllNews(ctx, params, *maxPages)
	if err != nil {
		handleError(err)
		os.Exit(1)
	}

	if len(articles) == 0 {
		fmt.Println("No articles found for the given query.")
		return
	}

	for i, a := range articles {
		fmt.Printf("%d. %s\n", i+1, a.Title)
		if a.SourceID != "" || a.PubDate != "" {
			fmt.Printf("   source: %s | %s\n", a.SourceID, a.PubDate)
		}
		if a.Link != "" {
			fmt.Printf("   %s\n", a.Link)
		}
		fmt.Println()
	}
	fmt.Printf("Fetched %d article(s).\n", len(articles))
}

func handleError(err error) {
	var apiErr *newsdata.APIError
	if errors.As(err, &apiErr) {
		switch {
		case apiErr.IsUnauthorized():
			fmt.Fprintln(os.Stderr, "error: invalid API key (401). Check NEWSDATA_API_KEY.")
		case apiErr.IsRateLimit():
			fmt.Fprintln(os.Stderr, "error: rate limit reached (429). Wait a moment and try again.")
		case apiErr.IsPaidOnly():
			fmt.Fprintln(os.Stderr, "note: that feature requires a paid plan; it is not available on the free tier.")
		default:
			fmt.Fprintf(os.Stderr, "API error: %v\n", apiErr)
		}
		return
	}
	fmt.Fprintf(os.Stderr, "error: %v\n", err)
}
