package newsdata

import (
	"encoding/json"
	"fmt"
	"net/http"
)

// Article is a single news article returned by the /news endpoint.
//
// The ai_* and sentiment fields are PAID-ONLY. On the free plan they are absent;
// they are typed as json.RawMessage so the client never fails to decode and never
// depends on them.
type Article struct {
	ArticleID   string   `json:"article_id"`
	Title       string   `json:"title"`
	Link        string   `json:"link"`
	Description string   `json:"description"`
	Content     string   `json:"content"`
	PubDate     string   `json:"pubDate"`
	ImageURL    string   `json:"image_url"`
	SourceID    string   `json:"source_id"`
	SourceName  string   `json:"source_name"`
	SourceURL   string   `json:"source_url"`
	SourceIcon  string   `json:"source_icon"`
	Language    string   `json:"language"`
	Country     []string `json:"country"`
	Category    []string `json:"category"`
	Creator     []string `json:"creator"`
	Keywords    []string `json:"keywords"`
	VideoURL    string   `json:"video_url"`
	Duplicate   bool     `json:"duplicate"`

	// Paid-only fields (empty on the free plan; decoded leniently).
	Sentiment      json.RawMessage `json:"sentiment,omitempty"`
	SentimentStats json.RawMessage `json:"sentiment_stats,omitempty"`
	AITag          json.RawMessage `json:"ai_tag,omitempty"`
	AIRegion       json.RawMessage `json:"ai_region,omitempty"`
	AIOrg          json.RawMessage `json:"ai_org,omitempty"`
	AISummary      json.RawMessage `json:"ai_summary,omitempty"`
}

// NewsResponse is the envelope returned by the /news endpoint.
type NewsResponse struct {
	Status       string    `json:"status"`
	TotalResults int       `json:"totalResults"`
	Results      []Article `json:"results"`
	NextPage     string    `json:"nextPage"`
}

// Source is a single news source returned by the /sources endpoint.
type Source struct {
	ID          string   `json:"id"`
	Name        string   `json:"name"`
	URL         string   `json:"url"`
	Icon        string   `json:"icon"`
	Description string   `json:"description"`
	Priority    int      `json:"priority"`
	Language    []string `json:"language"`
	Country     []string `json:"country"`
	Category    []string `json:"category"`
}

// SourcesResponse is the envelope returned by the /sources endpoint.
type SourcesResponse struct {
	Status       string   `json:"status"`
	TotalResults int      `json:"totalResults"`
	Results      []Source `json:"results"`
}

// APIError is a typed error for non-2xx responses from newsdata.io.
type APIError struct {
	StatusCode int
	Code       string
	Message    string
}

func (e *APIError) Error() string {
	if e.Code != "" {
		return fmt.Sprintf("newsdata: HTTP %d: %s (%s)", e.StatusCode, e.Message, e.Code)
	}
	return fmt.Sprintf("newsdata: HTTP %d: %s", e.StatusCode, e.Message)
}

// IsUnauthorized reports an invalid or missing API key (401).
func (e *APIError) IsUnauthorized() bool { return e.StatusCode == http.StatusUnauthorized }

// IsRateLimit reports that the rate limit was hit (429).
func (e *APIError) IsRateLimit() bool { return e.StatusCode == http.StatusTooManyRequests }

// IsPaidOnly reports that a paid-only feature was requested (403 or 422).
func (e *APIError) IsPaidOnly() bool {
	return e.StatusCode == http.StatusForbidden || e.StatusCode == http.StatusUnprocessableEntity
}

// parseAPIError extracts the message/code from a newsdata.io error body. The API
// typically returns {"status":"error","results":{"message":"...","code":"..."}}.
func parseAPIError(status int, body []byte) *APIError {
	e := &APIError{StatusCode: status}

	var env struct {
		Status  string `json:"status"`
		Results struct {
			Message string `json:"message"`
			Code    string `json:"code"`
		} `json:"results"`
		Message string `json:"message"`
		Code    string `json:"code"`
	}
	if err := json.Unmarshal(body, &env); err == nil {
		switch {
		case env.Results.Message != "":
			e.Message = env.Results.Message
			e.Code = env.Results.Code
		case env.Message != "":
			e.Message = env.Message
			e.Code = env.Code
		}
	}
	if e.Message == "" {
		if txt := http.StatusText(status); txt != "" {
			e.Message = txt
		} else {
			e.Message = "request failed"
		}
	}
	return e
}
