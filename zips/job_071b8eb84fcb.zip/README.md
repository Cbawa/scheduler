# newsdata-go-client

An unofficial, idiomatic **Go client** for the [newsdata.io](https://newsdata.io) news API.

- ✅ Strongly-typed request params and response structs
- ✅ Automatic retry + back-off on `429 Too Many Requests` (honours `Retry-After`)
- ✅ First-class pagination via the API's `nextPage` token
- ✅ Clear, typed errors (`401` invalid key, `429` rate limit, `403/422` paid-only)
- ✅ Works out of the box on the **FREE plan**

> This is a community project and is not affiliated with newsdata.io.

## Install

```bash
go get github.com/newsdata-io/newsdata-go-client@latest
```

Requires Go 1.21+.

## API key

Get a free API key from <https://newsdata.io>. The client and the demo CLI read it from the `NEWSDATA_API_KEY` environment variable — the key is **never** hardcoded.

```bash
export NEWSDATA_API_KEY=your_key_here
```

## Quick start (library)

```go
package main

import (
	"context"
	"fmt"
	"log"
	"os"

	newsdata "github.com/newsdata-io/newsdata-go-client"
)

func main() {
	client := newsdata.NewClient(os.Getenv("NEWSDATA_API_KEY"))

	resp, err := client.GetNews(context.Background(), newsdata.NewsParams{
		Query:    "technology",
		Language: "en",
		Country:  "us",
	})
	if err != nil {
		log.Fatal(err)
	}

	fmt.Printf("Found %d results\n", resp.TotalResults)
	for _, a := range resp.Results {
		fmt.Printf("- %s (%s)\n", a.Title, a.SourceID)
	}
}
```

## Pagination

The API returns a `nextPage` token instead of numeric page offsets. Use the built-in paginator:

```go
pg := client.NewsPaginator(newsdata.NewsParams{Query: "bitcoin", Language: "en"})
for pg.Next(context.Background()) {
	for _, a := range pg.Page().Results {
		fmt.Println(a.Title)
	}
}
if err := pg.Err(); err != nil {
	log.Fatal(err)
}
```

Or grab everything (up to a page cap) in one call:

```go
articles, err := client.AllNews(context.Background(),
	newsdata.NewsParams{Category: "science"}, 3) // fetch up to 3 pages
```

## Handling errors

```go
resp, err := client.GetNews(ctx, params)
if err != nil {
	var apiErr *newsdata.APIError
	if errors.As(err, &apiErr) {
		switch {
		case apiErr.IsUnauthorized(): // 401 — bad key
		case apiErr.IsRateLimit():    // 429 — slow down
		case apiErr.IsPaidOnly():     // 403/422 — feature not on free tier
		}
	}
}
```

The client automatically retries `429` responses (with exponential back-off, respecting any `Retry-After` header) up to `WithMaxRetries(n)` times before returning the error.

## Demo CLI

```bash
export NEWSDATA_API_KEY=your_key_here
go run ./cmd/demo -q "climate" -country us -language en -pages 2
```

Flags: `-q`, `-country`, `-language`, `-category`, `-pages`.

## Free tier vs paid plans

This client is built and tested against the **FREE** plan and only uses free endpoints/params in its core flow:

| Feature | Plan |
|---|---|
| `/news` (latest news), `/sources` | Free ✅ |
| `q`, `country`, `language`, `category`, `nextPage` pagination | Free ✅ |
| `sentiment`, `ai_tag`, `ai_region`, `ai_org`, `ai_summary` | **Paid only** |
| `/archive` (historical) & long date ranges | **Paid only** |
| Advanced full-text query operators | **Paid only** |

Paid-only response fields are exposed as `json.RawMessage` on the `Article` struct (`Sentiment`, `AITag`, …). On a free key they are simply empty — the client never depends on them, and a `403`/`422` "upgrade your plan" response is surfaced as `APIError.IsPaidOnly()` rather than crashing.

## Configuration options

```go
client := newsdata.NewClient(key,
	newsdata.WithMaxRetries(5),
	newsdata.WithHTTPClient(myHTTPClient),
	newsdata.WithBaseURL("https://newsdata.io/api/1"),
)
```

## License

MIT
