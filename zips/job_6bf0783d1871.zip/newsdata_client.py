"""Minimal, well-behaved client for the newsdata.io REST API (free tier)."""
import os

import requests

BASE_URL = "https://newsdata.io/api/1"


class NewsDataError(Exception):
    """Raised for any problem talking to newsdata.io."""


class NewsDataClient:
    def __init__(self, api_key=None, timeout=30):
        self.api_key = api_key or os.environ.get("NEWSDATA_API_KEY")
        if not self.api_key:
            raise NewsDataError(
                "NEWSDATA_API_KEY environment variable is not set. "
                "Get a free key at https://newsdata.io then run: "
                "export NEWSDATA_API_KEY=your_key"
            )
        self.timeout = timeout
        self.session = requests.Session()

    def get_latest(self, query=None, country=None, language="en", category=None, page=None):
        """Call GET /news with free-tier parameters and return the parsed JSON."""
        params = {"apikey": self.api_key}
        if query:
            params["q"] = query
        if country:
            params["country"] = country
        if language:
            params["language"] = language
        if category:
            params["category"] = category
        if page:
            params["page"] = page

        try:
            resp = self.session.get(BASE_URL + "/news", params=params, timeout=self.timeout)
        except requests.RequestException as e:
            raise NewsDataError(f"network error contacting newsdata.io: {e}") from e
        return self._parse(resp)

    def iter_articles(self, max_articles=10, **kwargs):
        """Yield articles, following the free 'nextPage' token as needed."""
        page = None
        seen = 0
        while seen < max_articles:
            data = self.get_latest(page=page, **kwargs)
            for article in data.get("results") or []:
                yield article
                seen += 1
                if seen >= max_articles:
                    return
            page = data.get("nextPage")
            if not page:
                return

    def _parse(self, resp):
        if resp.status_code == 401:
            raise NewsDataError("invalid API key (401). Check your NEWSDATA_API_KEY.")
        if resp.status_code == 429:
            raise NewsDataError(
                "rate limit reached (429). The free plan is limited -- "
                "wait a moment and try again."
            )
        if resp.status_code in (403, 422):
            try:
                body = resp.json()
                msg = body.get("results", {}).get("message") if isinstance(body.get("results"), dict) else None
                msg = msg or body.get("message") or resp.text
            except ValueError:
                msg = resp.text
            raise NewsDataError(
                f"request rejected ({resp.status_code}). This usually means a paid-only "
                f"feature or parameter was requested on a free key: {msg}"
            )
        if resp.status_code >= 400:
            raise NewsDataError(
                f"newsdata.io returned HTTP {resp.status_code}: {resp.text[:200]}"
            )

        try:
            data = resp.json()
        except ValueError as e:
            raise NewsDataError("could not decode JSON from newsdata.io") from e

        if data.get("status") == "error":
            raise NewsDataError(f"newsdata.io error response: {data}")
        return data
