"""Optional Twitter/X posting via tweepy. Imported lazily so the tool runs without it."""
import os


class TwitterError(Exception):
    """Raised when Twitter/X posting cannot be performed."""


class TwitterClient:
    def __init__(self):
        try:
            import tweepy
        except ImportError as e:
            raise TwitterError("tweepy is not installed; run 'pip install tweepy'") from e

        creds = {
            "consumer_key": os.environ.get("TWITTER_API_KEY"),
            "consumer_secret": os.environ.get("TWITTER_API_SECRET"),
            "access_token": os.environ.get("TWITTER_ACCESS_TOKEN"),
            "access_token_secret": os.environ.get("TWITTER_ACCESS_TOKEN_SECRET"),
        }
        missing = [k for k, v in creds.items() if not v]
        if missing:
            raise TwitterError(
                "missing Twitter/X credentials: "
                + ", ".join(missing)
                + ". Set the TWITTER_* environment variables to enable posting."
            )

        self._tweepy = tweepy
        self.client = tweepy.Client(
            consumer_key=creds["consumer_key"],
            consumer_secret=creds["consumer_secret"],
            access_token=creds["access_token"],
            access_token_secret=creds["access_token_secret"],
        )

    def post_thread(self, tweets):
        """Post tweets as a connected thread; return the status URLs."""
        urls = []
        reply_to = None
        for text in tweets:
            try:
                resp = self.client.create_tweet(text=text, in_reply_to_tweet_id=reply_to)
            except Exception as e:  # tweepy raises various API errors
                raise TwitterError(f"Twitter/X API error: {e}") from e
            tweet_id = resp.data["id"]
            reply_to = tweet_id
            urls.append(f"https://twitter.com/i/web/status/{tweet_id}")
        return urls
