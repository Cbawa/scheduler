"""Turn a newsdata.io article into a Twitter/X thread.

Uses OpenAI GPT-4 when requested/available, and otherwise falls back to a
deterministic built-in summarizer so the tool always works on a free key.
"""
import os
import re
import sys

TWEET_LIMIT = 280


def _split_sentences(text):
    parts = re.split(r"(?<=[.!?])\s+", (text or "").strip())
    return [p.strip() for p in parts if p.strip()]


def _truncate(text, limit=TWEET_LIMIT):
    text = (text or "").strip()
    if len(text) <= limit:
        return text
    cut = text[: limit - 1].rsplit(" ", 1)[0]
    return (cut or text[: limit - 1]) + "\u2026"


def _number(tweets):
    tweets = [t for t in tweets if t and t.strip()]
    if len(tweets) <= 1:
        return [_truncate(t) for t in tweets]
    total = len(tweets)
    out = []
    for i, t in enumerate(tweets, 1):
        suffix = f" ({i}/{total})"
        out.append(_truncate(t, TWEET_LIMIT - len(suffix)) + suffix)
    return out


def fallback_thread(article, max_tweets=3):
    """Build a thread from the article's own fields -- no external services."""
    title = article.get("title") or "Untitled"
    desc = article.get("description") or ""
    source = article.get("source_id") or ""
    link = article.get("link") or ""

    tweets = [_truncate(f"\U0001F9F5 {title}")]

    chunk = ""
    for sentence in _split_sentences(desc):
        if len(tweets) >= max_tweets - (1 if link else 0):
            break
        if len(chunk) + len(sentence) + 1 <= 250:
            chunk = (chunk + " " + sentence).strip()
        else:
            if chunk:
                tweets.append(chunk)
            chunk = sentence
    if chunk and len(tweets) < max_tweets:
        tweets.append(chunk)

    if link and len(tweets) < max_tweets:
        tail = f"\U0001F4F0 Source: {source}\n{link}".strip()
        tweets.append(tail)

    return tweets[:max_tweets]


def openai_thread(article, max_tweets=3, model=None):
    """Generate thread copy with OpenAI GPT-4. Raises on any failure."""
    from openai import OpenAI

    model = model or os.environ.get("OPENAI_MODEL", "gpt-4o")
    client = OpenAI()  # reads OPENAI_API_KEY from the environment

    title = article.get("title") or ""
    desc = article.get("description") or ""
    link = article.get("link") or ""
    source = article.get("source_id") or ""

    prompt = (
        "Write a concise, engaging Twitter/X thread that summarizes the news article below.\n"
        f"Use at most {max_tweets} tweets. Each tweet must be under 270 characters.\n"
        "Do not number the tweets yourself. Separate each tweet with a line containing only '---'.\n"
        "End the final tweet with the source link.\n\n"
        f"Title: {title}\nSource: {source}\nDescription: {desc}\nLink: {link}\n"
    )

    resp = client.chat.completions.create(
        model=model,
        messages=[{"role": "user", "content": prompt}],
        temperature=0.7,
        max_tokens=500,
    )
    text = (resp.choices[0].message.content or "").strip()
    parts = [p.strip() for p in text.split("---")]
    tweets = [p for p in parts if p]
    return tweets[:max_tweets] if tweets else None


def generate_thread(article, max_tweets=3, use_openai=False):
    """Return a numbered, character-safe list of tweets for one article."""
    tweets = None
    if use_openai:
        try:
            tweets = openai_thread(article, max_tweets=max_tweets)
        except Exception as e:  # network, auth, quota, import -- degrade gracefully
            print(f"warning: GPT-4 generation failed ({e}); using built-in summarizer.",
                  file=sys.stderr)
            tweets = None
    if not tweets:
        tweets = fallback_thread(article, max_tweets=max_tweets)
    return _number(tweets)
