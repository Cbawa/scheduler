#!/usr/bin/env python3
"""news-to-tweet -- turn top newsdata.io headlines into ready-to-post tweet threads.

Fetches the latest news from the newsdata.io API and generates a Twitter/X thread
for each article. Thread copy is written by OpenAI GPT-4 when an OPENAI_API_KEY is
available, and falls back to a built-in summarizer so the tool works out of the box
on a free newsdata.io key with no other accounts.
"""
import argparse
import os
import sys

try:
    from dotenv import load_dotenv
    load_dotenv()
except Exception:
    pass

from newsdata_client import NewsDataClient, NewsDataError
from summarizer import generate_thread
from twitter_client import TwitterClient, TwitterError


def parse_args():
    p = argparse.ArgumentParser(
        description="Generate Twitter/X tweet threads from newsdata.io top news."
    )
    p.add_argument("-q", "--query", help="Keyword to search for (newsdata.io 'q' param).")
    p.add_argument("-c", "--country", help="Comma-separated country codes, e.g. 'us,gb'.")
    p.add_argument("-l", "--language", default="en", help="Language code (default: en).")
    p.add_argument("--category", help="newsdata.io category, e.g. 'technology'.")
    p.add_argument("-n", "--limit", type=int, default=3, help="Number of articles to turn into threads.")
    p.add_argument("--max-tweets", type=int, default=3, help="Max tweets per thread.")
    p.add_argument("--post", action="store_true",
                   help="Actually post to Twitter/X (needs TWITTER_* creds). Default is dry-run.")
    p.add_argument("--no-openai", action="store_true",
                   help="Skip GPT-4 even if OPENAI_API_KEY is set.")
    return p.parse_args()


def main():
    args = parse_args()

    try:
        client = NewsDataClient()
    except NewsDataError as e:
        print(f"error: {e}", file=sys.stderr)
        return 1

    try:
        data = client.get_latest(
            query=args.query,
            country=args.country,
            language=args.language,
            category=args.category,
        )
    except NewsDataError as e:
        print(f"error: {e}", file=sys.stderr)
        return 1

    articles = data.get("results") or []
    if not articles:
        print("No articles found for those filters. Try a different query or remove filters.")
        return 0
    articles = articles[: max(1, args.limit)]

    poster = None
    if args.post:
        try:
            poster = TwitterClient()
        except TwitterError as e:
            print(f"warning: Twitter posting disabled ({e}). Falling back to dry-run.\n",
                  file=sys.stderr)
            poster = None

    use_openai = (not args.no_openai) and bool(os.environ.get("OPENAI_API_KEY"))
    if not use_openai and not args.no_openai:
        print("info: OPENAI_API_KEY not set -- using built-in summarizer.\n", file=sys.stderr)

    for i, article in enumerate(articles, 1):
        thread = generate_thread(article, max_tweets=args.max_tweets, use_openai=use_openai)
        title = (article.get("title") or "")[:80]
        print(f"\n=== Thread {i}/{len(articles)} : {title} ===")
        for tweet in thread:
            print("-" * 40)
            print(tweet)

        if poster:
            try:
                urls = poster.post_thread(thread)
                print(f"\nposted: {urls[0] if urls else 'ok'}")
            except TwitterError as e:
                print(f"post failed: {e}", file=sys.stderr)

    return 0


if __name__ == "__main__":
    sys.exit(main())
