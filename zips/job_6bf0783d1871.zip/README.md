# news-to-tweet

Auto-generate ready-to-post **Twitter/X threads** that summarize the top news of the day,
powered by the [newsdata.io](https://newsdata.io) news API.

Fetch the latest headlines from newsdata.io, turn each article into a tight, engaging
thread, and either print it for review (default) or post it straight to Twitter/X.

Thread copy is written by **OpenAI GPT-4** when an `OPENAI_API_KEY` is available, and
falls back to a fast built-in summarizer otherwise — so the tool works out of the box
on a **free newsdata.io key** with no other accounts required.

## Features

- Pull latest news from newsdata.io (`/news`) with query / country / language / category filters.
- Generate a concise, character-safe (<280) numbered thread per article.
- GPT-4 powered copy when `OPENAI_API_KEY` is set; graceful built-in fallback when it isn't.
- Optional posting to Twitter/X via `tweepy` (threaded replies). Defaults to a safe dry-run.
- Robust error handling for invalid keys (401), rate limits (429), paid-only params (403/422) and empty results.

## Requirements

- Python 3.9+
- A free newsdata.io API key — get one at <https://newsdata.io>
- (Optional) An OpenAI API key for GPT-4 copy
- (Optional) Twitter/X API credentials to actually post

## Setup

```bash
git clone https://github.com/your-username/news-to-tweet.git
cd news-to-tweet
python -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt
```

### Environment variables

The only **required** variable is your newsdata.io key:

```bash
export NEWSDATA_API_KEY="your_newsdata_key"
```

Optional — enable GPT-4 copy:

```bash
export OPENAI_API_KEY="your_openai_key"
# export OPENAI_MODEL="gpt-4o"   # default; any chat model works
```

Optional — enable real Twitter/X posting (used only with `--post`):

```bash
export TWITTER_API_KEY="..."
export TWITTER_API_SECRET="..."
export TWITTER_ACCESS_TOKEN="..."
export TWITTER_ACCESS_TOKEN_SECRET="..."
```

You can also place any of these in a `.env` file in the project root — it is loaded automatically.

## Usage

```bash
# Dry-run: print threads for the 3 latest top articles
python main.py

# Search a keyword, limit to 2 articles, 4 tweets each
python main.py --query "artificial intelligence" --limit 2 --max-tweets 4

# Filter by country + category
python main.py --country us --category technology

# Skip GPT-4 even if a key is set (use the built-in summarizer)
python main.py --no-openai

# Actually post to Twitter/X (requires the TWITTER_* credentials above)
python main.py --post
```

### CLI options

| Flag | Description |
| --- | --- |
| `-q, --query` | Keyword to search (newsdata.io `q`). |
| `-c, --country` | Comma-separated country codes, e.g. `us,gb`. |
| `-l, --language` | Language code (default `en`). |
| `--category` | newsdata.io category, e.g. `technology`. |
| `-n, --limit` | Number of articles to turn into threads (default 3). |
| `--max-tweets` | Max tweets per thread (default 3). |
| `--post` | Actually post to Twitter/X. Default is a dry-run. |
| `--no-openai` | Force the built-in summarizer. |

## Free plan vs. paid plan

This project is built to run entirely on the **newsdata.io free tier**. It only uses the
free `/news` endpoint and free parameters (`q`, `country`, `language`, `category`, `page`).

The following newsdata.io features are **paid-only** and are intentionally **not** used in
the core flow: sentiment analysis, the AI fields (`ai_tag`, `ai_region`, `ai_org`,
`ai_summary`), the historical `/archive` endpoint, and advanced full-text query operators.
If the API returns a `403`/`422` "upgrade your plan" style response, the client reports it
clearly instead of crashing.

GPT-4 (OpenAI) and Twitter/X posting are separate third-party services with their own
billing — both are **optional**; without them the tool still fetches news and produces
threads.

## How it works

```
newsdata.io /news  ->  newsdata_client.py  ->  summarizer.py (GPT-4 or fallback)  ->  twitter_client.py (optional)
```

- `newsdata_client.py` — thin, well-behaved wrapper around the newsdata.io REST API.
- `summarizer.py` — GPT-4 thread generation with a deterministic built-in fallback.
- `twitter_client.py` — optional `tweepy`-based threaded posting (dry-run by default).
- `main.py` — the CLI that wires it all together.

## License

MIT
