# 📰 Slack News Digest

A tiny, production-ready **Slack app** that posts a curated **daily news digest** to a channel in your workspace. Stories are pulled from the [newsdata.io](https://newsdata.io) news API and can be narrowed down with **category and keyword filters**.

It runs end-to-end on a brand-new **free** newsdata.io API key — no paid plan required. Optional paid-plan extras (sentiment, AI tags/summaries) can be switched on to enrich each digest, and they degrade gracefully if your key doesn't support them.

```
📰 News Digest — 2026-06-11
Filters — category: technology  ·  keywords: open source
────────────────────────────────────────
*Big release lands today*
A short description of the story…
📰 techsource  ·  🕒 2026-06-11 08:02:00  ·  mood: 🟢 positive
```

## Features

- Posts a clean [Block Kit](https://api.slack.com/block-kit) digest to any Slack channel.
- Filter the news feed by **category**, **keyword/query**, **country** and **language**.
- **Scheduled** delivery via cron (default: every day at 09:00) — or send one digest right now with `--once`.
- Resilient: handles invalid keys, rate limits, empty results and plan restrictions without crashing.

## Requirements

- **Node.js 18+** (uses the built-in `fetch`).
- A free **newsdata.io API key** — grab one at <https://newsdata.io/register>.
- A **Slack bot token** (`xoxb-…`) with the `chat:write` scope.

## Setup

### 1. Install

```bash
git clone https://github.com/your-account/slack-news-digest.git
cd slack-news-digest
npm install
```

### 2. Create a Slack app

1. Go to <https://api.slack.com/apps> → **Create New App** → *From scratch*.
2. Under **OAuth & Permissions**, add the **Bot Token Scope** `chat:write`.
3. Click **Install to Workspace** and copy the **Bot User OAuth Token** (`xoxb-…`).
4. Invite the bot to your target channel in Slack: `/invite @YourAppName`.

### 3. Configure environment variables

Copy the example file and fill it in:

```bash
cp .env.example .env
```

| Variable | Required | Default | Description |
| --- | --- | --- | --- |
| `NEWSDATA_API_KEY` | ✅ | — | Your newsdata.io API key. |
| `SLACK_BOT_TOKEN` | ✅ | — | Slack bot token (`xoxb-…`). |
| `SLACK_CHANNEL` | | `#news` | Channel ID or name to post to. |
| `NEWS_QUERY` | | _(empty)_ | Keyword(s) to filter on (`q` param). |
| `NEWS_CATEGORY` | | _(empty)_ | e.g. `technology`, `business`, `sports`. |
| `NEWS_COUNTRY` | | _(empty)_ | 2-letter country code, e.g. `us`. |
| `NEWS_LANGUAGE` | | `en` | Language code. |
| `MAX_ITEMS` | | `8` | Max stories per digest. |
| `DIGEST_CRON` | | `0 9 * * *` | Cron schedule for the digest. |
| `DIGEST_TIMEZONE` | | `UTC` | Timezone for the schedule. |

> The `.env` file is git-ignored. The API key is **never** hardcoded — it is read from `NEWSDATA_API_KEY`, and the app exits with a clear message if it (or the Slack token) is missing.

### 4. Run it

Send a single digest immediately (great for testing):

```bash
npm run digest        # node src/index.js --once
```

Run the scheduler (keeps the process alive and posts on the cron schedule):

```bash
npm start             # node src/index.js
```

## ✨ Optional paid-plan features (showcase)

newsdata.io's **paid plans** unlock richer data. These are **off by default** so a free key always works. Turn them on to enrich each digest — if your key doesn't include them, the app logs a friendly notice and falls back to the standard free digest, with any missing fields shown as `n/a`.

| Feature | Toggle | What it adds |
| --- | --- | --- |
| **Sentiment analysis** | `ENABLE_SENTIMENT=1` | Shows a mood indicator (🟢 positive / ⚪ neutral / 🔴 negative) per story from the `sentiment` field. |
| **AI tags & summaries** | `ENABLE_AI_SUMMARY=1` | Uses `ai_tag` for topic chips and `ai_summary` when a description is missing. |
| **Enable everything** | `NEWSDATA_PLAN=paid` | Convenience switch that turns on all of the above. |

Example:

```bash
ENABLE_SENTIMENT=1 ENABLE_AI_SUMMARY=1 npm run digest
```

> ℹ️ These fields are only populated on paid newsdata.io plans. On the free tier the toggles are harmless — the digest is still delivered, just without the extra annotations. Learn more at <https://newsdata.io/pricing>.

## Deploying the scheduler

The app uses [`node-cron`](https://www.npmjs.com/package/node-cron) internally, so you can keep `npm start` running under a process manager (pm2, systemd, Docker, etc.). Prefer your platform's own scheduler instead? Set up a cron job that runs `npm run digest` and ignore `DIGEST_CRON`.

## Project layout

```
src/
  index.js      # entry point: scheduling + posting to Slack
  config.js     # env loading, validation, feature toggles
  newsdata.js   # newsdata.io API client + error handling
  digest.js     # Block Kit message builder
```

## License

MIT — built as a showcase for the [newsdata.io](https://newsdata.io) news API.
