import { config } from './config.js';

const BASE_URL = 'https://newsdata.io/api/1';

/**
 * Raised when newsdata.io rejects a request because the feature/params
 * require a paid plan (HTTP 403 / 422). The caller can catch this and
 * gracefully retry on the free-tier feature set.
 */
export class PaidPlanRequired extends Error {
  constructor(message) {
    super(message);
    this.name = 'PaidPlanRequired';
  }
}

function buildParams(extra = {}) {
  const params = new URLSearchParams();
  // The key is read from the environment — never hardcoded.
  params.set('apikey', config.newsdataApiKey);

  if (config.query) params.set('q', config.query);
  if (config.category) params.set('category', config.category);
  if (config.country) params.set('country', config.country);
  if (config.language) params.set('language', config.language);

  for (const [key, value] of Object.entries(extra)) {
    if (value !== undefined && value !== null && value !== '') {
      params.set(key, String(value));
    }
  }
  return params;
}

/**
 * Fetch the latest news from newsdata.io.
 *
 * @param {{ withPaidFields?: boolean }} options
 *   When withPaidFields is true we additionally request paid-only query
 *   operators. On a free key newsdata.io answers with 403/422, which we
 *   surface as PaidPlanRequired so the caller can retry without them.
 * @returns {Promise<Array<object>>} up to config.maxItems article objects
 */
export async function fetchNews({ withPaidFields = false } = {}) {
  const extra = {};

  // Advanced query operators (qInTitle) are a paid feature. We only request
  // them when paid features are explicitly enabled AND a keyword is set.
  if (withPaidFields && config.query) {
    extra.qInTitle = config.query;
  }

  const url = `${BASE_URL}/news?${buildParams(extra).toString()}`;

  let res;
  try {
    res = await fetch(url);
  } catch (err) {
    throw new Error(`Network error contacting newsdata.io: ${err.message}`);
  }

  if (res.status === 401) {
    throw new Error('newsdata.io rejected the API key (401). Check NEWSDATA_API_KEY.');
  }
  if (res.status === 429) {
    throw new Error('newsdata.io rate limit reached (429). Wait a bit or upgrade your plan.');
  }
  if (res.status === 403 || res.status === 422) {
    throw new PaidPlanRequired(`newsdata.io returned a plan-restriction response (${res.status}).`);
  }
  if (!res.ok) {
    throw new Error(`newsdata.io request failed with HTTP ${res.status}.`);
  }

  const data = await res.json().catch(() => ({}));

  if (data && data.status === 'error') {
    const message = (data.results && data.results.message) || 'unknown error';
    throw new Error(`newsdata.io error: ${message}`);
  }

  const results = Array.isArray(data.results) ? data.results : [];
  return results.slice(0, config.maxItems);
}
