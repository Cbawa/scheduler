import cron from 'node-cron';
import { WebClient } from '@slack/web-api';
import { config, validateConfig } from './config.js';
import { fetchNews, PaidPlanRequired } from './newsdata.js';
import { buildDigestBlocks } from './digest.js';

const slack = new WebClient(config.slackToken);

async function getArticles() {
  const wantsPaid = config.enableSentiment || config.enableAiSummary;
  try {
    return await fetchNews({ withPaidFields: wantsPaid });
  } catch (err) {
    if (err instanceof PaidPlanRequired) {
      console.warn('\u26a0\ufe0f  A requested feature needs a paid newsdata.io plan \u2014 falling back to the free-tier digest.');
      return await fetchNews({ withPaidFields: false });
    }
    throw err;
  }
}

export async function sendDigest() {
  console.log('Fetching news from newsdata.io\u2026');

  let articles;
  try {
    articles = await getArticles();
  } catch (err) {
    console.error(`\u274c Could not fetch news: ${err.message}`);
    return;
  }

  if (!articles.length) {
    console.log('No articles matched the current filters \u2014 nothing to post.');
    try {
      await slack.chat.postMessage({
        channel: config.slackChannel,
        text: 'No news matched today\u2019s filters. Try broadening NEWS_QUERY or NEWS_CATEGORY.',
      });
    } catch (err) {
      console.error(`\u274c Slack post failed: ${err.message}`);
    }
    return;
  }

  const blocks = buildDigestBlocks(articles);
  try {
    const res = await slack.chat.postMessage({
      channel: config.slackChannel,
      text: `\ud83d\udcf0 Your news digest \u2014 ${articles.length} stories`,
      blocks,
      unfurl_links: false,
    });
    console.log(`\u2705 Posted digest with ${articles.length} stories to ${res.channel}.`);
  } catch (err) {
    console.error(`\u274c Slack post failed: ${err.message}`);
    if (err.data && err.data.error === 'not_in_channel') {
      console.error('   Invite the bot to the channel: /invite @YourAppName');
    }
  }
}

function main() {
  validateConfig();

  if (process.argv.includes('--once')) {
    sendDigest()
      .then(() => process.exit(0))
      .catch((err) => {
        console.error(err);
        process.exit(1);
      });
    return;
  }

  if (!cron.validate(config.cron)) {
    console.error(`\u274c Invalid DIGEST_CRON expression: "${config.cron}"`);
    process.exit(1);
  }

  console.log(`\ud83d\udd54 Scheduling daily digest (cron "${config.cron}", tz ${config.timezone}).`);
  console.log('   Tip: run with --once to send a digest immediately and exit.');
  cron.schedule(config.cron, sendDigest, { timezone: config.timezone });
}

main();
