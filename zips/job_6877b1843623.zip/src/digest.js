import { config } from './config.js';

function sentimentLabel(sentiment) {
  switch (String(sentiment || '').toLowerCase()) {
    case 'positive':
      return '\ud83d\udfe2 positive';
    case 'negative':
      return '\ud83d\udd34 negative';
    case 'neutral':
      return '\u26aa neutral';
    default:
      return 'n/a';
  }
}

function truncate(text, max) {
  if (!text) return '';
  const clean = String(text).replace(/\s+/g, ' ').trim();
  return clean.length > max ? `${clean.slice(0, max - 1)}\u2026` : clean;
}

/**
 * Build a Slack Block Kit payload for a list of newsdata.io articles.
 * Paid-only fields (sentiment, ai_tag, ai_summary) are read defensively
 * and only shown when their toggle is enabled — otherwise they render as n/a.
 */
export function buildDigestBlocks(articles) {
  const today = new Date().toISOString().slice(0, 10);

  const blocks = [
    {
      type: 'header',
      text: { type: 'plain_text', text: `\ud83d\udcf0 News Digest \u2014 ${today}`, emoji: true },
    },
  ];

  const filters = [];
  if (config.category) filters.push(`category: *${config.category}*`);
  if (config.query) filters.push(`keywords: *${config.query}*`);
  if (config.country) filters.push(`country: *${config.country}*`);
  if (filters.length) {
    blocks.push({
      type: 'context',
      elements: [{ type: 'mrkdwn', text: `Filters \u2014 ${filters.join('  \u00b7  ')}` }],
    });
  }
  blocks.push({ type: 'divider' });

  for (const article of articles) {
    const title = truncate(article.title || 'Untitled', 200);
    const link = article.link || '';
    const description = truncate(article.description || article.ai_summary || '_No summary available._', 280);
    const headline = link ? `*<${link}|${title}>*` : `*${title}*`;

    blocks.push({
      type: 'section',
      text: { type: 'mrkdwn', text: `${headline}\n${description}` },
    });

    const meta = [`\ud83d\udcf0 ${article.source_id || 'unknown'}`];
    if (article.pubDate) meta.push(`\ud83d\udd52 ${article.pubDate}`);

    // Paid feature: sentiment (guarded — absent on free keys -> n/a).
    if (config.enableSentiment) {
      meta.push(`mood: ${sentimentLabel(article.sentiment)}`);
    }

    // Paid feature: AI topic tags (guarded — only shown if present).
    if (config.enableAiSummary && article.ai_tag) {
      const tags = Array.isArray(article.ai_tag) ? article.ai_tag.join(', ') : article.ai_tag;
      meta.push(`\ud83c\udff7\ufe0f ${truncate(tags, 80)}`);
    }

    blocks.push({
      type: 'context',
      elements: [{ type: 'mrkdwn', text: meta.join('  \u00b7  ') }],
    });
    blocks.push({ type: 'divider' });
  }

  blocks.push({
    type: 'context',
    elements: [{ type: 'mrkdwn', text: 'Powered by <https://newsdata.io|newsdata.io>' }],
  });

  return blocks;
}
