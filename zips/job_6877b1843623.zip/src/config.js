import 'dotenv/config';

/**
 * Interpret common truthy strings as a boolean toggle.
 */
function bool(value) {
  return ['1', 'true', 'yes', 'on'].includes(String(value || '').toLowerCase());
}

const plan = (process.env.NEWSDATA_PLAN || 'free').toLowerCase();
const isPaid = plan === 'paid';

export const config = {
  // Core (free tier)
  newsdataApiKey: process.env.NEWSDATA_API_KEY,
  slackToken: process.env.SLACK_BOT_TOKEN,
  slackChannel: process.env.SLACK_CHANNEL || '#news',

  // Filters
  query: process.env.NEWS_QUERY || '',
  category: process.env.NEWS_CATEGORY || '',
  country: process.env.NEWS_COUNTRY || '',
  language: process.env.NEWS_LANGUAGE || 'en',
  maxItems: Math.max(1, parseInt(process.env.MAX_ITEMS || '8', 10) || 8),

  // Scheduling
  cron: process.env.DIGEST_CRON || '0 9 * * *',
  timezone: process.env.DIGEST_TIMEZONE || 'UTC',

  // Optional paid-plan features (OFF by default; enabling NEWSDATA_PLAN=paid
  // turns them all on). These only enrich the digest and never break free keys.
  plan,
  isPaid,
  enableSentiment: isPaid || bool(process.env.ENABLE_SENTIMENT),
  enableAiSummary: isPaid || bool(process.env.ENABLE_AI_SUMMARY),
};

/**
 * Fail fast (with a friendly message) if required secrets are missing.
 */
export function validateConfig() {
  const missing = [];
  if (!config.newsdataApiKey) missing.push('NEWSDATA_API_KEY');
  if (!config.slackToken) missing.push('SLACK_BOT_TOKEN');

  if (missing.length) {
    console.error(`\u274c Missing required environment variable(s): ${missing.join(', ')}`);
    console.error('   Copy .env.example to .env and fill it in — see README.md for details.');
    process.exit(1);
  }
}
