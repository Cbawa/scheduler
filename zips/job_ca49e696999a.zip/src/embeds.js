import { EmbedBuilder } from 'discord.js';

function safe(value, fallback = 'n/a') {
  if (value === undefined || value === null || value === '') return fallback;
  return String(value);
}

// Convert newsdata.io articles into Discord embeds. Paid-only fields
// (sentiment, ai_summary) are guarded so free-tier responses never crash.
export function buildNewsEmbeds(articles) {
  return articles.map((a) => {
    const embed = new EmbedBuilder()
      .setColor(0x1d9bf0)
      .setTitle(safe(a.title, 'Untitled').slice(0, 256));

    if (a.link) embed.setURL(a.link);
    if (a.description) embed.setDescription(String(a.description).slice(0, 400));
    if (a.image_url) embed.setThumbnail(a.image_url);

    const footerBits = [safe(a.source_id, 'unknown source'), safe(a.pubDate, '')].filter(Boolean);
    embed.setFooter({ text: footerBits.join(' \u2022 ').slice(0, 2048) });

    // --- Paid-plan fields: only shown when present in the response ---
    if (a.sentiment) {
      embed.addFields({ name: 'Sentiment (paid)', value: safe(a.sentiment), inline: true });
    }
    if (a.ai_summary) {
      embed.addFields({ name: 'AI Summary (paid)', value: String(a.ai_summary).slice(0, 300) });
    }

    return embed;
  });
}

export function buildErrorEmbed(message) {
  return new EmbedBuilder()
    .setColor(0xed4245)
    .setTitle('News fetch failed')
    .setDescription(safe(message, 'Unknown error.'));
}
