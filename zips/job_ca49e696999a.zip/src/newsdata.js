// Thin client for the newsdata.io REST API (https://newsdata.io/api/1).
// The core flow targets the FREE tier; paid features are optional add-ons
// that degrade gracefully when the plan does not support them.

const BASE_URL = 'https://newsdata.io/api/1';

export class NewsDataError extends Error {
  constructor(message, status = 0) {
    super(message);
    this.name = 'NewsDataError';
    this.status = status;
  }
}

export class PaidPlanError extends Error {
  constructor(message) {
    super(message);
    this.name = 'PaidPlanError';
  }
}

function isPaidPlan() {
  return (process.env.NEWSDATA_PLAN || 'free').toLowerCase() === 'paid';
}

// Build the /news query string. Paid params are only added when includePaid
// is true, so a free-tier request never accidentally trips a 403/422.
function buildParams(apiKey, options, includePaid) {
  const params = new URLSearchParams();
  params.set('apikey', apiKey);
  if (options.q) params.set('q', options.q);
  if (options.country) params.set('country', options.country);
  params.set('language', options.language || 'en');
  if (options.category) params.set('category', options.category);
  if (options.page) params.set('page', options.page);

  if (includePaid) {
    // --- Paid-only showcase params (OFF by default) ---
    if (process.env.ENABLE_SENTIMENT === '1') {
      params.set('sentiment', options.sentiment || 'positive');
    }
    if (options.fromDate) params.set('from_date', options.fromDate);
    if (options.toDate) params.set('to_date', options.toDate);
  }
  return params;
}

async function requestNews(apiKey, options, includePaid) {
  const params = buildParams(apiKey, options, includePaid);
  const url = `${BASE_URL}/news?${params.toString()}`;
  let res;
  try {
    res = await fetch(url, { headers: { 'User-Agent': 'discord-news-bot' } });
  } catch (err) {
    throw new NewsDataError(`Network error contacting newsdata.io: ${err.message}`, 0);
  }
  let body = {};
  try {
    body = await res.json();
  } catch {
    body = {};
  }
  return { status: res.status, body };
}

/**
 * Fetch the latest news. Always returns the parsed response body on success.
 * Throws NewsDataError for 401/429/other failures and PaidPlanError when a
 * paid-only request cannot be satisfied even after falling back.
 */
export async function fetchLatestNews(options = {}) {
  const apiKey = process.env.NEWSDATA_API_KEY;
  if (!apiKey) {
    throw new NewsDataError('NEWSDATA_API_KEY environment variable is not set.', 0);
  }

  const paid = isPaidPlan();
  const wantsPaid = paid && (process.env.ENABLE_SENTIMENT === '1' || options.fromDate || options.toDate);

  let { status, body } = await requestNews(apiKey, options, wantsPaid);

  // A paid feature was rejected — log, then retry the plain free-tier request.
  if ((status === 403 || status === 422) && wantsPaid) {
    console.warn('newsdata.io rejected a paid-only feature; falling back to the free-tier request.');
    ({ status, body } = await requestNews(apiKey, options, false));
  }

  if (status === 401) {
    throw new NewsDataError('Invalid API key (401). Check your NEWSDATA_API_KEY.', 401);
  }
  if (status === 429) {
    throw new NewsDataError('Rate limit reached (429). Please try again in a little while.', 429);
  }
  if (status === 403 || status === 422) {
    throw new PaidPlanError('This request requires a paid newsdata.io plan.');
  }
  if (status < 200 || status >= 300 || (body && body.status === 'error')) {
    const detail = (body && body.results && body.results.message) || (body && body.message) || `HTTP ${status}`;
    throw new NewsDataError(`newsdata.io request failed: ${detail}`, status);
  }

  return body;
}
