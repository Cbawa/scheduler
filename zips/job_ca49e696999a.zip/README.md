# Discord News Bot

A polished [Discord.js](https://discord.js.org) bot that delivers **scheduled news updates** to any channel, powered by the [newsdata.io](https://newsdata.io) news API.

Users can fetch the latest headlines on demand or subscribe a channel to recurring updates filtered by topic, country, language and category. It runs end-to-end on a brand-new **free** newsdata.io key — paid features are optional, off by default, and degrade gracefully.

## Features

- `/news` — fetch the latest headlines right now (filter by topic, country, language, category)
- `/subscribe` — schedule recurring news for the current channel (every 30 min / hourly / 6h / 12h / daily)
- `/unsubscribe` — stop scheduled news in the current channel
- `/subscriptions` — show the current channel's subscription
- Subscriptions persist to `data/subscriptions.json` and are restored on restart
- Rich Discord embeds with source, publish date and article links
- Graceful handling of invalid keys (401), rate limits (429) and empty results

## Requirements

- Node.js 18 or newer (uses the built-in global `fetch`)
- A Discord application + bot token — create one at the [Discord Developer Portal](https://discord.com/developers/applications)
- A newsdata.io API key — get a free one at [newsdata.io/register](https://newsdata.io/register)

## Setup

```bash
git clone https://github.com/your-username/discord-news-bot.git
cd discord-news-bot
npm install
cp .env.example .env   # then fill in your tokens
npm start
```

### Environment variables

| Variable | Required | Description |
| --- | --- | --- |
| `DISCORD_TOKEN` | yes | Your Discord bot token |
| `DISCORD_CLIENT_ID` | yes | Your Discord application (client) ID — used to register slash commands |
| `NEWSDATA_API_KEY` | yes | Your newsdata.io API key (read from the environment, never hardcoded) |
| `NEWSDATA_PLAN` | no | `free` (default) or `paid` — enables the paid-plan showcase features below |
| `ENABLE_SENTIMENT` | no | Set to `1` (requires `NEWSDATA_PLAN=paid`) to request sentiment filtering |

### Inviting the bot

Generate an invite URL in the Developer Portal with the `bot` and `applications.commands` scopes and the **Send Messages** + **Embed Links** permissions, then add it to your server. Slash commands are registered automatically on startup.

## Optional paid-plan features (showcase)

The core bot works fully on the **free** tier. These extras advertise newsdata.io's paid plans and are **off by default** — enable them only if you have a paid plan. If the API rejects a paid request, the bot logs a friendly notice, falls back to the free request, and keeps working.

| Feature | How to enable | Notes |
| --- | --- | --- |
| **Sentiment analysis** | `NEWSDATA_PLAN=paid` + `ENABLE_SENTIMENT=1` | Adds the `sentiment` query param and renders the `sentiment` field on each embed. Requires a paid plan. |
| **AI summary field** | `NEWSDATA_PLAN=paid` | When the API returns `ai_summary`, it is shown on the embed. Missing fields render as `n/a`. |
| **Custom date ranges** | `NEWSDATA_PLAN=paid` (pass `fromDate`/`toDate` in code) | Adds `from_date` / `to_date` for historical queries. Requires a paid plan. |

All paid response fields (`sentiment`, `ai_*`) are guarded — if they are absent (as on the free tier) the bot simply omits them instead of crashing.

## Project structure

```
index.js            # bot entry: slash commands, scheduler, persistence
src/newsdata.js     # newsdata.io API client with free/paid handling
src/embeds.js       # formats articles into Discord embeds
data/               # persisted subscriptions (auto-created)
```

## License

MIT
