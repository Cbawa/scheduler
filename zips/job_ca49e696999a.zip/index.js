import 'dotenv/config';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import cron from 'node-cron';
import {
  Client,
  GatewayIntentBits,
  REST,
  Routes,
  SlashCommandBuilder,
} from 'discord.js';
import { fetchLatestNews, NewsDataError, PaidPlanError } from './src/newsdata.js';
import { buildNewsEmbeds, buildErrorEmbed } from './src/embeds.js';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const SUBS_FILE = path.join(__dirname, 'data', 'subscriptions.json');

const DISCORD_TOKEN = process.env.DISCORD_TOKEN;
const CLIENT_ID = process.env.DISCORD_CLIENT_ID;

// --- Fail fast with clear messages if required config is missing ---
if (!DISCORD_TOKEN || !CLIENT_ID) {
  console.error('Missing DISCORD_TOKEN and/or DISCORD_CLIENT_ID. Copy .env.example to .env and fill them in.');
  process.exit(1);
}
if (!process.env.NEWSDATA_API_KEY) {
  console.error('Missing NEWSDATA_API_KEY. Get a free key at https://newsdata.io/register and set it in your environment.');
  process.exit(1);
}

// Map a friendly frequency to a cron expression.
const FREQUENCIES = {
  '30m': '*/30 * * * *',
  hourly: '0 * * * *',
  '6h': '0 */6 * * *',
  '12h': '0 */12 * * *',
  daily: '0 9 * * *',
};

// --- subscription persistence -------------------------------------------
function loadSubs() {
  try {
    return JSON.parse(fs.readFileSync(SUBS_FILE, 'utf8'));
  } catch {
    return {};
  }
}

function saveSubs(subs) {
  fs.mkdirSync(path.dirname(SUBS_FILE), { recursive: true });
  fs.writeFileSync(SUBS_FILE, JSON.stringify(subs, null, 2));
}

const tasks = new Map(); // channelId -> scheduled cron task

const client = new Client({ intents: [GatewayIntentBits.Guilds] });

// Fetch news and post it to a channel, handling every failure gracefully.
async function postNews(channelId, opts) {
  const channel = await client.channels.fetch(channelId).catch(() => null);
  if (!channel || !channel.isTextBased()) return;
  try {
    const data = await fetchLatestNews(opts || {});
    const results = Array.isArray(data.results) ? data.results : [];
    if (results.length === 0) {
      await channel.send('No news found for this query right now. Try a different topic or country.');
      return;
    }
    await channel.send({ embeds: buildNewsEmbeds(results.slice(0, 5)) });
  } catch (err) {
    if (err instanceof PaidPlanError) {
      await channel.send('Some requested options need a paid newsdata.io plan, so they were skipped.');
      return;
    }
    const msg = err instanceof NewsDataError ? err.message : 'Unexpected error fetching news.';
    console.error('postNews error:', msg);
    await channel.send({ embeds: [buildErrorEmbed(msg)] });
  }
}

function scheduleSub(channelId, sub) {
  if (tasks.has(channelId)) {
    tasks.get(channelId).stop();
    tasks.delete(channelId);
  }
  const expr = FREQUENCIES[sub.frequency] || FREQUENCIES.daily;
  const task = cron.schedule(expr, () => postNews(channelId, sub.query));
  tasks.set(channelId, task);
}

function readQueryOptions(interaction) {
  return {
    q: interaction.options.getString('topic') || undefined,
    country: interaction.options.getString('country') || undefined,
    language: interaction.options.getString('language') || undefined,
    category: interaction.options.getString('category') || undefined,
  };
}

// --- slash command definitions ------------------------------------------
const commands = [
  new SlashCommandBuilder()
    .setName('news')
    .setDescription('Fetch the latest news right now')
    .addStringOption((o) => o.setName('topic').setDescription('Keyword to search for (q)'))
    .addStringOption((o) => o.setName('country').setDescription('2-letter country code, e.g. us'))
    .addStringOption((o) => o.setName('language').setDescription('Language code, e.g. en'))
    .addStringOption((o) => o.setName('category').setDescription('e.g. technology, business, sports')),
  new SlashCommandBuilder()
    .setName('subscribe')
    .setDescription('Schedule recurring news updates for this channel')
    .addStringOption((o) =>
      o
        .setName('frequency')
        .setDescription('How often to post')
        .setRequired(true)
        .addChoices(
          { name: 'Every 30 minutes', value: '30m' },
          { name: 'Hourly', value: 'hourly' },
          { name: 'Every 6 hours', value: '6h' },
          { name: 'Every 12 hours', value: '12h' },
          { name: 'Daily (09:00 server time)', value: 'daily' },
        ),
    )
    .addStringOption((o) => o.setName('topic').setDescription('Keyword to search for (q)'))
    .addStringOption((o) => o.setName('country').setDescription('2-letter country code, e.g. us'))
    .addStringOption((o) => o.setName('language').setDescription('Language code, e.g. en'))
    .addStringOption((o) => o.setName('category').setDescription('e.g. technology, business, sports')),
  new SlashCommandBuilder().setName('unsubscribe').setDescription('Stop scheduled news in this channel'),
  new SlashCommandBuilder().setName('subscriptions').setDescription('Show the current channel subscription'),
].map((c) => c.toJSON());

client.on('interactionCreate', async (interaction) => {
  if (!interaction.isChatInputCommand()) return;
  const { commandName } = interaction;
  const channelId = interaction.channelId;

  try {
    if (commandName === 'news') {
      await interaction.deferReply();
      const opts = readQueryOptions(interaction);
      try {
        const data = await fetchLatestNews(opts);
        const results = Array.isArray(data.results) ? data.results : [];
        if (results.length === 0) {
          await interaction.editReply('No news found for this query right now.');
          return;
        }
        await interaction.editReply({ embeds: buildNewsEmbeds(results.slice(0, 5)) });
      } catch (err) {
        const msg =
          err instanceof PaidPlanError
            ? 'That request needs a paid newsdata.io plan. Try again without paid-only options.'
            : err instanceof NewsDataError
              ? err.message
              : 'Unexpected error fetching news.';
        await interaction.editReply({ embeds: [buildErrorEmbed(msg)] });
      }
      return;
    }

    if (commandName === 'subscribe') {
      const frequency = interaction.options.getString('frequency');
      const query = readQueryOptions(interaction);
      const subs = loadSubs();
      subs[channelId] = { frequency, query, guildId: interaction.guildId };
      saveSubs(subs);
      scheduleSub(channelId, subs[channelId]);
      await interaction.reply(`Subscribed this channel to **${frequency}** news updates. Posting the first batch now...`);
      await postNews(channelId, query);
      return;
    }

    if (commandName === 'unsubscribe') {
      const subs = loadSubs();
      if (subs[channelId]) {
        delete subs[channelId];
        saveSubs(subs);
      }
      if (tasks.has(channelId)) {
        tasks.get(channelId).stop();
        tasks.delete(channelId);
      }
      await interaction.reply('Unsubscribed this channel from scheduled news.');
      return;
    }

    if (commandName === 'subscriptions') {
      const sub = loadSubs()[channelId];
      if (!sub) {
        await interaction.reply('This channel has no active subscription. Use /subscribe to create one.');
        return;
      }
      const q = sub.query || {};
      await interaction.reply(
        [
          `**Frequency:** ${sub.frequency}`,
          `**Topic:** ${q.q || 'any'}`,
          `**Country:** ${q.country || 'any'}`,
          `**Language:** ${q.language || 'any'}`,
          `**Category:** ${q.category || 'any'}`,
        ].join('\n'),
      );
      return;
    }
  } catch (err) {
    console.error('Interaction handler error:', err);
    if (interaction.deferred || interaction.replied) {
      await interaction.editReply('Something went wrong handling that command.').catch(() => {});
    } else {
      await interaction.reply('Something went wrong handling that command.').catch(() => {});
    }
  }
});

client.once('ready', async () => {
  console.log(`Logged in as ${client.user.tag}`);
  try {
    const rest = new REST({ version: '10' }).setToken(DISCORD_TOKEN);
    await rest.put(Routes.applicationCommands(CLIENT_ID), { body: commands });
    console.log('Slash commands registered.');
  } catch (err) {
    console.error('Failed to register slash commands:', err.message);
  }

  const subs = loadSubs();
  for (const [channelId, sub] of Object.entries(subs)) {
    scheduleSub(channelId, sub);
  }
  console.log(`Restored ${Object.keys(subs).length} subscription(s).`);
});

client.login(DISCORD_TOKEN);
