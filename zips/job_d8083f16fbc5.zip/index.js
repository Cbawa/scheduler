const fs = require('fs');
const path = require('path');
const {
  default: makeWASocket,
  useMultiFileAuthState,
  DisconnectReason,
  fetchLatestBaileysVersion,
} = require('@whiskeysockets/baileys');
const qrcode = require('qrcode-terminal');
const cron = require('node-cron');
const pino = require('pino');

const config = require('./src/config');
const { getDigest } = require('./src/newsdata');
const { buildDigest } = require('./src/digest');

const logger = pino({ level: process.env.LOG_LEVEL || 'silent' });

class Store {
  constructor(file) {
    this.file = file;
    this.data = { groups: {} };
    try {
      this.data = JSON.parse(fs.readFileSync(file, 'utf8'));
    } catch (err) {
      this.data = { groups: {} };
    }
    if (!this.data.groups) this.data.groups = {};
  }

  save() {
    fs.mkdirSync(path.dirname(this.file), { recursive: true });
    fs.writeFileSync(this.file, JSON.stringify(this.data, null, 2));
  }

  subscribe(jid) {
    this.data.groups[jid] = { subscribedAt: new Date().toISOString() };
    this.save();
  }

  unsubscribe(jid) {
    delete this.data.groups[jid];
    this.save();
  }

  list() {
    return Object.keys(this.data.groups);
  }
}

const store = new Store(config.dataFile);

const sleep = (ms) => new Promise((resolve) => setTimeout(resolve, ms));

function extractText(msg) {
  const m = msg.message || {};
  return (
    m.conversation ||
    (m.extendedTextMessage && m.extendedTextMessage.text) ||
    (m.imageMessage && m.imageMessage.caption) ||
    (m.videoMessage && m.videoMessage.caption) ||
    ''
  );
}

function helpText() {
  const p = config.prefix;
  return [
    'News digest bot — commands:',
    `${p}subscribe — post the hourly digest to this group`,
    `${p}unsubscribe — stop the automatic digest`,
    `${p}news — post the latest digest now`,
    `${p}help — show this message`,
  ].join('\n');
}

async function reply(sock, jid, text) {
  await sock.sendMessage(jid, { text });
}

async function sendDigest(sock, jid) {
  try {
    const articles = await getDigest(config.digestSize);
    await reply(sock, jid, buildDigest(articles));
  } catch (err) {
    await reply(sock, jid, `⚠️ ${err.message}`);
  }
}

async function postToSubscribers(sock) {
  const groups = store.list();
  if (!groups.length) return;
  let text;
  try {
    const articles = await getDigest(config.digestSize);
    text = buildDigest(articles);
  } catch (err) {
    console.error('Skipping scheduled digest:', err.message);
    return;
  }
  for (const jid of groups) {
    try {
      await sock.sendMessage(jid, { text });
    } catch (err) {
      console.error('Failed to send to', jid, err.message);
    }
    await sleep(1500);
  }
}

async function handleMessage(sock, msg) {
  if (!msg.message || msg.key.fromMe) return;
  const jid = msg.key.remoteJid;
  if (!jid || !jid.endsWith('@g.us')) return; // group chats only

  const text = extractText(msg).trim();
  if (!text.startsWith(config.prefix)) return;

  const parts = text.slice(config.prefix.length).trim().split(/\s+/);
  const cmd = (parts.shift() || '').toLowerCase();

  switch (cmd) {
    case 'news':
      await sendDigest(sock, jid);
      break;
    case 'subscribe':
      store.subscribe(jid);
      await reply(sock, jid, 'Subscribed. This group will receive the hourly news digest.');
      break;
    case 'unsubscribe':
      store.unsubscribe(jid);
      await reply(sock, jid, 'Unsubscribed. No more automatic digests for this group.');
      break;
    case 'help':
      await reply(sock, jid, helpText());
      break;
    default:
      break;
  }
}

async function start() {
  if (!config.apiKey) {
    console.error(
      'NEWSDATA_API_KEY is not set. Get a free key at https://newsdata.io and add it to your .env file.'
    );
    process.exit(1);
  }

  const { state, saveCreds } = await useMultiFileAuthState(config.authDir);
  const { version } = await fetchLatestBaileysVersion();

  const sock = makeWASocket({
    version,
    auth: state,
    logger,
    printQRInTerminal: false,
    browser: ['News Digest Bot', 'Chrome', '1.0.0'],
  });

  sock.ev.on('creds.update', saveCreds);

  sock.ev.on('connection.update', (update) => {
    const { connection, lastDisconnect, qr } = update;
    if (qr) {
      console.log('Scan this QR code with WhatsApp (Linked devices):');
      qrcode.generate(qr, { small: true });
    }
    if (connection === 'open') {
      console.log('Connected to WhatsApp.');
    }
    if (connection === 'close') {
      const statusCode =
        lastDisconnect && lastDisconnect.error && lastDisconnect.error.output
          ? lastDisconnect.error.output.statusCode
          : undefined;
      const loggedOut = statusCode === DisconnectReason.loggedOut;
      if (loggedOut) {
        console.log('Logged out. Delete the auth folder and restart to re-link.');
      } else {
        console.log('Connection closed, reconnecting...');
        start();
      }
    }
  });

  sock.ev.on('messages.upsert', async ({ messages, type }) => {
    if (type !== 'notify') return;
    for (const msg of messages) {
      try {
        await handleMessage(sock, msg);
      } catch (err) {
        console.error('Error handling message:', err.message);
      }
    }
  });

  let schedule = config.postInterval;
  if (!cron.validate(schedule)) {
    console.error(`Invalid POST_INTERVAL "${schedule}"; falling back to hourly.`);
    schedule = '0 * * * *';
  }
  cron.schedule(schedule, () => {
    postToSubscribers(sock).catch((err) => console.error('Digest job error:', err.message));
  });
  console.log(`Automatic digest scheduled with cron "${schedule}".`);
}

start().catch((err) => {
  console.error('Fatal error:', err);
  process.exit(1);
});
