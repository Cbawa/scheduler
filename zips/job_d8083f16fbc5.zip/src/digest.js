function truncate(text, max) {
  const clean = String(text).replace(/\s+/g, ' ').trim();
  if (clean.length <= max) return clean;
  return `${clean.slice(0, max - 1).trimEnd()}…`;
}

// sentiment is a paid response field; it is absent on the free plan.
function sentimentBadge(sentiment) {
  const map = { positive: '🟢', neutral: '⚪', negative: '🔴' };
  return map[sentiment] || '';
}

// keywords are free; ai_tag is a paid field. Both are rendered as chips.
function toChips(article) {
  const aiTags = Array.isArray(article.ai_tag)
    ? article.ai_tag
    : article.ai_tag
    ? [article.ai_tag]
    : [];
  const keywords = Array.isArray(article.keywords) ? article.keywords : [];
  const seen = new Set();
  const chips = [];
  for (const raw of [...aiTags, ...keywords]) {
    const tag = String(raw).trim().replace(/\s+/g, '');
    if (!tag || seen.has(tag.toLowerCase())) continue;
    seen.add(tag.toLowerCase());
    chips.push(`#${tag}`);
    if (chips.length >= 5) break;
  }
  return chips;
}

function formatArticle(article, index) {
  const title = article.title || 'Untitled';
  const source = article.source_id || article.source_name || 'unknown source';
  const lines = [];

  const badge = sentimentBadge(article.sentiment);
  lines.push(`*${index}. ${title}*${badge ? ` ${badge}` : ''}`);

  // ai_summary is a paid field; fall back to the free description.
  const summary = article.ai_summary || article.description;
  if (summary) lines.push(truncate(summary, 180));

  const chips = toChips(article);
  if (chips.length) lines.push(chips.join(' '));

  if (article.link) lines.push(article.link);
  lines.push(`_${source}_`);

  return lines.join('\n');
}

function sentimentSummary(articles) {
  const counts = { positive: 0, neutral: 0, negative: 0 };
  let have = 0;
  for (const a of articles) {
    if (a.sentiment && counts[a.sentiment] !== undefined) {
      counts[a.sentiment] += 1;
      have += 1;
    }
  }
  if (!have) {
    return '_Sentiment breakdown: sample — live sentiment requires a paid newsdata.io plan._';
  }
  return `Sentiment: 🟢 ${counts.positive}  ⚪ ${counts.neutral}  🔴 ${counts.negative}`;
}

function buildDigest(articles) {
  if (!articles || !articles.length) {
    return 'No headlines available right now. Please try again shortly.';
  }
  const header = `📰 *News digest* — ${new Date().toUTCString()}`;
  const body = articles.map((a, i) => formatArticle(a, i + 1)).join('\n\n');
  const footer = sentimentSummary(articles);
  return [header, body, footer].join('\n\n');
}

module.exports = { buildDigest };
