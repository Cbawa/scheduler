require('dotenv').config();

function clampSize(value) {
  const n = parseInt(value, 10);
  if (!Number.isFinite(n)) return 5;
  return Math.max(1, Math.min(10, n));
}

module.exports = {
  apiKey: process.env.NEWSDATA_API_KEY || '',
  language: process.env.NEWS_LANGUAGE || 'en',
  country: process.env.NEWS_COUNTRY || '',
  category: process.env.NEWS_CATEGORY || '',
  query: process.env.NEWS_QUERY || '',
  digestSize: clampSize(process.env.DIGEST_SIZE),
  postInterval: process.env.POST_INTERVAL || '0 * * * *',
  prefix: process.env.COMMAND_PREFIX || '!',
  authDir: process.env.AUTH_DIR || 'auth',
  dataFile: process.env.DATA_FILE || 'data/subscriptions.json',
  enablePaid: process.env.ENABLE_PAID === '1',
  timeframe: process.env.NEWS_TIMEFRAME || '',
};
