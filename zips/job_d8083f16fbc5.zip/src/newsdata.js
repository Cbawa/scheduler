const config = require('./config');

const ENDPOINT = 'https://newsdata.io/api/1/latest';

class ApiError extends Error {
  constructor(message, status) {
    super(message);
    this.name = 'ApiError';
    this.status = status;
  }
}

function buildUrl(params) {
  const qs = new URLSearchParams();
  for (const [key, value] of Object.entries(params)) {
    if (value !== undefined && value !== null && value !== '') {
      qs.append(key, String(value));
    }
  }
  return `${ENDPOINT}?${qs.toString()}`;
}

async function request(url) {
  const res = await fetch(url, {
    headers: { 'User-Agent': 'whatsapp-news-group-bot' },
  });
  let json;
  try {
    json = await res.json();
  } catch (err) {
    throw new ApiError('Could not parse the response from newsdata.io', res.status);
  }
  return { status: res.status, json };
}

function unwrap(res) {
  if (res.status === 200) {
    const results = Array.isArray(res.json.results) ? res.json.results : [];
    return { results, nextPage: res.json.nextPage || null };
  }
  if (res.status === 401) {
    throw new ApiError('Invalid newsdata.io API key (401). Check NEWSDATA_API_KEY.', 401);
  }
  if (res.status === 429) {
    throw new ApiError('Rate limit reached (429). Please try again later.', 429);
  }
  const detail =
    res.json && res.json.results && res.json.results.message
      ? res.json.results.message
      : `HTTP ${res.status}`;
  throw new ApiError(`newsdata.io request failed: ${detail}`, res.status);
}

async function fetchPage(page) {
  // Free-tier safe parameters: q, language, country, category and size (<=10)
  // are all available on the free plan.
  const baseParams = {
    apikey: config.apiKey,
    language: config.language,
    country: config.country,
    category: config.category,
    q: config.query,
    size: config.digestSize,
    page,
  };

  // Paid-only query params error the whole request on a free key, so they are
  // sent only when paid mode is explicitly enabled.
  const paidParams = {};
  if (config.enablePaid && config.timeframe) {
    paidParams.timeframe = config.timeframe;
  }

  let res = await request(buildUrl({ ...baseParams, ...paidParams }));

  // If the paid params were rejected, retry once without them so a free key
  // still gets results.
  if ((res.status === 403 || res.status === 422) && Object.keys(paidParams).length) {
    res = await request(buildUrl(baseParams));
  }

  return unwrap(res);
}

async function getDigest(limit) {
  const articles = [];
  let page;
  let guard = 0;

  // Walk the nextPage cursor until we have enough articles or run out.
  while (articles.length < limit && guard < 5) {
    const { results, nextPage } = await fetchPage(page);
    articles.push(...results);
    guard += 1;
    if (!nextPage) break;
    page = nextPage;
  }

  return articles.slice(0, limit);
}

module.exports = { getDigest, ApiError };
