# whatsapp-news-group-bot

A small WhatsApp bot that posts a news digest into the group chats it has been added to, on an hourly schedule. It connects to WhatsApp through the [Baileys](https://github.com/WhiskeySockets/Baileys) library and pulls headlines from the newsdata.io news API (https://newsdata.io) — grab a free API key to run it.

Each digest is a short list of recent headlines with the source, a link, and keyword tags. Where the API returns them, articles also show a sentiment badge and a short AI summary; on the free plan those fields are simply absent and the bot leaves them out (see *Notes on paid data*).

## What it does

- Posts an hourly digest to any group that has run `!subscribe`
- Answers `!news` on demand with the current headlines
- Shows the source, a link, and keyword tags for every article
- Adds a sentiment badge and AI summary when those fields are present
- Logs in once by QR code and saves the session to disk
- Lets you filter the feed by language, country, category, or a search term

## Requirements

- Node.js 20 or newer
- A WhatsApp account to host the bot (a spare number is a good idea)
- A newsdata.io API key. The free tier is enough — sign up at https://newsdata.io and copy the key from your dashboard.

## Setup

1. Install dependencies:

   ```
   git clone <your-fork-url>
   cd whatsapp-news-group-bot
   npm install
   ```

2. Create your `.env` from the example and add your key:

   ```
   cp .env.example .env
   ```

   Then edit `.env` and set at least:

   ```
   NEWSDATA_API_KEY=your_key_here
   ```

3. Start the bot:

   ```
   npm start
   ```

   A QR code is printed in the terminal. On the host phone open WhatsApp → Settings → Linked devices → Link a device, and scan it. The session is stored under `auth/`, so later restarts don't need a new scan.

## Usage

Add the bot's number to a group, then send commands in that group:

- `!subscribe` — start posting the hourly digest here
- `!unsubscribe` — stop the automatic digest
- `!news` — post the current digest right now
- `!help` — list the commands

Example — sending `!news` in a group produces something like:

```
📰 *News digest* — Fri, 12 Jun 2026 09:00:00 GMT

*1. Coastal cities trial adjustable flood barriers* 🟢
A pilot installs height-adjustable barriers across three harbours ahead of the storm season.
#flooding #infrastructure
https://example.com/flood-barriers
_reuters_

*2. Regional rail operator restores weekend service*
Weekend trains return on two lines after months of engineering work.
#rail #transport
https://example.com/rail-weekend
_thehindu_

Sentiment: 🟢 1  ⚪ 1  🔴 0
```

The sentiment badges and the breakdown line appear when the API returns sentiment data; otherwise the digest falls back to the article description and keyword tags.

## Configuration

Everything is read from environment variables (see `.env.example`):

| Variable | Default | Description |
| --- | --- | --- |
| `NEWSDATA_API_KEY` | — | Required. Your newsdata.io key. |
| `NEWS_LANGUAGE` | `en` | Language code passed to the API. |
| `NEWS_COUNTRY` | — | Optional country filter, e.g. `us`. |
| `NEWS_CATEGORY` | — | Optional category, e.g. `technology`. |
| `NEWS_QUERY` | — | Optional keyword to search for. |
| `DIGEST_SIZE` | `5` | Headlines per digest (1–10 on the free plan). |
| `POST_INTERVAL` | `0 * * * *` | Cron expression for the automatic digest. |
| `COMMAND_PREFIX` | `!` | Prefix for bot commands. |
| `AUTH_DIR` | `auth` | Where the WhatsApp session is stored. |
| `DATA_FILE` | `data/subscriptions.json` | Where group subscriptions are stored. |

### Notes on paid data

`sentiment`, `ai_summary`, and `ai_tag` are returned by newsdata.io only on paid plans. The bot reads them when present and hides them otherwise, so it runs fine on a free key — the digest just uses the article description and keyword tags instead. If you do have a paid plan you can set `ENABLE_PAID=1` and `NEWS_TIMEFRAME=6` to limit the feed to the last few hours; on a free key that request is automatically retried without the extra parameter so you still get results.

## How it works

- `index.js` — WhatsApp connection, command handling, the cron schedule, and the subscription store
- `src/newsdata.js` — calls the `/latest` endpoint and paginates with the `nextPage` cursor
- `src/digest.js` — formats articles into a WhatsApp message
- `src/config.js` — reads settings from the environment

## License

MIT
