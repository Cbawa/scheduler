#!/usr/bin/env python3
"""Run the workflows in templates/ from a terminal, without n8n.

    alert   keyword watch; prints (and optionally posts) only unseen articles
    digest  paged fetch -> standalone HTML digest file
    enrich  company lookup -> JSON payload for a CRM field
    check   static checks on the n8n templates in templates/

Everything except `check` needs NEWSDATA_API_KEY in the environment.
"""

from __future__ import annotations

import argparse
import html
import json
import os
import sys
import textwrap
from collections import Counter
from datetime import datetime, timezone
from pathlib import Path

import requests

from newsdata_client import (
    FREE_MAX_PAGE_SIZE,
    PAID_QUERY_PARAMS,
    AuthError,
    MissingApiKey,
    NewsdataClient,
    NewsdataError,
    RateLimitError,
    summarize_sentiment,
    top_keywords,
)

REPO_ROOT = Path(__file__).resolve().parent
TEMPLATE_DIR = REPO_ROOT / "templates"
DEFAULT_STATE_FILE = REPO_ROOT / ".alert-state.json"

# Used only when nothing was scored, and always labelled as a sample.
SAMPLE_SENTIMENT = {"positive": 41, "neutral": 43, "negative": 16}
SAMPLE_CAPTION = "sample values - live sentiment requires a paid newsdata.io plan"
PAID_FIELD_NOTE = (
    "sentiment, ai_tag, ai_region, ai_org and ai_summary are paid response fields; "
    "on a free key they arrive empty and are shown as placeholders."
)


class _Style:
    def __init__(self, enabled):
        self.enabled = enabled

    def _wrap(self, text, code):
        return "\033[%sm%s\033[0m" % (code, text) if self.enabled else str(text)

    def bold(self, t):
        return self._wrap(t, "1")

    def dim(self, t):
        return self._wrap(t, "2")

    def red(self, t):
        return self._wrap(t, "31")

    def green(self, t):
        return self._wrap(t, "32")

    def yellow(self, t):
        return self._wrap(t, "33")

    def cyan(self, t):
        return self._wrap(t, "36")


S = _Style(
    sys.stdout.isatty() and os.environ.get("NO_COLOR") is None and os.environ.get("TERM") != "dumb"
)


def fmt_date(value):
    if not value:
        return "date unknown"
    for pattern in ("%Y-%m-%d %H:%M:%S", "%Y-%m-%dT%H:%M:%S"):
        try:
            return datetime.strptime(str(value)[:19], pattern).strftime("%d %b %H:%M UTC")
        except ValueError:
            continue
    return str(value)


def shorten(text, width=160):
    text = " ".join(str(text or "").split())
    return textwrap.shorten(text, width=width, placeholder=" [...]") if text else ""


def sentiment_badge(value):
    if value == "positive":
        return S.green("[+ positive]")
    if value == "negative":
        return S.red("[- negative]")
    if value == "neutral":
        return S.dim("[= neutral]")
    return S.dim("[sentiment n/a]")


def print_article(index, article):
    print("%2d. %s" % (index, S.bold(article["title"])))
    print(
        "    %s - %s  %s"
        % (article["source"], fmt_date(article["published"]), sentiment_badge(article["sentiment"]))
    )
    body = article["ai_summary"] or article["description"]
    if body:
        print("    " + S.dim(shorten(body)))
    if article["keywords"]:
        print("    " + S.cyan("keywords: ") + ", ".join(article["keywords"][:6]))
    if article["ai_tag"]:
        print("    " + S.cyan("ai tags:  ") + ", ".join(article["ai_tag"][:6]))
    if article["ai_org"]:
        print("    " + S.cyan("ai orgs:  ") + ", ".join(article["ai_org"][:6]))
    if article["link"]:
        print("    " + S.dim(article["link"]))
    print()


def print_sentiment_bars(breakdown):
    sample = not breakdown["available"]
    counts = SAMPLE_SENTIMENT if sample else breakdown["counts"]
    total = sum(counts.values()) or 1
    heading = S.bold("sentiment breakdown")
    if sample:
        heading += "  " + S.yellow("[SAMPLE]")
    print(heading)
    for name in ("positive", "neutral", "negative"):
        value = counts.get(name, 0)
        pct = int(round(value * 100.0 / total))
        bar = "#" * int(round(pct / 4.0))
        print("  %-9s %-26s %3d%%%s" % (name, bar, pct, "" if sample else "  (%d)" % value))
    if sample:
        print("  " + S.dim(SAMPLE_CAPTION))


def print_notes(client, show_field_note=False):
    lines = list(client.notes) if client else []
    if show_field_note:
        lines.append(PAID_FIELD_NOTE)
    if not lines:
        return
    print()
    for line in lines:
        print(S.yellow("note: ") + line)


def load_state(path):
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return {}


def save_state(path, state):
    try:
        path.write_text(json.dumps(state, indent=2), encoding="utf-8")
    except OSError as exc:
        print("warning: could not write %s (%s)" % (path, exc), file=sys.stderr)


def now_iso():
    return datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")


def fetch_articles(client, args, query):
    """Build the query and hand it to the client.

    Paid-only parameters are passed along regardless: the client drops them with
    a note unless --paid was given, and retries without them if refused.
    """
    params = {
        "q": query,
        "language": args.language,
        "country": args.country,
        "category": args.category,
        "size": args.size,
        "sentiment": args.sentiment,
        "timeframe": args.timeframe,
        "from_date": args.from_date,
        "to_date": args.to_date,
    }
    return client.latest_articles(max_pages=args.pages, **params)


def cmd_alert(args, client):
    articles = fetch_articles(client, args, args.query)
    print(
        "watching '%s' (language: %s) - %d article(s) returned"
        % (args.query, args.language or "any", len(articles))
    )
    print()

    state_path = Path(args.state_file)
    state = {} if args.reset else load_state(state_path)
    key = "%s|%s" % (args.query.lower(), args.language or "any")
    entry = state.setdefault("queries", {}).setdefault(key, {})
    seen = list(entry.get("seen") or [])
    seen_set = set(seen)

    fresh = [a for a in articles if a["article_id"] and a["article_id"] not in seen_set]
    if not fresh:
        print(S.dim("nothing new since the last run (%d id(s) remembered)" % len(seen)))
        print()
    else:
        for index, article in enumerate(fresh, 1):
            print_article(index, article)

    breakdown = summarize_sentiment(fresh or articles)
    print_sentiment_bars(breakdown)

    if args.webhook and fresh:
        post_to_webhook(args.webhook, args.query, fresh)

    if not args.dry_run:
        entry["seen"] = (seen + [a["article_id"] for a in fresh])[-500:]
        entry["last_run"] = now_iso()
        save_state(state_path, state)

    print_notes(client, not breakdown["available"])
    return 0


def post_to_webhook(url, query, articles):
    lines = ["*%d new article(s): %s*" % (len(articles), query)]
    for article in articles[:10]:
        bits = ["- <%s|%s>" % (article["link"], article["title"]), "_%s_" % article["source"]]
        if article["sentiment"]:
            bits.append(article["sentiment"])
        if article["keywords"]:
            bits.append("`" + ", ".join(article["keywords"][:3]) + "`")
        lines.append("  ".join(bits))
    try:
        response = requests.post(url, json={"text": "\n".join(lines)}, timeout=15)
    except requests.RequestException as exc:
        print("\nwebhook failed: %s" % exc, file=sys.stderr)
        return
    if response.status_code >= 400:
        print(
            "\nwebhook returned HTTP %d: %s" % (response.status_code, response.text[:120]),
            file=sys.stderr,
        )
    else:
        print("\n" + S.green("posted %d article(s) to the webhook" % len(articles)))


def cmd_digest(args, client):
    articles = fetch_articles(client, args, args.query)
    breakdown = summarize_sentiment(articles)
    keywords = top_keywords(articles, 14)
    generated = datetime.now(timezone.utc).strftime("%d %b %Y %H:%M UTC")

    document = render_digest_html(args.query, articles, breakdown, keywords, generated)
    out_path = Path(args.out)
    out_path.write_text(document, encoding="utf-8")

    print("%d article(s) for '%s'" % (len(articles), args.query))
    sources = sorted({a["source"] for a in articles})
    if sources:
        print(
            "%d source(s): %s%s"
            % (len(sources), ", ".join(sources[:6]), "..." if len(sources) > 6 else "")
        )
    print()
    print_sentiment_bars(breakdown)
    print()
    if keywords:
        print(
            S.bold("top keywords: ")
            + ", ".join("%s (%d)" % (word, count) for word, count in keywords[:10])
        )
    print("\nwrote %s (%s bytes) - open it in a browser" % (out_path, format(len(document), ",")))
    print_notes(client, not breakdown["available"])
    return 0


def cmd_enrich(args, client):
    articles = fetch_articles(client, args, args.company)
    payload = build_crm_payload(args.company, articles)
    text = json.dumps(payload, indent=2, ensure_ascii=False)
    if args.out:
        Path(args.out).write_text(text, encoding="utf-8")
        print("wrote %s (%d article(s))" % (args.out, len(articles)))
    else:
        print(text)
    for note in client.notes:
        print(S.yellow("note: ") + note, file=sys.stderr)
    return 0


def build_crm_payload(company, articles):
    breakdown = summarize_sentiment(articles)
    keywords = top_keywords(articles, 10)

    tags: Counter = Counter()
    orgs: Counter = Counter()
    for article in articles:
        tags.update(article["ai_tag"])
        orgs.update(article["ai_org"])

    headlines = [
        {
            "title": a["title"],
            "url": a["link"],
            "source": a["source"],
            "published": a["published"],
            "sentiment": a["sentiment"],
            "summary": shorten(a["ai_summary"] or a["description"], 240),
        }
        for a in articles[:10]
    ]

    note_lines = [
        "Recent coverage for %s (%d article(s) via newsdata.io):" % (company, len(articles))
    ]
    for article in articles[:5]:
        note_lines.append("- %s (%s)" % (article["title"], article["source"]))
    if not articles:
        note_lines.append("- no matching articles in the latest news window")
    if keywords:
        note_lines.append("Themes: " + ", ".join(word for word, _ in keywords[:6]))
    if breakdown["available"]:
        counts = breakdown["counts"]
        note_lines.append(
            "Sentiment: %d positive / %d neutral / %d negative"
            % (counts["positive"], counts["neutral"], counts["negative"])
        )
    else:
        note_lines.append("Sentiment: not scored on this plan")

    return {
        "company": company,
        "generated_at": now_iso(),
        "article_count": len(articles),
        "top_keywords": [[word, count] for word, count in keywords],
        "sentiment": {
            "counts": breakdown["counts"],
            "available": breakdown["available"],
            "note": None
            if breakdown["available"]
            else "sentiment is a paid newsdata.io response field and is empty on this key",
        },
        "ai_tags": [tag for tag, _ in tags.most_common(8)],
        "ai_orgs": [org for org, _ in orgs.most_common(8)],
        "headlines": headlines,
        "crm_note": "\n".join(note_lines),
    }


def cmd_check(args, client=None):
    directory = Path(args.dir)
    files = sorted(directory.glob("*.json"))
    if not files:
        print("no .json templates found in %s" % directory, file=sys.stderr)
        return 2

    failures = 0
    for path in files:
        problems = []
        try:
            raw_text = path.read_text(encoding="utf-8")
            data = json.loads(raw_text)
        except (OSError, ValueError) as exc:
            print("%s %s: %s" % (S.red("FAIL"), path.name, exc))
            failures += 1
            continue

        nodes = data.get("nodes") or []
        names = {node.get("name") for node in nodes}

        for source, connection in (data.get("connections") or {}).items():
            if source not in names:
                problems.append("connection from unknown node %r" % source)
            for group in connection.get("main") or []:
                for link in group or []:
                    if link.get("node") not in names:
                        problems.append("connection to unknown node %r" % link.get("node"))

        if "pub_" in raw_text:
            problems.append("looks like a real newsdata.io key is committed in this file")

        http_nodes = [
            node
            for node in nodes
            if node.get("type") == "n8n-nodes-base.httpRequest"
            and "newsdata.io" in str((node.get("parameters") or {}).get("url", ""))
        ]
        if not http_nodes:
            problems.append("no HTTP Request node calling newsdata.io")

        for node in http_nodes:
            params = node.get("parameters") or {}
            label = node.get("name")
            if params.get("genericAuthType") != "httpHeaderAuth":
                problems.append("%s: expected a header-auth credential (X-ACCESS-KEY)" % label)
            for entry in ((params.get("queryParameters") or {}).get("parameters")) or []:
                name = entry.get("name")
                value = str(entry.get("value", ""))
                if name == "apikey":
                    problems.append(
                        "%s: sends the key as a query parameter; use the header credential" % label
                    )
                if name in PAID_QUERY_PARAMS:
                    problems.append(
                        "%s: %s is a paid-plan parameter and fails on free keys" % (label, name)
                    )
                if name == "size" and value.isdigit() and int(value) > FREE_MAX_PAGE_SIZE:
                    problems.append(
                        "%s: size=%s is above the free-plan maximum of %d"
                        % (label, value, FREE_MAX_PAGE_SIZE)
                    )

        label = "%s (%d nodes)" % (path.name, len(nodes))
        if problems:
            failures += 1
            print("%s %s" % (S.red("FAIL"), label))
            for problem in problems:
                print("       - %s" % problem)
        else:
            print("%s   %s" % (S.green("ok"), label))

    print()
    print("%d template(s) checked, %d with problems" % (len(files), failures))
    return 1 if failures else 0


DIGEST_CSS = """
* { box-sizing: border-box; }
body { margin: 0; padding: 34px 16px; background: #f5f6f8; color: #16181d;
       font: 15px/1.55 -apple-system, "Segoe UI", Roboto, Helvetica, Arial, sans-serif; }
.wrap { max-width: 760px; margin: 0 auto; }
h1 { font-size: 22px; margin: 0 0 4px; }
.sub { color: #7a808a; font-size: 13px; margin: 0 0 22px; }
.card { background: #fff; border: 1px solid #e6e8ec; border-radius: 10px;
        padding: 16px 18px; margin-bottom: 18px; }
.card h2 { font-size: 12px; text-transform: uppercase; letter-spacing: .05em;
           color: #5a616c; margin: 0 0 12px; }
.row { display: flex; align-items: center; gap: 10px; margin-bottom: 7px; font-size: 13px; }
.row .label { width: 70px; color: #5a616c; }
.row .track { flex: 1; height: 10px; background: #eceef1; border-radius: 5px; overflow: hidden; }
.row .fill { display: block; height: 10px; border-radius: 5px; }
.fill.positive { background: #2e9e5b; }
.fill.neutral { background: #8a8f98; }
.fill.negative { background: #d1495b; }
.row .pct { width: 42px; text-align: right; color: #5a616c; }
.pill { font-size: 11px; font-weight: 600; border-radius: 10px; padding: 2px 8px;
        background: #eef1f6; color: #5a616c; margin-left: 8px; }
.pill.sample { background: #fff2cc; color: #7a5c00; }
.caption { font-size: 12px; color: #8a8f98; margin: 10px 0 0; }
.chip { display: inline-block; background: #eef1f6; color: #3c4551; border-radius: 12px;
        padding: 3px 10px; margin: 0 6px 6px 0; font-size: 12px; }
.chip.tag { background: #fff; border: 1px solid #d7dbe2; color: #5a616c; }
article { border-top: 1px solid #e6e8ec; padding: 15px 0; }
article:first-of-type { border-top: 0; padding-top: 0; }
a.title { font-size: 16px; font-weight: 600; color: #16181d; text-decoration: none; }
a.title:hover { text-decoration: underline; }
.meta { font-size: 12px; color: #7a808a; margin: 5px 0 7px; }
.sent { font-weight: 600; }
.sent.positive { color: #2e9e5b; }
.sent.neutral { color: #6b7280; }
.sent.negative { color: #d1495b; }
.sent.none { color: #a4a9b3; font-weight: 400; }
.summary { font-size: 14px; color: #3c4551; margin: 0 0 8px; }
footer { color: #8a8f98; font-size: 12px; text-align: center; margin-top: 26px; }
"""


def _sentiment_card(breakdown):
    sample = not breakdown["available"]
    counts = SAMPLE_SENTIMENT if sample else breakdown["counts"]
    total = sum(counts.values()) or 1
    rows = []
    for name in ("positive", "neutral", "negative"):
        pct = int(round(counts.get(name, 0) * 100.0 / total))
        rows.append(
            '<div class="row"><span class="label">%s</span>'
            '<span class="track"><span class="fill %s" style="width:%d%%"></span></span>'
            '<span class="pct">%d%%</span></div>' % (name, name, pct, pct)
        )
    if sample:
        pill = '<span class="pill sample">sample</span>'
        caption = '<p class="caption">%s</p>' % html.escape(SAMPLE_CAPTION)
    else:
        pill = '<span class="pill">%d scored</span>' % breakdown["total"]
        caption = '<p class="caption">from the sentiment field on each article</p>'
    return '<section class="card"><h2>Sentiment breakdown%s</h2>%s%s</section>' % (
        pill,
        "".join(rows),
        caption,
    )


def _article_html(article):
    sentiment = article["sentiment"]
    badge = (
        '<span class="sent %s">%s</span>' % (sentiment, sentiment)
        if sentiment
        else '<span class="sent none">sentiment n/a</span>'
    )
    summary = article["ai_summary"] or article["description"]
    parts = [
        "<article>",
        '<a class="title" href="%s">%s</a>'
        % (html.escape(article["link"]), html.escape(article["title"])),
        '<div class="meta">%s &middot; %s &middot; %s</div>'
        % (html.escape(article["source"]), html.escape(fmt_date(article["published"])), badge),
    ]
    if summary:
        parts.append('<p class="summary">%s</p>' % html.escape(shorten(summary, 280)))
    chips = ['<span class="chip tag">%s</span>' % html.escape(t) for t in article["ai_tag"][:5]]
    chips += ['<span class="chip">%s</span>' % html.escape(k) for k in article["keywords"][:6]]
    if chips:
        parts.append("<div>%s</div>" % "".join(chips))
    parts.append("</article>")
    return "".join(parts)


def render_digest_html(query, articles, breakdown, keywords, generated):
    chips = "".join(
        '<span class="chip">%s <b>%d</b></span>' % (html.escape(word), count)
        for word, count in keywords
    ) or '<span class="caption">no keywords in this batch</span>'
    cards = "".join(_article_html(a) for a in articles) or (
        '<p class="caption">No articles matched this query.</p>'
    )
    field_note = (
        "" if breakdown["available"] else '<p class="caption">%s</p>' % html.escape(PAID_FIELD_NOTE)
    )
    return "".join(
        [
            "<!doctype html>",
            '<html lang="en"><head><meta charset="utf-8">',
            '<meta name="viewport" content="width=device-width, initial-scale=1">',
            "<title>%s - news digest</title>" % html.escape(query),
            "<style>",
            DIGEST_CSS,
            '</style></head><body><div class="wrap">',
            "<h1>%s</h1>" % html.escape(query),
            '<p class="sub">%d article(s) - generated %s</p>'
            % (len(articles), html.escape(generated)),
            _sentiment_card(breakdown),
            '<section class="card"><h2>Keywords</h2>%s</section>' % chips,
            '<section class="card"><h2>Articles</h2>%s%s</section>' % (cards, field_note),
            "<footer>Data from the newsdata.io news API.</footer>",
            "</div></body></html>",
        ]
    )


def build_parser():
    parser = argparse.ArgumentParser(
        prog="run_local.py",
        description="Run the newsdata.io workflows in templates/ from the terminal.",
    )
    parser.set_defaults(needs_key=True)
    sub = parser.add_subparsers(dest="command")

    common = argparse.ArgumentParser(add_help=False)
    common.add_argument("--language", default="en", help="ISO language code (default: en)")
    common.add_argument("--country", default=None, help="ISO country code, e.g. us")
    common.add_argument("--category", default=None, help="newsdata.io category, e.g. technology")
    common.add_argument("--pages", type=int, default=1, help="nextPage cursors to follow")
    common.add_argument("--size", type=int, default=10, help="articles per page (max 10, free)")
    common.add_argument("--timeout", type=float, default=30.0)
    paid = common.add_argument_group("paid plan options (dropped unless --paid is given)")
    paid.add_argument(
        "--paid",
        action="store_true",
        default=os.environ.get("NEWSDATA_PAID") == "1",
        help="send paid-only query parameters; retries without them if refused",
    )
    paid.add_argument("--sentiment", choices=["positive", "neutral", "negative"])
    paid.add_argument("--timeframe", help="e.g. 24 (hours) or 30m (minutes)")
    paid.add_argument("--from-date", dest="from_date")
    paid.add_argument("--to-date", dest="to_date")

    alert = sub.add_parser("alert", parents=[common], help="articles new since the last run")
    alert.add_argument("-q", "--query", required=True)
    alert.add_argument("--webhook", help="Slack-compatible incoming webhook URL")
    alert.add_argument("--state-file", default=str(DEFAULT_STATE_FILE))
    alert.add_argument("--reset", action="store_true", help="forget previously seen articles")
    alert.add_argument("--dry-run", action="store_true", help="do not write the state file")
    alert.set_defaults(func=cmd_alert)

    digest = sub.add_parser("digest", parents=[common], help="build an HTML digest")
    digest.add_argument("-q", "--query", required=True)
    digest.add_argument("--out", default="digest.html")
    digest.set_defaults(func=cmd_digest, pages=2)

    enrich = sub.add_parser("enrich", parents=[common], help="CRM payload for a company")
    enrich.add_argument("-c", "--company", required=True)
    enrich.add_argument("--out")
    enrich.set_defaults(func=cmd_enrich)

    check = sub.add_parser("check", help="static checks on the n8n templates")
    check.add_argument("--dir", default=str(TEMPLATE_DIR))
    check.set_defaults(func=cmd_check, needs_key=False)

    return parser


def main(argv=None):
    parser = build_parser()
    args = parser.parse_args(argv)
    if not getattr(args, "func", None):
        parser.print_help()
        return 2

    if not args.needs_key:
        return args.func(args, None)

    try:
        client = NewsdataClient(allow_paid=args.paid, timeout=args.timeout)
    except MissingApiKey as exc:
        print("error: %s" % exc, file=sys.stderr)
        print(
            "       get a free key at https://newsdata.io, then: export NEWSDATA_API_KEY=...",
            file=sys.stderr,
        )
        return 2

    try:
        return args.func(args, client)
    except AuthError as exc:
        print("error: %s" % exc, file=sys.stderr)
        return 2
    except (RateLimitError, NewsdataError) as exc:
        print("error: %s" % exc, file=sys.stderr)
        return 1
    except KeyboardInterrupt:
        return 130


if __name__ == "__main__":
    sys.exit(main())
