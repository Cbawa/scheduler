# newsdata-n8n-workflows

Three n8n workflows for keeping an eye on the news: a keyword alert that posts to Slack, a
scheduled digest email, and a webhook that enriches a CRM record with recent coverage of a
company. They pull from the newsdata.io news API (https://newsdata.io) and are written so a
free API key is enough to run all three.

There is also `run_local.py`, a small Python runner that does the same three jobs from a
terminal. It exists so you can see the output — and check your key works — before importing
anything into n8n.

## What's here

| Template | Trigger | What it does |
| --- | --- | --- |
| `templates/keyword-alert.json` | schedule, every 15 min | Queries `/1/latest`, drops articles already seen (ids kept in workflow static data), posts the rest to a Slack incoming webhook. |
| `templates/daily-digest.json` | schedule, 07:00 daily | Pages through `/1/latest` with the `nextPage` cursor, builds an HTML digest with a sentiment breakdown and keyword chips, sends it over SMTP. |
| `templates/crm-enrichment.json` | webhook `POST /newsdata-enrich` | Takes `{"company":"Maersk"}` and returns headlines, top keywords, sentiment counts and a ready-to-paste note for a CRM field. |

## Trying it in a terminal first

Python 3.9+ and one dependency.

```
git clone https://github.com/YOU/newsdata-n8n-workflows.git
cd newsdata-n8n-workflows
python -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt
export NEWSDATA_API_KEY=pub_your_key_here      # free key from https://newsdata.io
```

### Keyword alert

```
$ python run_local.py alert --query "semiconductor export"
watching 'semiconductor export' (language: en) - 8 article(s) returned

 1. Chipmakers brace for tighter export rules
    Reuters - 31 Aug 09:12 UTC  [sentiment n/a]
    Suppliers said the restrictions would reach a wider set of components [...]
    keywords: semiconductors, export controls, trade
    https://www.reuters.com/technology/chipmakers-brace-for-tighter-rules

 2. Foundry orders slip ahead of policy decision
    Nikkei Asia - 31 Aug 07:40 UTC  [sentiment n/a]
    keywords: foundry, chips, taiwan
    https://asia.nikkei.com/business/tech/foundry-orders-slip

sentiment breakdown  [SAMPLE]
  positive  ##########                 41%
  neutral   ###########                43%
  negative  ####                       16%
  sample values - live sentiment requires a paid newsdata.io plan

note: sentiment, ai_tag, ai_region, ai_org and ai_summary are paid response fields; on a free key they arrive empty and are shown as placeholders.
```

Run it again and only unseen stories print — ids live in `.alert-state.json` (`--reset` clears
them, `--dry-run` leaves the file alone). Add `--webhook https://hooks.slack.com/...` to post
the same summary to Slack.

### Digest

```
$ python run_local.py digest --query "offshore wind" --pages 2 --out digest.html
18 article(s) for 'offshore wind'
11 source(s): BBC, Bloomberg, Recharge, Reuters, Splash247, The Guardian...

sentiment breakdown  [SAMPLE]
  positive  ##########                 41%
  neutral   ###########                43%
  negative  ####                       16%
  sample values - live sentiment requires a paid newsdata.io plan

top keywords: offshore wind (9), turbines (6), energy (5), grid (4), auction (3)

wrote digest.html (21,884 bytes) - open it in a browser
```

The HTML has the sentiment chart, keyword chips and one card per article. Cards use
`ai_summary` when present and fall back to `description` when it is empty.

### CRM enrichment

```
$ python run_local.py enrich --company "Maersk"
{
  "company": "Maersk",
  "generated_at": "2026-08-31T11:04:22Z",
  "article_count": 7,
  "top_keywords": [["shipping", 5], ["freight rates", 3], ["red sea", 2]],
  "sentiment": {
    "counts": {"positive": 0, "neutral": 0, "negative": 0},
    "available": false,
    "note": "sentiment is a paid newsdata.io response field and is empty on this key"
  },
  "ai_tags": [],
  "headlines": [
    {
      "title": "Maersk lifts full-year guidance",
      "url": "https://splash247.com/maersk-lifts-full-year-guidance",
      "source": "Splash 247",
      "published": "2026-08-31 06:20:11",
      "sentiment": null,
      "summary": "The carrier raised its outlook after a stronger quarter on Asia-Europe."
    }
  ],
  "crm_note": "Recent coverage for Maersk (7 article(s) via newsdata.io):\n- Maersk lifts full-year guidance (Splash 247)\n[...]"
}
```

Pipe that into whatever writes to your CRM, or use `--out payload.json`.

## Importing into n8n

1. **Workflows -> Import from File**, pick a file from `templates/`.
2. Create one credential of type **Header Auth**: name `X-ACCESS-KEY`, value your newsdata.io
   key. Select it on the HTTP Request node in each workflow — the imported nodes point at a
   placeholder credential id, so n8n shows it as missing until you do.
3. Open the settings node at the start (`Alert settings`, `Digest settings`) and change the
   query, language and destination.
4. `daily-digest.json` also needs an SMTP credential on the Send Email node.
5. `crm-enrichment.json` exposes `POST /webhook/newsdata-enrich`:

```
curl -X POST https://your-n8n.example.com/webhook/newsdata-enrich \
  -H 'content-type: application/json' -d '{"company":"Maersk"}'
```

The HTTP Request nodes run with `neverError` + `fullResponse`, and the Code node after each one
turns 401 / 429 / 403 into a readable message instead of a raw failure. The digest workflow uses
n8n's pagination option to follow the `nextPage` cursor, stopping after 3 pages — change
`maxRequestCount` on that node if you want more.

## Free plan, paid fields

`keywords` is on every article, so keyword chips work with any key. These fields only carry
values on paid newsdata.io plans:

`sentiment`, `sentiment_stats`, `ai_tag`, `ai_region`, `ai_org`, `ai_summary`

On a free key they arrive empty, or as a short "only available in ..." string that the Python
client and the Code nodes both filter out. Nothing breaks: badges read `sentiment n/a`, the
summary falls back to `description`, and the sentiment chart draws a clearly labelled sample
distribution so the layout doesn't collapse into an empty box.

Paid **query parameters** are different — they fail the whole request on a free key, so nothing
sends them unless you ask:

```
python run_local.py digest -q lithium --paid --sentiment positive --timeframe 24
```

`--paid` (or `NEWSDATA_PAID=1`) enables `--sentiment`, `--timeframe`, `--from-date`,
`--to-date` and `--size` above 10. Without it they are dropped and the reason printed; with it,
a 403/422 triggers one retry without them so you still get results.

## Checking the templates

`python run_local.py check` parses each template and fails on broken node connections, a
committed API key, the key sent as an `apikey` query parameter instead of the header, `size`
above 10, or any paid-only query parameter.

```
$ python run_local.py check
ok   crm-enrichment.json (5 nodes)
ok   daily-digest.json (6 nodes)
ok   keyword-alert.json (6 nodes)

3 template(s) checked, 0 with problems
```

## Notes

- The alert workflow keeps the last 500 seen article ids in workflow static data; the local
  runner keeps the same list per query in `.alert-state.json`.
- Free keys are rate limited. The runner honours `Retry-After` and retries a 429 twice before
  giving up; the Code nodes surface it as plain text so a failed execution is readable.
- Quoted phrases and boolean operators in `q` are a paid feature, so keep queries to plain words.
- Timestamps in the response are UTC.

## Licence

MIT.
