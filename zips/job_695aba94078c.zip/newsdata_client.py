"""A small client for the newsdata.io news API.

Covers what the workflows here need: GET /1/latest with cursor pagination
through ``nextPage``, readable errors for 401 / 429 / plan-restricted
parameters, and helpers that drop the "only available in paid plans"
placeholder strings free keys receive in fields such as ``sentiment`` and
``ai_summary`` so they never leak into the UI.

The key is read from NEWSDATA_API_KEY and sent as the X-ACCESS-KEY header.
"""

from __future__ import annotations

import os
import time
from collections import Counter
from typing import Any, Dict, Iterator, List, Optional

import requests

BASE_URL = "https://newsdata.io/api"
USER_AGENT = "newsdata-n8n-workflows/1.0"

# Largest page size a free key may ask for.
FREE_MAX_PAGE_SIZE = 10

# Query parameters that error on a free key; only sent with allow_paid=True.
PAID_QUERY_PARAMS = frozenset(
    {
        "sentiment",
        "sentiment_score",
        "tag",
        "region",
        "organization",
        "timeframe",
        "from_date",
        "to_date",
        "full_content",
    }
)

SENTIMENTS = ("positive", "neutral", "negative")
_UPSELL_HINTS = ("only available in", "available in paid", "upgrade", "subscribe")


class NewsdataError(RuntimeError):
    def __init__(self, message: str, *, status: Optional[int] = None, code: Optional[str] = None):
        super().__init__(message)
        self.status = status
        self.code = code


class MissingApiKey(NewsdataError):
    """NEWSDATA_API_KEY is not set."""


class AuthError(NewsdataError):
    """Key rejected (HTTP 401)."""


class RateLimitError(NewsdataError):
    """Too many requests (HTTP 429)."""


class PlanError(NewsdataError):
    """Parameter not available on this plan (HTTP 403/422)."""


def api_key_from_env(var: str = "NEWSDATA_API_KEY") -> Optional[str]:
    return (os.environ.get(var) or "").strip() or None


def clean_paid_field(value: Any) -> Any:
    """Return None for the notice text free keys get in paid-only fields."""
    if value is None:
        return None
    if isinstance(value, str):
        text = value.strip()
        if not text or any(hint in text.lower() for hint in _UPSELL_HINTS):
            return None
        return text
    if isinstance(value, (list, tuple)):
        cleaned = [item for item in (clean_paid_field(v) for v in value) if item]
        return cleaned or None
    if isinstance(value, dict):
        return value or None
    return value


def _as_list(value: Any) -> List[str]:
    value = clean_paid_field(value)
    if value is None:
        return []
    if isinstance(value, str):
        return [value]
    if isinstance(value, (list, tuple)):
        return [str(v).strip() for v in value if str(v).strip()]
    return [str(value)]


def normalize_article(raw: Dict[str, Any]) -> Dict[str, Any]:
    """Flatten one result. Paid-only fields become empty, never missing."""
    sentiment = clean_paid_field(raw.get("sentiment"))
    if isinstance(sentiment, str):
        sentiment = sentiment.lower()
    if sentiment not in SENTIMENTS:
        sentiment = None

    stats = raw.get("sentiment_stats")
    if not isinstance(stats, dict):
        stats = None

    return {
        "article_id": raw.get("article_id") or raw.get("link") or "",
        "title": (raw.get("title") or "Untitled").strip(),
        "link": raw.get("link") or "",
        "source": raw.get("source_name") or raw.get("source_id") or "unknown source",
        "published": raw.get("pubDate") or "",
        "description": (raw.get("description") or "").strip(),
        "image_url": raw.get("image_url") or "",
        "keywords": _as_list(raw.get("keywords"))[:10],
        "categories": _as_list(raw.get("category")),
        "language": raw.get("language") or "",
        # Paid response fields: present and empty on a free key.
        "sentiment": sentiment,
        "sentiment_stats": stats,
        "ai_tag": _as_list(raw.get("ai_tag")),
        "ai_region": _as_list(raw.get("ai_region")),
        "ai_org": _as_list(raw.get("ai_org")),
        "ai_summary": clean_paid_field(raw.get("ai_summary")),
    }


def summarize_sentiment(articles: List[Dict[str, Any]]) -> Dict[str, Any]:
    counts = {name: 0 for name in SENTIMENTS}
    for article in articles:
        label = article.get("sentiment")
        if label in counts:
            counts[label] += 1
    total = sum(counts.values())
    return {"counts": counts, "total": total, "available": total > 0}


def top_keywords(articles: List[Dict[str, Any]], limit: int = 12):
    counter: Counter = Counter()
    for article in articles:
        for keyword in article.get("keywords", [])[:6]:
            counter[str(keyword).lower()] += 1
    return counter.most_common(limit)


def _error_detail(payload: Any):
    if not isinstance(payload, dict):
        return "", None
    results = payload.get("results")
    if isinstance(results, dict):
        return str(results.get("message") or "").strip(), results.get("code")
    return str(payload.get("message") or "").strip(), payload.get("code")


class NewsdataClient:
    def __init__(
        self,
        api_key: Optional[str] = None,
        *,
        timeout: float = 30.0,
        allow_paid: bool = False,
        max_retries: int = 2,
        session: Optional[requests.Session] = None,
    ):
        key = api_key or api_key_from_env()
        if not key:
            raise MissingApiKey("NEWSDATA_API_KEY is not set")
        self.timeout = timeout
        self.allow_paid = allow_paid
        self.max_retries = max(0, int(max_retries))
        self.session = session or requests.Session()
        self.session.headers.update(
            {"X-ACCESS-KEY": key, "User-Agent": USER_AGENT, "Accept": "application/json"}
        )
        self.notes: List[str] = []
        self.total_results: Optional[int] = None

    def _note(self, message: str) -> None:
        if message not in self.notes:
            self.notes.append(message)

    @staticmethod
    def _clean(params: Optional[Dict[str, Any]]) -> Dict[str, Any]:
        cleaned: Dict[str, Any] = {}
        for key, value in (params or {}).items():
            if value is None:
                continue
            if isinstance(value, bool):
                value = 1 if value else 0
            if isinstance(value, (list, tuple, set)):
                value = ",".join(str(v) for v in value if str(v).strip())
            if isinstance(value, str):
                value = value.strip()
            if value == "":
                continue
            cleaned[key] = value
        return cleaned

    @staticmethod
    def _retry_after(response: requests.Response, attempt: int) -> int:
        header = response.headers.get("Retry-After")
        if header:
            try:
                return max(1, min(60, int(float(header))))
            except ValueError:
                pass
        return min(30, 5 * (attempt + 1))

    @staticmethod
    def _decode(response: requests.Response) -> Any:
        try:
            return response.json()
        except ValueError:
            return {"message": response.text[:300]}

    def get(self, endpoint: str, params: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        """GET an endpoint, keeping free keys away from paid-only parameters."""
        prepared = self._clean(params)
        paid = {k: v for k, v in prepared.items() if k in PAID_QUERY_PARAMS}
        size = prepared.get("size")
        oversized = size is not None and int(size) > FREE_MAX_PAGE_SIZE

        if not self.allow_paid:
            for key, value in paid.items():
                prepared.pop(key, None)
                self._note("dropped paid-plan parameter %s=%s (add --paid to send it)" % (key, value))
            if oversized:
                self._note("size=%s needs a paid plan; using %d instead" % (size, FREE_MAX_PAGE_SIZE))
                prepared["size"] = FREE_MAX_PAGE_SIZE
            paid, oversized = {}, False

        try:
            return self._request(endpoint, prepared)
        except PlanError as exc:
            if not paid and not oversized:
                raise
            fallback = {k: v for k, v in prepared.items() if k not in PAID_QUERY_PARAMS}
            if fallback.get("size") and int(fallback["size"]) > FREE_MAX_PAGE_SIZE:
                fallback["size"] = FREE_MAX_PAGE_SIZE
            self._note("newsdata.io refused the paid parameters (%s); retrying without them" % exc)
            return self._request(endpoint, fallback)

    def _request(self, endpoint: str, params: Dict[str, Any]) -> Dict[str, Any]:
        url = BASE_URL + endpoint
        last_error: Optional[NewsdataError] = None

        for attempt in range(self.max_retries + 1):
            try:
                response = self.session.get(url, params=params, timeout=self.timeout)
            except requests.RequestException as exc:
                last_error = NewsdataError("could not reach newsdata.io: %s" % exc)
                if attempt < self.max_retries:
                    time.sleep(1.5 * (attempt + 1))
                    continue
                raise last_error

            if response.status_code == 429:
                if attempt < self.max_retries:
                    wait = self._retry_after(response, attempt)
                    self._note("rate limited by newsdata.io (429); waited %ds and retried" % wait)
                    time.sleep(wait)
                    continue
                raise RateLimitError(
                    "newsdata.io rate limit reached (429). Free keys get a limited number of "
                    "credits per 15 minute window - wait for it to reset or query less often.",
                    status=429,
                )

            payload = self._decode(response)
            detail, code = _error_detail(payload)
            suffix = (" API said: " + detail) if detail else ""

            if response.status_code == 401:
                raise AuthError(
                    "newsdata.io rejected the API key (401). Check NEWSDATA_API_KEY." + suffix,
                    status=401,
                    code=code,
                )
            if response.status_code in (403, 422):
                raise PlanError(
                    "newsdata.io refused the request (%d).%s" % (response.status_code, suffix),
                    status=response.status_code,
                    code=code,
                )
            if response.status_code >= 400:
                raise NewsdataError(
                    "newsdata.io returned HTTP %d.%s" % (response.status_code, suffix),
                    status=response.status_code,
                    code=code,
                )
            if isinstance(payload, dict) and payload.get("status") == "error":
                raise NewsdataError(
                    "newsdata.io returned an error: %s" % (detail or "unknown error"), code=code
                )
            if not isinstance(payload, dict):
                raise NewsdataError("unexpected response from newsdata.io (not a JSON object)")
            return payload

        raise last_error or NewsdataError("request to newsdata.io failed")

    def paginate(
        self, endpoint: str, params: Optional[Dict[str, Any]] = None, *, max_pages: int = 1
    ) -> Iterator[Dict[str, Any]]:
        """Yield raw results, following the nextPage cursor until it is null."""
        cursor: Optional[str] = None
        pages = 0
        while pages < max(1, int(max_pages)):
            call = dict(params or {})
            if cursor:
                call["page"] = cursor
            payload = self.get(endpoint, call)
            if pages == 0:
                self.total_results = payload.get("totalResults")
            results = payload.get("results") or []
            if not isinstance(results, list):
                results = []
            for raw in results:
                if isinstance(raw, dict):
                    yield raw
            pages += 1
            cursor = payload.get("nextPage")
            if not cursor:
                break

    def latest_articles(self, *, max_pages: int = 1, **params) -> List[Dict[str, Any]]:
        return [normalize_article(raw) for raw in self.paginate("/1/latest", params, max_pages=max_pages)]
