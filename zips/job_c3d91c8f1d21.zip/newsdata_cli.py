#!/usr/bin/env python3
"""newsdata-cli: query the newsdata.io news API from your terminal.

Reads the API key from the NEWSDATA_API_KEY environment variable (a .env file
in the current directory is loaded automatically). Built around the free-tier
/news and /sources endpoints. Paid-only features are not relied upon.
"""
import csv
import io
import json as jsonlib
import os
import sys
import time

import click
import requests
from dotenv import load_dotenv

API_BASE = "https://newsdata.io/api/1"
DEFAULT_TIMEOUT = 30

# Fields shown by default in the table view (kept to free-tier-safe fields).
DEFAULT_FIELDS = ["title", "source_id", "pubDate", "link"]


class NewsDataError(click.ClickException):
    """A user-facing error that prints cleanly and sets a non-zero exit code."""


def get_api_key():
    """Load the API key from the environment, exiting clearly if it is missing."""
    load_dotenv()  # pick up a local .env if present; real env vars win
    key = os.environ.get("NEWSDATA_API_KEY", "").strip()
    if not key:
        raise NewsDataError(
            "NEWSDATA_API_KEY is not set.\n"
            "Get a free key at https://newsdata.io/register and then run:\n"
            "  export NEWSDATA_API_KEY=your_key_here\n"
            "or copy .env.example to .env and fill it in."
        )
    return key


def _handle_status(resp):
    """Translate well-known HTTP error codes into clear, actionable messages."""
    if resp.status_code == 200:
        return
    # Try to surface the API's own message when present.
    detail = ""
    try:
        body = resp.json()
        detail = (body.get("results", {}) or {}).get("message") or body.get("message", "")
    except Exception:
        detail = (resp.text or "").strip()[:200]

    if resp.status_code == 401:
        raise NewsDataError("Invalid or unauthorized API key (HTTP 401). "
                            "Check NEWSDATA_API_KEY.")
    if resp.status_code == 429:
        raise NewsDataError("Rate limit exceeded (HTTP 429). "
                            "Slow down or wait before retrying.")
    if resp.status_code in (403, 422):
        raise NewsDataError(
            f"Request rejected (HTTP {resp.status_code}). "
            "This often means a parameter requires a paid plan "
            "(e.g. sentiment, ai_* fields, /archive, advanced query operators). "
            f"{detail}".strip()
        )
    raise NewsDataError(f"Unexpected response (HTTP {resp.status_code}). {detail}".strip())


def api_get(endpoint, params, retries=2):
    """Perform a GET against the newsdata.io API with light retry on 429."""
    key = get_api_key()
    url = f"{API_BASE}/{endpoint}"
    query = {"apikey": key}
    query.update({k: v for k, v in params.items() if v is not None})

    attempt = 0
    while True:
        try:
            resp = requests.get(url, params=query, timeout=DEFAULT_TIMEOUT)
        except requests.RequestException as exc:
            raise NewsDataError(f"Network error talking to newsdata.io: {exc}")

        if resp.status_code == 429 and attempt < retries:
            wait = 2 ** attempt
            click.echo(f"Rate limited; retrying in {wait}s...", err=True)
            time.sleep(wait)
            attempt += 1
            continue

        _handle_status(resp)
        try:
            return resp.json()
        except ValueError:
            raise NewsDataError("Could not decode the API response as JSON.")


def fetch_articles(params, max_results):
    """Fetch up to max_results articles, following nextPage tokens as needed."""
    collected = []
    next_page = None
    while True:
        page_params = dict(params)
        if next_page:
            page_params["page"] = next_page
        data = api_get("news", page_params)
        results = data.get("results") or []
        collected.extend(results)
        next_page = data.get("nextPage")
        if not next_page or len(collected) >= max_results:
            break
    return collected[:max_results]


def render_json(rows):
    return jsonlib.dumps(rows, indent=2, ensure_ascii=False)


def render_csv(rows, fields):
    buf = io.StringIO()
    writer = csv.DictWriter(buf, fieldnames=fields, extrasaction="ignore")
    writer.writeheader()
    for row in rows:
        flat = {f: _stringify(row.get(f)) for f in fields}
        writer.writerow(flat)
    return buf.getvalue().rstrip("\n")


def _stringify(value):
    if value is None:
        return ""
    if isinstance(value, (list, dict)):
        return jsonlib.dumps(value, ensure_ascii=False)
    return str(value)


def render_table(rows, fields):
    if not rows:
        return ""
    headers = fields
    table = [[_truncate(_stringify(r.get(f)), 60) for f in fields] for r in rows]
    widths = [len(h) for h in headers]
    for line in table:
        for i, cell in enumerate(line):
            widths[i] = max(widths[i], len(cell))

    def fmt(cells):
        return "  ".join(c.ljust(widths[i]) for i, c in enumerate(cells))

    out = [fmt(headers), fmt(["-" * w for w in widths])]
    out.extend(fmt(line) for line in table)
    return "\n".join(out)


def _truncate(text, length):
    text = text.replace("\n", " ").strip()
    return text if len(text) <= length else text[: length - 1] + "\u2026"


def output(rows, fmt, fields):
    if fmt == "json":
        click.echo(render_json(rows))
    elif fmt == "csv":
        click.echo(render_csv(rows, fields))
    else:
        click.echo(render_table(rows, fields))


@click.group(context_settings={"help_option_names": ["-h", "--help"]})
@click.version_option("1.0.0", prog_name="newsdata-cli")
def cli():
    """Query the newsdata.io news API from your terminal.

    Set NEWSDATA_API_KEY in your environment or a local .env file before use.
    """


@cli.command()
@click.option("-q", "--query", "q", help="Keywords or phrase to search for.")
@click.option("-c", "--country", help="Comma-separated country codes, e.g. us,gb.")
@click.option("-l", "--language", help="Comma-separated language codes, e.g. en,es.")
@click.option("--category", help="Comma-separated categories, e.g. technology,business.")
@click.option("-n", "--max-results", default=10, show_default=True, type=int,
              help="Maximum number of articles to return (follows pagination).")
@click.option("-f", "--format", "fmt", type=click.Choice(["table", "json", "csv"]),
              default="table", show_default=True, help="Output format.")
@click.option("--fields", help="Comma-separated fields for table/csv output.")
def news(q, country, language, category, max_results, fmt, fields):
    """Fetch the latest news (the /news endpoint)."""
    if max_results < 1:
        raise NewsDataError("--max-results must be at least 1.")
    params = {
        "q": q,
        "country": country,
        "language": language,
        "category": category,
    }
    rows = fetch_articles(params, max_results)
    if not rows:
        click.echo("No articles matched your query.", err=True)
        return
    selected = [f.strip() for f in fields.split(",")] if fields else DEFAULT_FIELDS
    output(rows, fmt, selected)


@cli.command()
@click.option("-c", "--country", help="Filter sources by country code, e.g. us.")
@click.option("-l", "--language", help="Filter sources by language code, e.g. en.")
@click.option("--category", help="Filter sources by category, e.g. sports.")
@click.option("-f", "--format", "fmt", type=click.Choice(["table", "json", "csv"]),
              default="table", show_default=True, help="Output format.")
@click.option("--fields", help="Comma-separated fields for table/csv output.")
def sources(country, language, category, fmt, fields):
    """List available news sources (the /sources endpoint)."""
    params = {"country": country, "language": language, "category": category}
    data = api_get("sources", params)
    rows = data.get("results") or []
    if not rows:
        click.echo("No sources matched your filters.", err=True)
        return
    selected = ([f.strip() for f in fields.split(",")] if fields
                else ["id", "name", "country", "language", "category"])
    output(rows, fmt, selected)


def main():
    try:
        cli()
    except NewsDataError:
        raise
    except KeyboardInterrupt:
        click.echo("\nAborted.", err=True)
        sys.exit(130)


if __name__ == "__main__":
    main()
