plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("org.jetbrains.kotlin.kapt")
}

android {
    namespace = "com.headlinr"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.headlinr"
        minSdk = 24
        targetSdk = 34
        versionCode = 1
        versionName = "1.0"

        // The API key is read from the environment (or a Gradle property) at build
        // time and injected into BuildConfig — it is never committed to source.
        val apiKey = System.getenv("NEWSDATA_API_KEY")
            ?: (project.findProperty("NEWSDATA_API_KEY") as String?)
            ?: ""
        buildConfigField("String", "NEWSDATA_API_KEY", "\"$apiKey\"")

        val paid = (System.getenv("ENABLE_PAID_FEATURES")
            ?: (project.findProperty("ENABLE_PAID_FEATURES") as String?)
            ?: "0") == "1"
        buildConfigField("boolean", "ENABLE_PAID_FEATURES", paid.toString())
    }

    buildFeatures {
        viewBinding = true
        buildConfig = true
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    kotlinOptions {
        jvmTarget = "17"
    }

    buildTypes {
        release {
            isMinifyEnabled = false
        }
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("com.google.android.material:material:1.12.0")
    implementation("androidx.constraintlayout:constraintlayout:2.1.4")
    implementation("androidx.recyclerview:recyclerview:1.3.2")
    implementation("androidx.swiperefreshlayout:swiperefreshlayout:1.1.0")
    implementation("androidx.lifecycle:lifecycle-runtime-ktx:2.8.3")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.8.1")

    implementation("com.squareup.retrofit2:retrofit:2.11.0")
    implementation("com.squareup.retrofit2:converter-gson:2.11.0")
    implementation("com.squareup.okhttp3:logging-interceptor:4.12.0")

    implementation("androidx.room:room-runtime:2.6.1")
    implementation("androidx.room:room-ktx:2.6.1")
    kapt("androidx.room:room-compiler:2.6.1")

    implementation("com.github.bumptech.glide:glide:4.16.0")
}
