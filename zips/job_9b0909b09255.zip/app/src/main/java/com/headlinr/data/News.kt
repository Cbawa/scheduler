package com.headlinr.data

import android.content.Context
import androidx.room.Dao
import androidx.room.Database
import androidx.room.Entity
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.PrimaryKey
import androidx.room.Query
import androidx.room.Room
import androidx.room.RoomDatabase
import com.google.gson.annotations.SerializedName
import com.headlinr.BuildConfig
import kotlinx.coroutines.flow.Flow
import okhttp3.OkHttpClient
import okhttp3.logging.HttpLoggingInterceptor
import retrofit2.Response
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import retrofit2.http.GET
import retrofit2.http.Query as Q

// ----------------------------- Network DTOs -----------------------------

data class NewsResponse(
    @SerializedName("status") val status: String? = null,
    @SerializedName("totalResults") val totalResults: Int? = null,
    @SerializedName("results") val results: List<ApiArticle>? = null,
    @SerializedName("nextPage") val nextPage: String? = null
)

data class ApiArticle(
    @SerializedName("article_id") val articleId: String? = null,
    @SerializedName("title") val title: String? = null,
    @SerializedName("link") val link: String? = null,
    @SerializedName("description") val description: String? = null,
    @SerializedName("pubDate") val pubDate: String? = null,
    @SerializedName("image_url") val imageUrl: String? = null,
    @SerializedName("source_name") val sourceName: String? = null,
    @SerializedName("source_id") val sourceId: String? = null,
    @SerializedName("category") val category: List<String>? = null,
    // keywords is returned on the free plan.
    @SerializedName("keywords") val keywords: List<String>? = null,
    // The following are paid response fields: null (or a placeholder string) on a
    // free key. ai_tag can be an array on paid plans, so it is read leniently.
    @SerializedName("sentiment") val sentiment: String? = null,
    @SerializedName("ai_tag") val aiTag: Any? = null,
    @SerializedName("ai_summary") val aiSummary: String? = null
)

private const val PAID_HINT = "PAID PLANS"

private fun String?.cleanPaid(): String? {
    val v = this?.trim()
    return if (v.isNullOrEmpty() || v.contains(PAID_HINT, ignoreCase = true)) null else v
}

private fun anyToStringList(v: Any?): List<String> = when (v) {
    is List<*> -> v.mapNotNull { it?.toString()?.trim()?.takeIf { s -> s.isNotEmpty() } }
    else -> emptyList()
}

// ----------------------------- Retrofit -----------------------------

interface NewsApi {
    @GET("1/latest")
    suspend fun latest(
        @Q("apikey") apiKey: String,
        @Q("q") q: String? = null,
        @Q("country") country: String? = null,
        @Q("language") language: String? = null,
        @Q("category") category: String? = null,
        @Q("page") page: String? = null,
        @Q("size") size: Int? = null
    ): Response<NewsResponse>
}

object ApiClient {
    private const val BASE_URL = "https://newsdata.io/api/"

    val api: NewsApi by lazy {
        val logging = HttpLoggingInterceptor().apply {
            level = HttpLoggingInterceptor.Level.BASIC
        }
        val client = OkHttpClient.Builder()
            .addInterceptor(logging)
            .build()
        Retrofit.Builder()
            .baseUrl(BASE_URL)
            .client(client)
            .addConverterFactory(GsonConverterFactory.create())
            .build()
            .create(NewsApi::class.java)
    }
}

// ----------------------------- Room cache -----------------------------

@Entity(tableName = "articles")
data class Article(
    @PrimaryKey val id: String,
    val title: String,
    val link: String?,
    val description: String?,
    val sourceName: String?,
    val pubDate: String?,
    val imageUrl: String?,
    val category: String?,
    val keywords: String?,
    val sentiment: String?,
    val aiTags: String?,
    val aiSummary: String?,
    val position: Int
)

fun Article.keywordList(): List<String> =
    keywords?.split("|")?.filter { it.isNotBlank() } ?: emptyList()

fun Article.aiTagList(): List<String> =
    aiTags?.split("|")?.filter { it.isNotBlank() } ?: emptyList()

@Dao
interface ArticleDao {
    @Query("SELECT * FROM articles ORDER BY position ASC")
    fun observeAll(): Flow<List<Article>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAll(items: List<Article>)

    @Query("DELETE FROM articles")
    suspend fun clear()

    @Query("SELECT COUNT(*) FROM articles")
    suspend fun count(): Int
}

@Database(entities = [Article::class], version = 1, exportSchema = false)
abstract class NewsDb : RoomDatabase() {
    abstract fun articleDao(): ArticleDao

    companion object {
        @Volatile private var INSTANCE: NewsDb? = null

        fun get(context: Context): NewsDb = INSTANCE ?: synchronized(this) {
            INSTANCE ?: Room.databaseBuilder(
                context.applicationContext,
                NewsDb::class.java,
                "news.db"
            ).fallbackToDestructiveMigration().build().also { INSTANCE = it }
        }
    }
}

private fun ApiArticle.toEntity(position: Int): Article {
    val stableId = articleId ?: link ?: "${title.orEmpty()}#$position"
    return Article(
        id = stableId,
        title = title?.trim()?.takeIf { it.isNotEmpty() } ?: "(untitled)",
        link = link,
        description = description.cleanPaid(),
        sourceName = sourceName ?: sourceId,
        pubDate = pubDate,
        imageUrl = imageUrl,
        category = category?.firstOrNull(),
        keywords = keywords?.joinToString("|")?.takeIf { it.isNotBlank() },
        sentiment = sentiment.cleanPaid()?.lowercase(),
        aiTags = anyToStringList(aiTag).joinToString("|").takeIf { it.isNotBlank() },
        aiSummary = aiSummary.cleanPaid(),
        position = position
    )
}

// ----------------------------- Repository -----------------------------

sealed class RefreshResult {
    data class Success(val nextPage: String?, val count: Int) : RefreshResult()
    object InvalidKey : RefreshResult()
    object RateLimited : RefreshResult()
    object Empty : RefreshResult()
    data class Error(val message: String) : RefreshResult()
}

private sealed class CallOutcome {
    data class Ok(val body: NewsResponse) : CallOutcome()
    object Unauthorized : CallOutcome()
    object RateLimited : CallOutcome()
    data class Rejected(val message: String) : CallOutcome()
    data class Failure(val message: String) : CallOutcome()
}

class NewsRepository(context: Context) {

    private val dao = NewsDb.get(context).articleDao()
    private val api = ApiClient.api
    private val apiKey: String = BuildConfig.NEWSDATA_API_KEY
    private val paidEnabled: Boolean = BuildConfig.ENABLE_PAID_FEATURES

    val articles: Flow<List<Article>> = dao.observeAll()

    fun hasApiKey(): Boolean = apiKey.isNotBlank()

    suspend fun load(
        query: String?,
        category: String?,
        country: String?,
        page: String?,
        reset: Boolean
    ): RefreshResult {
        if (!hasApiKey()) return RefreshResult.Error("API key not set")

        val q = query?.trim()?.takeIf { it.isNotEmpty() }
        // size > 10 is a paid query parameter, so only send it in paid mode.
        val size = if (paidEnabled) 50 else null

        var outcome = call(q, category, country, page, size)
        // A free key rejects paid parameters — retry once without them.
        if (outcome is CallOutcome.Rejected && size != null) {
            outcome = call(q, category, country, page, null)
        }

        return when (outcome) {
            is CallOutcome.Unauthorized -> RefreshResult.InvalidKey
            is CallOutcome.RateLimited -> RefreshResult.RateLimited
            is CallOutcome.Rejected -> RefreshResult.Error(outcome.message)
            is CallOutcome.Failure -> RefreshResult.Error(outcome.message)
            is CallOutcome.Ok -> store(outcome.body, reset)
        }
    }

    private suspend fun store(body: NewsResponse, reset: Boolean): RefreshResult {
        val results = body.results.orEmpty()
        if (results.isEmpty()) {
            // Keep whatever is cached; just report the empty page.
            return if (reset) RefreshResult.Empty else RefreshResult.Success(body.nextPage, 0)
        }
        val base = if (reset) 0 else dao.count()
        val entities = results.mapIndexed { i, a -> a.toEntity(base + i) }
        if (reset) dao.clear()
        dao.insertAll(entities)
        return RefreshResult.Success(body.nextPage, entities.size)
    }

    private suspend fun call(
        q: String?,
        category: String?,
        country: String?,
        page: String?,
        size: Int?
    ): CallOutcome = try {
        val resp = api.latest(
            apiKey = apiKey,
            q = q,
            country = country,
            language = "en",
            category = category,
            page = page,
            size = size
        )
        when {
            resp.isSuccessful ->
                resp.body()?.let { CallOutcome.Ok(it) } ?: CallOutcome.Failure("Empty response body")
            resp.code() == 401 -> CallOutcome.Unauthorized
            resp.code() == 429 -> CallOutcome.RateLimited
            resp.code() == 403 || resp.code() == 422 ->
                CallOutcome.Rejected("Request rejected (HTTP ${resp.code()})")
            else -> CallOutcome.Failure("HTTP ${resp.code()}")
        }
    } catch (e: Exception) {
        CallOutcome.Failure(e.message ?: "Network error")
    }
}
