package com.headlinr

import android.graphics.Color
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.google.android.material.snackbar.Snackbar
import com.headlinr.data.Article
import com.headlinr.data.NewsRepository
import com.headlinr.data.RefreshResult
import com.headlinr.data.aiTagList
import com.headlinr.data.keywordList
import com.headlinr.databinding.ActivityMainBinding
import com.headlinr.databinding.ItemArticleBinding
import kotlinx.coroutines.launch

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private lateinit var repo: NewsRepository
    private val adapter = ArticleAdapter()

    private var nextPage: String? = null
    private var loading = false
    private var query: String? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
        setSupportActionBar(binding.toolbar)

        repo = NewsRepository(this)

        val lm = LinearLayoutManager(this)
        binding.recycler.layoutManager = lm
        binding.recycler.adapter = adapter
        binding.recycler.addOnScrollListener(object : RecyclerView.OnScrollListener() {
            override fun onScrolled(rv: RecyclerView, dx: Int, dy: Int) {
                if (dy <= 0) return
                if (!loading && nextPage != null &&
                    lm.findLastVisibleItemPosition() >= lm.itemCount - 3
                ) {
                    loadMore()
                }
            }
        })

        binding.swipeRefresh.setOnRefreshListener { reload() }
        binding.searchButton.setOnClickListener {
            query = binding.searchInput.text?.toString()?.trim()?.takeIf { it.isNotEmpty() }
            reload()
        }

        lifecycleScope.launch {
            repeatOnLifecycle(Lifecycle.State.STARTED) {
                repo.articles.collect { list ->
                    adapter.submitList(list)
                    renderSentiment(list)
                    binding.emptyState.visibility =
                        if (list.isEmpty() && !loading) View.VISIBLE else View.GONE
                }
            }
        }

        if (!repo.hasApiKey()) {
            binding.emptyText.text = getString(R.string.no_api_key)
            binding.emptyState.visibility = View.VISIBLE
        } else {
            reload()
        }
    }

    private fun reload() {
        if (!repo.hasApiKey()) {
            binding.swipeRefresh.isRefreshing = false
            return
        }
        lifecycleScope.launch {
            loading = true
            binding.swipeRefresh.isRefreshing = true
            handle(repo.load(query, null, null, null, reset = true))
            binding.swipeRefresh.isRefreshing = false
            loading = false
        }
    }

    private fun loadMore() {
        val page = nextPage ?: return
        lifecycleScope.launch {
            loading = true
            handle(repo.load(query, null, null, page, reset = false))
            loading = false
        }
    }

    private fun handle(result: RefreshResult) {
        when (result) {
            is RefreshResult.Success -> nextPage = result.nextPage
            is RefreshResult.InvalidKey -> snack(getString(R.string.err_invalid_key))
            is RefreshResult.RateLimited -> snack(getString(R.string.err_rate_limit))
            is RefreshResult.Empty -> snack(getString(R.string.err_empty))
            is RefreshResult.Error -> snack(result.message)
        }
    }

    private fun snack(message: String) {
        Snackbar.make(binding.root, message, Snackbar.LENGTH_LONG).show()
    }

    private fun renderSentiment(list: List<Article>) {
        val sentiments = list.mapNotNull { it.sentiment }
        if (sentiments.isEmpty()) {
            // Free key: no live sentiment, so show a clearly labeled sample.
            binding.sentimentSummary.text = getString(R.string.sentiment_sample)
            return
        }
        binding.sentimentSummary.text = getString(
            R.string.sentiment_live,
            sentiments.count { it == "positive" },
            sentiments.count { it == "neutral" },
            sentiments.count { it == "negative" }
        )
    }
}

class ArticleAdapter : ListAdapter<Article, ArticleAdapter.VH>(DIFF) {

    companion object {
        private val DIFF = object : DiffUtil.ItemCallback<Article>() {
            override fun areItemsTheSame(a: Article, b: Article) = a.id == b.id
            override fun areContentsTheSame(a: Article, b: Article) = a == b
        }
    }

    class VH(val b: ItemArticleBinding) : RecyclerView.ViewHolder(b.root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH =
        VH(ItemArticleBinding.inflate(LayoutInflater.from(parent.context), parent, false))

    override fun onBindViewHolder(holder: VH, position: Int) {
        val a = getItem(position)
        val b = holder.b
        val ctx = b.root.context

        b.title.text = a.title

        b.description.text = a.description.orEmpty()
        b.description.visibility = if (a.description.isNullOrBlank()) View.GONE else View.VISIBLE

        b.source.text = listOfNotNull(a.sourceName, a.pubDate).joinToString("  \u2022  ")

        // Keyword tags (free tier).
        val keywords = a.keywordList()
        if (keywords.isEmpty()) {
            b.keywords.visibility = View.GONE
        } else {
            b.keywords.visibility = View.VISIBLE
            b.keywords.text = ctx.getString(R.string.tags_fmt, keywords.take(6).joinToString(", "))
        }

        // AI tags (paid response field) — hidden when absent.
        val aiTags = a.aiTagList()
        if (aiTags.isEmpty()) {
            b.aiTags.visibility = View.GONE
        } else {
            b.aiTags.visibility = View.VISIBLE
            b.aiTags.text = ctx.getString(R.string.ai_tags_fmt, aiTags.take(6).joinToString(", "))
        }

        // AI summary (paid response field) — hidden when absent.
        if (a.aiSummary.isNullOrBlank()) {
            b.aiSummary.visibility = View.GONE
        } else {
            b.aiSummary.visibility = View.VISIBLE
            b.aiSummary.text = ctx.getString(R.string.ai_summary_fmt, a.aiSummary)
        }

        // Sentiment badge (paid response field) — hidden when absent.
        val sentiment = a.sentiment
        if (sentiment.isNullOrBlank()) {
            b.sentiment.visibility = View.GONE
        } else {
            b.sentiment.visibility = View.VISIBLE
            b.sentiment.text = sentiment.replaceFirstChar { it.uppercase() }
            b.sentiment.setBackgroundColor(
                when (sentiment) {
                    "positive" -> Color.parseColor("#2E7D32")
                    "negative" -> Color.parseColor("#C62828")
                    else -> Color.parseColor("#616161")
                }
            )
        }

        if (a.imageUrl.isNullOrBlank()) {
            b.image.visibility = View.GONE
        } else {
            b.image.visibility = View.VISIBLE
            Glide.with(b.image).load(a.imageUrl).centerCrop().into(b.image)
        }
    }
}
