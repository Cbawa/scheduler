# newsdesk-lens

A small research assistant for journalists: type in a topic, pull the last 30 days of coverage, and get a quick read on who and what keeps showing up — outlets, people, organizations, and the raw keyword tags newsdata.io attaches to each article.

I put this together after doing the same manual pass too many times before starting a story: search a topic, skim a couple dozen articles, jot down which outlets are covering it and which names/orgs keep recurring. This automates that first pass. It's not a replacement for reading the actual articles.

## What it does

- Takes a topic/keyword and queries the [newsdata.io](https://newsdata.io) news API for recent coverage (free-tier accounts get roughly the last 30-ish days via the `latest` endpoint's `timeframe` param).
- Runs each headline + description through spaCy NER to pull out people, organizations, and locations, then aggregates counts across the whole result set.
- Tallies which domains/sources published the most on the topic, so you can see who's leading vs. who's just wire-copying.
- Surfaces newsdata.io's own `keywords` field per article (this is on the free plan, unlike sentiment/AI tags below).
- Shows sentiment badges and AI-generated tags/summaries when they're present in the API response. On a free key those fields come back empty — the app still renders the widgets with a clearly labeled sample so you can see the shape of the feature, it just won't be live data.
- Lets you export the aggregated entity/source tables as CSV for further digging.

## Setup

```bash
pip install -r requirements.txt
python -m spacy download en_core_web_sm
```

Get a free API key at https://newsdata.io/api-key and set it as an environment variable:

```bash
export NEWSDATA_API_KEY=your_key_here
```

The app reads the key from this env var only — it won't run without it, and it will tell you plainly if it's missing.

## Running it

```bash
streamlit run app.py
```

This opens a local page at `http://localhost:8501`. Enter a topic (e.g. `"transit funding"`, `"local election"`, a company name), hit **Research**, and the app fetches pages of results (auto-paginating via newsdata.io's `nextPage` cursor, capped at a configurable number of pages to be polite to the free-tier rate limit) and renders:

- a bar chart of top sources
- tables of top people / organizations / locations extracted by spaCy
- a per-article list with keyword chips, source, and a sentiment badge (sample-labeled if the field is empty)
- CSV download buttons for the aggregated tables

### Sample output

```
$ streamlit run app.py
  Topic: "port authority strike"
  Fetched 42 articles across 5 pages (stopped: nextPage was null)

  Top sources:
    reuters.com       9
    apnews.com        6
    local-tribune.com 4

  Top organizations (spaCy):
    Port Authority        17
    ILA (dockworkers union) 11
    Maersk                 5

  Top people:
    Harold Daggett   6
    ...
```

## Configuration

| Env var | Purpose | Default |
|---|---|---|
| `NEWSDATA_API_KEY` | required, your newsdata.io key | — |
| `MAX_PAGES` | how many result pages to fetch per search | `5` |
| `ENABLE_SENTIMENT` | request `sentiment`-related display (the field itself only populates on a paid newsdata.io plan; this just controls whether the UI treats empty sentiment as "expected" vs shows the sample caption) | `0` |

This project does not send `sentiment=`, `tag=`, `region=`, `organization=`, `timeframe=` with paid-only values, or any other paid query parameter unless you've explicitly configured it — the default path only uses parameters available on the free plan, so a fresh free API key works out of the box. If a request with paid parameters ever gets rejected by the API, the app retries once without them rather than failing outright.

## Why spaCy instead of relying on the API's AI fields

newsdata.io can return `ai_tag`, `ai_org`, and `ai_region` fields, but those are paid-plan only. Running spaCy's `en_core_web_sm` locally on the title/description text means entity extraction works the same regardless of plan — it's slower and less accurate than a hosted NER model, but it's free and it's transparent about what it's doing.

## Known limitations

- Free-tier newsdata.io responses cap at 10 results per page and the app stops once `nextPage` comes back null, so very broad topics will only get partial coverage.
- spaCy's small English model sometimes mis-tags acronyms as people or misses non-English names; this is a first-pass tool, not a verified entity database.
- No persistence — each run is a fresh query, nothing is cached to disk.

## License

MIT
