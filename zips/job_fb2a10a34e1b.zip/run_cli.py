"""Optional command-line entry point: research a topic without launching Streamlit.

Useful for quick checks or scripting, e.g.:

    python run_cli.py "port authority strike"
"""
import os
import sys
from collections import Counter

from app import extract_entities, fetch_articles, load_nlp


def main():
    if len(sys.argv) < 2:
        print('Usage: python run_cli.py "<topic>"')
        sys.exit(1)

    api_key = os.environ.get("NEWSDATA_API_KEY")
    if not api_key:
        print("NEWSDATA_API_KEY environment variable is not set.")
        sys.exit(1)

    query = " ".join(sys.argv[1:])
    max_pages = int(os.environ.get("MAX_PAGES", "5"))

    print(f"Fetching articles for: {query!r}")
    articles, warning = fetch_articles(api_key, query, max_pages)
    if warning:
        print(f"Warning: {warning}")

    if not articles:
        print("No articles found.")
        sys.exit(0)

    print(f"Fetched {len(articles)} articles across up to {max_pages} pages.\n")

    sources = Counter()
    for art in articles:
        src = art.get("source_id")
        if src:
            sources[src] += 1

    print("Top sources:")
    for src, count in sources.most_common(10):
        print(f"  {src:<25} {count}")

    nlp = load_nlp.__wrapped__() if hasattr(load_nlp, "__wrapped__") else load_nlp()
    people, orgs, locs = extract_entities(nlp, articles)

    print("\nTop organizations:")
    for name, count in orgs.most_common(10):
        print(f"  {name:<30} {count}")

    print("\nTop people:")
    for name, count in people.most_common(10):
        print(f"  {name:<30} {count}")


if __name__ == "__main__":
    main()
