import os
import sys
import time
from collections import Counter

import pandas as pd
import requests
import spacy
import streamlit as st

API_BASE = "https://newsdata.io/api/1"
MAX_PAGES_DEFAULT = 5


@st.cache_resource(show_spinner=False)
def load_nlp():
    try:
        return spacy.load("en_core_web_sm")
    except OSError:
        st.error(
            "spaCy model 'en_core_web_sm' is not installed. Run:\n\n"
            "    python -m spacy download en_core_web_sm"
        )
        st.stop()


def get_api_key():
    key = os.environ.get("NEWSDATA_API_KEY")
    if not key:
        st.error(
            "NEWSDATA_API_KEY environment variable is not set. "
            "Get a free key at https://newsdata.io/api-key and export it, e.g.\n\n"
            "    export NEWSDATA_API_KEY=your_key_here"
        )
        st.stop()
    return key


def fetch_articles(api_key, query, max_pages, enable_sentiment=False):
    """Fetch articles for a topic, paginating via nextPage. Returns (articles, warning_message)."""
    articles = []
    page = None
    warning = None
    paid_params_used = enable_sentiment

    for _ in range(max_pages):
        params = {"apikey": api_key, "q": query, "language": "en"}
        if page:
            params["page"] = page
        if paid_params_used:
            params["sentiment"] = "positive"  # example paid filter, only if explicitly enabled

        try:
            resp = requests.get(f"{API_BASE}/latest", params=params, timeout=15)
        except requests.RequestException as exc:
            warning = f"Network error contacting newsdata.io: {exc}"
            break

        if resp.status_code == 401:
            st.error("newsdata.io rejected the API key (401). Double-check NEWSDATA_API_KEY.")
            st.stop()

        if resp.status_code == 429:
            warning = "Hit newsdata.io's rate limit (429). Showing results fetched so far."
            break

        if resp.status_code in (403, 422) and paid_params_used:
            # Paid param rejected on a free key — retry once without it.
            paid_params_used = False
            params.pop("sentiment", None)
            try:
                resp = requests.get(f"{API_BASE}/latest", params=params, timeout=15)
            except requests.RequestException as exc:
                warning = f"Network error contacting newsdata.io: {exc}"
                break

        if resp.status_code != 200:
            warning = f"newsdata.io returned status {resp.status_code}: {resp.text[:200]}"
            break

        data = resp.json()
        results = data.get("results") or []
        articles.extend(results)

        page = data.get("nextPage")
        if not page:
            break
        time.sleep(0.3)  # be polite between paginated calls

    return articles, warning


def extract_entities(nlp, articles):
    people, orgs, locs = Counter(), Counter(), Counter()
    for art in articles:
        text = " ".join(filter(None, [art.get("title"), art.get("description")]))
        if not text.strip():
            continue
        doc = nlp(text)
        for ent in doc.ents:
            if ent.label_ == "PERSON":
                people[ent.text.strip()] += 1
            elif ent.label_ == "ORG":
                orgs[ent.text.strip()] += 1
            elif ent.label_ in ("GPE", "LOC"):
                locs[ent.text.strip()] += 1
    return people, orgs, locs


def counter_to_df(counter, name_col):
    if not counter:
        return pd.DataFrame(columns=[name_col, "mentions"])
    df = pd.DataFrame(counter.most_common(25), columns=[name_col, "mentions"])
    return df


def sentiment_badge(article, sample_mode_note):
    sentiment = article.get("sentiment")
    if sentiment:
        return f"**{sentiment.title()}**", False
    # Free plan: field is absent/null. Show a clearly labeled sample so the
    # widget isn't just blank.
    sample = "Neutral"
    return f"{sample} _(sample — live sentiment requires a paid newsdata.io plan)_", True


def ai_tag_chips(article):
    ai_tag = article.get("ai_tag")
    if ai_tag:
        tags = ai_tag if isinstance(ai_tag, list) else [ai_tag]
        return tags, False
    return ["sample-tag-a", "sample-tag-b"], True


def main():
    st.set_page_config(page_title="newsdesk-lens", layout="wide")
    st.title("newsdesk-lens")
    st.caption(
        "Pulls recent coverage of a topic from the newsdata.io news API "
        "(https://newsdata.io) and extracts recurring sources, people, and organizations."
    )

    api_key = get_api_key()
    nlp = load_nlp()

    max_pages = int(os.environ.get("MAX_PAGES", MAX_PAGES_DEFAULT))
    enable_sentiment = os.environ.get("ENABLE_SENTIMENT", "0") == "1"

    with st.form("search_form"):
        query = st.text_input("Topic or keyword", placeholder='e.g. "port authority strike"')
        submitted = st.form_submit_button("Research")

    if not submitted or not query.strip():
        st.info("Enter a topic above and click Research to pull recent coverage.")
        return

    with st.spinner(f"Fetching up to {max_pages} pages of results for '{query}'..."):
        articles, warning = fetch_articles(api_key, query.strip(), max_pages, enable_sentiment)

    if warning:
        st.warning(warning)

    if not articles:
        st.warning(
            "No articles found for that topic in the available window. "
            "Try a broader or differently-worded query."
        )
        return

    st.success(f"Fetched {len(articles)} articles.")

    # --- Source breakdown ---
    sources = Counter()
    for art in articles:
        src = art.get("source_id") or (art.get("source_name") if art.get("source_name") else None)
        if src:
            sources[src] += 1

    col1, col2 = st.columns([1, 1])

    with col1:
        st.subheader("Top sources")
        src_df = counter_to_df(sources, "source")
        if not src_df.empty:
            st.bar_chart(src_df.set_index("source"))
        else:
            st.caption("No source data available.")

    # --- Keyword tags (free-tier field) ---
    with col2:
        st.subheader("Common keywords")
        kw_counter = Counter()
        for art in articles:
            for kw in (art.get("keywords") or []):
                kw_counter[kw] += 1
        if kw_counter:
            kw_df = counter_to_df(kw_counter, "keyword")
            st.bar_chart(kw_df.set_index("keyword"))
        else:
            st.caption("No keywords returned for this result set.")

    # --- Entity extraction via spaCy ---
    st.subheader("Entities mentioned (extracted locally with spaCy)")
    with st.spinner("Running NER over article text..."):
        people, orgs, locs = extract_entities(nlp, articles)

    ecol1, ecol2, ecol3 = st.columns(3)
    people_df = counter_to_df(people, "person")
    orgs_df = counter_to_df(orgs, "organization")
    locs_df = counter_to_df(locs, "location")

    with ecol1:
        st.markdown("**People**")
        st.dataframe(people_df, use_container_width=True, hide_index=True)
        if not people_df.empty:
            st.download_button(
                "Download people CSV", people_df.to_csv(index=False), "people.csv", "text/csv"
            )
    with ecol2:
        st.markdown("**Organizations**")
        st.dataframe(orgs_df, use_container_width=True, hide_index=True)
        if not orgs_df.empty:
            st.download_button(
                "Download organizations CSV", orgs_df.to_csv(index=False), "organizations.csv", "text/csv"
            )
    with ecol3:
        st.markdown("**Locations**")
        st.dataframe(locs_df, use_container_width=True, hide_index=True)
        if not locs_df.empty:
            st.download_button(
                "Download locations CSV", locs_df.to_csv(index=False), "locations.csv", "text/csv"
            )

    # --- Per-article list with sentiment + AI tag chips ---
    st.subheader("Articles")
    any_sample_sentiment = False
    any_sample_tags = False

    for art in articles:
        title = art.get("title") or "(untitled)"
        link = art.get("link")
        pub_date = art.get("pubDate", "")
        source = art.get("source_id", "unknown source")

        badge_text, is_sample_sentiment = sentiment_badge(art, None)
        tags, is_sample_tags = ai_tag_chips(art)
        any_sample_sentiment = any_sample_sentiment or is_sample_sentiment
        any_sample_tags = any_sample_tags or is_sample_tags

        ai_summary = art.get("ai_summary")

        with st.container(border=True):
            if link:
                st.markdown(f"**[{title}]({link})**")
            else:
                st.markdown(f"**{title}**")
            st.caption(f"{source} · {pub_date}")
            st.markdown(f"Sentiment: {badge_text}")
            if tags:
                chip_line = " ".join(f"`{t}`" for t in tags)
                suffix = " _(sample tags — AI tagging requires a paid plan)_" if is_sample_tags else ""
                st.markdown(f"AI tags: {chip_line}{suffix}")
            if ai_summary:
                st.markdown(f"> {ai_summary}")
            elif is_sample_tags:  # reuse the free-key signal
                st.markdown(
                    "> _Sample summary line — AI-generated summaries require a paid "
                    "newsdata.io plan. On a paid key this would show a 1-2 sentence "
                    "summary of the article._"
                )

    if any_sample_sentiment or any_sample_tags:
        st.caption(
            "Some widgets above show sample/example values because sentiment and AI-tag "
            "fields are empty on the current API key (free plan). Set ENABLE_SENTIMENT=1 "
            "and use a paid newsdata.io plan to see live values."
        )


if __name__ == "__main__":
    main()
