#!/usr/bin/env python3
"""news-entity-extractor

Fetch recent headlines from the newsdata.io news API, run spaCy named-entity
recognition over them, and report how often each person, organisation and
location is mentioned. Produces frequency charts and a JSON report.
"""
import argparse
import json
import os
import sys
import time
from collections import Counter
from pathlib import Path

import requests

API_BASE = "https://newsdata.io/api/1/latest"
USER_AGENT = "news-entity-extractor/1.0"
PAID_PLACEHOLDER = "only available"

# spaCy entity labels grouped into the three buckets we report on.
ENTITY_GROUPS = {
    "people": {"PERSON"},
    "organizations": {"ORG"},
    "locations": {"GPE", "LOC"},
}
GROUP_TITLES = {
    "people": "People",
    "organizations": "Organizations",
    "locations": "Locations",
}


def get_api_key():
    key = os.environ.get("NEWSDATA_API_KEY")
    if not key:
        sys.exit(
            "NEWSDATA_API_KEY is not set. Get a free key at https://newsdata.io "
            "and export it, e.g.  export NEWSDATA_API_KEY=pub_xxx"
        )
    return key


def _is_placeholder(value):
    """True for the 'only available in ... plans' strings paid fields return."""
    return isinstance(value, str) and PAID_PLACEHOLDER in value.lower()


def _request(session, params):
    """Single GET with friendly handling of the common newsdata.io errors.

    Returns the parsed JSON dict, or None when the caller should retry/stop.
    """
    try:
        resp = session.get(API_BASE, params=params, timeout=30)
    except requests.RequestException as exc:
        print(f"  network error: {exc}", file=sys.stderr)
        return None

    if resp.status_code == 401:
        sys.exit("newsdata.io rejected the API key (401). Check NEWSDATA_API_KEY.")
    if resp.status_code == 429:
        print("  rate limit hit (429); pausing briefly...", file=sys.stderr)
        time.sleep(2)
        return None
    if resp.status_code in (403, 422):
        # Usually a paid-only parameter used on a free key. Signal a retry.
        return None
    if resp.status_code >= 400:
        print(f"  request failed ({resp.status_code}): {resp.text[:200]}",
              file=sys.stderr)
        return None

    try:
        payload = resp.json()
    except ValueError:
        print("  could not parse response as JSON", file=sys.stderr)
        return None

    if payload.get("status") == "error":
        msg = payload.get("results") or payload.get("message") or payload
        print(f"  API error: {msg}", file=sys.stderr)
        return None
    return payload


def fetch_articles(api_key, *, query=None, country=None, language="en",
                   category=None, max_pages=3, enable_sentiment=False):
    """Fetch up to max_pages of articles, following the nextPage cursor.

    Only free-tier-safe parameters are sent by default. sentiment= is a paid
    query parameter; when enabled we try it and fall back without it on refusal.
    """
    session = requests.Session()
    session.headers.update({"User-Agent": USER_AGENT})

    base_params = {"apikey": api_key, "language": language}
    if query:
        base_params["q"] = query
    if country:
        base_params["country"] = country
    if category:
        base_params["category"] = category

    paid_params = {}
    if enable_sentiment:
        # Request every polarity so nothing is filtered out; this only exists
        # to surface the sentiment response field on a paid key.
        paid_params["sentiment"] = "positive,negative,neutral"

    articles = []
    page = None
    for _ in range(max_pages):
        params = dict(base_params, **paid_params)
        if page:
            params["page"] = page

        data = _request(session, params)
        if data is None and paid_params:
            print("  paid parameters rejected; retrying with free parameters only",
                  file=sys.stderr)
            paid_params = {}
            params = dict(base_params)
            if page:
                params["page"] = page
            data = _request(session, params)

        if data is None:
            break

        results = data.get("results") or []
        articles.extend(results)

        page = data.get("nextPage")
        if not page:
            break

    return articles


def load_spacy_model(model="en_core_web_sm"):
    try:
        import spacy
    except ImportError:
        sys.exit("spaCy is not installed. Run: pip install -r requirements.txt")
    try:
        return spacy.load(
            model, disable=["tagger", "parser", "lemmatizer", "attribute_ruler"]
        )
    except OSError:
        sys.exit(
            f"spaCy model '{model}' is missing. Install it with:\n"
            f"    python -m spacy download {model}"
        )


def extract_entities(nlp, articles):
    counters = {group: Counter() for group in ENTITY_GROUPS}
    label_to_group = {}
    for group, labels in ENTITY_GROUPS.items():
        for label in labels:
            label_to_group[label] = group

    texts = []
    for art in articles:
        parts = [art.get("title") or "", art.get("description") or ""]
        texts.append(". ".join(p for p in parts if p))

    for doc in nlp.pipe(texts, batch_size=32):
        seen = set()  # count each entity at most once per article
        for ent in doc.ents:
            group = label_to_group.get(ent.label_)
            if not group:
                continue
            name = " ".join(ent.text.split()).strip(" .,'\"")
            if len(name) < 2:
                continue
            key = (group, name.lower())
            if key in seen:
                continue
            seen.add(key)
            counters[group][name] += 1
    return counters


def summarize_fields(articles):
    """Aggregate the extra newsdata.io fields: keywords (free) plus the paid
    sentiment and ai_tag fields when a key happens to provide them."""
    keywords = Counter()
    sentiments = Counter()
    ai_tags = Counter()
    for art in articles:
        for kw in (art.get("keywords") or []):
            if kw and not _is_placeholder(kw):
                keywords[str(kw).lower()] += 1

        sentiment = art.get("sentiment")
        if sentiment and not _is_placeholder(sentiment):
            sentiments[str(sentiment).lower()] += 1

        tags = art.get("ai_tag")
        if isinstance(tags, str):
            tags = [tags]
        for tag in (tags or []):
            if tag and not _is_placeholder(tag):
                ai_tags[str(tag).lower()] += 1
    return keywords, sentiments, ai_tags


def print_summary(articles, counters, keywords, sentiments, ai_tags):
    print(f"\nAnalysed {len(articles)} articles.\n")
    for group in ENTITY_GROUPS:
        items = counters[group].most_common(10)
        print(f"Top {GROUP_TITLES[group].lower()}:")
        if not items:
            print("  (none detected)")
        for name, count in items:
            print(f"  {count:>3}  {name}")
        print()

    if keywords:
        chips = ", ".join(f"{k} ({v})" for k, v in keywords.most_common(12))
        print(f"Keywords (newsdata.io): {chips}\n")

    print("Sentiment:")
    if sentiments:
        ordered = ["positive", "neutral", "negative"]
        for label in ordered:
            if label in sentiments:
                print(f"  [{label}] {sentiments[label]}")
        for label, count in sentiments.items():
            if label not in ordered:
                print(f"  [{label}] {count}")
    else:
        print("  not present on this key — sentiment requires a paid newsdata.io plan")
    print()

    if ai_tags:
        chips = ", ".join(tag for tag, _ in ai_tags.most_common(12))
        print(f"AI tags: {chips}\n")
    else:
        print("AI tags: not present on this key — requires a paid newsdata.io plan\n")


def build_report(articles, counters, keywords, sentiments, ai_tags):
    def top(counter, n):
        return [{"name": name, "count": count}
                for name, count in counter.most_common(n)]

    return {
        "article_count": len(articles),
        "entities": {group: top(c, 25) for group, c in counters.items()},
        "top_keywords": top(keywords, 25),
        "sentiment": dict(sentiments),
        "top_ai_tags": top(ai_tags, 25),
    }


def render_entity_chart(counters, out_path, top_n=15):
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt

    groups = list(ENTITY_GROUPS)
    colors = {"people": "#4C72B0", "organizations": "#DD8452",
              "locations": "#55A868"}
    fig, axes = plt.subplots(1, len(groups), figsize=(16, 8))
    if len(groups) == 1:
        axes = [axes]

    for ax, group in zip(axes, groups):
        items = counters[group].most_common(top_n)
        ax.set_title(GROUP_TITLES[group])
        if not items:
            ax.text(0.5, 0.5, "no entities found", ha="center", va="center",
                    transform=ax.transAxes, color="gray")
            ax.set_xticks([])
            ax.set_yticks([])
            continue
        names = [n for n, _ in items][::-1]
        counts = [c for _, c in items][::-1]
        ax.barh(names, counts, color=colors[group])
        ax.set_xlabel("mentions")
        ax.margins(y=0.01)

    fig.suptitle("Named entities in recent headlines (newsdata.io)", fontsize=14)
    fig.tight_layout(rect=[0, 0, 1, 0.96])
    fig.savefig(out_path, dpi=120)
    plt.close(fig)


def render_sentiment_chart(sentiments, out_path):
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt

    is_sample = not sentiments
    if is_sample:
        data = {"positive": 4, "neutral": 5, "negative": 3}
    else:
        data = {k: sentiments.get(k, 0)
                for k in ("positive", "neutral", "negative")}
        for label, count in sentiments.items():
            data.setdefault(label, count)

    labels = list(data)
    values = [data[k] for k in labels]
    colors = {"positive": "#55A868", "neutral": "#C7C7C7", "negative": "#C44E52"}

    fig, ax = plt.subplots(figsize=(7, 5))
    ax.bar(labels, values, color=[colors.get(k, "#4C72B0") for k in labels])
    ax.set_ylabel("articles")
    title = "Headline sentiment breakdown"
    if is_sample:
        title += "\n(sample \u2014 live sentiment requires a paid newsdata.io plan)"
    ax.set_title(title)
    fig.tight_layout()
    fig.savefig(out_path, dpi=120)
    plt.close(fig)
    return is_sample


def parse_args(argv=None):
    parser = argparse.ArgumentParser(
        description="Extract named entities from newsdata.io headlines with spaCy."
    )
    parser.add_argument("-q", "--query", help="search term (q)")
    parser.add_argument("-c", "--country", help="two-letter country code")
    parser.add_argument("-l", "--language", default="en", help="language code")
    parser.add_argument("--category", help="newsdata.io category, e.g. technology")
    parser.add_argument("-p", "--pages", type=int, default=3,
                        help="how many pages to fetch (default 3)")
    parser.add_argument("-n", "--top", type=int, default=15,
                        help="entities per chart (default 15)")
    parser.add_argument("-o", "--output", default="output",
                        help="output directory (default: output)")
    parser.add_argument("--model", default="en_core_web_sm",
                        help="spaCy model to load")
    parser.add_argument("--enable-sentiment", action="store_true",
                        default=os.environ.get("ENABLE_SENTIMENT") == "1",
                        help="send the paid sentiment filter (needs a paid plan)")
    return parser.parse_args(argv)


def main(argv=None):
    args = parse_args(argv)
    api_key = get_api_key()

    print("Fetching headlines from newsdata.io...")
    articles = fetch_articles(
        api_key,
        query=args.query,
        country=args.country,
        language=args.language,
        category=args.category,
        max_pages=max(1, args.pages),
        enable_sentiment=args.enable_sentiment,
    )
    if not articles:
        print("No articles returned. Try a different query, country or category.")
        return 0

    nlp = load_spacy_model(args.model)
    print("Running named-entity recognition...")
    counters = extract_entities(nlp, articles)
    keywords, sentiments, ai_tags = summarize_fields(articles)

    out_dir = Path(args.output)
    out_dir.mkdir(parents=True, exist_ok=True)

    print_summary(articles, counters, keywords, sentiments, ai_tags)

    report = build_report(articles, counters, keywords, sentiments, ai_tags)
    (out_dir / "report.json").write_text(
        json.dumps(report, indent=2, ensure_ascii=False), encoding="utf-8"
    )

    render_entity_chart(counters, out_dir / "entities.png", top_n=args.top)
    is_sample = render_sentiment_chart(sentiments, out_dir / "sentiment.png")

    print(f"Wrote {out_dir / 'entities.png'}, {out_dir / 'sentiment.png'} "
          f"and {out_dir / 'report.json'}.")
    if is_sample:
        print("(sentiment.png uses sample values; enable a paid plan for live sentiment.)")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
