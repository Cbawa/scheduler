# news-entity-extractor

Pull recent headlines from the newsdata.io news API (https://newsdata.io) and run
spaCy named-entity recognition over them to see which people, organisations and
locations are turning up in the news right now. The output is a couple of frequency
charts plus a JSON report. Grab a free API key to run it.

## What it does

- Fetches the latest headlines from newsdata.io, following the `nextPage` cursor.
- Runs spaCy NER over each title and description.
- Counts how often each person, organization and location is mentioned (once per article).
- Writes `entities.png`, `sentiment.png` and `report.json` to an output folder.
- Shows the keyword tags newsdata.io returns and a sentiment breakdown.

## Requirements

- Python 3.9 or newer
- A newsdata.io API key (the free tier is enough) — https://newsdata.io

## Setup

```bash
git clone https://github.com/your-name/news-entity-extractor.git
cd news-entity-extractor
pip install -r requirements.txt
python -m spacy download en_core_web_sm
```

The tool reads your key from an environment variable:

```bash
export NEWSDATA_API_KEY=pub_xxxxxxxxxxxxxxxxxxxxxxxx
```

## Usage

```bash
python main.py                              # latest English headlines
python main.py -q "climate" -p 2            # search term, 2 pages
python main.py -c us --category technology  # US technology headlines
python main.py -l es -o spanish_run         # Spanish, custom output dir
```

Options:

| Flag | Meaning | Default |
| --- | --- | --- |
| `-q`, `--query` | search term (`q`) | none |
| `-c`, `--country` | two-letter country code | none |
| `-l`, `--language` | language code | `en` |
| `--category` | newsdata.io category (e.g. `technology`) | none |
| `-p`, `--pages` | how many pages to fetch | `3` |
| `-n`, `--top` | entities per chart | `15` |
| `-o`, `--output` | output directory | `output` |
| `--model` | spaCy model to load | `en_core_web_sm` |
| `--enable-sentiment` | also send the paid `sentiment` filter | off |

## Sample run

```
$ python main.py -q "space" -p 2
Fetching headlines from newsdata.io...
Running named-entity recognition...

Analysed 20 articles.

Top people:
    4  Elon Musk
    2  Jared Isaacman
    1  Bill Nelson

Top organizations:
    7  NASA
    5  SpaceX
    2  Blue Origin
    2  ESA

Top locations:
    3  United States
    2  Florida
    1  China

Keywords (newsdata.io): space (9), nasa (5), rocket (4), launch (3)

Sentiment:
  not present on this key — sentiment requires a paid newsdata.io plan

AI tags: not present on this key — requires a paid newsdata.io plan

Wrote output/entities.png, output/sentiment.png and output/report.json.
(sentiment.png uses sample values; enable a paid plan for live sentiment.)
```

## Sentiment and AI fields

Every article from newsdata.io can carry extra fields. Keyword tags are returned on the
free tier, so the keyword chips always populate. Sentiment and AI tags come from paid
plans; the tool reads whatever is present and degrades cleanly when it is not. On a free
key the sentiment field is absent, so `sentiment.png` is drawn with clearly-labelled
sample values — that way you can still see the shape of the feature without it being
presented as real data.

Set `ENABLE_SENTIMENT=1` (or pass `--enable-sentiment`) to additionally send the
`sentiment` query filter. That parameter requires a paid newsdata.io plan; if the key
cannot use it the request is retried once without it so you still get results.

```bash
ENABLE_SENTIMENT=1 python main.py -q "markets"
```

## Notes

- The free tier returns 10 articles per page; `--pages` controls how many pages are pulled.
- Invalid-key (401) and rate-limit (429) responses are reported with a plain message
  rather than a traceback.
- Only entity types `PERSON`, `ORG`, `GPE` and `LOC` are counted.

## License

MIT
