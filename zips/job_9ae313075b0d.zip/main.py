#!/usr/bin/env python3
"""Generate a weekly news report PDF for a topic using the newsdata.io API."""
import argparse
import os
import re
import sys

from newsdata_client import NewsDataClient, NewsDataError
from report import generate_report


def slugify(text):
    slug = re.sub(r"[^a-z0-9]+", "-", text.lower()).strip("-")
    return slug or "report"


def env_flag(name):
    return os.environ.get(name, "").strip().lower() in ("1", "true", "yes", "on")


def build_paid_params():
    """Collect opt-in paid query params; empty on a default free run."""
    params = {}
    if env_flag("ENABLE_FULL_CONTENT"):
        params["full_content"] = 1
    timeframe = os.environ.get("NEWSDATA_TIMEFRAME", "").strip()
    if timeframe:
        params["timeframe"] = timeframe
    return params


def parse_args(argv=None):
    parser = argparse.ArgumentParser(
        description="Build a weekly news report PDF for a topic using the "
                    "newsdata.io news API.")
    parser.add_argument("topic", help="topic or search query, e.g. clean energy")
    parser.add_argument("--language", help="ISO language code, e.g. en")
    parser.add_argument("--country", help="country code, e.g. us")
    parser.add_argument("--category", help="category, e.g. technology")
    parser.add_argument("--max-articles", type=int, default=30,
                        help="number of articles to include (default 30)")
    parser.add_argument("--output", help="output PDF path")
    return parser.parse_args(argv)


def main(argv=None):
    args = parse_args(argv)

    api_key = os.environ.get("NEWSDATA_API_KEY")
    if not api_key:
        print("Error: NEWSDATA_API_KEY is not set. Get a free key at "
              "https://newsdata.io and export it first.", file=sys.stderr)
        return 1

    paid_params = build_paid_params()
    use_paid = bool(paid_params)

    client = NewsDataClient(api_key)
    try:
        articles, paid_disabled = client.fetch_articles(
            query=args.topic,
            language=args.language,
            country=args.country,
            category=args.category,
            max_articles=max(1, args.max_articles),
            use_paid_params=use_paid,
            paid_params=paid_params,
        )
    except NewsDataError as exc:
        print("Error: {}".format(exc), file=sys.stderr)
        return 1

    if not articles:
        print("No articles found for '{}'. Try a broader topic or different "
              "filters.".format(args.topic))
        return 0

    if paid_disabled:
        print("Note: paid query options were dropped; fetched free results.")

    print("Fetched {} articles for '{}'.".format(len(articles), args.topic))

    output = args.output or "{}-weekly-report.pdf".format(slugify(args.topic))
    try:
        generate_report(args.topic, articles, output,
                        paid_requested=use_paid, paid_disabled=paid_disabled)
    except Exception as exc:  # pragma: no cover - surface PDF errors cleanly
        print("Error writing PDF: {}".format(exc), file=sys.stderr)
        return 1

    print("Wrote {} ({} articles).".format(output, len(articles)))
    return 0


if __name__ == "__main__":
    sys.exit(main())
