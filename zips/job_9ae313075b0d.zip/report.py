"""Render a weekly news report as a PDF using ReportLab."""
from collections import Counter
from datetime import datetime, timezone
from xml.sax.saxutils import escape

from reportlab.lib import colors
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.units import mm
from reportlab.graphics.shapes import Drawing
from reportlab.graphics.charts.piecharts import Pie
from reportlab.platypus import (SimpleDocTemplate, Paragraph, Spacer,
                                HRFlowable)

SENTIMENT_HEX = {
    "positive": "#2e7d32",
    "negative": "#c62828",
    "neutral": "#5f6368",
}
SENTIMENT_COLORS = {k: colors.HexColor(v) for k, v in SENTIMENT_HEX.items()}


def _styles():
    base = getSampleStyleSheet()
    return {
        "title": ParagraphStyle("wr_title", parent=base["Title"], fontSize=22,
                                spaceAfter=4),
        "subtitle": ParagraphStyle("wr_subtitle", parent=base["Normal"],
                                   fontSize=10, textColor=colors.grey,
                                   spaceAfter=10),
        "section": ParagraphStyle("wr_section", parent=base["Heading2"],
                                  fontSize=14, spaceBefore=14, spaceAfter=6),
        "headline": ParagraphStyle("wr_headline", parent=base["Heading3"],
                                   fontSize=12, spaceAfter=2),
        "meta": ParagraphStyle("wr_meta", parent=base["Normal"], fontSize=8,
                               textColor=colors.grey, spaceAfter=4),
        "body": ParagraphStyle("wr_body", parent=base["Normal"], fontSize=9.5,
                               leading=13, spaceAfter=4),
        "summary": ParagraphStyle("wr_summary", parent=base["Normal"],
                                  fontSize=9, leading=12,
                                  textColor=colors.HexColor("#37474f"),
                                  backColor=colors.HexColor("#eceff1"),
                                  borderPadding=4, spaceAfter=4),
        "tags": ParagraphStyle("wr_tags", parent=base["Normal"], fontSize=8,
                               textColor=colors.HexColor("#1565c0"),
                               spaceAfter=2),
        "caption": ParagraphStyle("wr_caption", parent=base["Normal"],
                                  fontSize=8, textColor=colors.grey,
                                  spaceAfter=4),
    }


def _sentiment_counter(articles):
    counter = Counter()
    for art in articles:
        label = (art.get("sentiment") or "").strip().lower()
        if label in SENTIMENT_COLORS:
            counter[label] += 1
    return counter


def _pie(counter):
    drawing = Drawing(420, 165)
    pie = Pie()
    pie.x = 150
    pie.y = 8
    pie.width = 150
    pie.height = 150
    pie.sideLabels = True
    labels = list(counter.keys())
    pie.data = [counter[k] for k in labels]
    pie.labels = ["{} ({})".format(k.title(), counter[k]) for k in labels]
    for i, k in enumerate(labels):
        pie.slices[i].fillColor = SENTIMENT_COLORS[k]
    drawing.add(pie)
    return drawing


def _badge(label):
    label = (label or "").strip().lower()
    hexcolor = SENTIMENT_HEX.get(label)
    if not hexcolor:
        return ""
    return " <font color='{}'><b>[{}]</b></font>".format(hexcolor, label)


def _as_list(value):
    if value is None:
        return []
    if isinstance(value, list):
        return value
    return [value]


def generate_report(topic, articles, output_path, paid_requested=False,
                    paid_disabled=False):
    styles = _styles()
    doc = SimpleDocTemplate(
        output_path, pagesize=A4,
        leftMargin=18 * mm, rightMargin=18 * mm,
        topMargin=18 * mm, bottomMargin=18 * mm,
        title="Weekly news report: {}".format(topic))

    story = []
    generated = datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M UTC")

    story.append(Paragraph("Weekly news report", styles["title"]))
    story.append(Paragraph(
        "Topic: <b>{}</b> &nbsp;&middot;&nbsp; {} articles &nbsp;&middot;&nbsp; "
        "generated {}".format(escape(topic), len(articles), generated),
        styles["subtitle"]))
    story.append(Paragraph(
        "Source: newsdata.io news API (https://newsdata.io)", styles["caption"]))
    story.append(HRFlowable(width="100%", color=colors.lightgrey,
                            spaceBefore=6, spaceAfter=8))

    # --- Sentiment overview -------------------------------------------------
    story.append(Paragraph("Sentiment overview", styles["section"]))
    counter = _sentiment_counter(articles)
    if counter:
        story.append(_pie(counter))
    else:
        story.append(_pie(Counter({"positive": 5, "neutral": 3, "negative": 2})))
        story.append(Paragraph(
            "Sample chart &mdash; live per-article sentiment requires a paid "
            "newsdata.io plan, so this key returned none.", styles["caption"]))

    # --- Top keywords (free field) -----------------------------------------
    kw_counter = Counter()
    for art in articles:
        for kw in _as_list(art.get("keywords")):
            if kw:
                kw_counter[str(kw).strip().lower()] += 1
    if kw_counter:
        top = ", ".join("{} ({})".format(escape(k), n)
                        for k, n in kw_counter.most_common(15))
        story.append(Paragraph("Top keywords", styles["section"]))
        story.append(Paragraph(top, styles["tags"]))

    # --- Headlines ----------------------------------------------------------
    story.append(Paragraph("Headlines", styles["section"]))
    for i, art in enumerate(articles, 1):
        title = escape(art.get("title") or "(untitled)")
        link = art.get("link") or ""
        if link:
            head = "{}. <a href='{}' color='#0d47a1'>{}</a>".format(
                i, escape(link), title)
        else:
            head = "{}. {}".format(i, title)
        head += _badge(art.get("sentiment"))
        story.append(Paragraph(head, styles["headline"]))

        meta_bits = []
        source = art.get("source_name") or art.get("source_id")
        if source:
            meta_bits.append(escape(str(source)))
        if art.get("pubDate"):
            meta_bits.append(escape(str(art.get("pubDate"))))
        creators = _as_list(art.get("creator"))
        if creators:
            meta_bits.append("by " + escape(", ".join(str(c) for c in creators)))
        if meta_bits:
            story.append(Paragraph(" &middot; ".join(meta_bits), styles["meta"]))

        desc = art.get("description") or ""
        if desc:
            story.append(Paragraph(escape(str(desc)), styles["body"]))

        ai_summary = art.get("ai_summary")
        if ai_summary:
            story.append(Paragraph(
                "AI summary: " + escape(str(ai_summary)), styles["summary"]))

        chips = []
        for tag in _as_list(art.get("ai_tag"))[:6]:
            if tag:
                chips.append("#" + escape(str(tag)))
        for kw in _as_list(art.get("keywords"))[:6]:
            if kw:
                chips.append(escape(str(kw)))
        if chips:
            story.append(Paragraph("&nbsp;&nbsp;".join(chips), styles["tags"]))

        story.append(HRFlowable(width="100%", color=colors.HexColor("#eeeeee"),
                                spaceBefore=6, spaceAfter=6))

    story.append(Spacer(1, 4))
    story.append(Paragraph(
        "Generated with news-weekly-report-generator. Data from newsdata.io.",
        styles["caption"]))

    doc.build(story)
    return output_path
