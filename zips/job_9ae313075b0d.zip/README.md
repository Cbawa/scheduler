# news-weekly-report-generator

A small command-line tool that pulls recent headlines on a topic you choose and
renders them into a tidy weekly PDF report. It reads live headlines from the
newsdata.io news API (https://newsdata.io) — grab a free API key to run it.

The report opens with a sentiment breakdown chart and a top-keywords list, then
lays out one card per article with its source, publish date, description, and
keyword tags. When your plan returns them, each card also shows a sentiment
badge and an AI summary line.

## Features

- Search any topic and build a dated PDF report with ReportLab.
- One card per headline: linked title, source, publish date, description.
- Keyword tags taken straight from the API response.
- Sentiment overview pie chart.
- Per-article sentiment badge and AI summary when the response includes them.
- Runs on a free newsdata.io key out of the box; paginates with the API's
  `nextPage` cursor.

## Requirements

- Python 3.9+
- A newsdata.io API key (the free tier is enough). Create one at
  https://newsdata.io and export it as an environment variable.

## Setup

```bash
python -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
export NEWSDATA_API_KEY=your_key_here
```

## Usage

```bash
python main.py "renewable energy"
python main.py "bitcoin" --language en --max-articles 20 --output crypto.pdf
```

Options:

```
--language       ISO language code, e.g. en, es, fr
--country        country code, e.g. us, gb, in
--category       e.g. business, technology, sports
--max-articles   how many articles to include (default 30)
--output         output PDF path
```

### Sample run

```
$ export NEWSDATA_API_KEY=pub_xxxxxxxx
$ python main.py "climate policy" --language en
Fetched 30 articles for 'climate policy'.
Wrote climate-policy-weekly-report.pdf (30 articles).
```

The resulting PDF has a header with the topic and generation time, a sentiment
pie chart, a top-keywords summary, and an article card for each headline.

## Optional: paid data fields

Some newsdata.io response fields — per-article `sentiment`, `ai_summary`,
`ai_tag` — are only populated on paid plans. The report renders them whenever
they are present, and shows a clearly labeled *sample* chart when sentiment is
absent, so the layout never looks broken on a free key.

A couple of request options also require a paid plan and are therefore opt-in:

- `ENABLE_FULL_CONTENT=1` requests full article text (`full_content`).
- `NEWSDATA_TIMEFRAME=24` limits results to the last N hours (`timeframe`).

If a paid option is set while using a free key, the request is automatically
retried without it so you still get results.

## Notes

On the free tier the API returns the most recent matching articles rather than
an arbitrary historical date range (date-range queries need a paid plan), so the
"weekly" report reflects the latest available headlines at the time you run it.

## License

MIT
