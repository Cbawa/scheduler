"""Thin client for the newsdata.io news API (https://newsdata.io)."""
import logging
import time

import requests

BASE_URL = "https://newsdata.io/api/1"
log = logging.getLogger(__name__)

# Query parameters that only work on paid newsdata.io plans. Sending any of
# these on a free key errors the whole request, so they are strictly opt-in.
PAID_PARAMS = ("timeframe", "full_content", "from_date", "to_date", "sentiment")


class NewsDataError(Exception):
    """Raised when the news API cannot be reached or returns an error."""


class NewsDataClient:
    def __init__(self, api_key, timeout=30, session=None):
        if not api_key:
            raise NewsDataError("Missing newsdata.io API key.")
        self.api_key = api_key
        self.timeout = timeout
        self.session = session or requests.Session()

    def _get(self, endpoint, params):
        url = "{}/{}".format(BASE_URL, endpoint)
        query = {k: v for k, v in params.items() if v is not None}
        query["apikey"] = self.api_key
        last_exc = None
        for attempt in range(3):
            try:
                resp = self.session.get(url, params=query, timeout=self.timeout)
            except requests.RequestException as exc:
                last_exc = exc
                time.sleep(2 ** attempt)
                continue
            if resp.status_code == 429:
                wait = 2 ** attempt
                log.warning("Rate limited (HTTP 429); retrying in %ss", wait)
                time.sleep(wait)
                continue
            return resp
        if last_exc is not None:
            raise NewsDataError("Network error contacting newsdata.io: {}".format(last_exc))
        raise NewsDataError("Rate limited by newsdata.io (HTTP 429). Try again later.")

    def fetch_articles(self, query, language=None, country=None, category=None,
                       max_articles=30, use_paid_params=False, paid_params=None):
        """Fetch up to max_articles via /latest, following the nextPage cursor.

        Returns (articles, paid_disabled). paid_disabled is True if paid query
        params were requested but had to be dropped after a 403/422.
        """
        collected = []
        page = None
        paid_disabled = False
        extra = dict(paid_params or {}) if use_paid_params else {}

        while len(collected) < max_articles:
            params = {
                "q": query,
                "language": language,
                "country": country,
                "category": category,
                "page": page,
            }
            if extra and not paid_disabled:
                params.update(extra)

            resp = self._get("latest", params)

            if resp.status_code == 401:
                raise NewsDataError(
                    "Invalid API key (HTTP 401). Check the NEWSDATA_API_KEY value.")
            if resp.status_code in (403, 422) and extra and not paid_disabled:
                log.warning(
                    "Paid parameters rejected (HTTP %s); retrying with a free "
                    "request.", resp.status_code)
                paid_disabled = True
                continue
            if resp.status_code != 200:
                raise NewsDataError(
                    "newsdata.io returned HTTP {}: {}".format(
                        resp.status_code, resp.text[:200]))

            try:
                payload = resp.json()
            except ValueError:
                raise NewsDataError("newsdata.io returned a non-JSON response.")

            if payload.get("status") != "success":
                detail = payload.get("results") or payload.get("message") or payload
                raise NewsDataError("API error: {}".format(detail))

            results = payload.get("results") or []
            collected.extend(results)

            page = payload.get("nextPage")
            if not page or not results:
                break

        return collected[:max_articles], paid_disabled
