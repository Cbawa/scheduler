"""Optional SMTP emailing of the trend report.

Reads SMTP settings from environment variables. Sending is only attempted when
the user explicitly passes --email, so a missing config never breaks the core
tool.
"""
import os
import smtplib
from email.mime.text import MIMEText


class EmailError(Exception):
    """Raised when an email cannot be sent."""


def send_email(to_address, subject, body):
    host = os.environ.get("SMTP_HOST", "smtp.gmail.com")
    port = int(os.environ.get("SMTP_PORT", "587"))
    user = os.environ.get("SMTP_USER")
    password = os.environ.get("SMTP_PASSWORD")
    from_address = os.environ.get("SMTP_FROM", user)

    if not user or not password:
        raise EmailError(
            "SMTP_USER and SMTP_PASSWORD must be set to send email."
        )

    message = MIMEText(body, "plain", "utf-8")
    message["Subject"] = subject
    message["From"] = from_address
    message["To"] = to_address

    try:
        with smtplib.SMTP(host, port, timeout=30) as server:
            server.starttls()
            server.login(user, password)
            server.sendmail(from_address, [to_address], message.as_string())
    except (smtplib.SMTPException, OSError) as exc:
        raise EmailError(f"SMTP error: {exc}")
