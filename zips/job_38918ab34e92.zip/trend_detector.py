"""TF-IDF based trend detection over a batch of news articles."""
import re

from sklearn.feature_extraction.text import TfidfVectorizer


def _article_text(article):
    """Combine the most informative free-text fields of an article."""
    parts = []
    for field in ("title", "description"):
        value = article.get(field)
        if value and isinstance(value, str):
            parts.append(value)
    return " ".join(parts).strip()


def _clean(text):
    text = re.sub(r"http\S+", " ", text)
    text = re.sub(r"[^A-Za-z0-9'\s-]", " ", text)
    return re.sub(r"\s+", " ", text).strip()


def detect_trends(articles, top_n=10, min_articles=2, max_ngram=2):
    """Return a ranked list of trending terms.

    Each item: {term, score, article_count, headlines: [{title, link}]}.
    """
    documents = []
    kept_articles = []
    for art in articles:
        text = _clean(_article_text(art))
        if len(text.split()) >= 3:  # skip near-empty docs
            documents.append(text)
            kept_articles.append(art)

    if len(documents) < 2:
        return []

    max_ngram = max(1, min(int(max_ngram), 3))
    # min_df guards against one-off noise; cap so it never exceeds the corpus.
    min_df = max(1, min(int(min_articles), len(documents)))

    try:
        vectorizer = TfidfVectorizer(
            stop_words="english",
            ngram_range=(1, max_ngram),
            min_df=min_df,
            max_df=0.85,
            token_pattern=r"(?u)\b[a-zA-Z][a-zA-Z'-]+\b",
            sublinear_tf=True,
        )
        matrix = vectorizer.fit_transform(documents)
    except ValueError:
        # Vocabulary became empty (e.g. min_df too high). Retry permissively.
        try:
            vectorizer = TfidfVectorizer(
                stop_words="english",
                ngram_range=(1, max_ngram),
                min_df=1,
            )
            matrix = vectorizer.fit_transform(documents)
        except ValueError:
            return []

    terms = vectorizer.get_feature_names_out()
    # Mean TF-IDF weight across documents = overall prominence of the term.
    mean_scores = matrix.mean(axis=0).A1
    # Document frequency (how many articles mention the term).
    doc_freq = (matrix > 0).sum(axis=0).A1

    ranked = sorted(
        range(len(terms)),
        key=lambda i: mean_scores[i],
        reverse=True,
    )

    trends = []
    for idx in ranked:
        count = int(doc_freq[idx])
        if count < min_articles:
            continue
        term = terms[idx]
        if term.isdigit():
            continue
        headlines = _headlines_for_term(term, documents, kept_articles, limit=3)
        trends.append({
            "term": term,
            "score": float(mean_scores[idx]),
            "article_count": count,
            "headlines": headlines,
        })
        if len(trends) >= top_n:
            break

    return trends


def _headlines_for_term(term, documents, articles, limit=3):
    needle = term.lower()
    out = []
    for doc, art in zip(documents, articles):
        if needle in doc.lower():
            out.append({
                "title": (art.get("title") or "").strip() or "(untitled)",
                "link": art.get("link") or "",
            })
        if len(out) >= limit:
            break
    return out
