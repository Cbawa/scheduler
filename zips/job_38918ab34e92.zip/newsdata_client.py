"""Thin client for the newsdata.io REST API (FREE-tier safe).

Only uses the /news endpoint with basic parameters and the nextPage token.
Handles auth errors, rate limits, paid-only upgrade responses, and empty
results without crashing.
"""
import time

import requests

BASE_URL = "https://newsdata.io/api/1"


class NewsDataError(Exception):
    """Raised for unrecoverable API problems with a human-friendly message."""


class NewsDataClient:
    def __init__(self, api_key, timeout=30):
        if not api_key:
            raise NewsDataError("An API key is required.")
        self.api_key = api_key
        self.timeout = timeout
        self.session = requests.Session()

    def fetch_latest(self, query=None, country=None, language="en",
                     category=None, pages=3):
        """Fetch up to `pages` pages from /news, following nextPage tokens.

        Returns a list of article dicts (possibly empty). Never raises on an
        empty page; raises NewsDataError only on hard failures (bad key, etc.).
        """
        pages = max(1, int(pages))
        articles = []
        next_page = None

        for page_index in range(pages):
            params = {"apikey": self.api_key}
            if query:
                params["q"] = query
            if country:
                params["country"] = country
            if language:
                params["language"] = language
            if category:
                params["category"] = category
            if next_page:
                params["page"] = next_page

            data = self._get("/news", params)
            results = data.get("results") or []
            articles.extend(results)

            next_page = data.get("nextPage")
            if not next_page:
                break
            # Be gentle with the free-tier rate limit.
            if page_index < pages - 1:
                time.sleep(1.0)

        return articles

    def _get(self, path, params, _retries=2):
        url = BASE_URL + path
        try:
            resp = self.session.get(url, params=params, timeout=self.timeout)
        except requests.RequestException as exc:
            raise NewsDataError(f"Network error contacting newsdata.io: {exc}")

        if resp.status_code == 200:
            return resp.json()

        if resp.status_code == 401:
            raise NewsDataError(
                "Invalid API key (401). Check your NEWSDATA_API_KEY."
            )

        if resp.status_code == 429:
            if _retries > 0:
                time.sleep(2.0)
                return self._get(path, params, _retries=_retries - 1)
            raise NewsDataError(
                "Rate limit reached (429). The free tier is limited; "
                "try again later or reduce --pages."
            )

        if resp.status_code in (403, 422):
            # Typically a paid-only feature / param. Surface clearly.
            msg = self._error_message(resp)
            raise NewsDataError(
                f"Request rejected ({resp.status_code}). This often means a "
                f"paid-only feature was requested. Details: {msg}"
            )

        msg = self._error_message(resp)
        raise NewsDataError(f"Unexpected API error ({resp.status_code}): {msg}")

    @staticmethod
    def _error_message(resp):
        try:
            payload = resp.json()
        except ValueError:
            return resp.text[:200] if resp.text else "no details"
        if isinstance(payload, dict):
            results = payload.get("results")
            if isinstance(results, dict):
                return results.get("message") or str(results)
            return payload.get("message") or str(payload)
        return str(payload)
