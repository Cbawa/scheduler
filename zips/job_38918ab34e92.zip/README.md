# News Trend Detector

Detect **trending topics** in the news using classic [TF-IDF](https://en.wikipedia.org/wiki/Tf%E2%80%93idf)
term weighting (via [scikit-learn](https://scikit-learn.org/)) over fresh articles pulled from the
[newsdata.io](https://newsdata.io/) news API — then optionally email yourself a clean daily trend report.

The tool scores the most distinctive, high-signal terms and phrases across the latest batch of
articles, ranks them, and shows the headlines driving each trend.

```
#  Trend                         Score   Articles
1  artificial intelligence       0.418   12
2  interest rates                0.371   9
3  general election              0.330   7
...
```

## Features

- Pulls the latest news from newsdata.io `/news` (works on the **FREE plan**).
- Ranks trending unigrams **and** bigrams with `TfidfVectorizer`.
- Shows the top headlines behind each trend.
- Prints a report to the terminal, writes it to a file, and can **email** it (optional SMTP).
- Graceful handling of invalid keys, rate limits, paid-only features, and empty results.

## How it works

1. Fetch N pages of recent articles (filtered by your query / country / language / category).
2. Treat every article's title + description as a document.
3. Fit a TF-IDF model over the corpus and average each term's weight across documents.
4. The highest-weighted terms are the day's emerging trends.

> **A note on the "historical archive".** The newsdata.io `/archive` endpoint and long date
> ranges are **paid-only**. To keep this project working for everyone on the free tier, trend
> detection runs over the **latest** news instead. Running the tool daily (e.g. via cron) gives
> you a rolling, day-over-day trend signal without needing the paid archive.

## Setup

### 1. Get a free API key

Sign up at [newsdata.io](https://newsdata.io/register) and copy your API key.

### 2. Install

```bash
git clone https://github.com/your-username/news-trend-detector.git
cd news-trend-detector
python -m venv .venv && source .venv/bin/activate   # Windows: .venv\Scripts\activate
pip install -r requirements.txt
```

### 3. Configure your key

The key is read from the `NEWSDATA_API_KEY` environment variable — it is **never** hardcoded.

```bash
export NEWSDATA_API_KEY="pub_xxxxxxxxxxxxxxxxxxxxxxxxxxxx"   # Windows: set NEWSDATA_API_KEY=...
```

Or copy `.env.example` to `.env` and fill it in (auto-loaded if present).

## Usage

```bash
# Top trends across the latest English-language news
python main.py

# Focus a topic / country / category, scan more pages, show more trends
python main.py --query "technology" --country us --language en --pages 4 --top 15

# Only show trends mentioned in at least 3 articles
python main.py --min-articles 3

# Save the report
python main.py --output report.txt

# Email the report (see SMTP env vars below)
python main.py --email you@example.com
```

### CLI options

| Flag | Default | Description |
|------|---------|-------------|
| `--query` | _(none)_ | Keyword to filter news (newsdata.io `q`). |
| `--country` | _(none)_ | 2-letter country code, e.g. `us`, `gb`, `in`. |
| `--language` | `en` | Language code. |
| `--category` | _(none)_ | e.g. `business`, `technology`, `sports`. |
| `--pages` | `3` | How many pages of latest news to scan (10 articles/page). |
| `--top` | `10` | Number of trends to report. |
| `--min-articles` | `2` | Minimum number of articles a term must appear in. |
| `--ngram` | `2` | Max n-gram size (1 = words only, 2 = words + bigrams). |
| `--output` | _(none)_ | Write the report to this file. |
| `--email` | _(none)_ | Email address to send the report to. |

## Daily report via cron

```cron
# Email a trend report every morning at 8am
0 8 * * * cd /path/to/news-trend-detector && NEWSDATA_API_KEY=pub_xxx \
  /path/to/.venv/bin/python main.py --pages 4 --email you@example.com
```

## Emailing (optional)

Emailing is off unless you pass `--email`. Configure an SMTP server via env vars:

| Variable | Default | Notes |
|----------|---------|-------|
| `SMTP_HOST` | `smtp.gmail.com` | Your SMTP server. |
| `SMTP_PORT` | `587` | STARTTLS port. |
| `SMTP_USER` | _(required)_ | SMTP username / from address. |
| `SMTP_PASSWORD` | _(required)_ | SMTP password or app password. |
| `SMTP_FROM` | `SMTP_USER` | Optional from address override. |

For Gmail, create an [App Password](https://support.google.com/accounts/answer/185833).

## Free vs. paid plan

This project is built for the **free** newsdata.io tier. It only uses the `/news` endpoint with
basic parameters (`q`, `country`, `language`, `category`, `page`). It does **not** require any
paid-only features:

- ❌ `/archive` endpoint & long historical date ranges (paid)
- ❌ `sentiment` and AI fields (`ai_tag`, `ai_summary`, `ai_region`, `ai_org`) (paid)
- ❌ advanced full-text query operators (paid)

If the API reports that a feature needs an upgrade, the tool skips it and keeps working.

## License

MIT
