#!/usr/bin/env python3
"""News Trend Detector.

Detects trending topics in the latest news using TF-IDF over articles from the
newsdata.io API, then prints / saves / emails a daily trend report.

Built for the newsdata.io FREE tier: only the /news endpoint with basic params
is used. The paid /archive endpoint is intentionally avoided.
"""
import argparse
import os
import sys
from datetime import datetime, timezone

from newsdata_client import NewsDataClient, NewsDataError
from trend_detector import detect_trends
from emailer import send_email, EmailError


def _load_dotenv():
    """Minimal .env loader (no external dependency required)."""
    path = os.path.join(os.path.dirname(os.path.abspath(__file__)), ".env")
    if not os.path.exists(path):
        return
    try:
        with open(path, "r", encoding="utf-8") as fh:
            for line in fh:
                line = line.strip()
                if not line or line.startswith("#") or "=" not in line:
                    continue
                key, _, value = line.partition("=")
                key = key.strip()
                value = value.strip().strip('"').strip("'")
                os.environ.setdefault(key, value)
    except OSError:
        pass


def parse_args(argv=None):
    p = argparse.ArgumentParser(
        description="Detect trending news topics with TF-IDF using the newsdata.io API."
    )
    p.add_argument("--query", help="Keyword to filter news (newsdata.io 'q').")
    p.add_argument("--country", help="2-letter country code, e.g. us, gb, in.")
    p.add_argument("--language", default="en", help="Language code (default: en).")
    p.add_argument("--category", help="Category, e.g. business, technology, sports.")
    p.add_argument("--pages", type=int, default=3,
                   help="Pages of latest news to scan (default: 3).")
    p.add_argument("--top", type=int, default=10,
                   help="Number of trends to report (default: 10).")
    p.add_argument("--min-articles", type=int, default=2,
                   help="Min articles a term must appear in (default: 2).")
    p.add_argument("--ngram", type=int, default=2, choices=[1, 2, 3],
                   help="Max n-gram size (default: 2).")
    p.add_argument("--output", help="Write the report to this file.")
    p.add_argument("--email", help="Email address to send the report to.")
    return p.parse_args(argv)


def build_report(trends, articles_scanned, args):
    now = datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M UTC")
    lines = []
    lines.append("=" * 64)
    lines.append("NEWS TREND REPORT")
    lines.append(f"Generated: {now}")
    scope = []
    if args.query:
        scope.append(f"query='{args.query}'")
    if args.country:
        scope.append(f"country={args.country}")
    if args.category:
        scope.append(f"category={args.category}")
    scope.append(f"language={args.language}")
    lines.append("Scope: " + ", ".join(scope))
    lines.append(f"Articles analyzed: {articles_scanned}")
    lines.append("=" * 64)
    lines.append("")

    if not trends:
        lines.append("No trends detected. Try more --pages or a broader --query.")
        return "\n".join(lines)

    header = f"{'#':>2}  {'Trend':<32}{'Score':>8}{'Articles':>10}"
    lines.append(header)
    lines.append("-" * len(header))
    for i, t in enumerate(trends, start=1):
        lines.append(
            f"{i:>2}  {t['term'][:32]:<32}{t['score']:>8.3f}{t['article_count']:>10}"
        )

    lines.append("")
    lines.append("Headlines driving the top trends")
    lines.append("-" * 64)
    for t in trends[: min(5, len(trends))]:
        lines.append(f"\n* {t['term'].upper()}")
        for h in t["headlines"][:3]:
            lines.append(f"   - {h['title']}")
            if h.get("link"):
                lines.append(f"     {h['link']}")
    lines.append("")
    lines.append("Powered by newsdata.io")
    return "\n".join(lines)


def main(argv=None):
    _load_dotenv()
    args = parse_args(argv)

    api_key = os.environ.get("NEWSDATA_API_KEY")
    if not api_key:
        print(
            "ERROR: NEWSDATA_API_KEY is not set.\n"
            "Get a free key at https://newsdata.io/register and run:\n"
            '  export NEWSDATA_API_KEY="your_key_here"',
            file=sys.stderr,
        )
        return 2

    client = NewsDataClient(api_key)

    try:
        articles = client.fetch_latest(
            query=args.query,
            country=args.country,
            language=args.language,
            category=args.category,
            pages=args.pages,
        )
    except NewsDataError as exc:
        print(f"ERROR: {exc}", file=sys.stderr)
        return 1

    if not articles:
        print("No articles returned for the given filters. Nothing to analyze.")
        return 0

    trends = detect_trends(
        articles,
        top_n=args.top,
        min_articles=args.min_articles,
        max_ngram=args.ngram,
    )

    report = build_report(trends, len(articles), args)
    print(report)

    if args.output:
        try:
            with open(args.output, "w", encoding="utf-8") as fh:
                fh.write(report + "\n")
            print(f"\nReport written to {args.output}")
        except OSError as exc:
            print(f"WARNING: could not write report: {exc}", file=sys.stderr)

    if args.email:
        subject = f"News Trend Report - {datetime.now().strftime('%Y-%m-%d')}"
        try:
            send_email(args.email, subject, report)
            print(f"Report emailed to {args.email}")
        except EmailError as exc:
            print(f"WARNING: email not sent: {exc}", file=sys.stderr)

    return 0


if __name__ == "__main__":
    raise SystemExit(main())
