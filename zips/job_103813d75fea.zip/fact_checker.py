"""Claim assessment logic.

Prefers GPT-4 (via the OpenAI API) to reason over the gathered news evidence,
but degrades gracefully to a transparent keyword-overlap heuristic when no
OpenAI key is available or the API call fails.
"""
import json
import os

VALID_VERDICTS = {"SUPPORTED", "REFUTED", "UNVERIFIED"}


def assess_claim(claim, articles, model="gpt-4o"):
    """Return a result dict describing whether the news supports the claim."""
    result = _assess_with_gpt4(claim, articles, model=model)
    if result is not None:
        return result
    return _assess_with_heuristic(claim, articles)


def _build_evidence_block(articles):
    lines = []
    for idx, art in enumerate(articles, start=1):
        desc = art.get("description") or "(no description)"
        lines.append(
            f"[{idx}] {art.get('title', '(untitled)')}\n"
            f"    source: {art.get('source_id', 'unknown')}\n"
            f"    summary: {desc}"
        )
    return "\n".join(lines)


def _assess_with_gpt4(claim, articles, model="gpt-4o"):
    """Use GPT-4 to judge the claim. Returns None if unavailable."""
    api_key = os.environ.get("OPENAI_API_KEY")
    if not api_key:
        return None
    try:
        from openai import OpenAI
    except ImportError:
        return None

    evidence = _build_evidence_block(articles)
    system_prompt = (
        "You are a careful fact-checking assistant. You are given a claim and a "
        "set of recent news article summaries. Judge ONLY based on the provided "
        "evidence. Respond with strict JSON of the form: "
        '{"verdict": "SUPPORTED|REFUTED|UNVERIFIED", '
        '"confidence": "low|medium|high", "rationale": "one or two sentences"}. '
        "Use UNVERIFIED when the evidence is insufficient or unrelated."
    )
    user_prompt = (
        f"CLAIM:\n{claim}\n\nNEWS EVIDENCE:\n{evidence}\n\n"
        "Return only the JSON object."
    )

    try:
        client = OpenAI(api_key=api_key)
        completion = client.chat.completions.create(
            model=model,
            messages=[
                {"role": "system", "content": system_prompt},
                {"role": "user", "content": user_prompt},
            ],
            temperature=0,
            response_format={"type": "json_object"},
        )
        content = completion.choices[0].message.content
        parsed = json.loads(content)
    except Exception:
        # Any failure (network, auth, quota, parsing) falls back to heuristic.
        return None

    verdict = str(parsed.get("verdict", "UNVERIFIED")).upper()
    if verdict not in VALID_VERDICTS:
        verdict = "UNVERIFIED"
    confidence = str(parsed.get("confidence", "low")).lower()
    if confidence not in {"low", "medium", "high"}:
        confidence = "low"

    return {
        "claim": claim,
        "verdict": verdict,
        "confidence": confidence,
        "rationale": parsed.get("rationale", "").strip() or "No rationale provided.",
        "method": f"gpt-4 ({model})",
        "sources": _sources(articles),
    }


def _assess_with_heuristic(claim, articles):
    """Transparent fallback: measure keyword overlap with the headlines."""
    stop_words = {
        "the", "a", "an", "is", "are", "was", "were", "to", "of", "in", "on",
        "at", "for", "and", "or", "with", "this", "that", "it", "as", "by",
    }
    claim_words = {
        w.strip(".,!?\"'();:").lower()
        for w in claim.split()
        if len(w) > 2
    } - stop_words

    if not claim_words:
        return _heuristic_result(claim, "UNVERIFIED", "low",
                                 "The claim had no searchable keywords.", articles)

    overlap_scores = []
    for art in articles:
        text = f"{art.get('title', '')} {art.get('description', '')}".lower()
        matched = sum(1 for w in claim_words if w in text)
        overlap_scores.append(matched / len(claim_words))

    best = max(overlap_scores) if overlap_scores else 0.0
    strong_matches = sum(1 for s in overlap_scores if s >= 0.5)

    if best >= 0.6 and strong_matches >= 2:
        verdict, confidence = "SUPPORTED", "medium"
        rationale = (
            f"{strong_matches} article(s) closely match the claim's key terms, "
            "suggesting the topic is being reported on."
        )
    elif best >= 0.4:
        verdict, confidence = "UNVERIFIED", "low"
        rationale = (
            "Some related coverage exists, but it is not strong enough to "
            "confirm or refute the claim."
        )
    else:
        verdict, confidence = "UNVERIFIED", "low"
        rationale = (
            "The retrieved articles do not clearly relate to the claim's key terms."
        )
    return _heuristic_result(claim, verdict, confidence, rationale, articles)


def _heuristic_result(claim, verdict, confidence, rationale, articles):
    return {
        "claim": claim,
        "verdict": verdict,
        "confidence": confidence,
        "rationale": rationale + " (Note: heuristic mode \u2014 set OPENAI_API_KEY "
                     "for GPT-4 reasoning.)",
        "method": "keyword-overlap heuristic",
        "sources": _sources(articles),
    }


def _sources(articles):
    return [
        {
            "title": art.get("title", "(untitled)"),
            "source_id": art.get("source_id", "unknown"),
            "link": art.get("link", ""),
        }
        for art in articles
    ]


def result_to_json(result):
    return json.dumps(result, indent=2, ensure_ascii=False)


def format_verdict(result, articles):
    bar = "\u2500" * 56
    lines = [
        "",
        bar,
        f"  VERDICT: {result['verdict']}  (confidence: {result['confidence']})",
        bar,
        f" {result['rationale']}",
        "",
        f" Assessment method: {result['method']}",
        "",
        " Sources considered:",
    ]
    for idx, art in enumerate(articles, start=1):
        title = art.get("title", "(untitled)")
        source = art.get("source_id", "unknown")
        lines.append(f"  [{idx}] {title} \u2014 {source}")
    lines.append("")
    return "\n".join(lines)
