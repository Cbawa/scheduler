#!/usr/bin/env python3
"""News Fact Checker.

Takes a claim, searches newsdata.io for related articles, and (optionally) uses
GPT-4 to assess whether the available news evidence supports the claim.

Free-tier safe: relies only on the /news endpoint with basic query params and
gracefully handles auth, rate-limit, and empty-result responses.
"""
import argparse
import os
import sys

from newsdata_client import NewsDataClient, NewsDataError
from fact_checker import assess_claim, format_verdict, result_to_json


def build_query(claim: str) -> str:
    """Turn a free-form claim into a concise newsdata.io search query.

    The free /news endpoint works best with short keyword queries, so we keep
    the most meaningful words and drop common stop-words.
    """
    stop_words = {
        "the", "a", "an", "is", "are", "was", "were", "be", "been", "being",
        "to", "of", "in", "on", "at", "for", "and", "or", "but", "with",
        "this", "that", "these", "those", "it", "its", "as", "by", "from",
        "has", "have", "had", "will", "would", "could", "should", "there",
        "their", "they", "he", "she", "we", "you", "i", "about", "into",
    }
    words = [w.strip(".,!?\"'();:").lower() for w in claim.split()]
    keywords = [w for w in words if w and w not in stop_words and len(w) > 2]
    # newsdata.io free queries are most reliable when kept short.
    query = " ".join(keywords[:8]) if keywords else claim.strip()
    return query


def parse_args(argv):
    parser = argparse.ArgumentParser(
        description="Fact-check a claim against recent news from newsdata.io.",
    )
    parser.add_argument("claim", help="The claim to fact-check (wrap in quotes).")
    parser.add_argument("--country", help="Two-letter country code filter (e.g. us, gb).")
    parser.add_argument("--language", default="en", help="Language code (default: en).")
    parser.add_argument("--category", help="News category (e.g. politics, science).")
    parser.add_argument(
        "--max-articles", type=int, default=10,
        help="Maximum number of articles to use as evidence (default: 10).",
    )
    parser.add_argument("--model", default="gpt-4o", help="OpenAI model (default: gpt-4o).")
    parser.add_argument("--json", action="store_true", help="Output result as JSON.")
    return parser.parse_args(argv)


def main(argv=None):
    args = parse_args(argv if argv is not None else sys.argv[1:])

    api_key = os.environ.get("NEWSDATA_API_KEY")
    if not api_key:
        print(
            "Error: NEWSDATA_API_KEY environment variable is not set.\n"
            "Get a free key at https://newsdata.io/register and run:\n"
            "  export NEWSDATA_API_KEY='your_key_here'",
            file=sys.stderr,
        )
        return 2

    claim = args.claim.strip()
    if not claim:
        print("Error: please provide a non-empty claim.", file=sys.stderr)
        return 2

    query = build_query(claim)
    client = NewsDataClient(api_key)

    if not args.json:
        print("\n\U0001F50E Searching newsdata.io for related coverage...")

    try:
        articles = client.search(
            query=query,
            country=args.country,
            language=args.language,
            category=args.category,
            max_articles=args.max_articles,
        )
    except NewsDataError as exc:
        print(f"Error talking to newsdata.io: {exc}", file=sys.stderr)
        return 1

    if not args.json:
        print(f"   Found {len(articles)} related article(s).")

    if not articles:
        print(
            "\nNo related news articles were found, so this claim cannot be "
            "verified against current coverage.\n"
            "Try rephrasing the claim or loosening filters (--country / --category)."
        )
        if args.json:
            empty = {
                "claim": claim,
                "verdict": "UNVERIFIED",
                "confidence": "low",
                "rationale": "No related news articles were found.",
                "method": "none",
                "sources": [],
            }
            print(result_to_json(empty))
        return 0

    if not args.json:
        print("\n\U0001F9E0 Weighing the evidence...")

    result = assess_claim(claim, articles, model=args.model)

    if args.json:
        print(result_to_json(result))
    else:
        print(format_verdict(result, articles))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
