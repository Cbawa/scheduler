"""A small, free-tier-friendly client for the newsdata.io REST API.

Only uses the /news endpoint and basic query parameters available on the free
plan. Handles authentication errors, rate limiting, paid-only upgrade prompts,
and empty results without crashing.
"""
import time

import requests

BASE_URL = "https://newsdata.io/api/1"


class NewsDataError(Exception):
    """Raised when the newsdata.io API returns an unrecoverable error."""


class NewsDataClient:
    def __init__(self, api_key: str, timeout: int = 20):
        if not api_key:
            raise NewsDataError("A newsdata.io API key is required.")
        self.api_key = api_key
        self.timeout = timeout
        self.session = requests.Session()

    def search(self, query, country=None, language="en", category=None,
               max_articles=10):
        """Search /news and return a list of normalized article dicts.

        Follows the free-tier `nextPage` pagination token until enough
        articles are gathered or pages run out.
        """
        collected = []
        next_page = None
        # Cap pages defensively so we never spin against the rate limit.
        max_pages = max(1, (max_articles + 9) // 10)

        for _ in range(max_pages):
            params = {"apikey": self.api_key}
            if query:
                params["q"] = query
            if country:
                params["country"] = country
            if language:
                params["language"] = language
            if category:
                params["category"] = category
            if next_page:
                params["page"] = next_page

            data = self._request("/news", params)
            results = data.get("results") or []
            for item in results:
                collected.append(self._normalize(item))
                if len(collected) >= max_articles:
                    return collected

            next_page = data.get("nextPage")
            if not next_page:
                break
            # Be polite to the free-tier rate limit between pages.
            time.sleep(1)

        return collected

    def _request(self, path, params):
        url = BASE_URL + path
        try:
            resp = self.session.get(url, params=params, timeout=self.timeout)
        except requests.RequestException as exc:
            raise NewsDataError(f"Network error: {exc}") from exc

        if resp.status_code == 401:
            raise NewsDataError(
                "Invalid or unauthorized API key (HTTP 401). "
                "Check your NEWSDATA_API_KEY."
            )
        if resp.status_code == 429:
            raise NewsDataError(
                "Rate limit reached (HTTP 429). The free tier has a limited "
                "number of requests \u2014 please wait and try again."
            )
        if resp.status_code in (403, 422):
            # Typically a paid-only feature/param was requested. Surface a
            # clear message rather than crashing.
            detail = self._error_message(resp)
            raise NewsDataError(
                f"Request rejected (HTTP {resp.status_code}). This usually means "
                f"a paid-only feature was used. Details: {detail}"
            )
        if resp.status_code >= 400:
            raise NewsDataError(
                f"API error (HTTP {resp.status_code}): {self._error_message(resp)}"
            )

        try:
            data = resp.json()
        except ValueError as exc:
            raise NewsDataError("Could not parse the API response as JSON.") from exc

        if data.get("status") == "error":
            raise NewsDataError(self._error_message(resp))
        return data

    @staticmethod
    def _error_message(resp):
        try:
            payload = resp.json()
        except ValueError:
            return resp.text[:200] if resp.text else "unknown error"
        results = payload.get("results")
        if isinstance(results, dict):
            return results.get("message") or str(results)
        return payload.get("message") or str(payload)[:200]

    @staticmethod
    def _normalize(item):
        return {
            "title": (item.get("title") or "").strip(),
            "description": (item.get("description") or "").strip(),
            "link": item.get("link") or "",
            "source_id": item.get("source_id") or "unknown",
            "pub_date": item.get("pubDate") or "",
        }
