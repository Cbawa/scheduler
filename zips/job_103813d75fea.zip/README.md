# 📰 News Fact Checker

A command-line tool that **fact-checks a claim against real news coverage**. Give it a
statement, and it will:

1. Search [newsdata.io](https://newsdata.io) for recent news articles related to your claim.
2. Pass the article headlines and descriptions as evidence to **GPT-4**.
3. Print a verdict — `SUPPORTED`, `REFUTED`, or `UNVERIFIED` — with a short rationale and the sources it used.

It is built as a showcase for the **newsdata.io** news API and runs perfectly on the
**free tier**.

```
$ python main.py "NASA landed a spacecraft on the moon in 2024"

🔎 Searching newsdata.io for related coverage...
   Found 8 related article(s).

🧠 Asking GPT-4 to weigh the evidence...

────────────────────────────────────────────────────────
  VERDICT: SUPPORTED  (confidence: high)
────────────────────────────────────────────────────────
 Multiple reputable outlets report the lunar landing took
 place in early 2024, consistent with the claim.

 Sources considered:
  [1] Private lander touches down on the Moon — bbc.com
  [2] Historic 2024 Moon mission succeeds — reuters.com
  ...
```

## Requirements

- Python 3.9+
- A **free** newsdata.io API key — get one at <https://newsdata.io/register>
- *(Optional)* An OpenAI API key for the GPT-4 assessment step

## Setup

```bash
git clone https://github.com/your-name/news-fact-checker.git
cd news-fact-checker
pip install -r requirements.txt
```

### Configure your API keys

The app reads keys from environment variables and **never** hardcodes them.

```bash
# Required: your newsdata.io key
export NEWSDATA_API_KEY="your_newsdata_key_here"

# Optional: enables the GPT-4 reasoning step.
# Without it, the tool falls back to a transparent keyword-overlap heuristic.
export OPENAI_API_KEY="your_openai_key_here"
```

On Windows (PowerShell):

```powershell
$env:NEWSDATA_API_KEY="your_newsdata_key_here"
$env:OPENAI_API_KEY="your_openai_key_here"
```

## Usage

```bash
# Basic
python main.py "The price of Bitcoin hit an all-time high this week"

# Restrict the news search
python main.py "There was a major earthquake" --country jp --language en

# Pull more articles as evidence (uses free-tier pagination)
python main.py "A new vaccine was approved" --max-articles 30

# Output a machine-readable result
python main.py "Inflation is falling" --json
```

### Options

| Flag | Description | Default |
|------|-------------|---------|
| `--country` | Two-letter country filter (e.g. `us`, `gb`, `in`) | none |
| `--language` | Language code (e.g. `en`, `es`) | `en` |
| `--category` | News category (e.g. `politics`, `science`) | none |
| `--max-articles` | Max articles to gather as evidence | `10` |
| `--json` | Print the full result as JSON | off |
| `--model` | OpenAI model to use | `gpt-4o` |

## How the GPT-4 step degrades gracefully

The GPT-4 assessment is **optional**. If `OPENAI_API_KEY` is not set, or the `openai`
package is not installed, or the API call fails, the tool automatically falls back to a
simple, fully transparent keyword-overlap heuristic so you always get a result.

## newsdata.io free tier & paid features

This project uses only **free-tier** endpoints and parameters:

- `GET /news` with `q`, `country`, `language`, `category`, and `page` pagination
  (via the `nextPage` token).

The following newsdata.io capabilities require a **paid plan** and are **not** used by
this tool, so free keys are never blocked:

- Sentiment analysis (`sentiment`)
- AI-enriched fields (`ai_tag`, `ai_region`, `ai_org`, `ai_summary`)
- The historical `/archive` endpoint and long date ranges
- Advanced full-text query operators

The client also handles `401` (invalid key), `429` (rate limit), `403/422`
("upgrade your plan") and empty results without crashing.

## License

MIT — see [LICENSE](LICENSE).
