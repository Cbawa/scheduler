"""Minimal client for the newsdata.io news API.

Built around the free-tier `/news` endpoint. Paid-only request features
(sentiment, ai_* fields, custom date ranges, advanced query operators) are
optional and degrade gracefully: if the key isn't on a paid plan the request
is retried without the paid params, so the core free flow keeps working.
"""
import os
import sys
import time

import requests

API_BASE = "https://newsdata.io/api/1"
NEWS_ENDPOINT = f"{API_BASE}/news"

# newsdata.io returns these statuses when a feature/param is paid-only.
_PAID_STATUS = {403, 422}


class NewsDataError(Exception):
    """Raised for unrecoverable newsdata.io API errors."""


def get_api_key():
    key = os.environ.get("NEWSDATA_API_KEY")
    if not key:
        sys.exit(
            "ERROR: NEWSDATA_API_KEY is not set.\n"
            "Get a free key at https://newsdata.io/register and run:\n"
            "  export NEWSDATA_API_KEY='your_key_here'"
        )
    return key


def _truthy(value):
    return str(value).strip().lower() in {"1", "true", "yes", "on"}


def fetch_news(
    query=None,
    language=None,
    country=None,
    category=None,
    pages=1,
    sentiment=False,
    ai_fields=False,
    from_date=None,
    to_date=None,
    qintitle=None,
):
    """Fetch up to `pages` pages of latest news.

    Returns a list of article dicts. Handles 401/429/empty results and
    paid-only params without crashing.
    """
    api_key = get_api_key()

    # Allow env vars to enable paid toggles as well as explicit args.
    sentiment = sentiment or _truthy(os.environ.get("ENABLE_SENTIMENT", ""))
    ai_fields = ai_fields or _truthy(os.environ.get("ENABLE_AI_FIELDS", ""))

    base_params = {"apikey": api_key}
    if qintitle:
        # Advanced full-text operator (paid). Falls back to `q` if rejected.
        base_params["qInTitle"] = qintitle
    elif query:
        base_params["q"] = query
    if language:
        base_params["language"] = language
    if country:
        base_params["country"] = country
    if category:
        base_params["category"] = category

    # --- Optional PAID params (showcased, OFF by default) ---
    paid_params = {}
    if sentiment:
        paid_params["sentiment"] = "positive,negative,neutral"
    if from_date:
        paid_params["from_date"] = from_date
    if to_date:
        paid_params["to_date"] = to_date
    # `ai_fields` only affects which response fields we read; no extra param needed,
    # but some plans accept a `full_content`/AI flag. We keep it informational here.

    articles = []
    next_page = None
    use_paid = bool(paid_params) or bool(qintitle)

    for page_num in range(1, max(1, pages) + 1):
        params = dict(base_params)
        if use_paid:
            params.update(paid_params)
        if next_page:
            params["page"] = next_page

        data = _request_with_fallback(params, use_paid, qintitle, query)
        if data is None:
            break
        # If paid params were stripped during fallback, stop sending them.
        if data.get("_paid_stripped"):
            use_paid = False
            qintitle = None

        results = data.get("results") or []
        if not results:
            print(f"  (page {page_num}: no results returned)")
        articles.extend(results)

        next_page = data.get("nextPage")
        if not next_page:
            break
        time.sleep(0.4)  # be gentle with the free-tier rate limit

    return articles


def _request_with_fallback(params, use_paid, qintitle, query):
    """Make one request; if paid params are rejected, retry without them."""
    try:
        resp = requests.get(NEWS_ENDPOINT, params=params, timeout=30)
    except requests.RequestException as exc:
        raise NewsDataError(f"Network error talking to newsdata.io: {exc}")

    if resp.status_code == 401:
        raise NewsDataError(
            "401 Unauthorized: your NEWSDATA_API_KEY is invalid. "
            "Check it at https://newsdata.io/dashboard"
        )
    if resp.status_code == 429:
        raise NewsDataError(
            "429 Too Many Requests: free-tier rate limit hit. "
            "Wait a bit and try again, or reduce --pages."
        )

    if resp.status_code in _PAID_STATUS and use_paid:
        # Paid feature not available on this plan -> strip and retry on free tier.
        print(
            "  NOTE: a requested feature needs a paid newsdata.io plan "
            f"(HTTP {resp.status_code}). Skipping it and continuing on the free tier.\n"
            "        See https://newsdata.io/pricing"
        )
        stripped = {
            k: v
            for k, v in params.items()
            if k not in {"sentiment", "from_date", "to_date", "qInTitle"}
        }
        if qintitle and query:
            stripped["q"] = query
        try:
            resp = requests.get(NEWS_ENDPOINT, params=stripped, timeout=30)
        except requests.RequestException as exc:
            raise NewsDataError(f"Network error talking to newsdata.io: {exc}")
        if resp.ok:
            data = resp.json()
            data["_paid_stripped"] = True
            return data

    if not resp.ok:
        raise NewsDataError(
            f"newsdata.io returned HTTP {resp.status_code}: {resp.text[:200]}"
        )

    try:
        return resp.json()
    except ValueError:
        raise NewsDataError("newsdata.io returned a non-JSON response.")
