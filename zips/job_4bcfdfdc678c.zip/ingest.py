"""Turn newsdata.io articles into a FAISS vector store using OpenAI embeddings."""
import os
import sys

from langchain_community.vectorstores import FAISS
from langchain_core.documents import Document
from langchain_openai import OpenAIEmbeddings

VECTOR_STORE_DIR = "vector_store"


def _require_openai_key():
    if not os.environ.get("OPENAI_API_KEY"):
        sys.exit(
            "ERROR: OPENAI_API_KEY is not set.\n"
            "Get one at https://platform.openai.com/api-keys and run:\n"
            "  export OPENAI_API_KEY='your_key_here'"
        )


def _safe(value, default="n/a"):
    """Render possibly-missing (e.g. paid-only) fields safely."""
    if value is None or value == "":
        return default
    if isinstance(value, (list, tuple)):
        return ", ".join(str(v) for v in value) if value else default
    return str(value)


def articles_to_documents(articles):
    """Convert newsdata.io article dicts into LangChain Documents.

    Paid-only fields (sentiment, ai_*) are included when present and shown as
    'n/a' otherwise, so free-tier articles are never dropped.
    """
    docs = []
    for art in articles:
        title = _safe(art.get("title"), "Untitled")
        description = _safe(art.get("description"), "")
        # ai_summary (paid) enriches the embedded text when available.
        ai_summary = _safe(art.get("ai_summary"), "")

        content_parts = [f"Title: {title}"]
        if description and description != "n/a":
            content_parts.append(f"Description: {description}")
        if ai_summary and ai_summary != "n/a":
            content_parts.append(f"AI summary: {ai_summary}")
        page_content = "\n".join(content_parts)

        metadata = {
            "title": title,
            "link": _safe(art.get("link")),
            "source": _safe(art.get("source_id")),
            "pub_date": _safe(art.get("pubDate")),
            # Paid-only fields (guarded -> 'n/a' if absent):
            "sentiment": _safe(art.get("sentiment")),
            "ai_tag": _safe(art.get("ai_tag")),
            "ai_region": _safe(art.get("ai_region")),
            "ai_org": _safe(art.get("ai_org")),
        }
        docs.append(Document(page_content=page_content, metadata=metadata))
    return docs


def build_vector_store(articles, persist_dir=VECTOR_STORE_DIR):
    """Build and persist a FAISS index from articles. Returns the count indexed."""
    _require_openai_key()

    docs = articles_to_documents(articles)
    if not docs:
        print("No articles to index. Try a broader query or more --pages.")
        return 0

    embed_model = os.environ.get("OPENAI_EMBED_MODEL", "text-embedding-3-small")
    embeddings = OpenAIEmbeddings(model=embed_model)

    print(f"Embedding {len(docs)} articles with '{embed_model}' ...")
    store = FAISS.from_documents(docs, embeddings)
    store.save_local(persist_dir)
    print(f"Saved FAISS index to ./{persist_dir}/")
    return len(docs)


def load_vector_store(persist_dir=VECTOR_STORE_DIR):
    """Load a previously persisted FAISS index."""
    _require_openai_key()
    if not os.path.isdir(persist_dir):
        sys.exit(
            f"No vector store found at ./{persist_dir}/.\n"
            "Run `python main.py ingest` first."
        )
    embed_model = os.environ.get("OPENAI_EMBED_MODEL", "text-embedding-3-small")
    embeddings = OpenAIEmbeddings(model=embed_model)
    return FAISS.load_local(
        persist_dir, embeddings, allow_dangerous_deserialization=True
    )
