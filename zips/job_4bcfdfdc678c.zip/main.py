"""CLI for the news RAG chatbot.

Commands:
  ingest   Fetch news from newsdata.io and build the FAISS vector store.
  ask      Ask a single question over the indexed news.
  chat     Start an interactive chat session.

The core flow works on a brand-new newsdata.io FREE key. Paid features are
optional, OFF by default, and documented in the README.
"""
import argparse
import sys

try:
    from dotenv import load_dotenv

    load_dotenv()
except ImportError:  # python-dotenv is optional at runtime
    pass

from chatbot import answer_question, chat_loop, format_sources
from ingest import build_vector_store
from newsdata_client import NewsDataError, fetch_news


def cmd_ingest(args):
    print("Fetching news from newsdata.io ...")
    try:
        articles = fetch_news(
            query=args.query,
            language=args.language,
            country=args.country,
            category=args.category,
            pages=args.pages,
            sentiment=args.sentiment,
            ai_fields=args.ai_fields,
            from_date=args.from_date,
            to_date=args.to_date,
            qintitle=args.qintitle,
        )
    except NewsDataError as exc:
        sys.exit(f"ERROR: {exc}")

    print(f"Fetched {len(articles)} articles.")
    count = build_vector_store(articles)
    if count:
        print(f"Done. {count} articles indexed. Try: python main.py ask \"...\"")


def cmd_ask(args):
    try:
        answer, sources = answer_question(args.question, k=args.k)
    except NewsDataError as exc:
        sys.exit(f"ERROR: {exc}")
    print("\nAnswer:")
    print(answer.strip() or "(no answer)")
    print("\nSources:")
    print(format_sources(sources))


def cmd_chat(args):
    chat_loop(k=args.k)


def build_parser():
    parser = argparse.ArgumentParser(
        description="RAG chatbot over today's news (newsdata.io + LangChain + OpenAI)."
    )
    sub = parser.add_subparsers(dest="command", required=True)

    p_ingest = sub.add_parser("ingest", help="Fetch news and build the vector store.")
    p_ingest.add_argument("--query", "-q", help="Free-text search (free tier `q`).")
    p_ingest.add_argument("--language", help="Language code, e.g. en.")
    p_ingest.add_argument("--country", help="Country code, e.g. us.")
    p_ingest.add_argument("--category", help="Category, e.g. technology, business.")
    p_ingest.add_argument(
        "--pages", type=int, default=1, help="Number of pages to fetch (default 1)."
    )
    # --- Optional paid-plan toggles (OFF by default) ---
    p_ingest.add_argument(
        "--sentiment",
        action="store_true",
        help="[PAID] Request sentiment analysis. Skipped gracefully on free plans.",
    )
    p_ingest.add_argument(
        "--ai-fields",
        dest="ai_fields",
        action="store_true",
        help="[PAID] Use ai_tag/ai_region/ai_org/ai_summary fields when present.",
    )
    p_ingest.add_argument(
        "--from-date", dest="from_date", help="[PAID] Start date YYYY-MM-DD."
    )
    p_ingest.add_argument(
        "--to-date", dest="to_date", help="[PAID] End date YYYY-MM-DD."
    )
    p_ingest.add_argument(
        "--qintitle",
        help="[PAID] Advanced title-only full-text query (qInTitle).",
    )
    p_ingest.set_defaults(func=cmd_ingest)

    p_ask = sub.add_parser("ask", help="Ask one question over the indexed news.")
    p_ask.add_argument("question", help="The question to ask.")
    p_ask.add_argument("-k", type=int, default=4, help="Top-k articles to retrieve.")
    p_ask.set_defaults(func=cmd_ask)

    p_chat = sub.add_parser("chat", help="Interactive chat session.")
    p_chat.add_argument("-k", type=int, default=4, help="Top-k articles to retrieve.")
    p_chat.set_defaults(func=cmd_chat)

    return parser


def main():
    parser = build_parser()
    args = parser.parse_args()
    args.func(args)


if __name__ == "__main__":
    main()
