# news-rag-chatbot

A **Retrieval-Augmented Generation (RAG)** chatbot that answers natural-language
questions about *today's* news. It pulls live articles from the
[newsdata.io](https://newsdata.io) news API, embeds them into a local
[FAISS](https://github.com/facebookresearch/faiss) vector store with OpenAI
embeddings, and uses [LangChain](https://www.langchain.com/) + OpenAI chat models
to answer your questions **grounded in the retrieved articles** (with sources).

```
  newsdata.io  ──►  ingest  ──►  FAISS vector store  ──►  retriever  ──►  LLM  ──►  answer + sources
   (/news)         (embed)        (local, on disk)        (top-k)      (OpenAI)
```

## Features

- 🔎 Fetches the latest news from newsdata.io (`/news`) with pagination.
- 🧠 Embeds article titles + descriptions with OpenAI embeddings into FAISS.
- 💬 Asks questions over the indexed news with a LangChain `RetrievalQA` chain.
- 📚 Every answer cites the source articles (title + link) it relied on.
- 🆓 Runs end-to-end on a **brand-new newsdata.io FREE key** — no paid plan required.
- ⭐ Optional, OFF-by-default toggles that showcase newsdata.io **paid** features.

## Requirements

- Python 3.9+
- A free **newsdata.io** API key — get one at <https://newsdata.io/register>
- An **OpenAI** API key — get one at <https://platform.openai.com/api-keys>

## Setup

```bash
git clone https://github.com/your-username/news-rag-chatbot.git
cd news-rag-chatbot

python -m venv .venv
source .venv/bin/activate        # Windows: .venv\Scripts\activate
pip install -r requirements.txt
```

Set your API keys as environment variables (the app reads them and exits with a
clear message if either is missing):

```bash
export NEWSDATA_API_KEY="your_newsdata_key_here"
export OPENAI_API_KEY="your_openai_key_here"
```

You can also copy `.env.example` to `.env` and fill in the values — the app loads
`.env` automatically.

## Usage

### 1. Ingest today's news into the vector store

```bash
# Fetch general top news (free tier)
python main.py ingest

# Narrow it down with free query params
python main.py ingest --query "artificial intelligence" --language en --country us --category technology --pages 2
```

This writes a FAISS index to `./vector_store/`.

### 2. Ask questions

```bash
# One-off question
python main.py ask "What are the latest developments in AI regulation?"

# Interactive chat session
python main.py chat
```

Example:

```
$ python main.py ask "What happened with the stock market today?"

Answer:
According to the indexed articles, ...

Sources:
  [1] Markets rally on rate-cut hopes — https://example.com/markets
  [2] Tech stocks lead gains — https://example.com/tech
```

## Optional paid-plan features (newsdata.io)

The core flow above works on the **free** tier. The features below showcase what
newsdata.io's **paid** plans unlock. They are all **OFF by default**, gated behind
explicit flags/env vars, and **degrade gracefully** — if your key isn't on a paid
plan, the app detects the "upgrade your plan" response, prints a friendly notice,
skips the feature, and keeps working.

| Feature | How to enable | What it does |
|---|---|---|
| **Sentiment analysis** | `--sentiment` flag on `ingest`, or `ENABLE_SENTIMENT=1` | Requests the `sentiment` field/param and stores each article's sentiment in the vector metadata so answers can reference tone. |
| **AI tags / region / org / summary** | `--ai-fields` flag on `ingest`, or `ENABLE_AI_FIELDS=1` | Requests `ai_tag`, `ai_region`, `ai_org`, `ai_summary` and folds `ai_summary` into the embedded text for richer retrieval. |
| **Historical / date range** | `--from-date YYYY-MM-DD --to-date YYYY-MM-DD` | Uses long/custom date ranges (the historical `/archive`-style window) when ingesting. |
| **Title-only / advanced query** | `--qintitle "..."` | Sends the `qInTitle` advanced full-text operator instead of a plain `q`. |

> Any paid-only response field (`sentiment`, `ai_*`) is treated as possibly absent
> and rendered as `n/a` when missing, so a free-tier run is never broken.

Learn more / upgrade: <https://newsdata.io/pricing>

## How it works

- `newsdata_client.py` — thin client for newsdata.io `/news` with pagination and
  graceful handling of `401` (bad key), `429` (rate limit), `403/422` (paid-only),
  and empty results.
- `ingest.py` — turns articles into LangChain `Document`s and builds/saves a FAISS index.
- `chatbot.py` — loads the index and runs a `RetrievalQA` chain over it.
- `main.py` — the CLI tying it together (`ingest`, `ask`, `chat`).

## Environment variables

| Variable | Required | Description |
|---|---|---|
| `NEWSDATA_API_KEY` | ✅ | Your newsdata.io API key. |
| `OPENAI_API_KEY` | ✅ | Your OpenAI API key (embeddings + chat). |
| `OPENAI_CHAT_MODEL` | ❌ | Chat model (default `gpt-4o-mini`). |
| `OPENAI_EMBED_MODEL` | ❌ | Embedding model (default `text-embedding-3-small`). |
| `ENABLE_SENTIMENT` | ❌ | `1` to request paid sentiment (same as `--sentiment`). |
| `ENABLE_AI_FIELDS` | ❌ | `1` to request paid `ai_*` fields (same as `--ai-fields`). |

## License

MIT — see `LICENSE`. Built as a community showcase for the newsdata.io news API.
