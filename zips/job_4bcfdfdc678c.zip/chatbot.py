"""RAG question-answering over the indexed news using LangChain + OpenAI."""
import os

from langchain.chains import RetrievalQA
from langchain_core.prompts import PromptTemplate
from langchain_openai import ChatOpenAI

from ingest import load_vector_store

_PROMPT = PromptTemplate(
    input_variables=["context", "question"],
    template=(
        "You are a helpful news assistant. Answer the question using ONLY the "
        "news context below. If the context does not contain the answer, say you "
        "don't have enough information from today's news.\n\n"
        "News context:\n{context}\n\n"
        "Question: {question}\n\n"
        "Answer:"
    ),
)


def _build_chain(k=4):
    store = load_vector_store()
    retriever = store.as_retriever(search_kwargs={"k": k})
    chat_model = os.environ.get("OPENAI_CHAT_MODEL", "gpt-4o-mini")
    llm = ChatOpenAI(model=chat_model, temperature=0)
    chain = RetrievalQA.from_chain_type(
        llm=llm,
        chain_type="stuff",
        retriever=retriever,
        return_source_documents=True,
        chain_type_kwargs={"prompt": _PROMPT},
    )
    return chain


def answer_question(question, k=4):
    """Return (answer_text, list_of_source_docs) for a question."""
    chain = _build_chain(k=k)
    result = chain.invoke({"query": question})
    return result.get("result", ""), result.get("source_documents", [])


def format_sources(source_docs):
    """Format retrieved documents as a readable source list."""
    if not source_docs:
        return "  (no sources retrieved)"
    lines = []
    seen = set()
    idx = 1
    for doc in source_docs:
        meta = doc.metadata or {}
        link = meta.get("link", "n/a")
        if link in seen:
            continue
        seen.add(link)
        title = meta.get("title", "Untitled")
        extras = []
        if meta.get("sentiment", "n/a") not in ("n/a", ""):
            extras.append(f"sentiment: {meta['sentiment']}")
        if meta.get("ai_tag", "n/a") not in ("n/a", ""):
            extras.append(f"tags: {meta['ai_tag']}")
        suffix = f"  ({'; '.join(extras)})" if extras else ""
        lines.append(f"  [{idx}] {title} — {link}{suffix}")
        idx += 1
    return "\n".join(lines)


def chat_loop(k=4):
    """Interactive REPL over the indexed news."""
    print("News RAG chatbot. Ask about today's news. Type 'exit' or 'quit' to leave.\n")
    chain = _build_chain(k=k)
    while True:
        try:
            question = input("you> ").strip()
        except (EOFError, KeyboardInterrupt):
            print("\nBye!")
            break
        if not question:
            continue
        if question.lower() in {"exit", "quit"}:
            print("Bye!")
            break
        result = chain.invoke({"query": question})
        print("\nbot> " + result.get("result", "").strip())
        print("\nSources:")
        print(format_sources(result.get("source_documents", [])))
        print()
