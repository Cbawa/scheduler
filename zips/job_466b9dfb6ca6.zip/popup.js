// Popup logic: load preferences, fetch latest news from newsdata.io,
// and render the top 5 headlines. Built for the FREE newsdata.io tier.

const API_BASE = "https://newsdata.io/api/1/news";
const MAX_HEADLINES = 5;

const DEFAULTS = {
  apiKey: "",
  category: "top",
  country: "us",
  language: "en",
};

const contentEl = document.getElementById("content");
const metaEl = document.getElementById("meta");

function getPrefs() {
  return new Promise((resolve) => {
    chrome.storage.sync.get(DEFAULTS, (items) => resolve(items));
  });
}

function setStatus(message, isError = false) {
  contentEl.innerHTML = "";
  const p = document.createElement("p");
  p.className = "status" + (isError ? " error" : "");
  p.textContent = message;
  contentEl.appendChild(p);
}

function setStatusWithSettings(message) {
  setStatus(message, true);
  const btn = document.createElement("button");
  btn.className = "link-btn";
  btn.textContent = "Open settings";
  btn.style.display = "block";
  btn.style.margin = "10px auto 0";
  btn.addEventListener("click", () => chrome.runtime.openOptionsPage());
  contentEl.appendChild(btn);
}

function formatDate(pubDate) {
  if (!pubDate) return "";
  // newsdata.io returns e.g. "2024-01-31 12:34:56" (UTC)
  const iso = pubDate.replace(" ", "T") + "Z";
  const d = new Date(iso);
  if (isNaN(d.getTime())) return pubDate;
  return d.toLocaleString(undefined, {
    month: "short",
    day: "numeric",
    hour: "2-digit",
    minute: "2-digit",
  });
}

function renderArticles(results) {
  contentEl.innerHTML = "";
  const items = results.slice(0, MAX_HEADLINES);

  if (items.length === 0) {
    setStatus("No headlines found for your preferences. Try a different category or country in settings.");
    return;
  }

  for (const item of items) {
    const a = document.createElement("a");
    a.className = "article";
    a.href = item.link || "#";
    a.target = "_blank";
    a.rel = "noopener";

    const title = document.createElement("p");
    title.className = "article-title";
    title.textContent = item.title || "(untitled)";

    const sub = document.createElement("p");
    sub.className = "article-sub";
    const source = item.source_id ? item.source_id : "unknown source";
    const when = formatDate(item.pubDate);
    sub.textContent = when ? `${source} \u00b7 ${when}` : source;

    a.appendChild(title);
    a.appendChild(sub);
    contentEl.appendChild(a);
  }
}

function buildUrl(prefs) {
  const params = new URLSearchParams();
  params.set("apikey", prefs.apiKey);
  if (prefs.language) params.set("language", prefs.language);
  if (prefs.category && prefs.category !== "top") {
    params.set("category", prefs.category);
  } else {
    params.set("category", "top");
  }
  if (prefs.country && prefs.country !== "any") {
    params.set("country", prefs.country);
  }
  return `${API_BASE}?${params.toString()}`;
}

async function loadHeadlines() {
  setStatus("Loading headlines\u2026");
  metaEl.textContent = "";

  const prefs = await getPrefs();

  if (!prefs.apiKey) {
    setStatusWithSettings("No API key set. Add your newsdata.io API key in settings to get started.");
    return;
  }

  const url = buildUrl(prefs);

  let response;
  try {
    response = await fetch(url);
  } catch (err) {
    setStatus("Network error. Check your internet connection and try again.", true);
    return;
  }

  // Handle non-OK responses without crashing.
  if (!response.ok) {
    let payload = {};
    try {
      payload = await response.json();
    } catch (_) {
      /* ignore non-JSON error bodies */
    }
    const apiMessage =
      (payload && payload.results && payload.results.message) ||
      (payload && payload.message) ||
      "";

    switch (response.status) {
      case 401:
        setStatusWithSettings("Invalid API key (401). Double-check your newsdata.io key in settings.");
        return;
      case 429:
        setStatus("Rate limit reached (429). The free plan has limited requests \u2014 please wait a bit and try again.", true);
        return;
      case 403:
      case 422:
        // Typically a paid-only feature / parameter on the free plan.
        setStatus(
          apiMessage
            ? `newsdata.io: ${apiMessage}`
            : "This request needs a paid newsdata.io plan. Reverting to free-tier defaults \u2014 try simpler preferences.",
          true
        );
        return;
      default:
        setStatus(`Request failed (${response.status}). ${apiMessage}`.trim(), true);
        return;
    }
  }

  let data;
  try {
    data = await response.json();
  } catch (err) {
    setStatus("Could not parse the response from newsdata.io.", true);
    return;
  }

  if (data.status && data.status !== "success") {
    const msg = (data.results && data.results.message) || "Unknown API error.";
    setStatus(`newsdata.io: ${msg}`, true);
    return;
  }

  const results = Array.isArray(data.results) ? data.results : [];
  renderArticles(results);

  const total = typeof data.totalResults === "number" ? data.totalResults : results.length;
  const shown = Math.min(results.length, MAX_HEADLINES);
  const catLabel = prefs.category || "top";
  const countryLabel = prefs.country && prefs.country !== "any" ? prefs.country.toUpperCase() : "Global";
  metaEl.textContent = `${catLabel} \u00b7 ${countryLabel} \u00b7 showing ${shown} of ${total}`;
}

document.getElementById("refresh").addEventListener("click", loadHeadlines);
document.getElementById("open-options").addEventListener("click", (e) => {
  e.preventDefault();
  chrome.runtime.openOptionsPage();
});

document.addEventListener("DOMContentLoaded", loadHeadlines);
