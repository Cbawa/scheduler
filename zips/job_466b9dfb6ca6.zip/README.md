# NewsData Chrome Extension

A lightweight **Manifest V3** Chrome extension that displays the **top 5 latest headlines** in its popup, powered by the [newsdata.io](https://newsdata.io) news API. Pick your preferred **category** and **country** on the options page and get a fresh news digest every time you click the toolbar icon.

![Manifest V3](https://img.shields.io/badge/Manifest-V3-blue) ![JavaScript](https://img.shields.io/badge/JavaScript-ES2020-yellow)

## Features

- 🗞️ Top 5 latest headlines in a clean popup
- 🌍 Customizable **country** preference
- 🏷️ Customizable **category** preference (business, technology, sports, …)
- 🔄 One-click refresh
- 🔗 Click any headline to open the full article in a new tab
- 🛡️ Graceful handling of invalid keys, rate limits, empty results, and paid-only feature errors
- 💾 Preferences synced via `chrome.storage.sync`
- ✅ **Works on the newsdata.io FREE plan** — no paid features required

## Getting your API key

1. Create a free account at [newsdata.io](https://newsdata.io/register).
2. Copy your API key from the [dashboard](https://newsdata.io/dashboard).

> ⚠️ Browser extensions cannot read shell environment variables. In a server-side project you would supply the key via the `NEWSDATA_API_KEY` environment variable; in this client-side extension you instead paste the key once on the **Options** page, where it is stored locally in `chrome.storage.sync`. The key is **never** hardcoded in the source.

## Installation (load unpacked)

1. Clone this repository:
   ```bash
   git clone https://github.com/your-username/newsdata-chrome-extension.git
   ```
2. Open Chrome and navigate to `chrome://extensions`.
3. Toggle **Developer mode** on (top-right).
4. Click **Load unpacked** and select the cloned `newsdata-chrome-extension` folder.
5. Click the extension icon, then the **gear / Options** link, and paste your API key.
6. (Optional) Choose a category and country, then **Save**.
7. Click the toolbar icon to see your headlines!

## Configuration

All preferences are set on the **Options** page and stored in `chrome.storage.sync`:

| Setting   | Description                                  | Default     |
|-----------|----------------------------------------------|-------------|
| API key   | Your newsdata.io API key                     | _(required)_ |
| Category  | News category to filter by                   | `top`       |
| Country   | Two-letter country code (or *Any*)           | `us`        |

## How it works

The popup calls the newsdata.io **Latest news** endpoint:

```
GET https://newsdata.io/api/1/news?apikey=YOUR_KEY&category=technology&country=us&language=en
```

It reads the `results` array from the JSON response and renders the first 5 items (`title`, `source_id`, `pubDate`, `link`).

## Free vs. paid plan

This extension is built entirely around endpoints and parameters available on the **free** newsdata.io tier (`/news` with `category`, `country`, `language`).

The following are **paid-only** and are intentionally **not** used:

- Sentiment analysis and AI fields (`sentiment`, `ai_tag`, `ai_region`, `ai_org`, `ai_summary`)
- The historical `/archive` endpoint and long date ranges
- Advanced full-text query operators

If newsdata.io returns a `403`/`422` "upgrade your plan" error (for example if you add a paid-only parameter), the extension detects it and shows a friendly message instead of breaking. Invalid keys (`401`) and rate limits (`429`) are likewise handled gracefully.

## Project structure

```
.
├── manifest.json     # MV3 manifest
├── popup.html        # Popup markup
├── popup.css         # Popup styles
├── popup.js          # Fetch + render headlines
├── options.html      # Preferences page
├── options.js        # Load/save preferences
└── .gitignore
```

## License

MIT

---

Built as a showcase for the [newsdata.io](https://newsdata.io) news API.
