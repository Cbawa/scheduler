// Load and persist user preferences in chrome.storage.sync.

const DEFAULTS = {
  apiKey: "",
  category: "top",
  country: "us",
  language: "en",
};

const fields = ["apiKey", "category", "country", "language"];

function restore() {
  chrome.storage.sync.get(DEFAULTS, (items) => {
    for (const key of fields) {
      const el = document.getElementById(key);
      if (el && items[key] !== undefined) {
        el.value = items[key];
      }
    }
  });
}

function save() {
  const prefs = {};
  for (const key of fields) {
    const el = document.getElementById(key);
    prefs[key] = el ? el.value.trim() : DEFAULTS[key];
  }

  chrome.storage.sync.set(prefs, () => {
    const status = document.getElementById("status");
    status.hidden = false;
    setTimeout(() => {
      status.hidden = true;
    }, 1800);
  });
}

document.addEventListener("DOMContentLoaded", restore);
document.getElementById("save").addEventListener("click", save);
