"""The request/response contract this app implements, as data.

App builders are good at screens and bad at API contracts, so instead of
letting one guess, hand it this. `build()` returns a JSON-serialisable dict;
`app.py --export-blueprint` writes it to a file and the running app serves it
at /api/blueprint.
"""

from __future__ import annotations

from typing import Any, Dict, List, Optional

from newsdata_client import BASE_URL, LATEST_PATH, paid_mode_enabled

# field -> plan that populates it -> where this app puts it
ARTICLE_FIELDS: List[Dict[str, str]] = [
    {"field": "article_id", "plan": "free", "ui": "list key"},
    {"field": "title", "plan": "free", "ui": "card headline, links to `link`"},
    {"field": "link", "plan": "free", "ui": "headline href, opens in a new tab"},
    {"field": "description", "plan": "free", "ui": "card body, used when ai_summary is empty"},
    {"field": "pubDate", "plan": "free", "ui": "relative timestamp; UTC, format 'YYYY-MM-DD HH:MM:SS'"},
    {"field": "source_name", "plan": "free", "ui": "byline (fall back to source_id)"},
    {"field": "source_icon", "plan": "free", "ui": "optional favicon next to the byline"},
    {"field": "image_url", "plan": "free", "ui": "card thumbnail; hide the element on load error"},
    {"field": "keywords", "plan": "free", "ui": "chips under the card + ranked keyword panel; may be null"},
    {"field": "category", "plan": "free", "ui": "array, used for filter state"},
    {"field": "country", "plan": "free", "ui": "array, shown on hover"},
    {"field": "language", "plan": "free", "ui": "filter state"},
    {"field": "sentiment", "plan": "paid", "ui": "badge on the card; one of positive/neutral/negative"},
    {"field": "sentiment_stats", "plan": "paid", "ui": "per-article confidence split"},
    {"field": "ai_tag", "plan": "paid", "ui": "accent-coloured chips, shown before keywords"},
    {"field": "ai_region", "plan": "paid", "ui": "optional geography chip"},
    {"field": "ai_org", "plan": "paid", "ui": "optional organisation chip"},
    {"field": "ai_summary", "plan": "paid", "ui": "one-line summary, replaces description when present"},
    {"field": "content", "plan": "paid", "ui": "not used here"},
]

BUILDER_PROMPT = """Build a single-page news reader with these exact bindings.

Data source: the newsdata.io news API. Do NOT call it from the browser. Put the
request behind your own backend/server action so the API key stays server-side;
read the key from an environment variable called NEWSDATA_API_KEY.

Request
  GET https://newsdata.io/api/1/latest
  auth: apikey=<key> as a query parameter (or an X-ACCESS-KEY header)
  parameters you may send on any plan: q, country, category, language, domain, page
  do NOT send: size, timeframe, from_date, to_date, full_content, sentiment, tag,
  region, organization, removeduplicate -- on a free key any one of these makes the
  whole request fail with 403/422, not just that filter.

Pagination
  The response has a `nextPage` string. To load the next page, send it back as
  `page`. When `nextPage` is null there are no more results: hide the load-more
  control. Never compute page numbers yourself.

Errors to handle explicitly
  401 -> "invalid API key" message, no retry
  429 -> "rate limited, try again shortly", no retry loop
  200 with an empty `results` array -> empty state, not an error

Screen
  Header: search box (-> q), category select, country select, language select.
  Feed: one card per item in `results` with thumbnail (image_url), source_name,
  relative time from pubDate (UTC, 'YYYY-MM-DD HH:MM:SS'), title linking to link,
  and description.
  Under each card: chips from `keywords` (this array is present on every plan;
  make each chip search that term).
  If `sentiment` is a non-empty string, show it as a coloured badge
  (positive/neutral/negative). If `ai_tag` is a non-empty array, show those as a
  second, visually distinct row of chips. If `ai_summary` is a non-empty string,
  show it in place of description with a small "ai_summary" label.
  Sidebar: ranked keyword list built from all loaded articles, and a sentiment
  breakdown bar.

Empty-field rule (important)
  sentiment, sentiment_stats, ai_tag, ai_region, ai_org and ai_summary are only
  populated on paid newsdata.io plans. Requesting them is safe; they arrive null
  or absent otherwise. Treat every one as optional: never assume an array, never
  index into it, and never render an empty box. If the sentiment breakdown has no
  data, keep the widget visible with placeholder proportions and a caption that
  says the values are a sample and live sentiment needs a paid plan -- do not pass
  placeholder numbers off as API output.
  Some plans return the literal string "ONLY AVAILABLE IN ..." instead of null for
  these fields; discard any value containing that phrase before rendering.
"""


def build(paid_mode: Optional[bool] = None) -> Dict[str, Any]:
    if paid_mode is None:
        paid_mode = paid_mode_enabled()

    return {
        "generated_by": "ai-news-app-blueprint",
        "purpose": "Request/response contract for a news reader, written for AI and no-code app builders.",
        "data_source": {
            "name": "newsdata.io",
            "site": "https://newsdata.io",
            "base_url": BASE_URL,
            "endpoint": LATEST_PATH,
            "method": "GET",
            "auth": {
                "query_param": "apikey",
                "header_alternative": "X-ACCESS-KEY",
                "env_var": "NEWSDATA_API_KEY",
                "note": "Call the API from a server, not the browser; the key must not ship to the client.",
            },
        },
        "request": {
            "free_parameters": [
                {"name": "q", "type": "string", "note": "free-text search, keep it under 100 characters"},
                {"name": "category", "type": "string", "note": "e.g. technology, business, sports"},
                {"name": "country", "type": "string", "note": "two-letter code, e.g. us, gb, in"},
                {"name": "language", "type": "string", "note": "two-letter code, e.g. en, es, de"},
                {"name": "domain", "type": "string", "note": "restrict to specific publishers"},
                {"name": "page", "type": "string", "note": "the nextPage cursor from the previous response"},
            ],
            "paid_only_parameters": [
                {"name": "size", "note": "values above 10 require a paid plan"},
                {"name": "timeframe", "note": "paid plan only"},
                {"name": "from_date", "note": "paid plan only"},
                {"name": "to_date", "note": "paid plan only"},
                {"name": "full_content", "note": "paid plan only"},
                {"name": "sentiment", "note": "paid plan only (as a filter; the response field is separate)"},
                {"name": "tag", "note": "paid plan only"},
                {"name": "region", "note": "paid plan only"},
                {"name": "organization", "note": "paid plan only"},
                {"name": "removeduplicate", "note": "paid plan only"},
            ],
            "failure_mode": "Sending any paid-only parameter with a free key fails the entire request (403/422). "
                            "Drop them and retry rather than surfacing an error.",
            "currently_sending_paid_parameters": bool(paid_mode),
        },
        "pagination": {
            "style": "opaque cursor",
            "cursor_field": "nextPage",
            "send_as": "page",
            "stop_when": "nextPage is null or missing",
        },
        "response": {
            "top_level": [
                {"field": "status", "note": "'success' or 'error'; can be 'error' even on HTTP 200"},
                {"field": "totalResults", "note": "integer, matches across pages"},
                {"field": "results", "note": "array of articles; may be empty, which is not an error"},
                {"field": "nextPage", "note": "cursor for the next page, or null"},
            ],
            "article_fields": ARTICLE_FIELDS,
            "degradation_rule": "Fields marked paid arrive null/absent on a free key. Guard every read; "
                                "discard values containing 'ONLY AVAILABLE IN'. Keep the widget visible with a "
                                "clearly labelled sample rather than rendering an empty box.",
        },
        "http_handling": {
            "401": "invalid or missing key -- show a message, do not retry",
            "403": "plan restriction -- drop paid parameters and retry once",
            "422": "unsupported parameter for this plan -- same as 403",
            "429": "rate limited -- back off, do not loop",
            "200 with empty results": "empty state",
        },
        "builder_prompt": BUILDER_PROMPT,
    }
