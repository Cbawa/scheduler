# ai-news-app-blueprint

A news reader that runs from one command, plus the exact API contract it uses exported as JSON — so an AI app builder can rebuild the UI without inventing parameter names.

Headlines come from the newsdata.io news API (https://newsdata.io); a free API key covers everything on the default path.

## Why this exists

Lovable, v0, FlutterFlow and Bubble will happily draw a news app in a couple of minutes. What they get wrong is the boring half: they guess query parameter names, skip the pagination cursor, bind UI to response fields the plan doesn't return, and paste the API key straight into browser code where anyone can read it.

So this repo is two things stapled together:

1. `app.py` — a small Flask backend that keeps the key server-side, and a plain HTML/JS front end that reads every field the API returns.
2. `blueprint.py` — the same contract, as data: endpoint, free parameters, paid parameters, the `nextPage` rule, and each response field tagged with the plan that provides it. A paste-ready prompt for your builder is included in the JSON.

Generate the screens however you like; take the wiring from here.

## What it does

- Latest headlines with free-text search plus category, country and language filters
- Cursor pagination — "load more" sends the previous `nextPage` value back as `page`, and stops when it comes back null
- Keyword chips from the `keywords` field (present on every plan); click one to search it
- Sentiment badges, a sentiment breakdown bar, AI tag chips and AI summary lines when the key returns those fields
- A "fields on this key" panel that counts, per response field, how many of the loaded articles actually carry it
- 401, 429, empty results and paid-only parameters all handled as messages, not stack traces
- A `--check` CLI that reports what your key returns before you build anything on it

## Setup

```bash
git clone https://github.com/<you>/ai-news-app-blueprint.git
cd ai-news-app-blueprint
python -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt
```

The key is read from `NEWSDATA_API_KEY` and is never written to disk or sent to the browser. Register at https://newsdata.io for a free key, then:

```bash
export NEWSDATA_API_KEY=your_key_here
```

## Running it

```bash
python app.py                 # http://127.0.0.1:5000
python app.py --port 8080     # or set PORT / HOST
```

The server is the only thing that talks to the news API; the front end calls `/api/news` on your own origin.

## Checking a key

`--check` makes real requests, walks the pagination cursor, and prints what came back. Useful for finding out which fields your plan populates before you wire a UI to them.

```console
$ python app.py --check --pages 2
newsdata.io GET /1/latest   paid mode: off
  request: language=en

  page 1  ->  10 articles   totalResults=2143   nextPage=1751284800...
  page 2  ->  10 articles   totalResults=2143   nextPage=1751281200...

field availability on this key (20 articles)
  keywords     20/20
  sentiment    0/20   requires a paid newsdata.io plan
  ai_tag       0/20   requires a paid newsdata.io plan
  ai_summary   0/20   requires a paid newsdata.io plan

latest headlines
  1. Chip maker lifts outlook after data-centre orders  --  Reuters
  2. Storm warnings extended along the south coast  --  BBC News
  3. Council approves transit funding package  --  CBC News
  4. Regulators open review of clearing-house rules  --  Financial Times
  5. Two teams tied at the top with three games left  --  ESPN
```

## The blueprint

```console
$ python app.py --export-blueprint blueprint.json
wrote blueprint.json
```

No API key needed for that command. The file describes the request (`GET https://newsdata.io/api/1/latest`, auth via the `apikey` query parameter or the `X-ACCESS-KEY` header), which parameters are safe on a free key, which ones fail the whole request, how the `nextPage` cursor works, and a field-by-field mapping to UI elements. `builder_prompt` inside it is written to be pasted into an app builder as-is; the same JSON is viewable in the running app under "Builder blueprint".

## Configuration

| Variable | Default | Meaning |
| --- | --- | --- |
| `NEWSDATA_API_KEY` | — | Required. The app refuses to start without it. |
| `NEWSDATA_PAID_MODE` | `0` | Set to `1` to send paid-only query parameters. Requires a paid newsdata.io plan. |
| `NEWSDATA_PAGE_SIZE` | `20` | Paid mode only, clamped to 1–50. Free keys must not send `size` above 10, so it is omitted entirely by default. |
| `NEWSDATA_TIMEFRAME` | unset | Paid mode only, e.g. `6` for the last six hours. |
| `NEWSDATA_SENTIMENT` | unset | Paid mode only: `positive`, `neutral` or `negative` to filter server-side. |
| `HOST` / `PORT` | `127.0.0.1` / `5000` | Bind address. |

If paid mode is on and the key turns out not to allow those parameters, the request is retried once without them and the reason is shown under the filter bar, so you still get articles.

## Free and paid fields

Two different things are easy to confuse here, and getting them backwards is what breaks generated apps:

- **Response fields** — `sentiment`, `sentiment_stats`, `ai_tag`, `ai_region`, `ai_org`, `ai_summary`, `content`. Asking for them is always fine; on a free key they simply arrive empty (sometimes as a literal `"ONLY AVAILABLE IN ..."` string, which this client filters out so it never reaches the UI). Everything here reads them defensively.
- **Query parameters** — `sentiment=`, `tag=`, `timeframe=`, `from_date=`, `full_content=`, `size` above 10, and the `/archive` and `/count` endpoints. Sending any of these on a free key returns an error for the *entire* request. They live behind `NEWSDATA_PAID_MODE`.

`keywords` is on every plan and does most of the visible work: chips per article and a ranked keyword panel for the loaded feed.

Where a paid field is empty, the widget stays on screen rather than collapsing — the sentiment bar renders placeholder proportions with a `sample` tag and a caption saying the values are not live. Nothing invented is presented as real API output.

## Layout

```
app.py               Flask routes, request validation, CLI (--check, --export-blueprint)
newsdata_client.py   the only module that talks to newsdata.io; errors, retries, normalisation
blueprint.py         the request/response contract as data, plus the builder prompt
templates/index.html markup and styles
static/app.js        rendering, aggregation, pagination
```

`/api/news` accepts `q`, `category`, `country`, `language` and `page`, validates them against known values, and returns normalised articles plus the parameters that were actually sent. `/api/blueprint` returns the same JSON as the export command.

## Notes

- Free keys are rate limited. A 429 surfaces as a one-line message in the UI and a non-zero exit from `--check`.
- Article images are loaded straight from the publisher; broken ones are removed from the card rather than left as an icon.
- No build step, no bundler, no framework on the front end — it is one JS file, and the point is that it stays readable enough to translate into whatever your builder emits.
- MIT licensed.
