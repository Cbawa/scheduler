#!/usr/bin/env python3
"""Flask server and CLI for a newsdata.io-backed news reader.

  python app.py                      start the web app
  python app.py --check --pages 2    report what the current key returns
  python app.py --export-blueprint   write the API contract to blueprint.json
"""

from __future__ import annotations

import argparse
import json
import os
import sys
from collections import Counter
from typing import Any, Dict, List, Optional

from flask import Flask, jsonify, render_template, request

import blueprint
from newsdata_client import (
    LATEST_PATH,
    NewsdataError,
    fetch_latest,
    iter_articles,
    paid_mode_enabled,
)

app = Flask(__name__)

CATEGORIES = [
    "top", "world", "business", "technology", "science", "health", "sports",
    "entertainment", "politics", "environment", "education", "food",
    "lifestyle", "tourism", "crime", "domestic", "other",
]

COUNTRIES = [
    ("", "Any country"),
    ("us", "United States"), ("gb", "United Kingdom"), ("in", "India"),
    ("ca", "Canada"), ("au", "Australia"), ("ie", "Ireland"),
    ("de", "Germany"), ("fr", "France"), ("es", "Spain"), ("it", "Italy"),
    ("br", "Brazil"), ("mx", "Mexico"), ("jp", "Japan"), ("sg", "Singapore"),
    ("za", "South Africa"), ("ae", "United Arab Emirates"), ("ng", "Nigeria"),
]

LANGUAGES = [
    ("", "Any language"),
    ("en", "English"), ("es", "Spanish"), ("fr", "French"), ("de", "German"),
    ("pt", "Portuguese"), ("it", "Italian"), ("nl", "Dutch"), ("hi", "Hindi"),
    ("ar", "Arabic"), ("ja", "Japanese"), ("zh", "Chinese"), ("ru", "Russian"),
]

TRACKED_FIELDS = (("keywords", "free"), ("sentiment", "paid"), ("ai_tag", "paid"), ("ai_summary", "paid"))


def _pick(value: Optional[str], allowed) -> Optional[str]:
    """Only forward values we recognise -- junk filters just cause 422s."""
    cleaned = (value or "").strip().lower()
    return cleaned if cleaned and cleaned in allowed else None


@app.get("/")
def index():
    return render_template(
        "index.html",
        categories=CATEGORIES,
        countries=COUNTRIES,
        languages=LANGUAGES,
        paid_mode=paid_mode_enabled(),
    )


@app.get("/api/news")
def api_news():
    args = request.args
    try:
        batch = fetch_latest(
            q=(args.get("q") or "").strip() or None,
            category=_pick(args.get("category"), CATEGORIES),
            country=_pick(args.get("country"), [code for code, _ in COUNTRIES if code]),
            language=_pick(args.get("language"), [code for code, _ in LANGUAGES if code]),
            page=(args.get("page") or "").strip() or None,
        )
    except NewsdataError as exc:
        if exc.status in (401, 429):
            code = exc.status
        elif exc.status is None:
            code = 500  # local configuration problem, e.g. no API key
        else:
            code = 502
        return jsonify({"error": exc.message, "status": exc.status, "retryable": exc.retryable}), code
    return jsonify(batch)


@app.get("/api/blueprint")
def api_blueprint():
    return jsonify(blueprint.build())


# --------------------------------------------------------------------------- #
# CLI
# --------------------------------------------------------------------------- #

def _short(cursor: Optional[str]) -> str:
    if not cursor:
        return "null (end of results)"
    text = str(cursor)
    return text if len(text) <= 14 else text[:14] + "..."


def run_check(pages: int, language: str, query: Optional[str]) -> int:
    counters: Counter = Counter()
    seen = 0
    headlines: List[str] = []

    print("newsdata.io GET %s   paid mode: %s" % (LATEST_PATH, "on" if paid_mode_enabled() else "off"))
    try:
        for index, batch in enumerate(iter_articles(pages=pages, language=language or None, q=query), start=1):
            if index == 1:
                shown = ", ".join("%s=%s" % (k, v) for k, v in sorted(batch["request"].items())) or "(no filters)"
                print("  request: %s" % shown)
                print("")
            print("  page %d  ->  %d articles   totalResults=%s   nextPage=%s"
                  % (index, len(batch["articles"]), batch["total"], _short(batch["next_page"])))
            for note in batch["notes"]:
                print("  note: %s" % note)
            for article in batch["articles"]:
                seen += 1
                for field, _plan in TRACKED_FIELDS:
                    if article.get(field):
                        counters[field] += 1
                if len(headlines) < 5:
                    headlines.append("%s  --  %s" % (article["title"], article["source"]))
    except NewsdataError as exc:
        print("", file=sys.stderr)
        print("error: %s" % exc.message, file=sys.stderr)
        return 1

    if not seen:
        print("")
        print("No articles came back for those filters. Try dropping the language or query.")
        return 0

    print("")
    print("field availability on this key (%d articles)" % seen)
    for field, plan in TRACKED_FIELDS:
        count = counters[field]
        if count:
            suffix = ""
        elif plan == "paid":
            suffix = "   requires a paid newsdata.io plan"
        else:
            suffix = "   not present in this batch"
        print("  %-12s %d/%d%s" % (field, count, seen, suffix))

    print("")
    print("latest headlines")
    for position, line in enumerate(headlines, start=1):
        print("  %d. %s" % (position, line))
    return 0


def main(argv: Optional[List[str]] = None) -> int:
    parser = argparse.ArgumentParser(description="News reader backed by the newsdata.io news API.")
    parser.add_argument("--check", action="store_true",
                        help="fetch live pages and report what this key returns, then exit")
    parser.add_argument("--pages", type=int, default=1, help="pages to walk with --check (default 1)")
    parser.add_argument("--language", default="en", help="language filter for --check (default en)")
    parser.add_argument("--query", default=None, help="optional search term for --check")
    parser.add_argument("--export-blueprint", metavar="PATH", nargs="?", const="blueprint.json",
                        help="write the API contract as JSON and exit (default blueprint.json)")
    parser.add_argument("--host", default=os.environ.get("HOST", "127.0.0.1"))
    parser.add_argument("--port", type=int, default=int(os.environ.get("PORT", "5000")))
    args = parser.parse_args(argv)

    if args.export_blueprint:
        with open(args.export_blueprint, "w", encoding="utf-8") as handle:
            json.dump(blueprint.build(), handle, indent=2)
            handle.write("\n")
        print("wrote %s" % args.export_blueprint)
        return 0

    if not os.environ.get("NEWSDATA_API_KEY", "").strip():
        print("NEWSDATA_API_KEY is not set.", file=sys.stderr)
        print("Get a free key at https://newsdata.io, then:", file=sys.stderr)
        print("  export NEWSDATA_API_KEY=your_key_here", file=sys.stderr)
        return 1

    if args.check:
        return run_check(args.pages, args.language, args.query)

    print("serving on http://%s:%d   paid mode: %s"
          % (args.host, args.port, "on" if paid_mode_enabled() else "off"))
    app.run(host=args.host, port=args.port, debug=False)
    return 0


if __name__ == "__main__":
    sys.exit(main())
