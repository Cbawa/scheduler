"""Small client for the newsdata.io news API (https://newsdata.io).

Everything the app needs comes from GET /api/1/latest. The API key is read from
NEWSDATA_API_KEY and never leaves this process.

Free keys reject a handful of query parameters outright -- and a rejected
parameter fails the whole request, not just that filter -- so those parameters
are only sent when NEWSDATA_PAID_MODE is on, and if the key still refuses them
the call is retried once without them.

Paid *response* fields (sentiment, ai_tag, ai_summary, ...) are the opposite
case: asking for them is always safe, they just come back empty. Some plans
return a literal "ONLY AVAILABLE IN ..." string instead of null, which is
filtered out here so it never reaches the UI.
"""

from __future__ import annotations

import json
import os
from typing import Any, Dict, List, Optional

import requests

BASE_URL = "https://newsdata.io/api"
LATEST_PATH = "/1/latest"
TIMEOUT_SECONDS = 20
USER_AGENT = "ai-news-app-blueprint/1.0"

# Query parameters any key may send.
FREE_PARAMS = ("q", "country", "category", "language", "domain", "page")

# Query parameters that fail the entire request on a free key.
PAID_PARAMS = (
    "size", "timeframe", "removeduplicate", "full_content", "sentiment",
    "tag", "region", "organization", "from_date", "to_date", "prioritydomain",
)

# Response fields that only a paid plan populates.
PAID_FIELDS = ("sentiment", "sentiment_stats", "ai_tag", "ai_region", "ai_org", "ai_summary", "content")

SENTIMENTS = ("positive", "neutral", "negative")
TRUTHY = {"1", "true", "yes", "on"}
PLAN_PLACEHOLDER = "only available in"


class NewsdataError(RuntimeError):
    """Anything that stopped us from returning articles."""

    def __init__(self, message: str, status: Optional[int] = None, retryable: bool = False):
        super().__init__(message)
        self.message = message
        self.status = status
        self.retryable = retryable


class PaidParamRejected(NewsdataError):
    """The key is not allowed to use one of the parameters we sent."""


def get_api_key() -> str:
    key = os.environ.get("NEWSDATA_API_KEY", "").strip()
    if not key:
        raise NewsdataError(
            "NEWSDATA_API_KEY is not set. Create a free key at https://newsdata.io "
            "and export it before starting the app."
        )
    return key


def paid_mode_enabled() -> bool:
    return os.environ.get("NEWSDATA_PAID_MODE", "").strip().lower() in TRUTHY


def paid_params() -> Dict[str, str]:
    """Extra query parameters, used only when the operator says the key is paid."""
    params: Dict[str, str] = {"removeduplicate": "1"}

    raw_size = os.environ.get("NEWSDATA_PAGE_SIZE", "20").strip()
    try:
        params["size"] = str(max(1, min(50, int(raw_size))))
    except ValueError:
        params["size"] = "20"

    timeframe = os.environ.get("NEWSDATA_TIMEFRAME", "").strip()
    if timeframe:
        params["timeframe"] = timeframe

    sentiment = os.environ.get("NEWSDATA_SENTIMENT", "").strip().lower()
    if sentiment in SENTIMENTS:
        params["sentiment"] = sentiment

    return params


# --------------------------------------------------------------------------- #
# HTTP
# --------------------------------------------------------------------------- #

def _error_message(payload: Any, fallback: str) -> str:
    if isinstance(payload, dict):
        results = payload.get("results")
        if isinstance(results, dict):
            message = results.get("message") or results.get("code")
            if message:
                return str(message)
        message = payload.get("message")
        if message:
            return str(message)
    return fallback


def _request(path: str, params: Dict[str, Any]) -> Dict[str, Any]:
    try:
        response = requests.get(
            BASE_URL + path,
            params=params,
            timeout=TIMEOUT_SECONDS,
            headers={"Accept": "application/json", "User-Agent": USER_AGENT},
        )
    except requests.exceptions.Timeout as exc:
        raise NewsdataError("newsdata.io did not respond within %ss." % TIMEOUT_SECONDS, retryable=True) from exc
    except requests.exceptions.RequestException as exc:
        raise NewsdataError("Could not reach newsdata.io: %s" % exc, retryable=True) from exc

    try:
        payload = response.json()
    except ValueError:
        payload = None

    status = response.status_code
    failed = not isinstance(payload, dict) or payload.get("status") == "error"

    if status == 200 and not failed:
        return payload
    if status == 401:
        raise NewsdataError(
            "newsdata.io rejected the API key (401). Check the value of NEWSDATA_API_KEY.",
            status=401,
        )
    if status == 429:
        raise NewsdataError(
            "Rate limit reached (429). Wait a moment before requesting more pages.",
            status=429,
            retryable=True,
        )
    if status in (403, 422):
        raise PaidParamRejected(
            _error_message(payload, "newsdata.io refused the request (HTTP %d)." % status),
            status=status,
        )
    raise NewsdataError(
        _error_message(payload, "newsdata.io returned HTTP %d." % status),
        status=status if status >= 400 else 502,
    )


# --------------------------------------------------------------------------- #
# Normalisation
# --------------------------------------------------------------------------- #

def _is_placeholder(value: Any) -> bool:
    return isinstance(value, str) and PLAN_PLACEHOLDER in value.lower()


def _clean_text(value: Any, limit: Optional[int] = None) -> str:
    if not isinstance(value, str) or _is_placeholder(value):
        return ""
    text = " ".join(value.split())
    if limit and len(text) > limit:
        text = text[:limit].rstrip() + "..."
    return text


def _as_list(value: Any) -> List[str]:
    if value is None or _is_placeholder(value):
        return []
    if isinstance(value, str):
        cleaned = _clean_text(value)
        return [cleaned] if cleaned else []
    if isinstance(value, list):
        out = []
        for item in value:
            if isinstance(item, (str, int, float)) and not _is_placeholder(item):
                text = _clean_text(str(item))
                if text:
                    out.append(text)
        return out
    return []


def _as_url(value: Any) -> str:
    if isinstance(value, str) and value.startswith(("http://", "https://")):
        return value
    return ""


def _sentiment(value: Any) -> str:
    if isinstance(value, str) and value.strip().lower() in SENTIMENTS:
        return value.strip().lower()
    return ""


def _sentiment_stats(value: Any) -> Dict[str, float]:
    if isinstance(value, str):
        if _is_placeholder(value):
            return {}
        try:
            value = json.loads(value)
        except ValueError:
            return {}
    if not isinstance(value, dict):
        return {}
    stats: Dict[str, float] = {}
    for key in SENTIMENTS:
        raw = value.get(key)
        try:
            stats[key] = round(float(raw), 2)
        except (TypeError, ValueError):
            continue
    return stats if len(stats) == len(SENTIMENTS) else {}


def normalize_article(raw: Dict[str, Any]) -> Dict[str, Any]:
    """Flatten one API result into the shape the front end binds to.

    Keys keep their newsdata.io names so the blueprint mapping stays obvious.
    Every paid field degrades to an empty string or empty list.
    """
    return {
        "id": _clean_text(raw.get("article_id")) or _as_url(raw.get("link")),
        "title": _clean_text(raw.get("title")) or "(untitled)",
        "link": _as_url(raw.get("link")),
        "source": _clean_text(raw.get("source_name")) or _clean_text(raw.get("source_id")) or "Unknown source",
        "source_icon": _as_url(raw.get("source_icon")),
        "image": _as_url(raw.get("image_url")),
        "published": _clean_text(raw.get("pubDate")),
        "description": _clean_text(raw.get("description"), 300),
        "creator": _as_list(raw.get("creator"))[:2],
        "language": _clean_text(raw.get("language")),
        "country": _as_list(raw.get("country"))[:3],
        "category": _as_list(raw.get("category"))[:3],
        # free on every plan -- the app leans on this
        "keywords": _as_list(raw.get("keywords"))[:8],
        # paid response fields: present when the plan provides them, empty otherwise
        "sentiment": _sentiment(raw.get("sentiment")),
        "sentiment_stats": _sentiment_stats(raw.get("sentiment_stats")),
        "ai_tag": _as_list(raw.get("ai_tag"))[:6],
        "ai_region": _as_list(raw.get("ai_region"))[:4],
        "ai_org": _as_list(raw.get("ai_org"))[:4],
        "ai_summary": _clean_text(raw.get("ai_summary"), 400),
    }


# --------------------------------------------------------------------------- #
# Public API
# --------------------------------------------------------------------------- #

def fetch_latest(
    *,
    q: Optional[str] = None,
    category: Optional[str] = None,
    country: Optional[str] = None,
    language: Optional[str] = None,
    page: Optional[str] = None,
    paid: Optional[bool] = None,
) -> Dict[str, Any]:
    """One page of /1/latest.

    `page` is the `nextPage` cursor from a previous call. The returned dict
    carries the cursor for the following page (None when there is nothing left)
    and an echo of the parameters actually sent, minus the key.
    """
    if paid is None:
        paid = paid_mode_enabled()

    base: Dict[str, Any] = {"apikey": get_api_key()}
    if q:
        base["q"] = q.strip()[:100]
    if category:
        base["category"] = category
    if country:
        base["country"] = country
    if language:
        base["language"] = language
    if page:
        base["page"] = page

    extras = paid_params() if paid else {}
    notes: List[str] = []

    try:
        payload = _request(LATEST_PATH, dict(base, **extras))
    except PaidParamRejected as exc:
        if not extras:
            raise NewsdataError(exc.message, status=exc.status) from exc
        notes.append(
            "This key rejected the paid parameters (%s), so they were dropped and the "
            "request was retried. API said: %s" % (", ".join(sorted(extras)), exc.message)
        )
        extras = {}
        payload = _request(LATEST_PATH, base)

    results = payload.get("results")
    articles = [normalize_article(item) for item in results if isinstance(item, dict)] if isinstance(results, list) else []

    return {
        "articles": articles,
        "next_page": payload.get("nextPage") or None,
        "total": payload.get("totalResults"),
        "request": {k: v for k, v in dict(base, **extras).items() if k != "apikey"},
        "paid_params_sent": sorted(extras),
        "paid_mode": bool(paid),
        "notes": notes,
    }


def iter_articles(pages: int = 1, **filters: Any):
    """Walk the nextPage cursor, yielding one batch per page.

    Stops early when the API returns a null cursor -- that is the documented
    end-of-results signal, not an error.
    """
    cursor = None
    for _ in range(max(1, pages)):
        batch = fetch_latest(page=cursor, **filters)
        yield batch
        cursor = batch["next_page"]
        if not cursor:
            break
