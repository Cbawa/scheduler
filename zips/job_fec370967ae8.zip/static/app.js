"use strict";

/* Front end for /api/news. Nodes are built with the DOM API rather than
   innerHTML, so headlines and keywords from the API are never parsed as markup. */

const FORM = document.getElementById("controls");
const FEED = document.getElementById("feed");
const STATUS = document.getElementById("status");
const META = document.getElementById("meta-note");
const MORE = document.getElementById("more");
const AVAIL = document.getElementById("availability");
const SENTIMENT = document.getElementById("sentiment-panel");
const KEYWORDS = document.getElementById("keyword-panel");
const DIALOG = document.getElementById("blueprint-dialog");
const DIALOG_BODY = document.getElementById("blueprint-body");

const TONES = ["positive", "neutral", "negative"];

/* Shown only when no article carries a sentiment value. Clearly labelled in the
   UI as a sample so nobody mistakes it for live output. */
const SAMPLE_SENTIMENT = { positive: 41, neutral: 44, negative: 15 };

const FIELD_ROWS = [
  { key: "keywords", plan: "free" },
  { key: "sentiment", plan: "paid" },
  { key: "ai_tag", plan: "paid" },
  { key: "ai_summary", plan: "paid" }
];

const state = {
  cursor: null,
  articles: [],
  filters: {},
  loading: false,
  done: false,
  blueprint: null
};

function el(tag, className, text) {
  const node = document.createElement(tag);
  if (className) node.className = className;
  if (text !== undefined && text !== null) node.textContent = String(text);
  return node;
}

function setStatus(message, kind) {
  STATUS.textContent = message || "";
  STATUS.className = "status" + (kind ? " " + kind : "");
  STATUS.hidden = !message;
}

function timeAgo(value) {
  if (!value) return "";
  const iso = value.indexOf("T") === -1 ? value.replace(" ", "T") + "Z" : value;
  const then = new Date(iso);
  if (isNaN(then.getTime())) return value;
  const minutes = Math.round((Date.now() - then.getTime()) / 60000);
  if (minutes < 1) return "just now";
  if (minutes < 60) return minutes + "m ago";
  const hours = Math.round(minutes / 60);
  if (hours < 24) return hours + "h ago";
  return Math.round(hours / 24) + "d ago";
}

function readFilters() {
  const data = new FormData(FORM);
  return {
    q: String(data.get("q") || "").trim(),
    category: String(data.get("category") || ""),
    country: String(data.get("country") || ""),
    language: String(data.get("language") || "")
  };
}

/* ------------------------------------------------------------------ cards */

function keywordChip(word) {
  const chip = el("button", "chip", word);
  chip.type = "button";
  chip.title = 'Search "' + word + '"';
  chip.addEventListener("click", function () {
    document.getElementById("q").value = word;
    load(true);
    window.scrollTo({ top: 0, behavior: "smooth" });
  });
  return chip;
}

function card(article) {
  const item = el("article", "card");

  if (article.image) {
    const media = el("div", "card-media");
    const img = document.createElement("img");
    img.src = article.image;
    img.alt = "";
    img.loading = "lazy";
    img.referrerPolicy = "no-referrer";
    img.addEventListener("error", function () { media.remove(); });
    media.appendChild(img);
    item.appendChild(media);
  }

  const body = el("div", "card-body");

  const meta = el("p", "card-meta");
  meta.appendChild(el("span", "source", article.source));
  if (article.published) meta.appendChild(el("span", null, timeAgo(article.published)));
  if (article.sentiment) meta.appendChild(el("span", "badge s-" + article.sentiment, article.sentiment));
  body.appendChild(meta);

  const heading = el("h2", "card-title");
  if (article.link) {
    const link = el("a", null, article.title);
    link.href = article.link;
    link.target = "_blank";
    link.rel = "noopener noreferrer";
    heading.appendChild(link);
  } else {
    heading.textContent = article.title;
  }
  body.appendChild(heading);

  if (article.ai_summary) {
    const summary = el("p", "card-summary");
    summary.appendChild(el("span", "tag-label", "ai_summary"));
    summary.appendChild(document.createTextNode(article.ai_summary));
    body.appendChild(summary);
  } else if (article.description) {
    body.appendChild(el("p", "card-desc", article.description));
  }

  const chips = el("div", "chips");
  (article.ai_tag || []).forEach(function (tag) { chips.appendChild(el("span", "chip ai", tag)); });
  (article.keywords || []).slice(0, 5).forEach(function (word) { chips.appendChild(keywordChip(word)); });
  if (chips.childNodes.length) body.appendChild(chips);

  item.appendChild(body);
  return item;
}

function renderArticles(batch) {
  const fragment = document.createDocumentFragment();
  batch.forEach(function (article) { fragment.appendChild(card(article)); });
  FEED.appendChild(fragment);
}

/* ---------------------------------------------------------------- sidebar */

function hasField(article, key) {
  const value = article[key];
  return Array.isArray(value) ? value.length > 0 : Boolean(value);
}

function renderAvailability() {
  AVAIL.replaceChildren();
  const total = state.articles.length;
  FIELD_ROWS.forEach(function (row) {
    const count = state.articles.filter(function (a) { return hasField(a, row.key); }).length;
    const line = el("li", count ? "on" : "off");
    line.appendChild(el("code", null, row.key));
    line.appendChild(el("span", "plan", count ? "live" : (row.plan === "paid" ? "paid plan" : "empty")));
    line.appendChild(el("span", "count", total ? count + "/" + total : "-"));
    AVAIL.appendChild(line);
  });
}

function renderSentiment() {
  SENTIMENT.replaceChildren();

  const counts = { positive: 0, neutral: 0, negative: 0 };
  state.articles.forEach(function (a) {
    if (a.sentiment && Object.prototype.hasOwnProperty.call(counts, a.sentiment)) counts[a.sentiment] += 1;
  });
  const live = counts.positive + counts.neutral + counts.negative;
  const isSample = live === 0;
  const data = isSample ? SAMPLE_SENTIMENT : counts;
  const total = isSample ? 100 : live;

  const bar = el("div", "bar" + (isSample ? " is-sample" : ""));
  TONES.forEach(function (tone) {
    const segment = el("span", "seg s-" + tone);
    segment.style.width = ((data[tone] / total) * 100).toFixed(1) + "%";
    segment.title = tone + ": " + data[tone];
    bar.appendChild(segment);
  });
  SENTIMENT.appendChild(bar);

  const legend = el("ul", "legend");
  TONES.forEach(function (tone) {
    const row = el("li");
    row.appendChild(el("span", "swatch s-" + tone));
    row.appendChild(el("span", null, tone));
    row.appendChild(el("span", "legend-value", isSample ? data[tone] + "%" : data[tone] + " of " + total));
    legend.appendChild(row);
  });
  SENTIMENT.appendChild(legend);

  const caption = el("p", "caption");
  if (isSample) {
    caption.appendChild(el("span", "sample-tag", "sample"));
    caption.appendChild(document.createTextNode(
      " Placeholder proportions. The sentiment field is empty on this key; live values need a paid newsdata.io plan."
    ));
  } else {
    caption.textContent = "From the sentiment field on " + live + " of " + state.articles.length + " loaded articles.";
  }
  SENTIMENT.appendChild(caption);
}

function renderKeywords() {
  KEYWORDS.replaceChildren();
  const counts = new Map();
  state.articles.forEach(function (article) {
    (article.keywords || []).forEach(function (word) {
      const key = word.toLowerCase();
      counts.set(key, (counts.get(key) || 0) + 1);
    });
  });

  if (!counts.size) {
    KEYWORDS.appendChild(el("p", "kw-empty", "No keywords on the loaded articles yet."));
    return;
  }

  const ranked = Array.from(counts.entries())
    .sort(function (a, b) { return b[1] - a[1] || a[0].localeCompare(b[0]); })
    .slice(0, 14);

  const chips = el("div", "chips");
  ranked.forEach(function (entry) {
    const chip = keywordChip(entry[0]);
    if (entry[1] > 1) {
      chip.appendChild(document.createTextNode(" "));
      chip.appendChild(el("span", "kw-count", entry[1]));
    }
    chips.appendChild(chip);
  });
  KEYWORDS.appendChild(chips);
}

function renderMeta(body) {
  const sent = Object.keys(body.request || {})
    .sort()
    .map(function (key) { return key === "page" ? "page=<cursor>" : key + "=" + body.request[key]; })
    .join("&");
  const parts = ["GET /1/latest" + (sent ? "?" + sent : "")];
  parts.push(body.paid_mode ? "paid parameters on" : "free parameters only");
  if (typeof body.total === "number") parts.push(body.total.toLocaleString() + " matching articles");
  META.textContent = parts.join("  -  ");
  (body.notes || []).forEach(function (note) {
    META.appendChild(document.createElement("br"));
    META.appendChild(document.createTextNode(note));
  });
}

/* ----------------------------------------------------------------- loading */

async function load(reset) {
  if (state.loading) return;
  if (reset) {
    state.cursor = null;
    state.articles = [];
    state.done = false;
    state.filters = readFilters();
    FEED.replaceChildren();
  }

  state.loading = true;
  MORE.disabled = true;
  setStatus(state.articles.length ? "Loading the next page..." : "Loading headlines...", "");

  const params = new URLSearchParams();
  Object.keys(state.filters).forEach(function (key) {
    if (state.filters[key]) params.set(key, state.filters[key]);
  });
  if (state.cursor) params.set("page", state.cursor);

  try {
    const response = await fetch("/api/news?" + params.toString(), { headers: { Accept: "application/json" } });
    let body = null;
    try { body = await response.json(); } catch (parseError) { body = null; }

    if (!response.ok || !body) {
      throw new Error((body && body.error) || "Request failed with HTTP " + response.status + ".");
    }

    const batch = body.articles || [];
    state.cursor = body.next_page || null;
    state.done = !state.cursor;
    state.articles = state.articles.concat(batch);

    renderArticles(batch);
    renderMeta(body);
    renderAvailability();
    renderSentiment();
    renderKeywords();

    if (!state.articles.length) {
      setStatus("No articles matched those filters. Try a broader query or clear the country filter.", "empty");
    } else {
      setStatus("", "");
    }
  } catch (error) {
    setStatus(error.message, "error");
  } finally {
    state.loading = false;
    MORE.disabled = state.done;
    MORE.hidden = state.done || state.articles.length === 0;
  }
}

/* --------------------------------------------------------------- blueprint */

async function openBlueprint() {
  DIALOG_BODY.textContent = "Loading...";
  if (typeof DIALOG.showModal === "function") DIALOG.showModal();
  try {
    const response = await fetch("/api/blueprint");
    const data = await response.json();
    state.blueprint = data;
    DIALOG_BODY.textContent = JSON.stringify(data, null, 2);
  } catch (error) {
    DIALOG_BODY.textContent = "Could not load the blueprint: " + error.message;
  }
}

document.getElementById("show-blueprint").addEventListener("click", openBlueprint);
document.getElementById("close-dialog").addEventListener("click", function () { DIALOG.close(); });
document.getElementById("copy-prompt").addEventListener("click", async function () {
  const button = this;
  if (!state.blueprint) return;
  try {
    await navigator.clipboard.writeText(state.blueprint.builder_prompt);
    button.textContent = "Copied";
  } catch (error) {
    button.textContent = "Copy failed - select the text";
  }
  setTimeout(function () { button.textContent = "Copy builder prompt"; }, 2200);
});

FORM.addEventListener("submit", function (event) {
  event.preventDefault();
  load(true);
});
FORM.querySelectorAll("select").forEach(function (select) {
  select.addEventListener("change", function () { load(true); });
});
MORE.addEventListener("click", function () { load(false); });

load(true);
