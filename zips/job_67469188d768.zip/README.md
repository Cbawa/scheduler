# Android News Reader 📱

A native **Android** news reader written in **Kotlin** that showcases the [newsdata.io](https://newsdata.io) news API. It pulls the latest headlines, renders them in a `RecyclerView`, and keeps the last fetch available **offline** by caching every article in a local **Room** database.

> Built and tested against the **newsdata.io FREE tier** — no paid features are required to run it.

## Features

- 🗞️ Latest headlines from the newsdata.io `/news` endpoint (Retrofit + Gson + OkHttp)
- 🔎 Free-text search (`q`) with pull-to-refresh
- 💾 Offline-first: articles are cached in Room and shown when the network is unavailable
- 🧱 Clean MVVM architecture (Repository → ViewModel → Activity) with Kotlin coroutines
- 🛡️ Graceful error handling for invalid key (401), rate limits (429), paid-only responses (403/422) and empty results
- 🔗 Tap an article to open it in the browser

## Architecture

```
MainActivity ──▶ NewsViewModel ──▶ NewsRepository ──┬─▶ NewsDataApi (Retrofit, /news)
     ▲                                              └─▶ ArticleDao (Room cache)
     └────────── RecyclerView (NewsAdapter)
```

The repository always tries the network first. On success it refreshes the Room cache and returns fresh data; on any failure (no internet, rate limit, bad key, paid-only feature) it returns the cached articles plus a friendly message so the app never crashes.

## Project layout

```
app/src/main/
├── AndroidManifest.xml
├── java/io/newsdata/androidnewsreader/
│   ├── data/
│   │   ├── remote/   NewsDataApi, RetrofitClient, NewsResponse (DTOs)
│   │   ├── local/    AppDatabase, ArticleDao, ArticleEntity
│   │   └── NewsRepository.kt
│   └── ui/           MainActivity, NewsViewModel, NewsAdapter
└── res/layout/       activity_main.xml, item_article.xml
```

## Getting your API key

1. Create a free account at https://newsdata.io
2. Copy your API key from the dashboard.

## Configuration — `NEWSDATA_API_KEY`

The key is **never hardcoded**. It is injected into `BuildConfig.NEWSDATA_API_KEY` at build time from either of these sources:

**Option A — `local.properties` (recommended for Android Studio):**

```properties
NEWSDATA_API_KEY=pub_xxxxxxxxxxxxxxxxxxxxxxxxxxxx
```

**Option B — environment variable (recommended for CI / command line):**

```bash
export NEWSDATA_API_KEY=pub_xxxxxxxxxxxxxxxxxxxxxxxxxxxx
```

If no key is found, the app still launches but shows a clear in-app message instead of crashing.

## Build & run

### With Android Studio (easiest)

1. Open the project folder in Android Studio (Hedgehog or newer).
2. Add your key to `local.properties` (see above).
3. Press **Run ▶**.

### From the command line

This repo ships the Gradle wrapper config but not the wrapper binary. Generate the wrapper once with a local Gradle 8.7+ install, then build:

```bash
gradle wrapper            # one-time, creates ./gradlew
export NEWSDATA_API_KEY=pub_xxxxxxxx
./gradlew assembleDebug    # build the debug APK
./gradlew installDebug     # install on a connected device/emulator
```

The APK is written to `app/build/outputs/apk/debug/app-debug.apk`.

## Free tier vs. paid plan

This app uses **only free-tier** parameters of `/news`: `apikey`, `q`, `country`, `language`, `category`, and `page`.

The following newsdata.io features are **paid-only** and are intentionally **not** part of the core flow:

| Feature | Status in this app |
| --- | --- |
| `sentiment` / sentiment analysis | Not used |
| AI fields (`ai_tag`, `ai_region`, `ai_org`, `ai_summary`) | Not used |
| `/archive` endpoint & long date ranges | Not used |
| Advanced full-text query operators | Not used |

If the API ever returns a `403`/`422` "upgrade your plan" response, the app detects it, skips the feature, keeps working with cached/free data, and shows a short notice.

## Tech stack

Kotlin · AndroidX · Material 3 · Retrofit 2 · OkHttp · Gson · Room · Coroutines · ViewModel/LiveData · RecyclerView

## License

MIT — see headers. This is an independent community sample demonstrating the newsdata.io API.
