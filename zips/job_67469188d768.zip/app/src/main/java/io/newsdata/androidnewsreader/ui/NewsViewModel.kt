package io.newsdata.androidnewsreader.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.viewModelScope
import io.newsdata.androidnewsreader.data.NewsRepository
import io.newsdata.androidnewsreader.data.NewsResult
import io.newsdata.androidnewsreader.data.local.AppDatabase
import io.newsdata.androidnewsreader.data.local.ArticleEntity
import io.newsdata.androidnewsreader.data.remote.RetrofitClient
import kotlinx.coroutines.launch

class NewsViewModel(app: Application) : AndroidViewModel(app) {

    private val repository = NewsRepository(
        RetrofitClient.api,
        AppDatabase.getInstance(app).articleDao()
    )

    private val _articles = MutableLiveData<List<ArticleEntity>>(emptyList())
    val articles: LiveData<List<ArticleEntity>> = _articles

    private val _loading = MutableLiveData(false)
    val loading: LiveData<Boolean> = _loading

    private val _message = MutableLiveData<String?>()
    val message: LiveData<String?> = _message

    fun refresh(query: String? = null, category: String? = null) {
        _loading.value = true
        viewModelScope.launch {
            when (val result = repository.loadNews(query, category)) {
                is NewsResult.Success -> {
                    _articles.value = result.articles
                    if (result.articles.isEmpty()) {
                        _message.value = "No articles found. Try a different search."
                    }
                }
                is NewsResult.Error -> {
                    _articles.value = result.articles
                    _message.value = result.message
                }
            }
            _loading.value = false
        }
    }
}
