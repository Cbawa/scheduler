package io.newsdata.androidnewsreader.ui

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import io.newsdata.androidnewsreader.data.local.ArticleEntity
import io.newsdata.androidnewsreader.databinding.ItemArticleBinding

class NewsAdapter(
    private val onClick: (ArticleEntity) -> Unit
) : ListAdapter<ArticleEntity, NewsAdapter.ArticleViewHolder>(DIFF) {

    inner class ArticleViewHolder(private val binding: ItemArticleBinding) :
        RecyclerView.ViewHolder(binding.root) {

        fun bind(item: ArticleEntity) {
            binding.titleText.text = item.title
            binding.descriptionText.text = item.description ?: ""
            binding.sourceText.text =
                listOfNotNull(item.sourceId, item.pubDate).joinToString("  \u2022  ")
            binding.root.setOnClickListener { onClick(item) }
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ArticleViewHolder {
        val binding = ItemArticleBinding.inflate(
            LayoutInflater.from(parent.context), parent, false
        )
        return ArticleViewHolder(binding)
    }

    override fun onBindViewHolder(holder: ArticleViewHolder, position: Int) {
        holder.bind(getItem(position))
    }

    companion object {
        private val DIFF = object : DiffUtil.ItemCallback<ArticleEntity>() {
            override fun areItemsTheSame(a: ArticleEntity, b: ArticleEntity) = a.id == b.id
            override fun areContentsTheSame(a: ArticleEntity, b: ArticleEntity) = a == b
        }
    }
}
