package io.newsdata.androidnewsreader.data.remote

import retrofit2.Response
import retrofit2.http.GET
import retrofit2.http.Query

/**
 * Retrofit interface for the newsdata.io REST API.
 *
 * Only FREE-tier parameters are exposed: apikey, q, country, language, category, page.
 * The `apikey` is passed as a query parameter on every call.
 */
interface NewsDataApi {

    @GET("news")
    suspend fun getLatestNews(
        @Query("apikey") apiKey: String,
        @Query("q") query: String? = null,
        @Query("country") country: String? = null,
        @Query("language") language: String? = "en",
        @Query("category") category: String? = null,
        @Query("page") page: String? = null
    ): Response<NewsResponse>

    companion object {
        const val BASE_URL = "https://newsdata.io/api/1/"
    }
}
