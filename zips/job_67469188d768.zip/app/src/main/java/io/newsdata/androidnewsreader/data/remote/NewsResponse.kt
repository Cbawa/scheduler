package io.newsdata.androidnewsreader.data.remote

import com.google.gson.annotations.SerializedName

/**
 * Top-level response from the newsdata.io /news endpoint.
 * Shape: { status, totalResults, results: [...], nextPage }
 */
data class NewsResponse(
    @SerializedName("status") val status: String?,
    @SerializedName("totalResults") val totalResults: Int?,
    @SerializedName("results") val results: List<ArticleDto>?,
    @SerializedName("nextPage") val nextPage: String?
)

/**
 * A single article. Only free-tier fields are mapped here.
 * Paid-only fields (sentiment, ai_tag, ai_summary, ...) are intentionally omitted.
 */
data class ArticleDto(
    @SerializedName("article_id") val articleId: String?,
    @SerializedName("title") val title: String?,
    @SerializedName("link") val link: String?,
    @SerializedName("description") val description: String?,
    @SerializedName("pubDate") val pubDate: String?,
    @SerializedName("source_id") val sourceId: String?,
    @SerializedName("image_url") val imageUrl: String?
)
