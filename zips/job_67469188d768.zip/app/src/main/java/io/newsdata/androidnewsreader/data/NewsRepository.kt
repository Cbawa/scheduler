package io.newsdata.androidnewsreader.data

import io.newsdata.androidnewsreader.BuildConfig
import io.newsdata.androidnewsreader.data.local.ArticleDao
import io.newsdata.androidnewsreader.data.local.ArticleEntity
import io.newsdata.androidnewsreader.data.remote.ArticleDto
import io.newsdata.androidnewsreader.data.remote.NewsDataApi
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.IOException

/**
 * Result of a news load. On error we still return whatever is cached so the
 * UI can keep showing content offline / after a failed request.
 */
sealed class NewsResult {
    data class Success(val articles: List<ArticleEntity>, val fromCache: Boolean) : NewsResult()
    data class Error(val message: String, val articles: List<ArticleEntity>) : NewsResult()
}

/**
 * Offline-first repository: tries the network, refreshes the Room cache on
 * success, and falls back to the cache on any failure.
 */
class NewsRepository(
    private val api: NewsDataApi,
    private val dao: ArticleDao
) {

    suspend fun loadNews(query: String?, category: String?): NewsResult = withContext(Dispatchers.IO) {
        val apiKey = BuildConfig.NEWSDATA_API_KEY
        if (apiKey.isBlank()) {
            return@withContext NewsResult.Error(
                "Missing NewsData.io API key. Add NEWSDATA_API_KEY to local.properties or your environment.",
                dao.getAll()
            )
        }

        try {
            val response = api.getLatestNews(
                apiKey = apiKey,
                query = query?.ifBlank { null },
                category = category?.ifBlank { null },
                language = "en"
            )

            if (response.isSuccessful) {
                val dtos = response.body()?.results.orEmpty()
                val entities = dtos.mapIndexedNotNull { index, dto -> dto.toEntity(index) }
                if (entities.isNotEmpty()) {
                    dao.clearAll()
                    dao.insertAll(entities)
                }
                NewsResult.Success(dao.getAll(), fromCache = false)
            } else {
                // Map known newsdata.io / HTTP error codes to friendly messages.
                val msg = when (response.code()) {
                    401 -> "Invalid API key (401). Double-check your NewsData.io key."
                    403, 422 -> "That request needs a paid NewsData.io plan. Showing free-tier results instead."
                    429 -> "Rate limit reached (429). Please wait a moment and try again."
                    else -> "Request failed (HTTP ${response.code()}). Showing cached news."
                }
                NewsResult.Error(msg, dao.getAll())
            }
        } catch (e: IOException) {
            NewsResult.Error("No internet connection. Showing cached news.", dao.getAll())
        } catch (e: Exception) {
            NewsResult.Error(e.message ?: "Unexpected error. Showing cached news.", dao.getAll())
        }
    }

    private fun ArticleDto.toEntity(index: Int): ArticleEntity? {
        val safeTitle = title ?: return null
        val safeId = articleId ?: link ?: "$safeTitle-$index"
        return ArticleEntity(
            id = safeId,
            title = safeTitle,
            description = description,
            link = link,
            pubDate = pubDate,
            sourceId = sourceId,
            imageUrl = imageUrl,
            sortIndex = index,
            cachedAt = System.currentTimeMillis()
        )
    }
}
