package io.newsdata.androidnewsreader.ui

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.widget.Toast
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import io.newsdata.androidnewsreader.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private val viewModel: NewsViewModel by viewModels()
    private lateinit var adapter: NewsAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        adapter = NewsAdapter { article ->
            val url = article.link
            if (!url.isNullOrBlank()) {
                runCatching {
                    startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
                }.onFailure {
                    Toast.makeText(this, "Could not open the article.", Toast.LENGTH_SHORT).show()
                }
            }
        }

        binding.recyclerView.layoutManager = LinearLayoutManager(this)
        binding.recyclerView.adapter = adapter

        binding.swipeRefresh.setOnRefreshListener { doSearch() }
        binding.searchButton.setOnClickListener { doSearch() }

        viewModel.articles.observe(this) { adapter.submitList(it) }
        viewModel.loading.observe(this) { binding.swipeRefresh.isRefreshing = it }
        viewModel.message.observe(this) { msg ->
            if (!msg.isNullOrBlank()) {
                Toast.makeText(this, msg, Toast.LENGTH_LONG).show()
            }
        }

        if (savedInstanceState == null) {
            viewModel.refresh()
        }
    }

    private fun doSearch() {
        val q = binding.searchInput.text?.toString()?.trim()
        viewModel.refresh(query = q)
    }
}
