package io.newsdata.androidnewsreader.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey

/**
 * Room entity representing a cached article. `sortIndex` preserves the
 * server ordering; `cachedAt` records when the row was stored.
 */
@Entity(tableName = "articles")
data class ArticleEntity(
    @PrimaryKey val id: String,
    val title: String,
    val description: String?,
    val link: String?,
    val pubDate: String?,
    val sourceId: String?,
    val imageUrl: String?,
    val sortIndex: Int,
    val cachedAt: Long
)
