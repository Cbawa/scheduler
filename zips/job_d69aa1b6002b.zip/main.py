#!/usr/bin/env python3
"""news-word-cloud — generate word clouds from live news headlines.

Powered by the newsdata.io news API (https://newsdata.io).
The core flow runs on a brand-new FREE API key; optional paid-plan features
are off by default and degrade gracefully.
"""
import argparse
import os
import sys

from newsdata_client import (
    NewsDataClient,
    NewsDataError,
    AuthError,
    RateLimitError,
    PaidPlanRequired,
)
from wordcloud_builder import build_word_cloud, extract_terms


def parse_args(argv=None):
    parser = argparse.ArgumentParser(
        prog="news-word-cloud",
        description="Generate a word cloud PNG from live news headlines (newsdata.io).",
    )
    parser.add_argument("--country", help="Two-letter country code, e.g. us, gb, in.")
    parser.add_argument("--category", help="News category, e.g. business, technology, sports.")
    parser.add_argument("--language", help="Language code, e.g. en, es, fr.")
    parser.add_argument("-q", "--query", help="Free-text search term.")
    parser.add_argument("--pages", type=int, default=1, help="Number of result pages to fetch (default: 1).")
    parser.add_argument("-o", "--output", default="wordcloud.png", help="Output PNG path (default: wordcloud.png).")
    parser.add_argument("--width", type=int, default=1600, help="Image width in pixels (default: 1600).")
    parser.add_argument("--height", type=int, default=900, help="Image height in pixels (default: 900).")
    parser.add_argument("--max-words", type=int, default=150, help="Maximum words in the cloud (default: 150).")
    parser.add_argument("--background", default="white", help="Background color (default: white).")
    parser.add_argument("--colormap", default="viridis", help="Matplotlib colormap (default: viridis).")
    parser.add_argument("--list-sources", action="store_true", help="List available newsdata.io sources and exit.")

    # --- Optional paid-plan showcases (OFF by default) ---
    paid = parser.add_argument_group("optional paid-plan features (requires a paid newsdata.io plan)")
    paid.add_argument("--sentiment", action="store_true",
                      help="Weight words by headline sentiment. Requires a paid plan.")
    paid.add_argument("--ai-tags", action="store_true",
                      help="Fold newsdata.io ai_tag topics into the cloud. Requires a paid plan.")
    paid.add_argument("--from-date", help="Start date YYYY-MM-DD (historical, paid plan).")
    paid.add_argument("--to-date", help="End date YYYY-MM-DD (historical, paid plan).")
    return parser.parse_args(argv)


def get_api_key():
    key = os.environ.get("NEWSDATA_API_KEY")
    if not key:
        print(
            "Error: NEWSDATA_API_KEY environment variable is not set.\n"
            "Get a free key at https://newsdata.io and run:\n"
            "  export NEWSDATA_API_KEY=\"your_key_here\"",
            file=sys.stderr,
        )
        sys.exit(1)
    return key


def main(argv=None):
    args = parse_args(argv)
    api_key = get_api_key()
    client = NewsDataClient(api_key)

    if args.list_sources:
        try:
            sources = client.fetch_sources(country=args.country, language=args.language)
        except AuthError:
            print("Error: Invalid API key (401). Check your NEWSDATA_API_KEY.", file=sys.stderr)
            sys.exit(2)
        except RateLimitError:
            print("Error: Rate limit reached (429). Please wait and try again.", file=sys.stderr)
            sys.exit(3)
        except NewsDataError as exc:
            print(f"Error fetching sources: {exc}", file=sys.stderr)
            sys.exit(4)
        if not sources:
            print("No sources returned.")
            return 0
        print(f"{len(sources)} sources:")
        for src in sources:
            name = src.get("name", "?")
            sid = src.get("id", "?")
            print(f"  {sid:<24} {name}")
        return 0

    # Resolve paid-feature toggles from flags OR environment variables.
    plan_paid = os.environ.get("NEWSDATA_PLAN", "").lower() == "paid"
    enable_sentiment = args.sentiment or os.environ.get("ENABLE_SENTIMENT") == "1"
    enable_ai_tags = args.ai_tags or plan_paid
    use_dates = bool(args.from_date or args.to_date)

    print("Fetching headlines from newsdata.io ...")
    try:
        articles = client.fetch_news(
            query=args.query,
            country=args.country,
            category=args.category,
            language=args.language,
            pages=max(1, args.pages),
            enable_sentiment=enable_sentiment,
            enable_ai_tags=enable_ai_tags,
            from_date=args.from_date if use_dates else None,
            to_date=args.to_date if use_dates else None,
        )
    except AuthError:
        print("Error: Invalid API key (401). Check your NEWSDATA_API_KEY.", file=sys.stderr)
        sys.exit(2)
    except RateLimitError:
        print("Error: Rate limit reached (429). Please wait and try again, or reduce --pages.", file=sys.stderr)
        sys.exit(3)
    except NewsDataError as exc:
        print(f"Error fetching news: {exc}", file=sys.stderr)
        sys.exit(4)

    if not articles:
        print("No headlines found. Try loosening your filters (--country / --category / --query).")
        return 0

    print(f"Collected {len(articles)} headlines.")

    terms = extract_terms(
        articles,
        weight_by_sentiment=enable_sentiment,
        include_ai_tags=enable_ai_tags,
    )
    if not terms:
        print("Headlines contained no usable words after cleaning. Nothing to render.")
        return 0

    try:
        build_word_cloud(
            terms,
            output_path=args.output,
            width=args.width,
            height=args.height,
            max_words=args.max_words,
            background_color=args.background,
            colormap=args.colormap,
        )
    except Exception as exc:  # rendering failure should not crash silently
        print(f"Error building word cloud: {exc}", file=sys.stderr)
        sys.exit(5)

    print(f"\u2713 Word cloud saved to {args.output}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
