"""Turn newsdata.io articles into a word-cloud PNG.

Handles missing/paid fields (sentiment, ai_tag) defensively so a free-tier
response never crashes the renderer.
"""
import re
from collections import Counter

from wordcloud import WordCloud

# A compact English stop-word list (no extra downloads required).
STOP_WORDS = {
    "a", "about", "above", "after", "again", "all", "am", "an", "and", "any",
    "are", "as", "at", "be", "because", "been", "before", "being", "below",
    "between", "both", "but", "by", "can", "could", "did", "do", "does",
    "doing", "down", "during", "each", "few", "for", "from", "further", "had",
    "has", "have", "having", "he", "her", "here", "hers", "him", "his", "how",
    "i", "if", "in", "into", "is", "it", "its", "just", "me", "more", "most",
    "my", "no", "nor", "not", "now", "of", "off", "on", "once", "only", "or",
    "other", "our", "out", "over", "own", "said", "same", "says", "she", "should",
    "so", "some", "such", "than", "that", "the", "their", "them", "then", "there",
    "these", "they", "this", "those", "through", "to", "too", "under", "until",
    "up", "very", "was", "we", "were", "what", "when", "where", "which", "while",
    "who", "whom", "why", "will", "with", "would", "you", "your", "new", "news",
    "amid", "vs", "per", "get", "gets", "may", "one", "two", "day", "week",
}

WORD_RE = re.compile(r"[A-Za-z][A-Za-z'-]+")

# Multiplier applied to word counts based on headline sentiment (paid feature).
SENTIMENT_WEIGHT = {"positive": 1.5, "negative": 1.5, "neutral": 1.0}


def _tokenize(text):
    if not text:
        return []
    words = WORD_RE.findall(text.lower())
    return [w for w in words if len(w) > 2 and w not in STOP_WORDS]


def extract_terms(articles, weight_by_sentiment=False, include_ai_tags=False):
    """Build a {word: frequency} dict from article titles/descriptions.

    Every field access is guarded: paid fields (sentiment, ai_tag) may be
    absent on the free tier and simply contribute nothing extra.
    """
    counts = Counter()
    for art in articles:
        if not isinstance(art, dict):
            continue
        title = art.get("title") or ""
        description = art.get("description") or ""
        tokens = _tokenize(title) + _tokenize(description)

        weight = 1.0
        if weight_by_sentiment:
            sentiment = art.get("sentiment")  # paid field; may be None
            if isinstance(sentiment, str):
                weight = SENTIMENT_WEIGHT.get(sentiment.lower(), 1.0)

        for tok in tokens:
            counts[tok] += weight

        if include_ai_tags:
            ai_tags = art.get("ai_tag")  # paid field; str or list or None
            if isinstance(ai_tags, str):
                ai_tags = [ai_tags]
            if isinstance(ai_tags, list):
                for tag in ai_tags:
                    for tok in _tokenize(str(tag)):
                        counts[tok] += 2.0  # tags are high-signal

    # WordCloud expects ints-ish frequencies; round the weighted floats.
    return {word: round(freq, 2) for word, freq in counts.items() if freq > 0}


def build_word_cloud(terms, output_path="wordcloud.png", width=1600, height=900,
                     max_words=150, background_color="white", colormap="viridis"):
    """Render and save a PNG from a {word: frequency} mapping."""
    if not terms:
        raise ValueError("No terms to render.")
    wc = WordCloud(
        width=width,
        height=height,
        max_words=max_words,
        background_color=background_color,
        colormap=colormap,
        collocations=False,
    )
    wc.generate_from_frequencies(terms)
    wc.to_file(output_path)
    return output_path
