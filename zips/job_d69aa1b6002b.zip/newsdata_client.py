"""Thin client for the newsdata.io REST API.

Docs: https://newsdata.io/documentation
Base URL: https://newsdata.io/api/1

The core /news flow works on the FREE tier. Paid-only parameters (sentiment,
ai_tag, from_date/to_date) are sent only when explicitly enabled, and a paid-plan
rejection (403/422) is caught so the caller can degrade gracefully.
"""
import time

import requests

BASE_URL = "https://newsdata.io/api/1"
DEFAULT_TIMEOUT = 30


class NewsDataError(Exception):
    """Generic newsdata.io API error."""


class AuthError(NewsDataError):
    """Raised on a 401 invalid-key response."""


class RateLimitError(NewsDataError):
    """Raised on a 429 rate-limit response."""


class PaidPlanRequired(NewsDataError):
    """Raised when a parameter requires a paid plan (403/422 'upgrade')."""


class NewsDataClient:
    def __init__(self, api_key, base_url=BASE_URL, timeout=DEFAULT_TIMEOUT):
        if not api_key:
            raise ValueError("api_key is required")
        self.api_key = api_key
        self.base_url = base_url.rstrip("/")
        self.timeout = timeout
        self.session = requests.Session()

    # ------------------------------------------------------------------ #
    def _request(self, endpoint, params):
        params = {k: v for k, v in params.items() if v is not None}
        params["apikey"] = self.api_key
        url = f"{self.base_url}/{endpoint}"
        try:
            resp = self.session.get(url, params=params, timeout=self.timeout)
        except requests.RequestException as exc:
            raise NewsDataError(f"Network error: {exc}") from exc

        if resp.status_code == 401:
            raise AuthError("Invalid API key (401).")
        if resp.status_code == 429:
            raise RateLimitError("Rate limit reached (429).")
        if resp.status_code in (403, 422):
            # Often signals a parameter that needs a paid plan.
            raise PaidPlanRequired(self._message(resp))
        if resp.status_code >= 400:
            raise NewsDataError(f"HTTP {resp.status_code}: {self._message(resp)}")

        try:
            data = resp.json()
        except ValueError as exc:
            raise NewsDataError("Could not decode API response as JSON.") from exc

        if data.get("status") == "error":
            msg = self._message(resp, data)
            if "plan" in msg.lower() or "upgrade" in msg.lower():
                raise PaidPlanRequired(msg)
            raise NewsDataError(msg)
        return data

    @staticmethod
    def _message(resp, data=None):
        if data is None:
            try:
                data = resp.json()
            except ValueError:
                return resp.text[:200]
        results = data.get("results")
        if isinstance(results, dict):
            return results.get("message") or str(results)
        if isinstance(data.get("message"), str):
            return data["message"]
        return str(data)

    # ------------------------------------------------------------------ #
    def fetch_news(self, query=None, country=None, category=None, language=None,
                   pages=1, enable_sentiment=False, enable_ai_tags=False,
                   from_date=None, to_date=None):
        """Fetch latest news, following the nextPage token up to `pages` times.

        Returns a list of article dicts. Paid params are attempted only when
        enabled; if the plan rejects them we retry once without them so the
        free-tier flow still works.
        """
        base_params = {
            "q": query,
            "country": country,
            "category": category,
            "language": language,
        }
        paid_params = {}
        if from_date:
            paid_params["from_date"] = from_date
        if to_date:
            paid_params["to_date"] = to_date
        # NOTE: sentiment / ai_tag come back as response *fields*; the
        # `sentiment` query param itself is a paid filter we leave off unless
        # requested. We surface a warning instead of silently sending it.
        if enable_sentiment:
            print("  (sentiment requested — requires a paid newsdata.io plan; "
                  "will use the field if present.)")
        if enable_ai_tags:
            print("  (ai_tag requested — requires a paid newsdata.io plan; "
                  "will use the field if present.)")

        articles = []
        next_page = None
        used_paid = bool(paid_params)
        for _ in range(max(1, pages)):
            params = dict(base_params)
            params.update(paid_params)
            if next_page:
                params["page"] = next_page
            try:
                data = self._request("news", params)
            except PaidPlanRequired as exc:
                if used_paid:
                    print(f"  Note: {exc} Retrying on the free tier without "
                          "paid parameters.")
                    paid_params = {}
                    used_paid = False
                    params = dict(base_params)
                    if next_page:
                        params["page"] = next_page
                    data = self._request("news", params)
                else:
                    raise
            batch = data.get("results") or []
            articles.extend(batch)
            next_page = data.get("nextPage")
            if not next_page:
                break
            time.sleep(0.4)  # be gentle with free-tier rate limits
        return articles

    def fetch_sources(self, country=None, language=None):
        data = self._request("sources", {"country": country, "language": language})
        return data.get("results") or []
