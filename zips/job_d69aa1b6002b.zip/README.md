# news-word-cloud

Generate beautiful **word clouds** from live news headlines, powered by the
[newsdata.io](https://newsdata.io) news API. Filter by country, category, language
or a free-text query, and export a crisp PNG you can drop into a dashboard, a tweet,
or a daily report.

![example](example_output.png)

> Built as a showcase for the newsdata.io REST API. The core flow works on a
> **brand-new FREE API key** — no paid plan required.

---

## Features

- Pulls the latest headlines from the newsdata.io `/news` endpoint.
- Filter by `--country`, `--category`, `--language`, and free-text `--query`.
- Follows the `nextPage` pagination token to gather more headlines (`--pages`).
- Smart text cleaning + stop-word removal so the cloud highlights real topics.
- Renders a high-resolution PNG with the `wordcloud` library.
- Graceful handling of invalid keys (401), rate limits (429) and empty results.
- Optional **paid-plan** showcases (sentiment-weighted clouds, AI tags) that are
  **off by default** and degrade gracefully on the free tier.

---

## Setup

```bash
git clone https://github.com/your-account/news-word-cloud.git
cd news-word-cloud
python -m venv .venv && source .venv/bin/activate   # optional but recommended
pip install -r requirements.txt
```

### Get a free API key

1. Create a free account at <https://newsdata.io>.
2. Copy your API key from the dashboard.
3. Export it (the program reads the `NEWSDATA_API_KEY` environment variable):

```bash
export NEWSDATA_API_KEY="pub_xxxxxxxxxxxxxxxxxxxxxxxxxxxx"
```

On Windows (PowerShell):

```powershell
$Env:NEWSDATA_API_KEY = "pub_xxxxxxxxxxxxxxxxxxxxxxxxxxxx"
```

---

## Usage

Generate a word cloud of the latest US headlines:

```bash
python main.py --country us --output us_news.png
```

Technology headlines in English, scanning 3 pages of results:

```bash
python main.py --category technology --language en --pages 3 --output tech.png
```

A themed query:

```bash
python main.py --query "climate" --country gb --output climate.png
```

### All options

```
--country     Two-letter country code (e.g. us, gb, in). Optional.
--category    News category: business, technology, sports, science, ... Optional.
--language    Language code (e.g. en, es, fr). Optional.
--query, -q   Free-text search term. Optional.
--pages       Number of result pages to fetch (default: 1).
--output, -o  Output PNG path (default: wordcloud.png).
--width       Image width in pixels (default: 1600).
--height      Image height in pixels (default: 900).
--max-words   Maximum words in the cloud (default: 150).
--background  Background color (default: white).
--colormap    Matplotlib colormap name (default: viridis).
--list-sources  List available newsdata.io sources and exit.
```

---

## Optional paid-plan features (showcase)

These flags advertise newsdata.io's paid capabilities. They are **OFF by default**
and the program keeps working on the free tier — if the API replies that a paid
plan is required, the feature is skipped with a friendly message and the core word
cloud is still generated.

| Feature | How to enable | Requires |
| --- | --- | --- |
| **Sentiment-weighted cloud** — emphasize words from positive/negative headlines | `--sentiment` flag _or_ `ENABLE_SENTIMENT=1` | Paid newsdata.io plan |
| **AI tags** — fold newsdata.io's `ai_tag` topics into the cloud | `--ai-tags` flag _or_ `NEWSDATA_PLAN=paid` | Paid newsdata.io plan |
| **Custom date range** — historical headlines via `from_date`/`to_date` | `--from-date YYYY-MM-DD --to-date YYYY-MM-DD` | Paid newsdata.io plan |

Example (will gracefully fall back if your key is free-tier):

```bash
python main.py --country us --sentiment --ai-tags --output enriched.png
```

---

## How it works

1. `newsdata_client.py` calls `GET /news` with your filters and follows the
   `nextPage` token to collect headlines.
2. `wordcloud_builder.py` cleans the text (lowercasing, stripping punctuation,
   removing common stop-words) and renders a PNG with the `wordcloud` library.
3. `main.py` wires the CLI together and handles errors cleanly.

---

## Troubleshooting

- **`NEWSDATA_API_KEY environment variable is not set`** — export your key (see Setup).
- **`Invalid API key (401)`** — double-check the key from your newsdata.io dashboard.
- **`Rate limit reached (429)`** — the free tier has limits; wait and retry, or
  reduce `--pages`.
- **`No headlines found`** — loosen your filters (try fewer of `--country`,
  `--category`, `--query`).

---

## License

MIT — see [LICENSE](LICENSE).
