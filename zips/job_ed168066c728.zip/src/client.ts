import type { Endpoint, NewsDataArticle, NewsDataSuccess, NewsQuery } from "./types.js";

const BASE_URL = "https://newsdata.io/api/1";

/** Query params that error a request on the free tier. */
const PAID_PARAMS = new Set([
  "sentiment",
  "timeframe",
  "tag",
  "region",
  "organization",
  "from_date",
  "to_date",
  "full_content",
]);

export class NewsDataApiError extends Error {
  constructor(
    public readonly httpStatus: number,
    message: string,
    public readonly code?: string,
  ) {
    super(message);
    this.name = "NewsDataApiError";
  }
}

export interface ClientOptions {
  apiKey?: string;
  /** Send paid query params (requires a paid newsdata.io plan). */
  paidMode?: boolean;
  /** Max retry attempts for HTTP 429 (rate limit). */
  maxRetries?: number;
}

const sleep = (ms: number): Promise<void> => new Promise((r) => setTimeout(r, ms));

export class NewsDataClient {
  private readonly apiKey: string;
  private readonly paidMode: boolean;
  private readonly maxRetries: number;

  constructor(opts: ClientOptions = {}) {
    const key = opts.apiKey ?? process.env.NEWSDATA_API_KEY;
    if (!key) {
      throw new Error(
        "NEWSDATA_API_KEY is not set.\n" +
          "Get a free key at https://newsdata.io and export it before running:\n" +
          "  export NEWSDATA_API_KEY=your_key_here",
      );
    }
    this.apiKey = key;
    this.paidMode = opts.paidMode ?? process.env.NEWSDATA_PAID_MODE === "1";
    this.maxRetries = opts.maxRetries ?? 3;
  }

  /** Fetch a single page of results. */
  async fetchPage(endpoint: Endpoint, query: NewsQuery = {}): Promise<NewsDataSuccess> {
    let params = this.toParams(query);
    if (!this.paidMode) params = this.stripPaid(params);

    try {
      return await this.request(endpoint, params);
    } catch (err) {
      // If a paid param slipped through and the server rejected it, retry free.
      if (
        err instanceof NewsDataApiError &&
        (err.httpStatus === 403 || err.httpStatus === 422) &&
        this.hasPaid(params)
      ) {
        return await this.request(endpoint, this.stripPaid(params));
      }
      throw err;
    }
  }

  /**
   * Iterate every page using the nextPage cursor. Stops when nextPage is null
   * or after maxPages batches.
   */
  async *paginate(
    endpoint: Endpoint,
    query: NewsQuery = {},
    opts: { maxPages?: number } = {},
  ): AsyncGenerator<NewsDataArticle[]> {
    const maxPages = opts.maxPages ?? Number.POSITIVE_INFINITY;
    let page: string | undefined = query.page;
    let pages = 0;

    while (pages < maxPages) {
      const resp = await this.fetchPage(endpoint, { ...query, page });
      pages++;
      yield resp.results ?? [];
      if (!resp.nextPage) break;
      page = resp.nextPage;
    }
  }

  /** Collect articles across pages into a single array. */
  async collect(
    endpoint: Endpoint,
    query: NewsQuery = {},
    opts: { maxPages?: number } = {},
  ): Promise<NewsDataArticle[]> {
    const all: NewsDataArticle[] = [];
    for await (const batch of this.paginate(endpoint, query, opts)) {
      all.push(...batch);
    }
    return all;
  }

  // --- internals ---

  private async request(
    endpoint: string,
    params: Record<string, string>,
  ): Promise<NewsDataSuccess> {
    const url = this.buildUrl(endpoint, params);

    for (let attempt = 1; ; attempt++) {
      const res = await fetch(url, { headers: { Accept: "application/json" } });

      if (res.status === 429) {
        if (attempt > this.maxRetries) {
          throw new NewsDataApiError(
            429,
            "Rate limit reached (HTTP 429). Slow down or wait before retrying.",
          );
        }
        await sleep(this.backoffMs(attempt, res));
        continue;
      }

      let body: any = null;
      try {
        body = await res.json();
      } catch {
        /* non-JSON body */
      }

      if (!res.ok || body?.status === "error") {
        const msg = body?.results?.message ?? body?.message ?? res.statusText;
        const code = body?.results?.code;
        if (res.status === 401) {
          throw new NewsDataApiError(401, `Invalid or unauthorized API key: ${msg}`, code);
        }
        throw new NewsDataApiError(res.status || 500, String(msg), code);
      }

      return body as NewsDataSuccess;
    }
  }

  private buildUrl(endpoint: string, params: Record<string, string>): string {
    const url = new URL(`${BASE_URL}/${endpoint}`);
    url.searchParams.set("apikey", this.apiKey);
    for (const [k, v] of Object.entries(params)) {
      if (v !== "" && v !== undefined && v !== null) url.searchParams.set(k, v);
    }
    return url.toString();
  }

  private toParams(query: NewsQuery): Record<string, string> {
    const out: Record<string, string> = {};
    for (const [k, v] of Object.entries(query)) {
      if (v === undefined || v === null || v === "") continue;
      out[k] = typeof v === "boolean" ? (v ? "1" : "0") : String(v);
    }
    return out;
  }

  private hasPaid(params: Record<string, string>): boolean {
    return Object.keys(params).some((k) => PAID_PARAMS.has(k));
  }

  private stripPaid(params: Record<string, string>): Record<string, string> {
    const out: Record<string, string> = {};
    for (const [k, v] of Object.entries(params)) {
      if (!PAID_PARAMS.has(k)) out[k] = v;
    }
    return out;
  }

  private backoffMs(attempt: number, res: Response): number {
    const retryAfter = res.headers.get("retry-after");
    if (retryAfter) {
      const secs = Number(retryAfter);
      if (!Number.isNaN(secs)) return secs * 1000;
    }
    return Math.min(1000 * 2 ** (attempt - 1), 8000);
  }
}
