/**
 * Runnable examples for the newsdata.io news API.
 *
 *   npm run latest
 *   npm run paginate -- --pages=3
 *   npm run filter -- --country=us --category=technology
 *   npm run sentiment
 */
import { NewsDataApiError, NewsDataClient } from "./client.js";
import type { NewsDataArticle, NewsQuery } from "./types.js";
import { formatArticle, sentimentBreakdown } from "./format.js";

function parseFlags(args: string[]): Record<string, string> {
  const out: Record<string, string> = {};
  for (const arg of args) {
    const m = /^--([^=]+)=(.*)$/.exec(arg);
    if (m) out[m[1]] = m[2];
  }
  return out;
}

function printArticles(articles: NewsDataArticle[]): void {
  articles.forEach((a, i) => {
    console.log(formatArticle(a, i));
    console.log("");
  });
}

async function runLatest(flags: Record<string, string>): Promise<void> {
  const client = new NewsDataClient();
  const query: NewsQuery = { q: flags.q, language: flags.language ?? "en" };
  const page = await client.fetchPage("latest", query);

  console.log(`Latest headlines (${page.results.length} of ~${page.totalResults}):`);
  console.log("");
  if (page.results.length === 0) {
    console.log("No articles matched. Try a different query.");
    return;
  }
  printArticles(page.results);
}

async function runPaginate(flags: Record<string, string>): Promise<void> {
  const client = new NewsDataClient();
  const maxPages = Number(flags.pages ?? "3");
  const query: NewsQuery = { q: flags.q ?? "technology", language: flags.language ?? "en" };

  let total = 0;
  let pageNo = 0;
  for await (const batch of client.paginate("latest", query, { maxPages })) {
    pageNo++;
    total += batch.length;
    console.log(`page ${pageNo}: ${batch.length} articles`);
    for (const a of batch) console.log(`  - ${a.title ?? "(untitled)"}`);
  }
  console.log("");
  console.log(`Collected ${total} articles across ${pageNo} page(s).`);
}

async function runFilter(flags: Record<string, string>): Promise<void> {
  const client = new NewsDataClient();
  const query: NewsQuery = {
    q: flags.q,
    country: flags.country,
    category: flags.category,
    language: flags.language ?? "en",
    domain: flags.domain,
  };
  console.log("Filters:", JSON.stringify(query));
  console.log("");
  const page = await client.fetchPage("latest", query);
  console.log(`${page.results.length} result(s):`);
  console.log("");
  printArticles(page.results);
}

async function runSentiment(flags: Record<string, string>): Promise<void> {
  const paidMode = process.env.NEWSDATA_PAID_MODE === "1";
  const client = new NewsDataClient({ paidMode });
  const query: NewsQuery = { q: flags.q ?? "economy", language: flags.language ?? "en" };
  // sentiment= is a paid query param, so only send it in paid mode.
  if (paidMode) query.sentiment = flags.sentiment ?? "positive";

  const page = await client.fetchPage("latest", query);
  console.log(sentimentBreakdown(page.results));
  console.log("");
  printArticles(page.results.slice(0, 5));
}

function help(): void {
  console.log(
    [
      "Usage: npm run <command> [-- --flag=value]",
      "",
      "Commands:",
      "  latest      Fetch the latest headlines",
      "  paginate    Walk pages with the nextPage cursor (--pages=3)",
      "  filter      Filter by --country --category --language --domain --q",
      "  sentiment   Per-article sentiment + breakdown (degrades on free keys)",
    ].join("\n"),
  );
}

async function main(): Promise<void> {
  const [cmd, ...rest] = process.argv.slice(2);
  const flags = parseFlags(rest);
  try {
    switch (cmd) {
      case "latest":
        await runLatest(flags);
        break;
      case "paginate":
        await runPaginate(flags);
        break;
      case "filter":
        await runFilter(flags);
        break;
      case "sentiment":
        await runSentiment(flags);
        break;
      default:
        help();
    }
  } catch (err) {
    if (err instanceof NewsDataApiError) {
      console.error(`API error (HTTP ${err.httpStatus}): ${err.message}`);
    } else {
      console.error(err instanceof Error ? err.message : String(err));
    }
    process.exitCode = 1;
  }
}

main();
