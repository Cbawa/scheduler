import type { NewsDataArticle, SentimentStats } from "./types.js";

const PAID_NOTE = "sample — live sentiment requires a paid newsdata.io plan";

function asArray(value: string[] | string | null | undefined): string[] {
  if (!value) return [];
  return Array.isArray(value) ? value : [value];
}

function truncate(text: string, max: number): string {
  return text.length > max ? `${text.slice(0, max - 1)}…` : text;
}

/** One-line per-article sentiment badge, with a clear placeholder when absent. */
export function sentimentBadge(article: NewsDataArticle): string {
  switch (article.sentiment) {
    case "positive":
      return "[+ positive]";
    case "negative":
      return "[- negative]";
    case "neutral":
      return "[= neutral]";
    default:
      return "[sentiment n/a]";
  }
}

export function formatArticle(article: NewsDataArticle, index: number): string {
  const lines: string[] = [];
  const num = String(index + 1).padStart(2, " ");
  lines.push(`${num}. ${article.title ?? "(untitled)"} ${sentimentBadge(article)}`);

  const source = article.source_name ?? article.source_id ?? "unknown source";
  const date = article.pubDate ?? "";
  lines.push(`    ${source}  ${date}`.trimEnd());

  if (article.link) lines.push(`    ${article.link}`);

  const keywords = asArray(article.keywords).slice(0, 6);
  if (keywords.length) lines.push(`    keywords: ${keywords.join(", ")}`);

  const aiTags = asArray(article.ai_tag).slice(0, 6);
  lines.push(
    aiTags.length
      ? `    ai tags: ${aiTags.join(", ")}`
      : "    ai tags: none (paid newsdata.io field)",
  );

  if (article.ai_summary) {
    lines.push(`    summary: ${article.ai_summary}`);
  } else if (article.description) {
    lines.push(`    ${truncate(article.description, 140)}`);
  }

  return lines.join("\n");
}

function bar(label: string, value: number, total: number): string {
  const width = total > 0 ? Math.round((value / total) * 20) : 0;
  return `  ${label} | ${"#".repeat(width)}${".".repeat(20 - width)} ${value}`;
}

/** Aggregate sentiment over a batch; falls back to a clearly labeled sample. */
export function sentimentBreakdown(articles: NewsDataArticle[]): string {
  const counts = { positive: 0, neutral: 0, negative: 0 };
  let live = 0;
  for (const a of articles) {
    if (a.sentiment && a.sentiment in counts) {
      counts[a.sentiment as keyof typeof counts]++;
      live++;
    }
  }

  if (live === 0) {
    // No live sentiment (free tier) — show an explicitly labeled sample.
    const sample: SentimentStats = { positive: 4, neutral: 5, negative: 1 };
    return [
      "Sentiment breakdown:",
      bar("positive", sample.positive ?? 0, 10),
      bar("neutral ", sample.neutral ?? 0, 10),
      bar("negative", sample.negative ?? 0, 10),
      `(${PAID_NOTE})`,
    ].join("\n");
  }

  return [
    `Sentiment breakdown (${live} of ${articles.length} articles with sentiment):`,
    bar("positive", counts.positive, live),
    bar("neutral ", counts.neutral, live),
    bar("negative", counts.negative, live),
  ].join("\n");
}
