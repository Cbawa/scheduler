/**
 * Response and article shapes returned by the newsdata.io REST API.
 *
 * Paid-only response fields (sentiment, ai_*) are typed as nullable because
 * they are simply absent on a free API key.
 */

export interface SentimentStats {
  positive?: number;
  neutral?: number;
  negative?: number;
}

export interface NewsDataArticle {
  article_id: string;
  title: string | null;
  link: string | null;
  description: string | null;
  content: string | null;
  pubDate: string | null;
  image_url: string | null;
  source_id: string | null;
  source_name: string | null;
  source_url: string | null;
  language: string | null;
  country: string[] | null;
  category: string[] | null;
  creator: string[] | null;

  /** Usually present on the free tier. */
  keywords: string[] | null;

  /** Paid response fields — null/absent without a paid plan. */
  sentiment: "positive" | "neutral" | "negative" | null;
  sentiment_stats: SentimentStats | null;
  ai_tag: string[] | string | null;
  ai_region: string[] | string | null;
  ai_org: string[] | string | null;
  ai_summary: string | null;

  duplicate?: boolean;
}

export interface NewsDataSuccess {
  status: "success";
  totalResults: number;
  results: NewsDataArticle[];
  nextPage: string | null;
}

export interface NewsDataErrorBody {
  status: "error";
  results?: { message?: string; code?: string };
  message?: string;
}

export type Endpoint = "latest" | "crypto" | "news";

export interface NewsQuery {
  q?: string;
  qInTitle?: string;
  country?: string;
  category?: string;
  language?: string;
  domain?: string;
  domainurl?: string;
  prioritydomain?: string;
  coin?: string;
  page?: string;

  /** Paid query params — only sent when paid mode is enabled. */
  sentiment?: string;
  timeframe?: string;
  tag?: string;
  region?: string;
  organization?: string;
  from_date?: string;
  to_date?: string;
  full_content?: boolean;
}
