# newsdata-sandbox

A small browser-based sandbox for poking at the [newsdata.io](https://newsdata.io) news API without writing any code. Pick parameters in a form, hit send, and see the raw JSON response plus a readable rendering of the articles it returned. Useful for figuring out what a given combination of `q`, `country`, `category`, etc. actually returns before you wire it into something else.

It's a Flask app: the backend holds your API key and proxies requests to newsdata.io's `/1/latest` endpoint, and a single-page vanilla-JS frontend builds the query and displays results. Nothing is stored server-side beyond the key.

## Features

- Form-based query builder for the free-tier-safe parameters: `q`, `qInTitle`, `qInMeta`, `country`, `category`, `language`, `domain`, `excludedomain`
- Live, syntax-highlighted JSON response panel alongside a rendered article list
- Pagination via the API's `nextPage` cursor ("Load more" button, disabled once there's no next page)
- Per-article keyword chips (always available on the free tier)
- Sentiment and AI-tag badges when the response includes them (paid plans only) — shown as a labeled sample state otherwise, so the UI demonstrates the feature without pretending to have data it doesn't
- Clean handling of invalid keys, rate limits, and zero-result searches instead of a blank or broken page
- Optional "paid mode" toggle that adds paid-only query params (`sentiment`, `full_content`, etc.) for accounts that have them enabled

## Setup

```bash
pip install -r requirements.txt
export NEWSDATA_API_KEY=your_key_here
python main.py
```

Then open http://localhost:5000 in a browser. Get a free API key at https://newsdata.io if you don't have one.

The app reads the key only from the `NEWSDATA_API_KEY` environment variable — it refuses to start without it rather than failing confusingly later.

### Paid mode (optional)

By default the sandbox only sends parameters that work on a free newsdata.io plan. If your account has a paid plan, set:

```bash
export NEWSDATA_ENABLE_PAID=1
```

This lets the query builder attach `sentiment`, `full_content`, and similar paid-only parameters. If a paid-mode request gets rejected (403/422), the app automatically retries once without the paid parameters and shows a small notice in the UI so the search still completes.

## Usage example

With the server running, search for "electric vehicles" restricted to English articles:

```bash
curl "http://localhost:5000/api/search?q=electric+vehicles&language=en"
```

Sample (trimmed) response:

```json
{
  "status": "success",
  "totalResults": 1832,
  "nextPage": "1653493802461635",
  "results": [
    {
      "title": "EV sales climb in Q3 as battery costs fall",
      "link": "https://example.com/ev-sales-q3",
      "pubDate": "2026-09-20 14:02:11",
      "source_id": "reuters",
      "keywords": ["electric vehicles", "battery", "automotive"],
      "sentiment": null,
      "ai_tag": null
    }
  ]
}
```

In the browser, the same search renders each article as a card with its title, source, publish date, keyword chips, and a sentiment badge (shown as a greyed-out "sample — requires paid plan" pill when `sentiment` comes back null, which it will on a free key).

## How it works

- `main.py` — Flask app: serves the frontend, exposes `/api/search` which forwards the built query to `https://newsdata.io/api/1/latest`, and normalizes 401/429/empty-results into consistent JSON error shapes the frontend already knows how to render.
- `static/app.js` — builds the query string from the form, calls `/api/search`, renders results and pagination, and renders the sentiment/AI-tag widgets with sample-state fallbacks.
- `static/index.html` / `static/style.css` — the single-page UI.

## Notes

- Only `/1/latest` is used. The `/archive` and `/count` endpoints require a paid plan and aren't wired in.
- `size` is left at the API default; the free plan caps it at 10 and larger values error the whole request, so the app never sends its own `size`.
- Rate-limited responses (HTTP 429) are shown as a dismissible banner rather than a stack trace.
