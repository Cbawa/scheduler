import os
import sys

import requests
from flask import Flask, jsonify, request, send_from_directory

API_KEY = os.environ.get("NEWSDATA_API_KEY")
if not API_KEY:
    print("ERROR: NEWSDATA_API_KEY environment variable is not set.", file=sys.stderr)
    print("Get a free key at https://newsdata.io and export it before running this app.", file=sys.stderr)
    sys.exit(1)

PAID_MODE = os.environ.get("NEWSDATA_ENABLE_PAID", "").lower() in ("1", "true", "yes")

BASE_URL = "https://newsdata.io/api/1/latest"

# Parameters that are safe to send on a free plan.
FREE_PARAMS = {
    "q", "qInTitle", "qInMeta", "country", "category", "language",
    "domain", "excludedomain", "page",
}

# Parameters that only work on a paid plan and error the whole request on free keys.
PAID_PARAMS = {"sentiment", "full_content", "tag", "region", "organization", "timeframe"}

app = Flask(__name__, static_folder="static", static_url_path="")


@app.route("/")
def index():
    return send_from_directory(app.static_folder, "index.html")


def _build_params(args):
    params = {"apikey": API_KEY}
    for key in FREE_PARAMS:
        value = args.get(key)
        if value:
            params[key] = value

    if PAID_MODE:
        for key in PAID_PARAMS:
            value = args.get(key)
            if value:
                params[key] = value

    return params


def _strip_paid_params(params):
    return {k: v for k, v in params.items() if k not in PAID_PARAMS}


@app.route("/api/search")
def search():
    params = _build_params(request.args)

    try:
        resp = requests.get(BASE_URL, params=params, timeout=15)
    except requests.RequestException as exc:
        return jsonify({"status": "error", "message": f"Could not reach newsdata.io: {exc}"}), 502

    retried_without_paid = False
    if resp.status_code in (403, 422) and any(k in params for k in PAID_PARAMS):
        # Paid params rejected on this key — retry once without them so the
        # user still gets a result instead of a hard failure.
        params = _strip_paid_params(params)
        retried_without_paid = True
        try:
            resp = requests.get(BASE_URL, params=params, timeout=15)
        except requests.RequestException as exc:
            return jsonify({"status": "error", "message": f"Could not reach newsdata.io: {exc}"}), 502

    if resp.status_code == 401:
        return jsonify({"status": "error", "message": "newsdata.io rejected the API key (401). Check NEWSDATA_API_KEY."}), 401

    if resp.status_code == 429:
        return jsonify({"status": "error", "message": "Rate limit hit (429). Wait a bit before searching again."}), 429

    if not resp.ok:
        message = f"newsdata.io returned HTTP {resp.status_code}"
        try:
            body = resp.json()
            if isinstance(body, dict) and "results" in body and isinstance(body["results"], dict):
                message = body["results"].get("message", message)
        except ValueError:
            pass
        return jsonify({"status": "error", "message": message}), resp.status_code

    data = resp.json()
    results = data.get("results") or []

    articles = []
    for item in results:
        articles.append({
            "title": item.get("title") or "(untitled)",
            "link": item.get("link"),
            "source_id": item.get("source_id"),
            "pubDate": item.get("pubDate"),
            "description": item.get("description"),
            "keywords": item.get("keywords") or [],
            "sentiment": item.get("sentiment"),
            "sentiment_stats": item.get("sentiment_stats"),
            "ai_tag": item.get("ai_tag"),
            "ai_region": item.get("ai_region"),
            "ai_org": item.get("ai_org"),
            "ai_summary": item.get("ai_summary"),
            "image_url": item.get("image_url"),
        })

    return jsonify({
        "status": "success",
        "totalResults": data.get("totalResults", len(articles)),
        "nextPage": data.get("nextPage"),
        "retried_without_paid": retried_without_paid,
        "results": articles,
    })


if __name__ == "__main__":
    port = int(os.environ.get("PORT", 5000))
    app.run(host="0.0.0.0", port=port, debug=False)
