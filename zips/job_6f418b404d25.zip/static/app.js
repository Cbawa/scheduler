const form = document.getElementById("search-form");
const statusBanner = document.getElementById("status-banner");
const articleList = document.getElementById("article-list");
const jsonView = document.getElementById("json-view");
const resultCount = document.getElementById("result-count");
const loadMoreBtn = document.getElementById("load-more");

let currentParams = {};
let nextPageCursor = null;
let allArticles = [];

function showBanner(message, kind) {
  statusBanner.textContent = message;
  statusBanner.className = "banner " + (kind || "info");
  statusBanner.classList.remove("hidden");
}

function hideBanner() {
  statusBanner.classList.add("hidden");
}

function buildQueryParams(extra) {
  const params = {};
  new FormData(form).forEach((value, key) => {
    if (value) params[key] = value;
  });
  return Object.assign(params, extra || {});
}

function renderKeywords(keywords) {
  if (!keywords || keywords.length === 0) return "";
  const chips = keywords.slice(0, 6).map(k => `<span class="chip">${escapeHtml(k)}</span>`).join("");
  return `<div class="chip-row">${chips}</div>`;
}

function renderSentiment(sentiment) {
  if (sentiment) {
    const label = typeof sentiment === "string" ? sentiment : JSON.stringify(sentiment);
    return `<span class="badge sentiment-${escapeHtml(String(sentiment)).toLowerCase()}">sentiment: ${escapeHtml(label)}</span>`;
  }
  return `<span class="badge badge-sample" title="sample — live sentiment requires a paid newsdata.io plan">sentiment: sample (paid plan)</span>`;
}

function renderAiTags(ai_tag) {
  if (ai_tag && ai_tag.length) {
    const tags = Array.isArray(ai_tag) ? ai_tag : [ai_tag];
    return tags.slice(0, 5).map(t => `<span class="chip chip-ai">${escapeHtml(t)}</span>`).join("");
  }
  return `<span class="chip chip-ai chip-sample" title="sample — AI tags require a paid newsdata.io plan">ai-tag: sample</span>`;
}

function escapeHtml(str) {
  const div = document.createElement("div");
  div.textContent = str;
  return div.innerHTML;
}

function renderArticle(article) {
  const card = document.createElement("article");
  card.className = "article-card";

  const title = document.createElement("h3");
  const link = document.createElement("a");
  link.href = article.link || "#";
  link.target = "_blank";
  link.rel = "noopener";
  link.textContent = article.title;
  title.appendChild(link);
  card.appendChild(title);

  const meta = document.createElement("p");
  meta.className = "meta";
  meta.textContent = [article.source_id, article.pubDate].filter(Boolean).join(" \u00b7 ");
  card.appendChild(meta);

  if (article.description) {
    const desc = document.createElement("p");
    desc.className = "description";
    desc.textContent = article.description;
    card.appendChild(desc);
  }

  const badges = document.createElement("div");
  badges.className = "badge-row";
  badges.innerHTML = renderSentiment(article.sentiment) + renderAiTags(article.ai_tag);
  card.appendChild(badges);

  const keywordsHtml = renderKeywords(article.keywords);
  if (keywordsHtml) {
    const wrap = document.createElement("div");
    wrap.innerHTML = keywordsHtml;
    card.appendChild(wrap);
  }

  if (article.ai_summary) {
    const summary = document.createElement("p");
    summary.className = "ai-summary";
    summary.textContent = "AI summary: " + article.ai_summary;
    card.appendChild(summary);
  }

  return card;
}

async function runSearch(params, append) {
  hideBanner();
  const query = new URLSearchParams(params).toString();

  try {
    const resp = await fetch("/api/search?" + query);
    const data = await resp.json();

    if (data.status === "error") {
      showBanner(data.message, "error");
      if (!append) {
        articleList.innerHTML = "";
        resultCount.textContent = "";
      }
      loadMoreBtn.classList.add("hidden");
      jsonView.textContent = JSON.stringify(data, null, 2);
      return;
    }

    if (data.retried_without_paid) {
      showBanner("Paid parameters were rejected for this key — showing results without them.", "warn");
    }

    if (!append) {
      allArticles = data.results || [];
      articleList.innerHTML = "";
    } else {
      allArticles = allArticles.concat(data.results || []);
    }

    if ((data.results || []).length === 0 && !append) {
      articleList.innerHTML = "<p class=\"empty\">No articles found for this query.</p>";
    } else {
      data.results.forEach(article => articleList.appendChild(renderArticle(article)));
    }

    resultCount.textContent = `${allArticles.length} loaded of ${data.totalResults ?? "?"} total`;
    jsonView.textContent = JSON.stringify(data, null, 2);

    nextPageCursor = data.nextPage || null;
    currentParams = params;
    loadMoreBtn.classList.toggle("hidden", !nextPageCursor);
  } catch (err) {
    showBanner("Request failed: " + err.message, "error");
  }
}

form.addEventListener("submit", (e) => {
  e.preventDefault();
  const params = buildQueryParams();
  runSearch(params, false);
});

loadMoreBtn.addEventListener("click", () => {
  if (!nextPageCursor) return;
  const params = Object.assign({}, currentParams, { page: nextPageCursor });
  runSearch(params, true);
});
