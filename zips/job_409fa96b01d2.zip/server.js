import express from 'express';
import path from 'path';
import { fileURLToPath } from 'url';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const app = express();

const PORT = process.env.PORT || 5174;
const API_KEY = process.env.NEWSDATA_API_KEY;
const PAID = process.env.NEWSDATA_PAID === '1';
const isProd =
  process.argv.includes('--prod') || process.env.NODE_ENV === 'production';

const NEWSDATA = 'https://newsdata.io/api/1';
const COINGECKO = 'https://api.coingecko.com/api/v3';

if (!API_KEY) {
  console.error(
    'NEWSDATA_API_KEY is not set.\n' +
      'Get a free key at https://newsdata.io and start again, e.g.:\n' +
      '  NEWSDATA_API_KEY=your_key npm run dev'
  );
  process.exit(1);
}

async function fetchNews(page, sentiment) {
  const params = new URLSearchParams();
  params.set('apikey', API_KEY);
  params.set('q', 'bitcoin');
  params.set('language', 'en');
  if (page) params.set('page', page);
  // Paid query param: only attempted when paid mode is enabled.
  if (PAID && sentiment) params.set('sentiment', sentiment);
  return fetch(`${NEWSDATA}/latest?${params.toString()}`);
}

app.get('/api/news', async (req, res) => {
  const page = typeof req.query.page === 'string' ? req.query.page : null;
  const sentiment =
    PAID && typeof req.query.sentiment === 'string' ? req.query.sentiment : null;
  try {
    let r = await fetchNews(page, sentiment);
    // A free key rejects paid query params — retry once without them.
    if (sentiment && (r.status === 403 || r.status === 422)) {
      r = await fetchNews(page, null);
    }
    if (r.status === 401) {
      return res
        .status(401)
        .json({ error: 'Invalid newsdata.io API key. Check NEWSDATA_API_KEY.' });
    }
    if (r.status === 429) {
      return res
        .status(429)
        .json({ error: 'newsdata.io rate limit reached. Try again in a moment.' });
    }
    const data = await r.json().catch(() => ({}));
    if (!r.ok || data.status === 'error') {
      const message =
        (data.results && data.results.message) ||
        data.message ||
        'Request to newsdata.io failed.';
      return res.status(r.ok ? 502 : r.status).json({ error: message });
    }
    res.json({ results: data.results || [], nextPage: data.nextPage || null });
  } catch (e) {
    res.status(502).json({ error: 'Could not reach newsdata.io.' });
  }
});

app.get('/api/price', async (req, res) => {
  try {
    const [spotRes, chartRes] = await Promise.all([
      fetch(
        `${COINGECKO}/simple/price?ids=bitcoin&vs_currencies=usd&include_24hr_change=true`
      ),
      fetch(
        `${COINGECKO}/coins/bitcoin/market_chart?vs_currency=usd&days=7&interval=daily`
      ),
    ]);
    const spot = await spotRes.json().catch(() => ({}));
    const chart = await chartRes.json().catch(() => ({}));
    res.json({
      usd: (spot.bitcoin && spot.bitcoin.usd) ?? null,
      change24h: (spot.bitcoin && spot.bitcoin.usd_24h_change) ?? null,
      sparkline: Array.isArray(chart.prices)
        ? chart.prices.map((p) => p[1])
        : [],
    });
  } catch (e) {
    res.status(502).json({ error: 'Could not reach CoinGecko.' });
  }
});

async function start() {
  if (isProd) {
    app.use(express.static(path.join(__dirname, 'dist')));
    app.get('*', (req, res) =>
      res.sendFile(path.join(__dirname, 'dist', 'index.html'))
    );
  } else {
    const { createServer } = await import('vite');
    const vite = await createServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  }
  app.listen(PORT, () => {
    console.log(`Bitcoin News Tracker running on http://localhost:${PORT}`);
  });
}

start();
