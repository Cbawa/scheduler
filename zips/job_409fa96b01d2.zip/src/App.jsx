import React, { useEffect, useState, useCallback } from 'react';

const SENTIMENTS = ['positive', 'negative', 'neutral'];
const COLORS = { positive: '#1a7f4b', negative: '#c0362c', neutral: '#7a7a7a' };

// On a free key, paid fields can come back as a placeholder string instead of null.
function paidPlaceholder(v) {
  return typeof v === 'string' && v.toUpperCase().includes('ONLY AVAILABLE IN PAID');
}

function cleanText(v) {
  if (!v || typeof v !== 'string' || paidPlaceholder(v)) return null;
  return v;
}

function cleanList(v) {
  if (!Array.isArray(v)) return [];
  return v.filter((x) => typeof x === 'string' && x && !paidPlaceholder(x));
}

function classifySentiment(v) {
  if (!v || typeof v !== 'string' || paidPlaceholder(v)) return null;
  const s = v.toLowerCase();
  return SENTIMENTS.includes(s) ? s : null;
}

function formatPrice(n) {
  if (n == null) return '\u2014';
  return n.toLocaleString('en-US', {
    style: 'currency',
    currency: 'USD',
    maximumFractionDigits: 0,
  });
}

function Sparkline({ data }) {
  if (!data || data.length < 2) return null;
  const w = 130;
  const h = 38;
  const min = Math.min(...data);
  const max = Math.max(...data);
  const range = max - min || 1;
  const points = data
    .map((v, i) => {
      const x = (i / (data.length - 1)) * w;
      const y = h - ((v - min) / range) * h;
      return `${x.toFixed(1)},${y.toFixed(1)}`;
    })
    .join(' ');
  const up = data[data.length - 1] >= data[0];
  return (
    <svg className="sparkline" width={w} height={h} viewBox={`0 0 ${w} ${h}`}>
      <polyline
        points={points}
        fill="none"
        stroke={up ? COLORS.positive : COLORS.negative}
        strokeWidth="2"
      />
    </svg>
  );
}

function PriceOverlay({ price }) {
  if (!price) return <div className="price-overlay muted">Loading price\u2026</div>;
  const change = price.change24h;
  const up = change != null && change >= 0;
  return (
    <div className="price-overlay">
      <div className="price-main">
        <span className="price-value">{formatPrice(price.usd)}</span>
        {change != null && (
          <span className={up ? 'change up' : 'change down'}>
            {up ? '\u25B2' : '\u25BC'} {Math.abs(change).toFixed(2)}%
          </span>
        )}
      </div>
      <div className="price-side">
        <Sparkline data={price.sparkline} />
        <span className="muted small">7-day \u00B7 CoinGecko</span>
      </div>
    </div>
  );
}

function SentimentBreakdown({ articles }) {
  const counts = { positive: 0, negative: 0, neutral: 0 };
  let real = false;
  for (const a of articles) {
    const c = classifySentiment(a.sentiment);
    if (c) {
      counts[c] += 1;
      real = true;
    }
  }
  const sample = { positive: 6, negative: 3, neutral: 5 };
  const data = real ? counts : sample;
  const total = SENTIMENTS.reduce((s, k) => s + data[k], 0) || 1;
  return (
    <section className="panel">
      <h2>Sentiment breakdown</h2>
      <div className="bars">
        {SENTIMENTS.map((k) => {
          const pct = Math.round((data[k] / total) * 100);
          return (
            <div className="bar-row" key={k}>
              <span className="bar-label">{k}</span>
              <div className="bar-track">
                <div
                  className="bar-fill"
                  style={{ width: `${pct}%`, background: COLORS[k] }}
                />
              </div>
              <span className="bar-count">{data[k]}</span>
            </div>
          );
        })}
      </div>
      {!real && (
        <p className="caption">
          Sample values \u2014 live sentiment requires a paid newsdata.io plan.
        </p>
      )}
    </section>
  );
}

function SentimentBadge({ value }) {
  const c = classifySentiment(value);
  if (!c) return null;
  return (
    <span className="badge" style={{ background: COLORS[c] }}>
      {c}
    </span>
  );
}

function ArticleCard({ a }) {
  const summary = cleanText(a.ai_summary) || cleanText(a.description);
  const keywords = cleanList(a.keywords).slice(0, 6);
  const aiTags = cleanList(a.ai_tag).slice(0, 4);
  const date = a.pubDate ? a.pubDate.slice(0, 16) : '';
  return (
    <article className="card">
      {a.image_url && (
        <img
          className="card-img"
          src={a.image_url}
          alt=""
          loading="lazy"
          onError={(e) => {
            e.currentTarget.style.display = 'none';
          }}
        />
      )}
      <div className="card-body">
        <div className="card-meta">
          <span>{a.source_id || 'unknown source'}</span>
          {date && <span>\u00B7 {date}</span>}
          <SentimentBadge value={a.sentiment} />
        </div>
        <h3 className="card-title">
          <a href={a.link} target="_blank" rel="noreferrer noopener">
            {a.title || 'Untitled'}
          </a>
        </h3>
        {summary && <p className="card-summary">{summary}</p>}
        {(keywords.length > 0 || aiTags.length > 0) && (
          <div className="chips">
            {aiTags.map((t) => (
              <span className="chip chip-ai" key={`ai-${t}`}>
                #{t}
              </span>
            ))}
            {keywords.map((k) => (
              <span className="chip" key={`kw-${k}`}>
                {k}
              </span>
            ))}
          </div>
        )}
      </div>
    </article>
  );
}

export default function App() {
  const [articles, setArticles] = useState([]);
  const [nextPage, setNextPage] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);
  const [price, setPrice] = useState(null);

  const loadNews = useCallback(async (page) => {
    setLoading(true);
    setError(null);
    try {
      const url = page
        ? `/api/news?page=${encodeURIComponent(page)}`
        : '/api/news';
      const res = await fetch(url);
      const data = await res.json();
      if (!res.ok) {
        setError(data.error || 'Failed to load news.');
        return;
      }
      const results = Array.isArray(data.results) ? data.results : [];
      setArticles((prev) => (page ? [...prev, ...results] : results));
      setNextPage(data.nextPage || null);
    } catch (e) {
      setError('Network error while loading news.');
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    loadNews(null);
  }, [loadNews]);

  useEffect(() => {
    fetch('/api/price')
      .then((r) => r.json())
      .then((d) => {
        if (!d.error) setPrice(d);
      })
      .catch(() => {});
  }, []);

  return (
    <div className="app">
      <header className="header">
        <h1>Bitcoin News Tracker</h1>
        <PriceOverlay price={price} />
      </header>

      <SentimentBreakdown articles={articles} />

      {error && (
        <div className="notice error">
          <span>{error}</span>
          <button onClick={() => loadNews(null)}>Retry</button>
        </div>
      )}

      <section className="feed">
        {articles.map((a, i) => (
          <ArticleCard key={a.article_id || a.link || i} a={a} />
        ))}
      </section>

      {!loading && !error && articles.length === 0 && (
        <p className="muted">No articles found right now.</p>
      )}

      {loading && <p className="muted">Loading\u2026</p>}

      {nextPage && !loading && (
        <div className="load-more">
          <button onClick={() => loadNews(nextPage)}>Load more</button>
        </div>
      )}

      <footer className="footer">News from newsdata.io \u00B7 Price from CoinGecko</footer>
    </div>
  );
}
