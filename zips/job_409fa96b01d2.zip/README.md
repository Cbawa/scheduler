# Bitcoin News Tracker

A small React app that shows recent Bitcoin news next to the current BTC price.
Each article lists its source, publish time, and keyword tags; when the data is
available it also shows a sentiment badge and an AI summary line. The price and a
7-day sparkline come from CoinGecko.

## Data sources

- News: the newsdata.io API — get a free API key at https://newsdata.io
- Price: the public CoinGecko API (no key required)

## Requirements

- Node.js 18 or newer (uses the built-in `fetch`)

## Setup

```bash
npm install
export NEWSDATA_API_KEY=your_key_here
npm run dev
```

Then open http://localhost:5174.

The key is read from the `NEWSDATA_API_KEY` environment variable and used only on
the server side (`server.js`), so it is never bundled into the browser code. The
same server proxies the news and price requests, which also avoids browser CORS
issues.

## Production build

```bash
npm run build      # outputs static files to dist/
npm start          # serves dist/ and the API proxy
```

## Configuration

| Variable           | Default | Description                                            |
|--------------------|---------|--------------------------------------------------------|
| `NEWSDATA_API_KEY` | —       | Required. Your newsdata.io API key.                    |
| `PORT`             | 5174    | Port for the local server.                             |
| `NEWSDATA_PAID`    | unset   | Set to `1` to allow paid query parameters (see below). |

## Free vs. paid data

The default request only uses parameters that work on a free newsdata.io key
(`q`, `language`, and the `page` cursor for pagination).

Some response fields — `sentiment`, `ai_tag`, `ai_summary` — are only filled in on
paid newsdata.io plans. The app reads them when present and falls back to a clean
placeholder otherwise:

- The sentiment badge is hidden when an article has no sentiment.
- The sentiment breakdown chart shows clearly labeled sample values until real
  sentiment data is available.
- The summary line falls back to the article description.
- Keyword tags come from the free `keywords` field and show for every article.

Setting `NEWSDATA_PAID=1` lets the server send the `sentiment` query parameter. If
a request with paid parameters is rejected, the server retries once without them so
you still get results.

## Project layout

- `server.js` — Express server: API proxy plus static/dev serving
- `src/App.jsx` — the React UI
- `src/main.jsx` — entry point
- `index.html` — page shell and styles

## License

MIT
