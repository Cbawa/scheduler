"""Atomic JSON persistence for per-chat bot preferences."""
from __future__ import annotations

import json
import os
import tempfile
import threading

_LOCK = threading.Lock()
PATH = os.getenv("SUBSCRIPTIONS_FILE", "subscriptions.json")


def load() -> dict:
    """Return the stored preferences map, or {} if the file is missing/corrupt."""
    try:
        with open(PATH, "r", encoding="utf-8") as fh:
            data = json.load(fh)
        return data if isinstance(data, dict) else {}
    except (FileNotFoundError, json.JSONDecodeError):
        return {}


def save(data: dict) -> None:
    """Write the preferences map atomically (temp file + os.replace)."""
    with _LOCK:
        directory = os.path.dirname(os.path.abspath(PATH)) or "."
        fd, tmp = tempfile.mkstemp(dir=directory, suffix=".tmp")
        try:
            with os.fdopen(fd, "w", encoding="utf-8") as fh:
                json.dump(data, fh, indent=2, ensure_ascii=False)
            os.replace(tmp, PATH)
        except Exception:
            if os.path.exists(tmp):
                os.remove(tmp)
            raise
