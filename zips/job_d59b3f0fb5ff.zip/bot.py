"""Telegram news-digest bot powered by newsdata.io.

Sends on-demand and hourly news digests filtered by category, country, or
keyword. The core flow runs on the free newsdata.io plan; paid features
(sentiment, AI fields) are optional and degrade gracefully.
"""
from __future__ import annotations

import html
import logging
import sys

from telegram import Update
from telegram.constants import ParseMode
from telegram.ext import Application, CommandHandler, ContextTypes

import config
import storage
from newsdata import NewsDataClient, NewsDataError

logging.basicConfig(
    format="%(asctime)s %(levelname)s %(name)s: %(message)s",
    level=logging.INFO,
)
log = logging.getLogger("telegram-news-bot")

VALID_CATEGORIES = (
    "business", "crime", "domestic", "education", "entertainment",
    "environment", "food", "health", "lifestyle", "other", "politics",
    "science", "sports", "technology", "top", "tourism", "world",
)

JOB_PREFIX = "digest:"

HELP = (
    "🤖 <b>newsdata.io News Bot</b>\n"
    "I send news digests by category, country, or keyword.\n\n"
    "<b>Commands</b>\n"
    "/digest — get a digest now\n"
    "/category &lt;name&gt; — filter by category (e.g. technology)\n"
    "/country &lt;code&gt; — filter by country (e.g. us, gb, in)\n"
    "/keyword &lt;words&gt; — filter by search term\n"
    "/language &lt;code&gt; — set language (default en)\n"
    "/clear — clear all filters\n"
    "/subscribe — receive a digest every hour\n"
    "/unsubscribe — stop hourly digests\n"
    "/status — show your current settings\n"
    "/help — show this message"
)


def get_prefs(chat_id: str) -> dict:
    return storage.load().get(chat_id, {})


def set_prefs(chat_id: str, prefs: dict) -> None:
    data = storage.load()
    if prefs:
        data[chat_id] = prefs
    else:
        data.pop(chat_id, None)
    storage.save(data)


def describe(prefs: dict) -> str:
    bits = []
    if prefs.get("category"):
        bits.append(f"category={prefs['category']}")
    if prefs.get("country"):
        bits.append(f"country={prefs['country']}")
    if prefs.get("keyword"):
        bits.append(f'keyword="{prefs["keyword"]}"')
    bits.append(f"language={prefs.get('language', config.DEFAULT_LANGUAGE)}")
    return ", ".join(bits)


def render_article(a: dict, show_sentiment: bool, show_ai: bool) -> str:
    title = a.get("title") or "(untitled)"
    link = a.get("link") or ""
    source = a.get("source_id") or "unknown"
    pub = a.get("pubDate") or ""
    desc = (a.get("description") or "").strip()
    if len(desc) > 220:
        desc = desc[:217] + "..."

    lines = [f"<b>{html.escape(str(title))}</b>"]
    meta = f"📰 {html.escape(str(source))}"
    if pub:
        meta += f" · {html.escape(str(pub))}"
    lines.append(meta)
    if desc:
        lines.append(html.escape(desc))

    if show_sentiment:
        sentiment = a.get("sentiment") or "n/a"
        lines.append(f"📊 Sentiment: {html.escape(str(sentiment))}")
    if show_ai:
        summary = a.get("ai_summary") or "n/a"
        lines.append(f"🤖 AI summary: {html.escape(str(summary))}")
        tag = a.get("ai_tag")
        if isinstance(tag, list):
            tag = ", ".join(map(str, tag))
        if tag:
            lines.append(f"🏷️ AI tags: {html.escape(str(tag))}")

    if link:
        lines.append(f'<a href="{html.escape(str(link))}">Read more →</a>')
    return "\n".join(lines)


async def deliver_digest(context: ContextTypes.DEFAULT_TYPE, chat_id: str, prefs: dict) -> None:
    client: NewsDataClient = context.bot_data["client"]
    language = prefs.get("language", config.DEFAULT_LANGUAGE)
    try:
        articles = await client.latest(
            q=prefs.get("keyword"),
            country=prefs.get("country") or config.DEFAULT_COUNTRY or None,
            category=prefs.get("category"),
            language=language,
        )
    except NewsDataError as exc:
        await context.bot.send_message(chat_id=int(chat_id), text=f"⚠️ {exc}")
        return

    if not articles:
        await context.bot.send_message(
            chat_id=int(chat_id),
            text=f"No news found for {describe(prefs)} right now. Try different filters.",
        )
        return

    header = f"🗞️ <b>News digest</b> — {html.escape(describe(prefs))}"
    if client.paid_blocked:
        header += (
            "\n<i>Note: sentiment filtering needs a paid newsdata.io plan; "
            "showing free-tier results.</i>"
        )
    await context.bot.send_message(
        chat_id=int(chat_id), text=header, parse_mode=ParseMode.HTML
    )

    for article in articles[: config.DIGEST_SIZE]:
        await context.bot.send_message(
            chat_id=int(chat_id),
            text=render_article(article, client.enable_sentiment, client.enable_ai),
            parse_mode=ParseMode.HTML,
        )


async def scheduled_digest(context: ContextTypes.DEFAULT_TYPE) -> None:
    chat_id = context.job.data["chat_id"]
    prefs = get_prefs(chat_id)
    if prefs.get("subscribed"):
        await deliver_digest(context, chat_id, prefs)


def reschedule(job_queue, chat_id: str) -> None:
    for job in job_queue.get_jobs_by_name(JOB_PREFIX + chat_id):
        job.schedule_removal()
    interval = config.DIGEST_INTERVAL_MINUTES * 60
    job_queue.run_repeating(
        scheduled_digest,
        interval=interval,
        first=interval,
        name=JOB_PREFIX + chat_id,
        data={"chat_id": chat_id},
    )


async def cmd_start(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    await update.message.reply_text(HELP, parse_mode=ParseMode.HTML)


async def cmd_help(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    await update.message.reply_text(HELP, parse_mode=ParseMode.HTML)


async def cmd_digest(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    chat_id = str(update.effective_chat.id)
    await update.message.reply_text("Fetching the latest news… 🗞️")
    await deliver_digest(context, chat_id, get_prefs(chat_id))


async def cmd_category(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    chat_id = str(update.effective_chat.id)
    if not context.args:
        await update.message.reply_text(
            "Usage: /category technology\nValid: " + ", ".join(VALID_CATEGORIES)
        )
        return
    cat = context.args[0].lower()
    prefs = get_prefs(chat_id)
    if cat in ("none", "clear", "off"):
        prefs.pop("category", None)
        await update.message.reply_text("Category filter cleared.")
    elif cat not in VALID_CATEGORIES:
        await update.message.reply_text(
            f"Unknown category '{cat}'.\nValid: " + ", ".join(VALID_CATEGORIES)
        )
        return
    else:
        prefs["category"] = cat
        await update.message.reply_text(f"Category set to '{cat}'.")
    set_prefs(chat_id, prefs)


async def cmd_country(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    chat_id = str(update.effective_chat.id)
    if not context.args:
        await update.message.reply_text("Usage: /country us  (ISO-2 code; 'none' to clear)")
        return
    code = context.args[0].lower()
    prefs = get_prefs(chat_id)
    if code in ("none", "clear", "off"):
        prefs.pop("country", None)
        await update.message.reply_text("Country filter cleared.")
    else:
        prefs["country"] = code
        await update.message.reply_text(f"Country set to '{code}'.")
    set_prefs(chat_id, prefs)


async def cmd_keyword(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    chat_id = str(update.effective_chat.id)
    if not context.args:
        await update.message.reply_text("Usage: /keyword climate change  ('none' to clear)")
        return
    text = " ".join(context.args)
    prefs = get_prefs(chat_id)
    if text.lower() in ("none", "clear", "off"):
        prefs.pop("keyword", None)
        await update.message.reply_text("Keyword filter cleared.")
    else:
        prefs["keyword"] = text
        await update.message.reply_text(f'Keyword set to "{text}".')
    set_prefs(chat_id, prefs)


async def cmd_language(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    chat_id = str(update.effective_chat.id)
    if not context.args:
        await update.message.reply_text("Usage: /language en")
        return
    prefs = get_prefs(chat_id)
    prefs["language"] = context.args[0].lower()
    set_prefs(chat_id, prefs)
    await update.message.reply_text(f"Language set to '{prefs['language']}'.")


async def cmd_clear(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    chat_id = str(update.effective_chat.id)
    subscribed = get_prefs(chat_id).get("subscribed", False)
    set_prefs(chat_id, {"subscribed": True} if subscribed else {})
    await update.message.reply_text("Filters cleared. Now showing top headlines.")


async def cmd_subscribe(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    chat_id = str(update.effective_chat.id)
    prefs = get_prefs(chat_id)
    prefs["subscribed"] = True
    set_prefs(chat_id, prefs)
    reschedule(context.job_queue, chat_id)
    await update.message.reply_text(
        f"✅ Subscribed! I'll send a digest every {config.DIGEST_INTERVAL_MINUTES} min "
        f"for {describe(prefs)}.\nUse /unsubscribe to stop."
    )


async def cmd_unsubscribe(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    chat_id = str(update.effective_chat.id)
    prefs = get_prefs(chat_id)
    prefs["subscribed"] = False
    set_prefs(chat_id, prefs)
    for job in context.job_queue.get_jobs_by_name(JOB_PREFIX + chat_id):
        job.schedule_removal()
    await update.message.reply_text("🛑 Unsubscribed. No more hourly digests.")


async def cmd_status(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    chat_id = str(update.effective_chat.id)
    prefs = get_prefs(chat_id)
    client: NewsDataClient = context.bot_data["client"]
    paid = (
        ("sentiment ON" if client.enable_sentiment else "sentiment off")
        + ", "
        + ("AI fields ON" if client.enable_ai else "AI fields off")
    )
    await update.message.reply_text(
        "<b>Your settings</b>\n"
        f"Filters: {html.escape(describe(prefs))}\n"
        f"Hourly digest: {'on' if prefs.get('subscribed') else 'off'}\n"
        f"Paid showcase: {paid}",
        parse_mode=ParseMode.HTML,
    )


async def on_startup(app: Application) -> None:
    count = 0
    for chat_id, prefs in storage.load().items():
        if prefs.get("subscribed"):
            reschedule(app.job_queue, chat_id)
            count += 1
    log.info("Rescheduled %d subscription(s) on startup.", count)


def build_application() -> Application:
    app = (
        Application.builder()
        .token(config.TELEGRAM_BOT_TOKEN)
        .post_init(on_startup)
        .build()
    )
    app.bot_data["client"] = NewsDataClient(
        config.NEWSDATA_API_KEY,
        enable_sentiment=config.ENABLE_SENTIMENT,
        enable_ai=config.ENABLE_AI,
        sentiment_filter=config.SENTIMENT_FILTER,
    )
    commands = {
        "start": cmd_start,
        "help": cmd_help,
        "digest": cmd_digest,
        "category": cmd_category,
        "country": cmd_country,
        "keyword": cmd_keyword,
        "language": cmd_language,
        "clear": cmd_clear,
        "subscribe": cmd_subscribe,
        "unsubscribe": cmd_unsubscribe,
        "status": cmd_status,
    }
    for name, handler in commands.items():
        app.add_handler(CommandHandler(name, handler))
    return app


def main() -> None:
    missing = [
        name
        for name, value in (
            ("TELEGRAM_BOT_TOKEN", config.TELEGRAM_BOT_TOKEN),
            ("NEWSDATA_API_KEY", config.NEWSDATA_API_KEY),
        )
        if not value
    ]
    if missing:
        sys.exit(
            "Missing required environment variable(s): "
            + ", ".join(missing)
            + "\nSee .env.example and set them before running."
        )
    app = build_application()
    log.info("Bot starting (polling)…")
    app.run_polling(allowed_updates=Update.ALL_TYPES)


if __name__ == "__main__":
    main()
