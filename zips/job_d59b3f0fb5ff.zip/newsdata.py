"""Async client for the newsdata.io REST API.

The core /news flow works on the FREE plan. Optional paid-plan features
(sentiment filtering, AI fields) are requested only when explicitly enabled
via toggles and degrade gracefully when the API rejects them.
"""
from __future__ import annotations

import logging
from typing import Any, Optional

import httpx

log = logging.getLogger(__name__)

BASE_URL = "https://newsdata.io/api/1"


class NewsDataError(Exception):
    """Unrecoverable newsdata.io API error."""


class PaidPlanRequired(Exception):
    """A requested feature requires a paid newsdata.io plan."""


class NewsDataClient:
    """Thin async wrapper around the newsdata.io /news endpoint."""

    def __init__(
        self,
        api_key: str,
        *,
        enable_sentiment: bool = False,
        enable_ai: bool = False,
        sentiment_filter: str = "",
        timeout: float = 20.0,
    ) -> None:
        if not api_key:
            raise NewsDataError("NEWSDATA_API_KEY is not set")
        self.api_key = api_key
        self.enable_sentiment = enable_sentiment
        self.enable_ai = enable_ai
        self.sentiment_filter = sentiment_filter
        self.timeout = timeout
        # Set when a paid-only parameter was dropped so the caller can warn.
        self.paid_blocked = False

    @staticmethod
    def _message(resp: httpx.Response) -> str:
        try:
            payload = resp.json()
            results = payload.get("results")
            if isinstance(results, dict):
                return str(results.get("message", ""))
            return str(payload.get("message", ""))
        except Exception:
            return resp.text[:200]

    async def _get(self, endpoint: str, params: dict[str, Any]) -> dict[str, Any]:
        url = f"{BASE_URL}/{endpoint}"
        try:
            async with httpx.AsyncClient(timeout=self.timeout) as client:
                resp = await client.get(url, params=params)
        except httpx.RequestError as exc:
            raise NewsDataError(f"Network error contacting newsdata.io: {exc}") from exc

        if resp.status_code == 401:
            raise NewsDataError(
                "Invalid NEWSDATA_API_KEY (HTTP 401). Check your key at newsdata.io."
            )
        if resp.status_code == 429:
            raise NewsDataError(
                "Rate limit reached (HTTP 429). Wait a moment or upgrade your plan."
            )
        if resp.status_code in (403, 422):
            # Often returned when a paid-only feature is requested on a free key.
            raise PaidPlanRequired(self._message(resp) or f"HTTP {resp.status_code}")
        if resp.status_code >= 400:
            raise NewsDataError(
                f"newsdata.io error HTTP {resp.status_code}: {resp.text[:200]}"
            )

        data = resp.json()
        if data.get("status") != "success":
            raise NewsDataError(f"newsdata.io returned status={data.get('status')!r}")
        return data

    async def latest(
        self,
        *,
        q: Optional[str] = None,
        country: Optional[str] = None,
        category: Optional[str] = None,
        language: str = "en",
        page: Optional[str] = None,
    ) -> list[dict[str, Any]]:
        """Fetch latest news. Retries without paid params if they are rejected."""
        want_sentiment = self.enable_sentiment and bool(self.sentiment_filter)

        for attempt in (1, 2):
            params: dict[str, Any] = {"apikey": self.api_key, "language": language}
            if q:
                params["q"] = q
            if country:
                params["country"] = country
            if category:
                params["category"] = category
            if page:
                params["page"] = page
            # Paid-only filter (OFF by default).
            if want_sentiment:
                params["sentiment"] = self.sentiment_filter

            try:
                data = await self._get("news", params)
                return data.get("results") or []
            except PaidPlanRequired as exc:
                if attempt == 1 and want_sentiment:
                    log.warning(
                        "Paid sentiment filter rejected (%s); retrying on free tier.",
                        exc,
                    )
                    self.paid_blocked = True
                    want_sentiment = False
                    continue
                raise NewsDataError(
                    f"newsdata.io rejected the request (likely a paid-only feature): {exc}"
                ) from exc
        return []
