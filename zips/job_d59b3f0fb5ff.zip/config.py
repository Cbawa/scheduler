"""Environment-variable configuration for the Telegram news bot."""
import os

from dotenv import load_dotenv

load_dotenv()


def _bool(name: str, default: bool = False) -> bool:
    val = os.getenv(name)
    if val is None:
        return default
    return val.strip().lower() in {"1", "true", "yes", "on"}


def _int(name: str, default: int) -> int:
    try:
        return int(os.getenv(name, str(default)))
    except (TypeError, ValueError):
        return default


# --- Required ---
TELEGRAM_BOT_TOKEN = os.getenv("TELEGRAM_BOT_TOKEN", "").strip()
NEWSDATA_API_KEY = os.getenv("NEWSDATA_API_KEY", "").strip()

# --- Optional core settings ---
DEFAULT_LANGUAGE = os.getenv("DEFAULT_LANGUAGE", "en").strip() or "en"
DEFAULT_COUNTRY = os.getenv("DEFAULT_COUNTRY", "").strip()
DIGEST_SIZE = max(1, _int("DIGEST_SIZE", 5))
DIGEST_INTERVAL_MINUTES = max(1, _int("DIGEST_INTERVAL_MINUTES", 60))

# --- Optional paid-plan showcase toggles (OFF by default) ---
# Each requires a paid newsdata.io plan and degrades gracefully when absent.
ENABLE_SENTIMENT = _bool("ENABLE_SENTIMENT", False)
NEWSDATA_PLAN = os.getenv("NEWSDATA_PLAN", "free").strip().lower()
ENABLE_AI = NEWSDATA_PLAN == "paid"
SENTIMENT_FILTER = os.getenv("NEWSDATA_SENTIMENT", "").strip().lower()
