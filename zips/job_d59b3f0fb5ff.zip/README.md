# Telegram News Bot 📰

A Telegram bot that delivers **hourly news digests** by category, country, or
keyword, powered by the [newsdata.io](https://newsdata.io) news API and built
with [python-telegram-bot](https://python-telegram-bot.org).

It works out of the box on the **free** newsdata.io plan, and optionally
showcases paid-plan features (sentiment & AI fields) when you enable them.

## Features
- 🗞️ On-demand digests with `/digest`
- ⏰ Automatic hourly digests via `/subscribe`
- 🏷️ Filter by category, country, keyword, and language
- 💾 Per-chat preferences persisted atomically to disk
- 🛡️ Graceful handling of invalid keys (401), rate limits (429), empty results, and paid-only rejections

## Requirements
- Python 3.10+
- A Telegram bot token from [@BotFather](https://t.me/BotFather)
- A free newsdata.io API key from https://newsdata.io/register

## Setup
1. Install dependencies:
   ```bash
   pip install -r requirements.txt
   ```
2. Copy the environment template and fill it in:
   ```bash
   cp .env.example .env
   ```
3. Set at least these two variables (in `.env` or your shell):
   ```bash
   export TELEGRAM_BOT_TOKEN="123456:ABC-your-bot-token"
   export NEWSDATA_API_KEY="pub_xxxxxxxxxxxxxxxxxxxx"
   ```
4. Run the bot:
   ```bash
   python bot.py
   ```

The bot reads the API key from the `NEWSDATA_API_KEY` environment variable and
exits with a clear message if it (or the Telegram token) is missing. Credentials
are never hardcoded.

## Commands
| Command | Description |
| --- | --- |
| `/digest` | Get a news digest right now |
| `/category <name>` | Filter by category (e.g. `technology`) |
| `/country <code>` | Filter by ISO-2 country code (e.g. `us`, `gb`, `in`) |
| `/keyword <words>` | Filter by search term |
| `/language <code>` | Set language (default `en`) |
| `/clear` | Clear all filters |
| `/subscribe` | Receive a digest every hour |
| `/unsubscribe` | Stop hourly digests |
| `/status` | Show your current settings |
| `/help` | Show help |

## Configuration
All configuration is via environment variables (see `.env.example`):

| Variable | Default | Description |
| --- | --- | --- |
| `TELEGRAM_BOT_TOKEN` | — | **Required.** Telegram bot token |
| `NEWSDATA_API_KEY` | — | **Required.** newsdata.io API key |
| `DEFAULT_LANGUAGE` | `en` | Default article language |
| `DEFAULT_COUNTRY` | — | Optional default country code |
| `DIGEST_SIZE` | `5` | Articles per digest |
| `DIGEST_INTERVAL_MINUTES` | `60` | Minutes between automatic digests |

## Optional paid-plan features 💎
These are **off by default** and require a paid newsdata.io plan. The bot
requests them only when you opt in, detects "upgrade your plan" responses
(HTTP 403/422), logs a friendly note, drops the paid parameter, and keeps the
free-tier flow working. Any missing paid field is rendered as `n/a` instead of
crashing.

| Feature | Toggle | Effect |
| --- | --- | --- |
| Sentiment analysis | `ENABLE_SENTIMENT=1` | Shows the `sentiment` field per article. Combine with `NEWSDATA_SENTIMENT=positive` to filter by tone (paid). |
| AI fields | `NEWSDATA_PLAN=paid` | Shows `ai_summary` and `ai_tag` per article when present. |

Example (paid plan):
```bash
export ENABLE_SENTIMENT=1
export NEWSDATA_SENTIMENT=positive
export NEWSDATA_PLAN=paid
python bot.py
```
If your key is on the free plan, these toggles are safely ignored: the bot logs
a note, retries without the paid parameter, and still returns free-tier news.

## Project layout
- `bot.py` — python-telegram-bot application, commands, and the hourly `JobQueue`.
- `newsdata.py` — async newsdata.io client for `/news`, with graceful error handling.
- `storage.py` — atomic JSON persistence of per-chat preferences.
- `config.py` — environment-variable configuration.

## License
MIT. Built as an open showcase for the newsdata.io news API.
