"""A tiny on-disk preference store that learns a user's news interests.

Each Discord user gets a record with the explicit topics they subscribed to and
a set of learned keyword weights. Weights grow when a user thumbs-up an article
and slowly decay, so recent interests win.
"""
import json
import os
import re
import tempfile
import threading

DECAY = 0.98
MAX_WEIGHTS = 40


class PreferenceStore:
    def __init__(self, path="data/preferences.json"):
        self.path = path
        self._lock = threading.Lock()
        self._data = self._load()

    def _load(self):
        try:
            with open(self.path, "r", encoding="utf-8") as fh:
                data = json.load(fh)
                if isinstance(data, dict):
                    return data
        except (FileNotFoundError, json.JSONDecodeError):
            pass
        return {}

    def _save(self):
        directory = os.path.dirname(self.path) or "."
        os.makedirs(directory, exist_ok=True)
        fd, tmp = tempfile.mkstemp(dir=directory, suffix=".tmp")
        try:
            with os.fdopen(fd, "w", encoding="utf-8") as fh:
                json.dump(self._data, fh, indent=2, sort_keys=True)
            os.replace(tmp, self.path)
        except Exception:
            if os.path.exists(tmp):
                os.unlink(tmp)
            raise

    def _user(self, uid):
        rec = self._data.get(uid)
        if not isinstance(rec, dict):
            rec = {}
        rec.setdefault("topics", [])
        rec.setdefault("weights", {})
        self._data[uid] = rec
        return rec

    @staticmethod
    def _clean(term):
        term = re.sub(r"[^\w\s-]", " ", str(term)).strip().lower()
        term = re.sub(r"\s+", " ", term)
        return term

    def add_topic(self, uid, topic):
        topic = self._clean(topic)
        if not topic:
            return False
        with self._lock:
            rec = self._user(uid)
            if topic not in rec["topics"]:
                rec["topics"].append(topic)
            # Seed a strong weight so the topic shows up immediately.
            rec["weights"][topic] = max(rec["weights"].get(topic, 0.0), 3.0)
            self._save()
        return True

    def remove_topic(self, uid, topic):
        topic = self._clean(topic)
        with self._lock:
            rec = self._user(uid)
            existed = topic in rec["topics"]
            rec["topics"] = [t for t in rec["topics"] if t != topic]
            rec["weights"].pop(topic, None)
            self._save()
        return existed

    def boost(self, uid, keywords, amount=1.0):
        cleaned = [self._clean(k) for k in keywords]
        cleaned = [k for k in cleaned if k]
        if not cleaned:
            return
        with self._lock:
            rec = self._user(uid)
            weights = rec["weights"]
            # Decay everything a little, then reward the new keywords.
            for key in list(weights):
                weights[key] = round(weights[key] * DECAY, 4)
            for key in cleaned:
                weights[key] = round(weights.get(key, 0.0) + amount, 4)
            self._prune(rec)
            self._save()

    def _prune(self, rec):
        weights = rec["weights"]
        topics = set(rec["topics"])
        for key in list(weights):
            if weights[key] < 0.15 and key not in topics:
                del weights[key]
        if len(weights) > MAX_WEIGHTS:
            ranked = sorted(weights.items(), key=lambda kv: kv[1], reverse=True)
            keep = dict(ranked[:MAX_WEIGHTS])
            for key in topics:
                if key not in keep and key in weights:
                    keep[key] = weights[key]
            rec["weights"] = keep

    def list_topics(self, uid):
        with self._lock:
            return list(self._user(uid)["topics"])

    def top_interests(self, uid, limit=8):
        with self._lock:
            rec = self._user(uid)
            ranked = sorted(rec["weights"].items(), key=lambda kv: kv[1], reverse=True)
            return ranked[:limit]

    def query_terms(self, uid, limit=5):
        with self._lock:
            rec = self._user(uid)
            terms = []
            for topic in rec["topics"]:
                if topic not in terms:
                    terms.append(topic)
            ranked = sorted(rec["weights"].items(), key=lambda kv: kv[1], reverse=True)
            for key, _ in ranked:
                if key not in terms:
                    terms.append(key)
        terms = [t for t in terms if t][:limit]
        if not terms:
            return ""
        quoted = [f'"{t}"' if " " in t else t for t in terms]
        query = " OR ".join(quoted)
        return query[:90]

    def reset(self, uid):
        with self._lock:
            self._data.pop(uid, None)
            self._save()
