"""Personal News Digest Bot.

A Discord bot that learns what you like to read and sends personalized digests
from the newsdata.io news API (https://newsdata.io). Slash commands manage your
interests; a 👍 reaction on any story nudges future digests.
"""
import logging
import os

import discord
from discord import app_commands
from discord.ext import commands
from dotenv import load_dotenv

from digest import article_keywords, build_article_embed, build_summary_embed
from newsdata import NewsDataClient, NewsDataError, extract_articles
from preferences import PreferenceStore

load_dotenv()

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")
log = logging.getLogger("digest-bot")

DISCORD_TOKEN = os.environ.get("DISCORD_TOKEN")
NEWSDATA_API_KEY = os.environ.get("NEWSDATA_API_KEY")
NEWS_LANGUAGE = os.environ.get("NEWS_LANGUAGE", "en")
NEWS_COUNTRY = os.environ.get("NEWS_COUNTRY") or None
PAID_MODE = os.environ.get("ENABLE_SENTIMENT", "0").lower() in ("1", "true", "yes")
PREF_PATH = os.environ.get("PREFERENCES_FILE", "data/preferences.json")
MAX_ARTICLES = 5

intents = discord.Intents.default()
intents.reactions = True


class DigestBot(commands.Bot):
    def __init__(self):
        super().__init__(command_prefix="!", intents=intents)
        self.store = PreferenceStore(PREF_PATH)
        self.client = None  # set in main()
        self.article_index = {}

    async def setup_hook(self):
        self.tree.add_command(interests_group)
        await self.tree.sync()
        log.info("Slash commands synced.")

    def remember(self, message_id, uid, keywords):
        self.article_index[message_id] = {"uid": uid, "keywords": keywords}
        if len(self.article_index) > 1000:
            oldest = next(iter(self.article_index))
            self.article_index.pop(oldest, None)


bot = DigestBot()

interests_group = app_commands.Group(
    name="interests", description="Manage the topics your digest learns from"
)


@interests_group.command(name="add", description="Follow a topic or keyword")
@app_commands.describe(topic="A topic to follow, e.g. 'climate' or 'artificial intelligence'")
async def interests_add(interaction: discord.Interaction, topic: str):
    ok = bot.store.add_topic(str(interaction.user.id), topic)
    if ok:
        await interaction.response.send_message(
            f"Added **{topic}** to your interests.", ephemeral=True
        )
    else:
        await interaction.response.send_message(
            "That topic didn't contain any usable words.", ephemeral=True
        )


@interests_group.command(name="remove", description="Stop following a topic")
@app_commands.describe(topic="The topic to remove")
async def interests_remove(interaction: discord.Interaction, topic: str):
    existed = bot.store.remove_topic(str(interaction.user.id), topic)
    msg = f"Removed **{topic}**." if existed else f"**{topic}** wasn't in your list."
    await interaction.response.send_message(msg, ephemeral=True)


@interests_group.command(name="list", description="Show what the bot has learned about you")
async def interests_list(interaction: discord.Interaction):
    uid = str(interaction.user.id)
    topics = bot.store.list_topics(uid)
    learned = bot.store.top_interests(uid, limit=8)
    embed = discord.Embed(title="Your interests", color=0x5865F2)
    embed.add_field(
        name="Following",
        value=", ".join(topics) if topics else "nothing yet — try `/interests add`",
        inline=False,
    )
    if learned:
        lines = "\n".join(f"`{k}` — {v:.1f}" for k, v in learned)
        embed.add_field(name="Learned weights", value=lines, inline=False)
    await interaction.response.send_message(embed=embed, ephemeral=True)


@interests_group.command(name="reset", description="Forget everything the bot learned about you")
async def interests_reset(interaction: discord.Interaction):
    bot.store.reset(str(interaction.user.id))
    await interaction.response.send_message("Cleared your interests.", ephemeral=True)


@bot.tree.command(name="digest", description="Get a personalized news digest")
@app_commands.describe(topic="Optional: focus this digest on a single topic")
async def digest(interaction: discord.Interaction, topic: str = None):
    await interaction.response.defer(thinking=True)
    uid = str(interaction.user.id)

    if topic:
        bot.store.add_topic(uid, topic)
        query = PreferenceStore._clean(topic)
    else:
        query = bot.store.query_terms(uid)

    try:
        payload = await bot.client.latest(query=query or None)
    except NewsDataError as exc:
        await interaction.followup.send(f"⚠️ {exc}")
        return

    articles = extract_articles(payload)
    if not articles:
        hint = "Try `/interests add <topic>` or `/digest topic:<something>`."
        await interaction.followup.send(f"No stories found right now. {hint}")
        return

    articles = articles[:MAX_ARTICLES]
    await interaction.followup.send(embed=build_summary_embed(query, articles))

    for art in articles:
        keywords = article_keywords(art)
        # Passive learning: lightly reward whatever the user is served.
        bot.store.boost(uid, keywords, amount=0.2)
        embed = build_article_embed(art)
        message = await interaction.followup.send(embed=embed, wait=True)
        if keywords:
            bot.remember(message.id, uid, keywords)
            try:
                await message.add_reaction("👍")
            except discord.HTTPException:
                pass


@bot.event
async def on_raw_reaction_add(payload: discord.RawReactionActionEvent):
    if bot.user and payload.user_id == bot.user.id:
        return
    if str(payload.emoji) != "👍":
        return
    record = bot.article_index.get(payload.message_id)
    if not record:
        return
    bot.store.boost(str(payload.user_id), record["keywords"], amount=2.0)
    log.info("Boosted interests for user %s", payload.user_id)


@bot.event
async def on_ready():
    log.info("Logged in as %s", bot.user)


def main():
    if not DISCORD_TOKEN:
        raise SystemExit("DISCORD_TOKEN is not set. Add it to your environment or .env file.")
    if not NEWSDATA_API_KEY:
        raise SystemExit(
            "NEWSDATA_API_KEY is not set. Get a free key at https://newsdata.io and export it."
        )
    try:
        bot.client = NewsDataClient(
            NEWSDATA_API_KEY,
            language=NEWS_LANGUAGE,
            country=NEWS_COUNTRY,
            paid_mode=PAID_MODE,
        )
    except NewsDataError as exc:
        raise SystemExit(str(exc))
    bot.run(DISCORD_TOKEN)


if __name__ == "__main__":
    main()
