"""Async client for the newsdata.io news API.

Only the free-tier-safe parts of the API are used by default. Paid query
parameters are attached only when paid mode is enabled, and the client falls
back to a free request if the paid request is rejected.
"""
import aiohttp

BASE_URL = "https://newsdata.io/api/1"
REQUEST_TIMEOUT = 30


class NewsDataError(Exception):
    """Raised for any problem talking to newsdata.io."""


class NewsDataClient:
    def __init__(self, api_key, language="en", country=None, paid_mode=False):
        if not api_key:
            raise NewsDataError("NEWSDATA_API_KEY is not set.")
        self.api_key = api_key
        self.language = language or None
        self.country = country or None
        self.paid_mode = paid_mode

    def _base_params(self):
        params = {"apikey": self.api_key, "size": 10}
        if self.language:
            params["language"] = self.language
        if self.country:
            params["country"] = self.country
        return params

    async def latest(self, query=None, page=None):
        """Fetch the latest news, optionally filtered by an OR query string."""
        params = self._base_params()
        if query:
            params["q"] = query
        if page:
            params["page"] = page

        used_paid = False
        if self.paid_mode:
            # size > 10 is a paid-only capability; request more when allowed.
            params["size"] = 50
            used_paid = True

        status, payload = await self._request("/latest", params)

        # If a paid parameter tripped the free plan, retry once without it.
        if status in (403, 422) and used_paid:
            params["size"] = 10
            status, payload = await self._request("/latest", params)

        self._raise_for_status(status, payload)
        return payload

    async def _request(self, path, params):
        url = BASE_URL + path
        timeout = aiohttp.ClientTimeout(total=REQUEST_TIMEOUT)
        try:
            async with aiohttp.ClientSession(timeout=timeout) as session:
                async with session.get(url, params=params) as resp:
                    try:
                        payload = await resp.json()
                    except aiohttp.ContentTypeError:
                        payload = {}
                    return resp.status, payload
        except aiohttp.ClientError as exc:
            raise NewsDataError(f"Network error contacting newsdata.io: {exc}")

    @staticmethod
    def _raise_for_status(status, payload):
        if status == 200:
            return
        message = ""
        if isinstance(payload, dict):
            results = payload.get("results")
            if isinstance(results, dict):
                message = results.get("message") or ""
            message = message or payload.get("message", "")
        if status == 401:
            raise NewsDataError("Invalid API key (401). Check NEWSDATA_API_KEY.")
        if status == 429:
            raise NewsDataError("Rate limit reached (429). Wait a bit and try again.")
        raise NewsDataError(f"newsdata.io request failed ({status}). {message}".strip())


def extract_articles(payload):
    """Return the article list, or an empty list if there are no results."""
    results = payload.get("results")
    if isinstance(results, list):
        return results
    return []


def next_page(payload):
    """Return the pagination cursor to pass back as `page`, or None."""
    return payload.get("nextPage")
