# Personal News Digest Bot

A Discord bot that learns which topics you care about and sends you a tailored
news digest on request. It pulls live headlines from the newsdata.io news API
(https://newsdata.io) — you'll need a free API key to run it.

The bot keeps a small per-user preference file. When you follow a topic or give
a story a 👍, it adjusts the keyword weights it uses to query the API, so your
digests drift toward what you actually read over time.

## Features

- `/digest` builds a personalized batch of headlines from your saved interests.
- 👍 a story and the bot remembers the keywords behind it for next time.
- `/interests add|remove|list|reset` to manage topics by hand.
- Per-article sentiment badge, keyword chips, and an AI summary line when the
  data is available.
- A sentiment breakdown chart for each digest.
- Works on a free newsdata.io key; paid-only fields degrade to labelled
  placeholders instead of breaking.

## Requirements

- Python 3.10+
- A Discord bot token (from the Discord Developer Portal)
- A newsdata.io API key — the free tier is enough — https://newsdata.io

## Setup

1. Clone the repo and install dependencies:

   ```
   python -m venv .venv
   source .venv/bin/activate
   pip install -r requirements.txt
   ```

2. Create a Discord application and bot at
   https://discord.com/developers/applications, copy its token, and invite the
   bot to your server with the `bot` and `applications.commands` scopes.

3. Copy the example environment file and fill in your keys:

   ```
   cp .env.example .env
   ```

   Set `DISCORD_TOKEN` and `NEWSDATA_API_KEY`. The newsdata.io key is read from
   the `NEWSDATA_API_KEY` environment variable and is never stored in the repo.

## Running

```
python bot.py
```

On startup the bot registers its slash commands. Give Discord a minute or two
for them to appear the first time.

## Usage

In any channel the bot can see:

```
/interests add topic: renewable energy
/interests add topic: formula 1
/digest
```

A digest looks roughly like this:

```
Your news digest
Showing 5 stories for "renewable energy" OR "formula 1"

Sentiment breakdown
positive █████░░░░░░░ 2
neutral  ███████░░░░░ 3
negative ░░░░░░░░░░░░ 0

— Solar capacity additions hit a new high in Q1   [Positive]
  Keywords: `solar`  `energy`  `grid`
...
```

React 👍 on the stories you like and your next `/digest` leans further in that
direction. Run `/interests list` to see the weights the bot has learned.

## Optional: paid data

newsdata.io exposes extra fields (article sentiment, AI tags and summaries, and
larger result pages) on its paid plans. The bot reads them when they're present
and shows clearly-labelled placeholders when they aren't, so nothing extra is
needed on the free tier. To request them, set `ENABLE_SENTIMENT=1`; if the API
rejects the paid request the bot automatically retries without the paid
parameters so you still get free results.

## Files

- `bot.py` — Discord client, slash commands, reaction learning.
- `newsdata.py` — async wrapper around the newsdata.io endpoints.
- `preferences.py` — the per-user interest store (JSON on disk).
- `digest.py` — builds the Discord embeds.
- `data/preferences.json` — created on first run; safe to delete to reset.

## License

MIT
