"""Turn newsdata.io article dicts into Discord embeds.

Every paid response field (sentiment, ai_summary, ai_tag, ...) is read
defensively: when it is missing on a free plan the embed shows a clearly
labelled placeholder instead of breaking.
"""
import discord

SENTIMENT_STYLE = {
    "positive": ("🟢 Positive", 0x2ECC71),
    "neutral": ("🟡 Neutral", 0xF1C40F),
    "negative": ("🔴 Negative", 0xE74C3C),
}
DEFAULT_COLOR = 0x5865F2


def article_keywords(article):
    """Collect free-tier keywords plus any AI tags for learning and display."""
    terms = []
    kws = article.get("keywords")
    if isinstance(kws, list):
        terms.extend(k for k in kws if isinstance(k, str))
    tags = article.get("ai_tag")
    if isinstance(tags, list):
        terms.extend(t for t in tags if isinstance(t, str))
    elif isinstance(tags, str) and "only available in paid" not in tags.lower():
        if tags.strip():
            terms.append(tags)
    # De-duplicate while preserving order.
    seen = set()
    out = []
    for term in terms:
        key = term.strip().lower()
        if key and key not in seen:
            seen.add(key)
            out.append(term.strip())
    return out


def _clean_text(value):
    if isinstance(value, str) and value.strip():
        if "only available in paid" in value.strip().lower():
            return None
        return value.strip()
    return None


def build_article_embed(article):
    title = _clean_text(article.get("title")) or "(untitled)"
    link = article.get("link") if isinstance(article.get("link"), str) else None

    sentiment = article.get("sentiment")
    label, color = SENTIMENT_STYLE.get(sentiment, (None, DEFAULT_COLOR))

    summary = _clean_text(article.get("ai_summary")) or _clean_text(article.get("description"))
    if summary and len(summary) > 350:
        summary = summary[:347] + "..."

    embed = discord.Embed(title=title[:256], url=link, description=summary, color=color)

    source = _clean_text(article.get("source_id")) or "unknown source"
    embed.set_author(name=source)

    if label:
        embed.add_field(name="Sentiment", value=label, inline=True)
    else:
        embed.add_field(name="Sentiment", value="— (paid plan)", inline=True)

    keywords = article_keywords(article)
    if keywords:
        chips = "  ".join(f"`{k}`" for k in keywords[:6])
        embed.add_field(name="Keywords", value=chips, inline=False)

    image = article.get("image_url")
    if isinstance(image, str) and image.startswith("http"):
        embed.set_thumbnail(url=image)

    pub = _clean_text(article.get("pubDate"))
    embed.set_footer(text=pub if pub else "newsdata.io")
    return embed


def _bar(counts):
    total = sum(counts.values()) or 1
    rows = []
    for name in ("positive", "neutral", "negative"):
        n = counts.get(name, 0)
        filled = round((n / total) * 12)
        bar = "\u2588" * filled + "\u2591" * (12 - filled)
        rows.append(f"{name:<8} {bar} {n}")
    return "```\n" + "\n".join(rows) + "\n```"


def build_summary_embed(query, articles):
    counts = {"positive": 0, "neutral": 0, "negative": 0}
    have_sentiment = False
    for art in articles:
        s = art.get("sentiment")
        if s in counts:
            counts[s] += 1
            have_sentiment = True

    desc = f"Showing **{len(articles)}** stories"
    if query:
        desc += f" for `{query}`"
    embed = discord.Embed(title="Your news digest", description=desc, color=DEFAULT_COLOR)

    if have_sentiment:
        embed.add_field(name="Sentiment breakdown", value=_bar(counts), inline=False)
    else:
        sample = {"positive": 3, "neutral": 5, "negative": 2}
        embed.add_field(
            name="Sentiment breakdown (sample)",
            value=_bar(sample) + "\nsample — live sentiment requires a paid newsdata.io plan",
            inline=False,
        )
    embed.set_footer(text="React 👍 on a story to tune future digests")
    return embed
