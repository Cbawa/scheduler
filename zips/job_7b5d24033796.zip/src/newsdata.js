'use strict';

// Free-tier-safe client for the newsdata.io latest-news endpoint.
// Only free query params are sent on the default path; paid params (timeframe)
// are sent only when paid mode is on, and dropped + retried on rejection.

const BASE = 'https://newsdata.io/api/1/latest';

async function request(params) {
  const url = BASE + '?' + new URLSearchParams(params).toString();
  const res = await fetch(url, { headers: { 'User-Agent': 'news-github-action' } });
  let data = {};
  try {
    data = await res.json();
  } catch (_) {
    data = {};
  }
  return { res, data };
}

function errorMessage(data, status) {
  if (data && data.results && typeof data.results === 'object' && data.results.message) {
    return data.results.message;
  }
  if (data && data.message) return data.message;
  return 'HTTP ' + status;
}

async function fetchNews(opts) {
  const collected = [];
  let page = null;
  let guard = 0;

  while (collected.length < opts.max && guard < 8) {
    guard += 1;

    const params = { apikey: opts.apiKey, size: String(opts.size) };
    if (opts.language) params.language = opts.language;
    if (opts.q) params.q = opts.q;
    if (opts.country) params.country = opts.country;
    if (opts.category) params.category = opts.category;
    if (opts.paid && opts.timeframe) params.timeframe = opts.timeframe;
    if (page) params.page = page;

    let { res, data } = await request(params);

    // Paid query params rejected on free plans -> drop them and retry once.
    if ((res.status === 403 || res.status === 422) && opts.paid && params.timeframe) {
      console.log('::warning::Paid query parameters were rejected (free plan?). Retrying without them.');
      delete params.timeframe;
      ({ res, data } = await request(params));
    }

    if (res.status === 401) {
      throw new Error('newsdata.io rejected the API key (401). Check the api-key / NEWSDATA_API_KEY value.');
    }
    if (res.status === 429) {
      throw new Error('newsdata.io rate limit reached (429). Reduce frequency or try again later.');
    }
    if (!res.ok || (data && data.status === 'error')) {
      throw new Error('newsdata.io request failed: ' + errorMessage(data, res.status));
    }

    const results = Array.isArray(data.results) ? data.results : [];
    collected.push(...results);

    page = data.nextPage || null;
    if (!page) break;
  }

  return collected.slice(0, opts.max);
}

module.exports = { fetchNews };
