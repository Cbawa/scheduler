'use strict';

const { fetchNews } = require('./newsdata');
const { buildSummary } = require('./format');
const { postDiscussion, postWiki } = require('./publish');

function env(name, def) {
  const v = process.env[name];
  return v === undefined || v === '' ? def : v;
}

function asBool(v) {
  return ['1', 'true', 'yes', 'on'].includes(String(v).toLowerCase());
}

function fail(msg) {
  console.error('::error::' + msg);
  process.exit(1);
}

async function main() {
  const apiKey = (process.env.NEWS_API_KEY || process.env.NEWSDATA_API_KEY || '').trim();
  if (!apiKey) {
    fail('No API key set. Provide the api-key input or NEWSDATA_API_KEY env var. Get a free key at https://newsdata.io');
  }

  const target = env('TARGET', 'discussion').toLowerCase();
  const dryRun = asBool(env('DRY_RUN', 'false'));
  const enablePaid = asBool(env('ENABLE_PAID', 'false'));
  const maxArticles = Math.min(Math.max(parseInt(env('MAX_ARTICLES', '10'), 10) || 10, 1), 50);

  const query = {
    apiKey,
    q: env('QUERY', '') || undefined,
    country: env('COUNTRY', '') || undefined,
    language: env('LANGUAGE', 'en') || undefined,
    category: env('CATEGORY', '') || undefined,
    size: Math.min(maxArticles, 10),
    max: maxArticles,
    paid: enablePaid,
    timeframe: enablePaid ? env('TIMEFRAME', '') || undefined : undefined,
  };

  let articles;
  try {
    articles = await fetchNews(query);
  } catch (e) {
    fail(e.message);
  }

  const date = new Date().toISOString().slice(0, 10);
  const title = env('TITLE_PREFIX', 'Daily news') + ' \u2014 ' + date;
  const body = buildSummary(articles, { date });

  if (dryRun || target === 'stdout') {
    console.log('\n===== ' + title + ' =====\n');
    console.log(body);
    return;
  }

  const token = (process.env.GH_TOKEN || process.env.GITHUB_TOKEN || '').trim();
  if (!token) fail('No GitHub token available to post with (github-token input).');

  const repo = env('GITHUB_REPOSITORY', '');
  const [owner, name] = repo.split('/');
  if (!owner || !name) fail('GITHUB_REPOSITORY is not set (expected "owner/repo").');

  try {
    if (target === 'wiki') {
      await postWiki({ owner, name, token, page: env('WIKI_PAGE', 'Daily-News'), title, body });
    } else {
      await postDiscussion({
        owner,
        name,
        token,
        category: env('DISCUSSION_CATEGORY', 'Announcements'),
        title,
        body,
      });
    }
  } catch (e) {
    fail(e.message);
  }
}

main().catch((e) => fail(e && e.message ? e.message : String(e)));
