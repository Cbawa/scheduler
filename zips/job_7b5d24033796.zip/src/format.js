'use strict';

// Turns newsdata.io results into a Markdown digest. Paid-only fields
// (sentiment, ai_tag, ai_summary) are read straight from each result and
// guarded so a missing value never breaks the layout.

function clean(v) {
  if (typeof v === 'string' && /ONLY AVAILABLE IN/i.test(v)) return null;
  if (typeof v === 'string' && v.trim() === '') return null;
  return v === undefined ? null : v;
}

function sentimentBadge(s) {
  switch (String(s || '').toLowerCase()) {
    case 'positive':
      return '\uD83D\uDFE2 positive';
    case 'negative':
      return '\uD83D\uDD34 negative';
    case 'neutral':
      return '\u26AA neutral';
    default:
      return null;
  }
}

function chips(arr) {
  if (!Array.isArray(arr)) return '';
  const items = arr.filter(Boolean).slice(0, 6).map((k) => '`' + String(k).replace(/`/g, '') + '`');
  return items.join(' ');
}

function bar(count, total) {
  const width = 12;
  const filled = total > 0 ? Math.round((count / total) * width) : 0;
  return '\u2588'.repeat(filled) + '\u2591'.repeat(Math.max(0, width - filled));
}

function sentimentSection(articles) {
  const counts = { positive: 0, neutral: 0, negative: 0 };
  let known = 0;
  for (const a of articles) {
    const s = clean(a.sentiment);
    const k = s ? String(s).toLowerCase() : null;
    if (k && Object.prototype.hasOwnProperty.call(counts, k)) {
      counts[k] += 1;
      known += 1;
    }
  }

  const out = ['## Sentiment', ''];
  let data = counts;
  let total = known;

  if (!known) {
    out.push('> sample \u2014 live sentiment requires a paid newsdata.io plan', '');
    data = { positive: 4, neutral: 5, negative: 1 };
    total = 10;
  }

  for (const k of ['positive', 'neutral', 'negative']) {
    out.push('- ' + k.padEnd(8) + ' `' + bar(data[k], total) + '` ' + data[k]);
  }
  return out.join('\n');
}

function articleBlock(a) {
  const title = String(a.title || 'Untitled').replace(/\s+/g, ' ').trim();
  const link = a.link || '#';
  const source = a.source_id || a.source_name || 'source';
  const date = String(a.pubDate || '').slice(0, 16);
  const meta = [source, date].filter(Boolean).join(' \u00B7 ');
  const badge = sentimentBadge(clean(a.sentiment));

  const lines = [];
  lines.push('### [' + title + '](' + link + ')');
  lines.push('_' + meta + (badge ? ' \u00B7 ' + badge : '') + '_');

  const summary = clean(a.ai_summary) || (a.description ? String(a.description).trim() : '');
  if (summary) {
    lines.push('', String(summary).replace(/\s+/g, ' ').slice(0, 400));
  }

  const keywords = clean(a.keywords);
  const aiTags = clean(a.ai_tag);
  const source2 = Array.isArray(keywords) && keywords.length ? keywords : Array.isArray(aiTags) ? aiTags : [];
  const tagLine = chips(source2);
  if (tagLine) lines.push('', tagLine);

  lines.push('');
  return lines.join('\n');
}

function buildSummary(articles, ctx) {
  const lines = [];
  lines.push('_Headlines via the [newsdata.io](https://newsdata.io) news API. Generated ' + ctx.date + '._');
  lines.push('');

  if (!articles || !articles.length) {
    lines.push('No articles were returned for this query today.');
    return lines.join('\n');
  }

  lines.push(sentimentSection(articles));
  lines.push('');
  lines.push('## Headlines');
  lines.push('');
  for (const a of articles) lines.push(articleBlock(a));
  lines.push('---');
  lines.push(
    '<sub>' + articles.length + ' articles. Sentiment and AI tags are shown when present in the newsdata.io response (paid fields).</sub>'
  );
  return lines.join('\n');
}

module.exports = { buildSummary };
