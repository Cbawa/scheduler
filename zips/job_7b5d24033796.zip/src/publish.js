'use strict';

const fs = require('fs');
const os = require('os');
const path = require('path');
const { execSync } = require('child_process');

function setOutput(name, value) {
  const f = process.env.GITHUB_OUTPUT;
  if (f) {
    fs.appendFileSync(f, name + '=' + String(value).replace(/\r?\n/g, ' ') + '\n');
  }
}

async function graphql(token, query, variables) {
  const res = await fetch('https://api.github.com/graphql', {
    method: 'POST',
    headers: {
      Authorization: 'Bearer ' + token,
      'Content-Type': 'application/json',
      'User-Agent': 'news-github-action',
    },
    body: JSON.stringify({ query, variables }),
  });
  const data = await res.json().catch(() => ({}));
  if (data.errors && data.errors.length) {
    throw new Error('GitHub GraphQL error: ' + data.errors.map((e) => e.message).join('; '));
  }
  if (!data.data) throw new Error('GitHub GraphQL returned no data (HTTP ' + res.status + ').');
  return data.data;
}

async function postDiscussion({ owner, name, token, category, title, body }) {
  const q =
    'query($owner:String!,$name:String!){repository(owner:$owner,name:$name){id discussionCategories(first:50){nodes{id name}}}}';
  const d = await graphql(token, q, { owner, name });
  const repo = d.repository;
  if (!repo) throw new Error('Repository not found, or the token lacks access.');

  const cats = repo.discussionCategories.nodes || [];
  const cat = cats.find((c) => c.name.toLowerCase() === String(category).toLowerCase());
  if (!cat) {
    const available = cats.map((c) => c.name).join(', ') || '(none)';
    throw new Error(
      'Discussion category "' + category + '" not found. Available: ' + available + '. Enable Discussions in repository settings and create the category.'
    );
  }

  const m =
    'mutation($repositoryId:ID!,$categoryId:ID!,$title:String!,$body:String!){createDiscussion(input:{repositoryId:$repositoryId,categoryId:$categoryId,title:$title,body:$body}){discussion{url}}}';
  const r = await graphql(token, m, { repositoryId: repo.id, categoryId: cat.id, title, body });
  const url = r.createDiscussion.discussion.url;
  console.log('Posted discussion: ' + url);
  setOutput('url', url);
  return url;
}

async function postWiki({ owner, name, token, page, title, body }) {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'news-wiki-'));
  const remote = 'https://x-access-token:' + token + '@github.com/' + owner + '/' + name + '.wiki.git';
  const run = (cmd) => execSync(cmd, { cwd: dir, stdio: 'pipe' }).toString();

  try {
    execSync('git clone ' + remote + ' ' + dir, { stdio: 'pipe' });
  } catch (e) {
    throw new Error(
      'Could not clone the wiki. Create it first by adding any page in the repository Wiki tab. (' + e.message + ')'
    );
  }

  const safe = String(page).replace(/[^A-Za-z0-9_-]/g, '-');
  const file = path.join(dir, safe + '.md');
  fs.writeFileSync(file, '# ' + title + '\n\n' + body + '\n');

  run('git config user.name "news-github-action"');
  run('git config user.email "actions@users.noreply.github.com"');
  run('git add -A');

  try {
    run('git commit -m "Update ' + safe + ' (' + title + ')"');
  } catch (_) {
    console.log('No wiki changes to commit.');
    return;
  }
  run('git push origin HEAD');
  console.log('Updated wiki page: ' + safe);
}

module.exports = { postDiscussion, postWiki };
