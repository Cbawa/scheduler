# Daily News GitHub Action

A small GitHub Action that posts a daily news summary into your repository's
**Discussions** or **wiki**. It pulls live headlines from the newsdata.io news API
(https://newsdata.io) — grab a free API key to run it — and renders them as Markdown
with source, date, keyword tags, and, when your plan provides them, per-article
sentiment and an AI summary line.

It's written as a composite action that runs a small Node script (Node 18+, no
bundled dependencies), so there's nothing to build or vendor.

## What it does

- Fetches the latest articles for an optional keyword/country/category filter.
- Builds a Markdown digest: a sentiment overview plus one block per headline.
- Posts the digest as a new repository Discussion, or writes it to a wiki page.
- Can also print the digest to the log (`dry-run`) so you can preview it.
- Degrades cleanly on the free plan: paid-only response fields (sentiment, AI tags,
  AI summary) are simply omitted or shown as a clearly-labeled sample, and paid-only
  query parameters are dropped automatically if the API rejects them.

## Setup

1. Get a free API key from newsdata.io (https://newsdata.io) and add it to your
   repository as a secret named `NEWSDATA_API_KEY`
   (*Settings → Secrets and variables → Actions*).
2. For the default `discussion` target, enable **Discussions** for the repository
   (*Settings → General → Features*) and make sure the category you want to post in
   exists (the default is `Announcements`).
3. Add a workflow like the one below.

```yaml
# .github/workflows/daily-news.yml
name: Daily news

on:
  schedule:
    - cron: '0 13 * * *'   # every day at 13:00 UTC
  workflow_dispatch:

permissions:
  discussions: write
  contents: read

jobs:
  news:
    runs-on: ubuntu-latest
    steps:
      - uses: your-name/news-github-action@v1
        with:
          api-key: ${{ secrets.NEWSDATA_API_KEY }}
          target: discussion
          discussion-category: Announcements
          country: us
          category: technology
          language: en
```

To write to the wiki instead, create the wiki first (open the **Wiki** tab and add
any page), then:

```yaml
    permissions:
      contents: write
    steps:
      - uses: your-name/news-github-action@v1
        with:
          api-key: ${{ secrets.NEWSDATA_API_KEY }}
          target: wiki
          wiki-page: Daily-News
```

## Inputs

| Input | Default | Description |
| --- | --- | --- |
| `api-key` | — | newsdata.io API key (required). Pass a secret. |
| `github-token` | `${{ github.token }}` | Token used to post. Needs `discussions: write` for Discussions, or `contents: write` for the wiki. |
| `target` | `discussion` | `discussion`, `wiki`, or `stdout`. |
| `discussion-category` | `Announcements` | Existing Discussion category name. |
| `wiki-page` | `Daily-News` | Wiki page name when `target: wiki`. |
| `query` | — | Keyword filter (maps to `q`). |
| `country` | — | Comma-separated country codes, e.g. `us,gb`. |
| `language` | `en` | Comma-separated language codes. |
| `category` | — | Comma-separated newsdata.io categories, e.g. `technology,business`. |
| `max-articles` | `10` | Number of articles to include (the free plan returns up to 10 per request). |
| `title-prefix` | `Daily news` | Prefix for the post title. |
| `enable-paid` | `false` | Send paid-only query params (see below). |
| `timeframe` | — | Paid only: limit to the last N hours (used when `enable-paid: true`). |
| `dry-run` | `false` | Print the summary to the log instead of posting. |

## Outputs

| Output | Description |
| --- | --- |
| `url` | URL of the created discussion (when `target: discussion`). |

## Optional paid configuration

The digest reads richer fields straight from each article when they are present:
`sentiment`, `ai_tag`, and `ai_summary`. These require a paid newsdata.io plan. On a
free key they are absent, so the sentiment overview is shown as a labeled sample and
the per-article badges/summary are simply skipped — keyword tags (free) are always
shown.

Set `enable-paid: true` to also send paid-only **query** parameters such as
`timeframe`. If the API rejects them (which it does on the free plan), the request is
retried once without them so you still get results.

## Run it locally

No install step is needed. With a key in your environment:

```bash
NEWSDATA_API_KEY=your_key DRY_RUN=true LANGUAGE=en CATEGORY=technology node src/index.js
```

Sample output:

```
===== Daily news — 2026-06-11 =====

_Headlines via the [newsdata.io](https://newsdata.io) news API. Generated 2026-06-11._

## Sentiment

> sample — live sentiment requires a paid newsdata.io plan

- positive `████░░░░░░░░` 4
- neutral  `██████░░░░░░` 5
- negative `█░░░░░░░░░░░` 1

## Headlines

### [Chipmaker reports record quarter](https://example.com/a)
_reuters · 2026-06-11 09:12_

The company beat estimates on strong data-centre demand...

`semiconductors` `earnings` `data-center`
```

With a paid plan, each headline also shows a sentiment badge (🟢/⚪/🔴) and the AI
summary line, and the sentiment overview reflects the real article counts.

## Notes

- The free plan returns up to 10 articles per request; `max-articles` above 10 uses
  the `nextPage` cursor to page through results, which consumes additional credits.
- The wiki target overwrites the named page on each run. Create the wiki (one page)
  before first use, or the push has nowhere to go.
- Errors from the API are surfaced as workflow annotations: an invalid key (401) and
  rate limiting (429) produce a clear message and a failed step.

## License

MIT
