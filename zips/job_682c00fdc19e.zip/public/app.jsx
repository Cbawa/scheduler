const { useState, useEffect, useRef, useMemo, useCallback } = React;

const SENT_COLORS = { positive: '#2e9e5b', negative: '#d24b4b', neutral: '#8a8f98' };

const PRESETS = [
  { label: 'Geopolitics', q: 'geopolitics' },
  { label: 'Diplomacy', q: 'diplomacy' },
  { label: 'Sanctions', q: 'sanctions' },
  { label: 'Conflict', q: 'military conflict' },
  { label: 'Trade', q: 'trade war' },
  { label: 'Energy', q: 'energy security' },
];

function asArray(v) {
  if (Array.isArray(v)) return v;
  if (v === null || v === undefined || v === '') return [];
  return [v];
}

function parseDate(s) {
  if (!s) return null;
  const d = new Date(String(s).replace(' ', 'T') + 'Z');
  return isNaN(d) ? null : d;
}

function fmtDate(s) {
  const d = parseDate(s);
  return d ? d.toLocaleString() : (s || '');
}

function SentimentBadge({ value }) {
  if (!value || !SENT_COLORS[value]) return null;
  return <span className="badge" style={{ background: SENT_COLORS[value] }}>{value}</span>;
}

function Chips({ items, kind, onClick }) {
  const arr = asArray(items).slice(0, 8);
  if (!arr.length) return null;
  return (
    <div className="chips">
      {arr.map((t, i) => (
        <span
          key={i}
          className={'chip chip-' + kind}
          onClick={onClick ? () => onClick(t) : undefined}
        >{t}</span>
      ))}
    </div>
  );
}

function ArticleCard({ a, onKeyword }) {
  const summary = a.ai_summary || a.description || (a.content ? String(a.content).slice(0, 240) : '');
  return (
    <article className="card">
      <div className="card-head">
        <SentimentBadge value={a.sentiment} />
        <span className="src">{a.source_name || a.source_id || 'Unknown source'}</span>
        <span className="date">{fmtDate(a.pubDate)}</span>
      </div>
      <h3>
        {a.link ? <a href={a.link} target="_blank" rel="noreferrer">{a.title}</a> : (a.title || 'Untitled')}
      </h3>
      {summary ? <p className="summary">{summary}</p> : null}
      {asArray(a.ai_tag).length ? <Chips items={a.ai_tag} kind="ai" /> : null}
      <Chips items={a.keywords} kind="kw" onClick={onKeyword} />
      <div className="meta">
        {asArray(a.country).map((c, i) => <span key={i} className="pill">{c}</span>)}
      </div>
    </article>
  );
}

function SentimentBreakdown({ articles }) {
  const ref = useRef();
  const { counts, real } = useMemo(() => {
    const c = { positive: 0, negative: 0, neutral: 0 };
    let real = 0;
    articles.forEach(a => {
      if (a.sentiment && c[a.sentiment] !== undefined) { c[a.sentiment]++; real++; }
    });
    return { counts: c, real };
  }, [articles]);

  const sample = real === 0;
  const data = sample ? { positive: 45, neutral: 25, negative: 30 } : counts;

  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    d3.select(el).selectAll('*').remove();
    const keys = ['positive', 'neutral', 'negative'];
    const total = keys.reduce((s, k) => s + data[k], 0) || 1;
    const W = el.clientWidth || 320;
    const H = 18;
    const svg = d3.select(el).append('svg').attr('width', W).attr('height', H + 30);
    let x = 0;
    keys.forEach(k => {
      const w = (data[k] / total) * W;
      svg.append('rect').attr('x', x).attr('y', 0).attr('width', Math.max(0, w - 1))
        .attr('height', H).attr('fill', SENT_COLORS[k]).attr('rx', 3);
      if (w > 34) {
        svg.append('text').attr('x', x + 5).attr('y', 13).attr('fill', '#fff')
          .attr('font-size', 11).text(Math.round((data[k] / total) * 100) + '%');
      }
      x += w;
    });
    let lx = 0;
    keys.forEach(k => {
      const g = svg.append('g').attr('transform', 'translate(' + lx + ',' + (H + 12) + ')');
      g.append('rect').attr('width', 10).attr('height', 10).attr('fill', SENT_COLORS[k]).attr('rx', 2);
      g.append('text').attr('x', 14).attr('y', 9).attr('font-size', 11).attr('fill', '#cfd3da').text(k);
      lx += k.length * 7 + 36;
    });
  }, [data, sample]);

  return (
    <div className="panel">
      <div className="panel-title">Sentiment breakdown</div>
      <div ref={ref}></div>
      {sample
        ? <div className="note">sample &mdash; live sentiment requires a paid newsdata.io plan</div>
        : <div className="note">based on {real} article(s) with sentiment data</div>}
    </div>
  );
}

function Timeline({ articles }) {
  const ref = useRef();
  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    d3.select(el).selectAll('*').remove();
    const dates = articles.map(a => parseDate(a.pubDate)).filter(Boolean);
    if (!dates.length) {
      d3.select(el).append('div').attr('class', 'note').text('No dated articles yet.');
      return;
    }
    const buckets = d3.rollup(dates, v => v.length, d => d3.timeHour(d).getTime());
    const data = Array.from(buckets, ([t, c]) => ({ t: new Date(+t), c })).sort((a, b) => a.t - b.t);
    const W = el.clientWidth || 640;
    const H = 160;
    const m = { t: 10, r: 12, b: 26, l: 28 };
    const svg = d3.select(el).append('svg').attr('width', W).attr('height', H);
    const x = d3.scaleTime().domain(d3.extent(data, d => d.t)).range([m.l, W - m.r]);
    const y = d3.scaleLinear().domain([0, d3.max(data, d => d.c)]).nice().range([H - m.b, m.t]);
    const bw = Math.max(2, (W - m.l - m.r) / Math.max(data.length, 1) - 2);
    svg.append('g').selectAll('rect').data(data).join('rect')
      .attr('x', d => x(d.t) - bw / 2)
      .attr('y', d => y(d.c))
      .attr('width', bw)
      .attr('height', d => y(0) - y(d.c))
      .attr('fill', '#4c8bf5').attr('rx', 2);
    svg.append('g').attr('transform', 'translate(0,' + (H - m.b) + ')')
      .call(d3.axisBottom(x).ticks(5).tickFormat(d3.timeFormat('%m/%d %Hh'))).attr('color', '#7d828b');
    svg.append('g').attr('transform', 'translate(' + m.l + ',0)')
      .call(d3.axisLeft(y).ticks(4)).attr('color', '#7d828b');
  }, [articles]);

  return (
    <div className="panel">
      <div className="panel-title">Event timeline (by hour, UTC)</div>
      <div ref={ref}></div>
    </div>
  );
}

function CountryGraph({ articles, onCountry }) {
  const ref = useRef();
  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    d3.select(el).selectAll('*').remove();
    const nodeMap = new Map();
    const edgeMap = new Map();
    articles.forEach(a => {
      const cs = Array.from(new Set(asArray(a.country).map(c => String(c).toLowerCase()))).filter(Boolean);
      cs.forEach(c => nodeMap.set(c, (nodeMap.get(c) || 0) + 1));
      for (let i = 0; i < cs.length; i++) {
        for (let j = i + 1; j < cs.length; j++) {
          const key = [cs[i], cs[j]].sort().join('|');
          edgeMap.set(key, (edgeMap.get(key) || 0) + 1);
        }
      }
    });
    const nodes = Array.from(nodeMap, ([id, v]) => ({ id, v }));
    if (!nodes.length) {
      d3.select(el).append('div').attr('class', 'note').text('No country data in current results.');
      return;
    }
    const links = Array.from(edgeMap, ([k, w]) => {
      const parts = k.split('|');
      return { source: parts[0], target: parts[1], w };
    });
    const W = el.clientWidth || 640;
    const H = 320;
    const svg = d3.select(el).append('svg').attr('width', W).attr('height', H);
    const r = d3.scaleSqrt().domain([1, d3.max(nodes, d => d.v) || 1]).range([6, 22]);
    const link = svg.append('g').attr('stroke', '#3a3f47').selectAll('line').data(links).join('line')
      .attr('stroke-width', d => Math.min(6, d.w));
    const node = svg.append('g').selectAll('g').data(nodes).join('g')
      .style('cursor', 'pointer')
      .on('click', (e, d) => onCountry && onCountry(d.id));
    node.append('circle').attr('r', d => r(d.v)).attr('fill', '#4c8bf5')
      .attr('stroke', '#0d0f12').attr('stroke-width', 1.5);
    node.append('text').text(d => d.id.toUpperCase()).attr('font-size', 10)
      .attr('fill', '#cfd3da').attr('text-anchor', 'middle').attr('dy', d => -(r(d.v) + 4));
    const sim = d3.forceSimulation(nodes)
      .force('link', d3.forceLink(links).id(d => d.id).distance(70))
      .force('charge', d3.forceManyBody().strength(-160))
      .force('center', d3.forceCenter(W / 2, H / 2))
      .force('collide', d3.forceCollide().radius(d => r(d.v) + 10));
    sim.on('tick', () => {
      link.attr('x1', d => d.source.x).attr('y1', d => d.source.y)
        .attr('x2', d => d.target.x).attr('y2', d => d.target.y);
      node.attr('transform', d => 'translate(' +
        Math.max(20, Math.min(W - 20, d.x)) + ',' +
        Math.max(20, Math.min(H - 20, d.y)) + ')');
    });
    return () => sim.stop();
  }, [articles, onCountry]);

  return (
    <div className="panel">
      <div className="panel-title">Country co-occurrence graph</div>
      <div ref={ref}></div>
      <div className="note">Nodes are countries mentioned together in the same article; click one to filter.</div>
    </div>
  );
}

function TopKeywords({ articles, onKeyword }) {
  const top = useMemo(() => {
    const m = new Map();
    articles.forEach(a => asArray(a.keywords).forEach(k => {
      const key = String(k).toLowerCase();
      m.set(key, (m.get(key) || 0) + 1);
    }));
    return Array.from(m, ([k, c]) => ({ k, c })).sort((a, b) => b.c - a.c).slice(0, 18);
  }, [articles]);

  return (
    <div className="panel">
      <div className="panel-title">Top keywords</div>
      {top.length
        ? <div className="chips">{top.map(t => (
            <span key={t.k} className="chip chip-kw" onClick={() => onKeyword(t.k)}>
              {t.k} <span className="cnt">{t.c}</span>
            </span>
          ))}</div>
        : <div className="note">No keywords in current results.</div>}
    </div>
  );
}

function App() {
  const [q, setQ] = useState('geopolitics');
  const [input, setInput] = useState('geopolitics');
  const [country, setCountry] = useState('');
  const [articles, setArticles] = useState([]);
  const [nextPage, setNextPage] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);
  const [total, setTotal] = useState(0);

  const load = useCallback(async (opts) => {
    opts = opts || {};
    const append = !!opts.append;
    const page = opts.page || null;
    const query = opts.query !== undefined ? opts.query : q;
    const ctry = opts.ctry !== undefined ? opts.ctry : country;
    setLoading(true);
    setError(null);
    try {
      const u = new URL(window.location.origin + '/api/news');
      u.searchParams.set('q', query);
      if (ctry) u.searchParams.set('country', ctry);
      if (page) u.searchParams.set('page', page);
      const r = await fetch(u);
      const d = await r.json();
      if (!r.ok) {
        setError(d.message || 'Request failed.');
        if (!append) setArticles([]);
        return;
      }
      setTotal(d.totalResults || 0);
      setNextPage(d.nextPage || null);
      setArticles(prev => append ? prev.concat(d.results) : d.results);
      if (!append && d.results.length === 0) {
        setError('No articles matched. Try another topic or region.');
      }
    } catch (e) {
      setError(e.message);
    } finally {
      setLoading(false);
    }
  }, [q, country]);

  useEffect(() => { load({ query: 'geopolitics', ctry: '' }); }, []);

  const submit = (e) => {
    if (e) e.preventDefault();
    const v = input.trim() || 'geopolitics';
    setQ(v); setCountry('');
    load({ query: v, ctry: '' });
  };
  const preset = (p) => {
    setInput(p.q); setQ(p.q); setCountry('');
    load({ query: p.q, ctry: '' });
  };
  const onKeyword = useCallback((kw) => {
    setInput(kw); setQ(kw); setCountry('');
    load({ query: kw, ctry: '' });
  }, [load]);
  const onCountry = useCallback((c) => {
    setCountry(c);
    load({ ctry: c });
  }, [load]);

  return (
    <div className="wrap">
      <header>
        <h1>Geopolitics News Dashboard</h1>
        <p className="sub">Live headlines from the newsdata.io news API, mapped into country relationships, a timeline, and sentiment.</p>
      </header>

      <form className="search" onSubmit={submit}>
        <input
          value={input}
          onChange={e => setInput(e.target.value)}
          placeholder="Search a topic, e.g. NATO, Taiwan, sanctions"
        />
        <button type="submit">Search</button>
      </form>

      <div className="presets">
        {PRESETS.map(p => (
          <button key={p.q} className="preset" onClick={() => preset(p)}>{p.label}</button>
        ))}
      </div>

      <div className="statusbar">
        <span>Query: <b>{q}</b></span>
        {country ? (
          <span> &middot; Country: <b>{country.toUpperCase()}</b>{' '}
            <button className="link" onClick={() => { setCountry(''); load({ ctry: '' }); }}>clear</button>
          </span>
        ) : null}
        <span> &middot; {articles.length} loaded{total ? (' of ~' + total) : ''}</span>
      </div>

      {error ? <div className="error">{error}</div> : null}

      <div className="grid">
        <div className="col-main">
          <CountryGraph articles={articles} onCountry={onCountry} />
          <Timeline articles={articles} />
        </div>
        <div className="col-side">
          <SentimentBreakdown articles={articles} />
          <TopKeywords articles={articles} onKeyword={onKeyword} />
        </div>
      </div>

      <div className="list">
        {articles.map((a, i) => (
          <ArticleCard key={a.article_id || i} a={a} onKeyword={onKeyword} />
        ))}
      </div>

      <div className="loadmore">
        {loading
          ? <span className="note">Loading&hellip;</span>
          : nextPage
            ? <button onClick={() => load({ append: true, page: nextPage })}>Load more</button>
            : (articles.length ? <span className="note">End of results.</span> : null)}
      </div>

      <footer>
        Data from <a href="https://newsdata.io" target="_blank" rel="noreferrer">newsdata.io</a> &middot; runs on a free API key
      </footer>
    </div>
  );
}

const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(<App />);
