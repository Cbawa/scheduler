const express = require('express');
const path = require('path');

const PORT = process.env.PORT || 3000;
const API_KEY = process.env.NEWSDATA_API_KEY;
const BASE = 'https://newsdata.io/api/1';
const ENABLE_FULL_CONTENT = process.env.ENABLE_FULL_CONTENT === '1';

if (!API_KEY) {
  console.error('NEWSDATA_API_KEY is not set.');
  console.error('Get a free key at https://newsdata.io and run:');
  console.error('  export NEWSDATA_API_KEY=your_key_here');
  process.exit(1);
}

const app = express();
app.use(express.static(path.join(__dirname, 'public')));

// Build a /1/latest URL. Paid query params are only added in "withPaid" mode
// because they error the whole request on a free key.
function buildUrl(params, withPaid) {
  const url = new URL(BASE + '/latest');
  url.searchParams.set('apikey', API_KEY);
  for (const [k, v] of Object.entries(params)) {
    if (v !== undefined && v !== null && v !== '') {
      url.searchParams.set(k, String(v));
    }
  }
  if (withPaid && ENABLE_FULL_CONTENT) {
    url.searchParams.set('full_content', '1');
  }
  return url;
}

async function callNewsData(params) {
  let resp = await fetch(buildUrl(params, true));
  // If a paid param was rejected, retry once without it so free keys still work.
  if ((resp.status === 403 || resp.status === 422) && ENABLE_FULL_CONTENT) {
    resp = await fetch(buildUrl(params, false));
  }
  return resp;
}

app.get('/api/news', async (req, res) => {
  const params = {
    q: (req.query.q && String(req.query.q).trim()) || 'geopolitics',
    language: req.query.language || 'en',
    country: req.query.country || undefined,
    category: req.query.category || undefined,
    page: req.query.page || undefined,
  };

  try {
    const resp = await callNewsData(params);

    if (resp.status === 401) {
      return res.status(401).json({
        error: 'invalid_key',
        message: 'newsdata.io rejected the API key (401). Check NEWSDATA_API_KEY.',
      });
    }
    if (resp.status === 429) {
      return res.status(429).json({
        error: 'rate_limited',
        message: 'newsdata.io rate limit reached (429). Wait a moment and try again.',
      });
    }

    let data = null;
    try {
      data = await resp.json();
    } catch (e) {
      data = null;
    }

    if (!data || data.status === 'error') {
      const msg =
        (data && ((data.results && data.results.message) || data.message)) ||
        ('newsdata.io error (HTTP ' + resp.status + ')');
      return res.status(502).json({ error: 'api_error', message: msg });
    }

    return res.json({
      results: Array.isArray(data.results) ? data.results : [],
      nextPage: data.nextPage || null,
      totalResults: data.totalResults || 0,
    });
  } catch (e) {
    return res.status(500).json({ error: 'server_error', message: e.message });
  }
});

app.get('/api/health', (req, res) => res.json({ ok: true }));

app.listen(PORT, () => {
  console.log('geopolitics-news-dashboard running on http://localhost:' + PORT);
  if (ENABLE_FULL_CONTENT) {
    console.log('full_content enabled (requires a paid newsdata.io plan)');
  }
});
