# Geopolitics News Dashboard

A small web dashboard for watching geopolitical news. It pulls live headlines
from the newsdata.io news API (https://newsdata.io) and turns the results into
three views: a country co-occurrence graph, an hourly event timeline, and a
sentiment breakdown. Grab a free API key to run it.

The frontend is React with D3.js for the charts. A small Express server sits in
front of newsdata.io so your API key stays on the server and never ships to the
browser.

## Features

- Search any topic, or pick a preset (diplomacy, sanctions, trade, energy, ...).
- Country co-occurrence graph (D3 force layout) built from the `country` field
  of each article; click a country to filter the feed.
- Hourly timeline of when the current stories were published.
- Sentiment breakdown bar.
- Per-article cards with source, publish time, keyword chips, AI tag chips, and
  an AI summary line when those fields are present.
- Click a keyword chip to re-search on it.
- "Load more" follows newsdata.io's `nextPage` cursor.

## Requirements

- Node.js 18 or newer (the server uses the built-in `fetch`).
- A newsdata.io API key. The free tier is enough to run everything here.

## Setup

1. Install dependencies:

   ```bash
   npm install
   ```

2. Set your API key. The server reads it from `NEWSDATA_API_KEY`:

   ```bash
   export NEWSDATA_API_KEY=your_key_here
   ```

   You can get a free key at https://newsdata.io. There is an `.env.example`
   for reference, but the key is read from the environment, not from a file.

3. Start it:

   ```bash
   npm start
   ```

   Then open http://localhost:3000.

## How it behaves on the free tier

newsdata.io returns some fields only on paid plans: `sentiment`, the AI fields
(`ai_tag`, `ai_summary`, `ai_region`, `ai_org`), and full article content. On a
free key those come back empty. The dashboard reads them when present and falls
back cleanly when they aren't:

- Article cards drop the sentiment badge and AI-tag chips when that data is
  absent, and use the plain `description` when there's no `ai_summary`.
- The sentiment breakdown shows a clearly-labeled sample distribution until a
  plan that includes sentiment is in use.
- Keywords (`keywords`) are part of the free tier, so the keyword chips and the
  "Top keywords" panel always work.

## Optional configuration

These are off by default because they need a paid newsdata.io plan. If you turn
one on and newsdata.io rejects the request, the server retries once without it
so you still get free-tier results.

| Variable              | Effect                                          |
|-----------------------|-------------------------------------------------|
| `ENABLE_FULL_CONTENT` | Request `full_content=1` (full article body).   |
| `PORT`                | Port to listen on (default `3000`).             |

## API

The server exposes one endpoint that proxies newsdata.io's `/1/latest`:

```
GET /api/news?q=<topic>&country=<cc>&page=<nextPageCursor>
```

Example:

```bash
curl 'http://localhost:3000/api/news?q=sanctions'
```

Sample output (trimmed):

```json
{
  "totalResults": 1240,
  "nextPage": "1700000000000000000",
  "results": [
    {
      "article_id": "abc123",
      "title": "Foreign ministers meet over new sanctions package",
      "link": "https://example.com/article",
      "source_name": "Example Wire",
      "pubDate": "2026-06-12 09:14:00",
      "country": ["united states", "russia"],
      "keywords": ["sanctions", "diplomacy"],
      "sentiment": null,
      "ai_summary": null
    }
  ]
}
```

(`sentiment` and `ai_summary` are `null` here because the request used a free
key.)

## Project layout

```
server.js          Express proxy + static file server
public/index.html  Page shell, styles, CDN script tags
public/app.jsx     React + D3 dashboard (compiled in the browser)
```

The frontend is intentionally build-free: React, ReactDOM, D3, and Babel load
from a CDN and `app.jsx` is compiled in the browser, so there's no bundler step
to set up.

## License

MIT
