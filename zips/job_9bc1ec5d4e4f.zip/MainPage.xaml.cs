using System.Collections.ObjectModel;
using Microsoft.Maui.ApplicationModel;
using Microsoft.Maui.Storage;
using NewsMauiApp.Services;

namespace NewsMauiApp;

public partial class MainPage : ContentPage
{
    private const string ApiKeyPref = "newsdata_api_key";

    private readonly NewsDataService _service = new();
    private readonly ObservableCollection<Article> _articles = new();
    private string? _nextPage;
    private bool _busy;
    private bool _ready;

    private static readonly string[] Categories =
    {
        "all", "top", "world", "business", "technology",
        "sports", "science", "health", "entertainment", "politics"
    };

    public MainPage()
    {
        InitializeComponent();

        NewsList.ItemsSource = _articles;

        foreach (var c in Categories)
            CategoryPicker.Items.Add(c);
        CategoryPicker.SelectedIndex = 0;

        ApiKeyEntry.Text = ReadStoredKey();
        UpdateSentimentChart();

        _ready = true;
    }

    protected override async void OnAppearing()
    {
        base.OnAppearing();
        if (_articles.Count == 0)
            await LoadAsync(reset: true);
    }

    private static string ReadStoredKey()
    {
        var env = Environment.GetEnvironmentVariable("NEWSDATA_API_KEY");
        if (!string.IsNullOrWhiteSpace(env))
            return env.Trim();
        return Preferences.Get(ApiKeyPref, "");
    }

    private string CurrentApiKey()
    {
        var typed = ApiKeyEntry.Text?.Trim();
        if (!string.IsNullOrWhiteSpace(typed))
        {
            Preferences.Set(ApiKeyPref, typed);
            return typed;
        }
        return ReadStoredKey();
    }

    private async Task LoadAsync(bool reset)
    {
        if (_busy)
            return;
        _busy = true;

        try
        {
            if (reset)
            {
                _nextPage = null;
                StatusLabel.Text = "Loading\u2026";
            }

            var key = CurrentApiKey();
            var category = CategoryPicker.SelectedItem as string;
            var query = SearchEntry.Text;
            var page = reset ? null : _nextPage;

            var result = await _service.GetLatestAsync(key, query, category, page);

            if (reset)
                _articles.Clear();
            foreach (var a in result.Articles)
                _articles.Add(a);

            _nextPage = result.NextPage;
            LoadMoreButton.IsVisible = !string.IsNullOrEmpty(_nextPage);

            UpdateSentimentChart();

            StatusLabel.Text = _articles.Count == 0
                ? "No articles found. Try another search or category."
                : $"Showing {_articles.Count} article(s).";
        }
        catch (NewsDataException ex)
        {
            StatusLabel.Text = ex.Message;
        }
        catch (Exception ex)
        {
            StatusLabel.Text = "Something went wrong: " + ex.Message;
        }
        finally
        {
            _busy = false;
            Refresher.IsRefreshing = false;
        }
    }

    private void UpdateSentimentChart()
    {
        var b = NewsDataService.ComputeBreakdown(_articles);

        SentimentChartContainer.Children.Clear();
        SentimentChartContainer.Children.Add(MakeBar("Positive", b.Positive, Color.FromArgb("#1B998B")));
        SentimentChartContainer.Children.Add(MakeBar("Neutral", b.Neutral, Color.FromArgb("#5B6C8F")));
        SentimentChartContainer.Children.Add(MakeBar("Negative", b.Negative, Color.FromArgb("#C84630")));

        SentimentCaption.Text = b.IsSample
            ? "Sample data \u2014 live sentiment requires a paid newsdata.io plan."
            : "Based on the sentiment field in the current results.";
    }

    private static View MakeBar(string label, double fraction, Color color)
    {
        var grid = new Grid
        {
            ColumnDefinitions =
            {
                new ColumnDefinition(new GridLength(72)),
                new ColumnDefinition(GridLength.Star),
                new ColumnDefinition(new GridLength(40))
            },
            ColumnSpacing = 6
        };

        grid.Add(new Label { Text = label, FontSize = 11, VerticalOptions = LayoutOptions.Center }, 0, 0);

        var track = new Grid { BackgroundColor = Color.FromArgb("#EEF0F6"), HeightRequest = 14 };
        var fill = new BoxView
        {
            Color = color,
            HorizontalOptions = LayoutOptions.Start,
            WidthRequest = Math.Max(2, fraction * 170)
        };
        track.Add(fill, 0, 0);
        grid.Add(track, 1, 0);

        grid.Add(new Label { Text = $"{fraction * 100:0}%", FontSize = 11, VerticalOptions = LayoutOptions.Center }, 2, 0);
        return grid;
    }

    private async void OnSearchClicked(object? sender, EventArgs e) => await LoadAsync(reset: true);

    private async void OnCategoryChanged(object? sender, EventArgs e)
    {
        if (!_ready)
            return;
        await LoadAsync(reset: true);
    }

    private async void OnRefreshing(object? sender, EventArgs e) => await LoadAsync(reset: true);

    private async void OnLoadMoreClicked(object? sender, EventArgs e) => await LoadAsync(reset: false);

    private async void OnReadClicked(object? sender, EventArgs e)
    {
        if (sender is Button btn && btn.CommandParameter is string url && !string.IsNullOrWhiteSpace(url))
        {
            try
            {
                await Launcher.Default.OpenAsync(url);
            }
            catch
            {
                StatusLabel.Text = "Couldn't open the link.";
            }
        }
    }
}
