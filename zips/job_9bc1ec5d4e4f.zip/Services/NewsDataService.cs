using System.Net;
using System.Text.Json;

namespace NewsMauiApp.Services;

public class NewsDataException : Exception
{
    public NewsDataException(string message) : base(message) { }
}

public class Article
{
    public string Title { get; set; } = "(untitled)";
    public string Description { get; set; } = "";
    public string SourceName { get; set; } = "Unknown source";
    public string Link { get; set; } = "";
    public string? ImageUrl { get; set; }
    public string PubDate { get; set; } = "";
    public List<string> Keywords { get; set; } = new();
    public List<string> AiTags { get; set; } = new();
    public string? Sentiment { get; set; }
    public string? AiSummary { get; set; }

    public bool HasImage => !string.IsNullOrWhiteSpace(ImageUrl);
    public bool HasKeywords => Keywords.Count > 0;
    public bool HasSentiment => !string.IsNullOrWhiteSpace(Sentiment);
    public bool HasAiSummary => !string.IsNullOrWhiteSpace(AiSummary);

    public string SentimentText => HasSentiment ? Sentiment!.ToUpperInvariant() : "SENTIMENT N/A";

    public Color SentimentColor => Sentiment?.ToLowerInvariant() switch
    {
        "positive" => Color.FromArgb("#1B998B"),
        "negative" => Color.FromArgb("#C84630"),
        "neutral" => Color.FromArgb("#5B6C8F"),
        _ => Color.FromArgb("#9AA0A6")
    };

    public string AiSummaryText => HasAiSummary ? AiSummary! : string.Empty;
}

public class NewsPage
{
    public List<Article> Articles { get; set; } = new();
    public string? NextPage { get; set; }
    public int TotalResults { get; set; }
}

public class SentimentBreakdown
{
    public double Positive { get; set; }
    public double Neutral { get; set; }
    public double Negative { get; set; }
    public bool IsSample { get; set; }
}

public class NewsDataService
{
    // newsdata.io latest-news endpoint. Auth via the apikey query parameter.
    private const string BaseUrl = "https://newsdata.io/api/1/latest";

    private readonly HttpClient _http;

    public NewsDataService(HttpClient? http = null)
    {
        _http = http ?? new HttpClient { Timeout = TimeSpan.FromSeconds(30) };
    }

    public async Task<NewsPage> GetLatestAsync(string apiKey, string? query, string? category, string? page, CancellationToken ct = default)
    {
        if (string.IsNullOrWhiteSpace(apiKey))
            throw new NewsDataException("No API key set. Add your newsdata.io key (NEWSDATA_API_KEY) in the field above.");

        var url = BuildUrl(apiKey, query, category, page);

        HttpResponseMessage resp;
        try
        {
            resp = await _http.GetAsync(url, ct);
        }
        catch (Exception ex)
        {
            throw new NewsDataException("Network error: " + ex.Message);
        }

        var body = await resp.Content.ReadAsStringAsync(ct);

        if (resp.StatusCode == HttpStatusCode.Unauthorized)
            throw new NewsDataException("Invalid API key (401). Check your newsdata.io key.");
        if ((int)resp.StatusCode == 429)
            throw new NewsDataException("Rate limit reached (429). Wait a moment and try again.");
        if (!resp.IsSuccessStatusCode)
            throw new NewsDataException($"Request failed ({(int)resp.StatusCode}). {ExtractMessage(body)}");

        return Parse(body);
    }

    private static string BuildUrl(string apiKey, string? query, string? category, string? page)
    {
        // Only free-plan parameters are sent so a brand-new free key works as-is.
        var qs = new List<string>
        {
            "apikey=" + Uri.EscapeDataString(apiKey),
            "language=en"
        };

        if (!string.IsNullOrWhiteSpace(query))
            qs.Add("q=" + Uri.EscapeDataString(query.Trim()));
        if (!string.IsNullOrWhiteSpace(category) && category != "all")
            qs.Add("category=" + Uri.EscapeDataString(category));
        if (!string.IsNullOrWhiteSpace(page))
            qs.Add("page=" + Uri.EscapeDataString(page));

        return BaseUrl + "?" + string.Join("&", qs);
    }

    private static NewsPage Parse(string body)
    {
        using var doc = JsonDocument.Parse(body);
        var root = doc.RootElement;

        if (root.TryGetProperty("status", out var st) &&
            st.ValueKind == JsonValueKind.String &&
            string.Equals(st.GetString(), "error", StringComparison.OrdinalIgnoreCase))
        {
            throw new NewsDataException(ExtractMessage(body));
        }

        var result = new NewsPage();

        if (root.TryGetProperty("nextPage", out var np) && np.ValueKind == JsonValueKind.String)
            result.NextPage = np.GetString();
        if (root.TryGetProperty("totalResults", out var tr) && tr.ValueKind == JsonValueKind.Number)
            result.TotalResults = tr.GetInt32();

        if (root.TryGetProperty("results", out var results) && results.ValueKind == JsonValueKind.Array)
        {
            foreach (var item in results.EnumerateArray())
                result.Articles.Add(ParseArticle(item));
        }

        return result;
    }

    private static Article ParseArticle(JsonElement item)
    {
        var a = new Article
        {
            Title = GetString(item, "title") ?? "(untitled)",
            Description = GetString(item, "description") ?? "",
            SourceName = GetString(item, "source_name") ?? GetString(item, "source_id") ?? "Unknown source",
            Link = GetString(item, "link") ?? "",
            ImageUrl = GetString(item, "image_url"),
            PubDate = GetString(item, "pubDate") ?? "",
            Keywords = GetStringList(item, "keywords"),
            AiTags = GetStringList(item, "ai_tag")
        };

        // Paid response fields: simply absent / placeholder text on a free key.
        var sentiment = GetString(item, "sentiment");
        if (!IsPaidPlaceholder(sentiment))
            a.Sentiment = sentiment;

        var summary = GetString(item, "ai_summary");
        if (!IsPaidPlaceholder(summary))
            a.AiSummary = summary;

        return a;
    }

    private static bool IsPaidPlaceholder(string? s)
    {
        if (string.IsNullOrWhiteSpace(s))
            return true;
        return s.ToUpperInvariant().Contains("ONLY AVAILABLE");
    }

    private static string? GetString(JsonElement el, string name)
    {
        if (el.TryGetProperty(name, out var v) && v.ValueKind == JsonValueKind.String)
        {
            var s = v.GetString();
            return string.IsNullOrWhiteSpace(s) ? null : s;
        }
        return null;
    }

    private static List<string> GetStringList(JsonElement el, string name)
    {
        var list = new List<string>();
        if (!el.TryGetProperty(name, out var v))
            return list;

        if (v.ValueKind == JsonValueKind.Array)
        {
            foreach (var x in v.EnumerateArray())
            {
                if (x.ValueKind == JsonValueKind.String)
                {
                    var s = x.GetString();
                    if (!string.IsNullOrWhiteSpace(s) && !IsPaidPlaceholder(s))
                        list.Add(s!);
                }
            }
        }
        else if (v.ValueKind == JsonValueKind.String)
        {
            var s = v.GetString();
            if (!string.IsNullOrWhiteSpace(s) && !IsPaidPlaceholder(s))
                list.Add(s!);
        }

        return list;
    }

    private static string ExtractMessage(string body)
    {
        try
        {
            using var doc = JsonDocument.Parse(body);
            var root = doc.RootElement;
            if (root.TryGetProperty("results", out var r) &&
                r.ValueKind == JsonValueKind.Object &&
                r.TryGetProperty("message", out var m) &&
                m.ValueKind == JsonValueKind.String)
            {
                return m.GetString() ?? "Unknown error.";
            }
            if (root.TryGetProperty("message", out var m2) && m2.ValueKind == JsonValueKind.String)
                return m2.GetString() ?? "Unknown error.";
        }
        catch
        {
            // fall through
        }
        return "Unknown error.";
    }

    public static SentimentBreakdown ComputeBreakdown(IEnumerable<Article> articles)
    {
        int pos = 0, neu = 0, neg = 0;
        foreach (var a in articles)
        {
            switch (a.Sentiment?.ToLowerInvariant())
            {
                case "positive": pos++; break;
                case "negative": neg++; break;
                case "neutral": neu++; break;
            }
        }

        int total = pos + neu + neg;
        if (total == 0)
        {
            // No live sentiment (free plan): show a clearly-labeled sample so the
            // capability stays visible without faking real API output.
            return new SentimentBreakdown { Positive = 0.45, Neutral = 0.40, Negative = 0.15, IsSample = true };
        }

        return new SentimentBreakdown
        {
            Positive = (double)pos / total,
            Neutral = (double)neu / total,
            Negative = (double)neg / total,
            IsSample = false
        };
    }
}
