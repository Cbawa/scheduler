# News MAUI

A cross-platform news reader built with .NET MAUI. It shows live headlines from the [newsdata.io](https://newsdata.io) news API and runs from a single codebase on Android, iOS, Windows, and macOS (Mac Catalyst). Grab a free API key from newsdata.io to run it.

## What it does

- Fetches the latest headlines and shows the title, source, image, and description
- Search by keyword and filter by category
- Pull-to-refresh and a "Load more" button that pages with the API's `nextPage` cursor
- Per-article keyword tags taken from the response
- A per-article sentiment badge and a small sentiment-mix bar chart
- Opens the full article in the system browser

## Requirements

- .NET 8 SDK
- The MAUI workload: `dotnet workload install maui`
- Platform tooling for whatever you build (Android SDK, Xcode for iOS/macOS, Windows App SDK on Windows)

## Setup

1. Clone the repo.
2. Get a free API key at https://newsdata.io.
3. Provide the key. On desktop, set an environment variable:
   - macOS/Linux: `export NEWSDATA_API_KEY=your_key_here`
   - Windows (PowerShell): `setx NEWSDATA_API_KEY your_key_here`

   On a phone or emulator where environment variables are awkward, paste the key into the field at the top of the app instead — it is stored locally with `Preferences`.

## Run

Restore once, then build-and-run for a target framework:

```
dotnet restore

# Android (emulator or device attached)
dotnet build -t:Run -f net8.0-android

# Windows
dotnet build -t:Run -f net8.0-windows10.0.19041.0

# Mac Catalyst
dotnet build -t:Run -f net8.0-maccatalyst
```

iOS is usually launched from Visual Studio or VS Code with a simulator selected.

## Example

With a key set, the first screen loads about ten latest English headlines. A run looks roughly like:

```
Showing 10 article(s).
- Markets edge higher as...   Reuters    [SENTIMENT N/A]   #markets #stocks
- New telescope captures...   BBC News   [SENTIMENT N/A]   #space #science
...
```

Pick a category or type a search term and the list reloads; "Load more" appends the next page.

## Notes on data fields

The app reads these fields straight from each result and shows them when present:

- `keywords` — available on the free plan; rendered as tag chips.
- `sentiment` — shown as a colored badge. On the free plan this field is absent, so the badge reads "SENTIMENT N/A" and the sentiment-mix chart shows clearly labeled sample values. Both become live on a paid newsdata.io plan.
- `ai_summary` — shown as an italic line under an article when the plan includes it.

The default requests use only free-plan parameters (`q`, `category`, `language`, `page`), so a brand-new free key works with no extra configuration. Paid-only query parameters (sentiment filtering, date ranges, larger page sizes, the archive endpoint) are intentionally not sent.

## Project layout

- `MainPage.xaml` / `MainPage.xaml.cs` — UI plus load, refresh, and pagination logic
- `Services/NewsDataService.cs` — HTTP calls to newsdata.io and tolerant JSON parsing
- `Platforms/` — per-platform entry points
- `Resources/` — app icon and splash screen

## License

MIT
