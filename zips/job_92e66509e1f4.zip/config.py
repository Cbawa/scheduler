import os
import sys

try:
    from dotenv import load_dotenv
    load_dotenv()
except Exception:
    # python-dotenv is optional; real environment variables still work.
    pass


def _get(name, default=None):
    value = os.getenv(name)
    if value is None or value == '':
        return default
    return value


NEWSDATA_API_KEY = _get('NEWSDATA_API_KEY')
AIRTABLE_API_KEY = _get('AIRTABLE_API_KEY')
AIRTABLE_BASE_ID = _get('AIRTABLE_BASE_ID')
AIRTABLE_TABLE_NAME = _get('AIRTABLE_TABLE_NAME', 'News')

try:
    MAX_RESULTS = int(_get('MAX_RESULTS', '50'))
except ValueError:
    MAX_RESULTS = 50

ENABLE_PAID_PARAMS = _get('ENABLE_PAID_PARAMS', '0') == '1'


def require_newsdata():
    if not NEWSDATA_API_KEY:
        sys.exit(
            'NEWSDATA_API_KEY is not set. Get a free key at https://newsdata.io '
            'and export it, e.g.\n  export NEWSDATA_API_KEY=pub_xxx'
        )


def require_airtable():
    missing = [name for name, value in (
        ('AIRTABLE_API_KEY', AIRTABLE_API_KEY),
        ('AIRTABLE_BASE_ID', AIRTABLE_BASE_ID),
    ) if not value]
    if missing:
        sys.exit(
            'Missing Airtable settings: ' + ', '.join(missing) +
            '. Set them in your environment or .env, or run with --dry-run to '
            'preview without writing.'
        )
