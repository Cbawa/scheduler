import json
import os

DEFAULT_MAP = {
    'article_id': 'Article ID',
    'title': 'Title',
    'link': 'URL',
    'description': 'Description',
    'content': 'Content',
    'pubDate': 'Published',
    'source_id': 'Source',
    'creator': 'Author',
    'image_url': 'Image',
    'category': 'Category',
    'country': 'Country',
    'language': 'Language',
    'keywords': 'Keywords',
    'sentiment': 'Sentiment',
    'ai_tag': 'AI Tags',
    'ai_region': 'AI Regions',
    'ai_org': 'AI Organizations',
    'ai_summary': 'AI Summary',
}

KEY_SOURCE_FIELD = 'article_id'
_MAP_FILE = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'field_map.json')


def load_field_map():
    """Default mapping, optionally overridden by a field_map.json in the root."""
    mapping = dict(DEFAULT_MAP)
    if os.path.exists(_MAP_FILE):
        try:
            with open(_MAP_FILE, 'r', encoding='utf-8') as handle:
                custom = json.load(handle)
            if isinstance(custom, dict):
                mapping.update({str(k): str(v) for k, v in custom.items()})
        except (ValueError, OSError) as exc:
            print('Warning: could not read field_map.json (' + str(exc) + '); using defaults.')
    return mapping


def _coerce(value):
    if isinstance(value, list):
        joined = ', '.join(str(v) for v in value if v not in (None, ''))
        return joined or None
    if isinstance(value, str):
        value = value.strip()
        return value or None
    return value


def article_to_fields(article, field_map):
    """Build an Airtable {column: value} dict, skipping missing/empty fields."""
    fields = {}
    for src, column in field_map.items():
        coerced = _coerce(article.get(src))
        if coerced in (None, ''):
            continue
        fields[column] = coerced
    return fields


def key_column(field_map):
    return field_map.get(KEY_SOURCE_FIELD, DEFAULT_MAP[KEY_SOURCE_FIELD])
