from urllib.parse import quote

import requests

API_ROOT = 'https://api.airtable.com/v0'


class AirtableError(Exception):
    pass


class AirtableClient:
    def __init__(self, api_key, base_id):
        self.base_id = base_id
        self.session = requests.Session()
        self.session.headers.update({'Authorization': 'Bearer ' + (api_key or '')})

    def _table_url(self, table):
        return API_ROOT + '/' + self.base_id + '/' + quote(table, safe='')

    def existing_keys(self, table, key_field):
        """Return the set of values already stored in key_field across the table."""
        return self._list_values(table, key_field, with_field_filter=True)

    def _list_values(self, table, key_field, with_field_filter):
        url = self._table_url(table)
        keys = set()
        offset = None
        while True:
            params = {'pageSize': 100}
            if with_field_filter:
                params['fields[]'] = key_field
            if offset:
                params['offset'] = offset
            try:
                resp = self.session.get(url, params=params, timeout=30)
            except requests.RequestException as exc:
                raise AirtableError('Network error talking to Airtable: ' + str(exc))

            if resp.status_code == 401:
                raise AirtableError('Airtable rejected the token (401). Check AIRTABLE_API_KEY.')
            if resp.status_code == 404:
                raise AirtableError('Airtable base or table not found (404): ' + table)
            if resp.status_code == 422 and with_field_filter:
                # The key column may not exist yet; retry pulling all fields.
                return self._list_values(table, key_field, with_field_filter=False)
            if not resp.ok:
                raise AirtableError('Airtable list failed: HTTP ' + str(resp.status_code) + ' ' + resp.text[:300])

            data = resp.json()
            for record in data.get('records', []):
                value = record.get('fields', {}).get(key_field)
                if value not in (None, ''):
                    keys.add(str(value))
            offset = data.get('offset')
            if not offset:
                break
        return keys

    def create_records(self, table, field_dicts):
        """Create records in batches of 10 (Airtable's per-request limit)."""
        url = self._table_url(table)
        created = 0
        for start in range(0, len(field_dicts), 10):
            batch = field_dicts[start:start + 10]
            payload = {'records': [{'fields': fields} for fields in batch], 'typecast': True}
            try:
                resp = self.session.post(url, json=payload, timeout=30)
            except requests.RequestException as exc:
                raise AirtableError('Network error talking to Airtable: ' + str(exc))
            if not resp.ok:
                raise AirtableError('Airtable create failed: HTTP ' + str(resp.status_code) + ' ' + resp.text[:300])
            created += len(resp.json().get('records', []))
        return created
