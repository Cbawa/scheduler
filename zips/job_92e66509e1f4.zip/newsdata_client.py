import time

import requests

import config

BASE_URL = 'https://newsdata.io/api/1'
_PAID_STATUS = (403, 422)


class NewsDataError(Exception):
    pass


class _PaidParamError(NewsDataError):
    """Raised when a request is rejected for using a paid-only query param."""

    def __init__(self, status, body):
        super().__init__('Paid parameter rejected (HTTP ' + str(status) + ')')
        self.status = status
        self.body = body


def _request(endpoint, params):
    url = BASE_URL + '/' + endpoint
    headers = {'X-ACCESS-KEY': config.NEWSDATA_API_KEY or ''}
    attempts = 0
    while True:
        attempts += 1
        try:
            resp = requests.get(url, params=params, headers=headers, timeout=30)
        except requests.RequestException as exc:
            raise NewsDataError('Network error talking to newsdata.io: ' + str(exc))

        if resp.status_code == 200:
            try:
                return resp.json()
            except ValueError:
                raise NewsDataError('newsdata.io returned a non-JSON response.')
        if resp.status_code == 401:
            raise NewsDataError('newsdata.io rejected the API key (401). Check NEWSDATA_API_KEY.')
        if resp.status_code == 429:
            if attempts <= 3:
                time.sleep(2 ** attempts)
                continue
            raise NewsDataError('newsdata.io rate limit hit (429). Try again later.')
        if resp.status_code in _PAID_STATUS:
            raise _PaidParamError(resp.status_code, resp.text)
        raise NewsDataError('newsdata.io returned HTTP ' + str(resp.status_code) + ': ' + resp.text[:300])


def fetch_latest(query=None, country=None, category=None, language=None,
                 max_results=50, paid_params=None):
    """Fetch latest articles, paging via the nextPage cursor up to max_results.

    paid_params (sentiment, full_content, ...) are only sent when provided and
    are dropped automatically if newsdata.io rejects them on a free key.
    """
    base_params = {}
    if query:
        base_params['q'] = query
    if country:
        base_params['country'] = country
    if category:
        base_params['category'] = category
    if language:
        base_params['language'] = language

    use_paid = dict(paid_params) if paid_params else {}
    collected = []
    page = None
    retried_without_paid = False

    while len(collected) < max_results:
        params = dict(base_params)
        params.update(use_paid)
        if page:
            params['page'] = page
        try:
            data = _request('latest', params)
        except _PaidParamError:
            if use_paid and not retried_without_paid:
                print('newsdata.io rejected paid query params; retrying on the free path.')
                use_paid = {}
                retried_without_paid = True
                page = None
                collected = []
                continue
            raise
        results = data.get('results') or []
        collected.extend(results)
        page = data.get('nextPage')
        if not page:
            break

    return collected[:max_results]
