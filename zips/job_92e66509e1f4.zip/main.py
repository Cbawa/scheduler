#!/usr/bin/env python3
"""Sync the latest newsdata.io headlines into an Airtable base."""
import argparse
import sys
from collections import Counter

import config
from newsdata_client import fetch_latest, NewsDataError
from airtable_client import AirtableClient, AirtableError
from mapping import load_field_map, article_to_fields, key_column

_BADGES = {'positive': '[+]', 'negative': '[-]', 'neutral': '[=]'}


def parse_args():
    parser = argparse.ArgumentParser(
        description='Sync newsdata.io news into an Airtable base with dedup.')
    parser.add_argument('-q', '--query', help='Search keywords (newsdata.io q param)')
    parser.add_argument('--country', help='Comma-separated country codes, e.g. us,gb')
    parser.add_argument('--category', help='Comma-separated categories, e.g. technology')
    parser.add_argument('--language', help='Comma-separated language codes, e.g. en')
    parser.add_argument('--table', default=config.AIRTABLE_TABLE_NAME,
                        help='Airtable table name (default: %(default)s)')
    parser.add_argument('--max-results', type=int, default=config.MAX_RESULTS,
                        help='Maximum articles to pull (default: %(default)s)')
    parser.add_argument('--sentiment', choices=['positive', 'negative', 'neutral'],
                        help='Filter by sentiment (requires a paid newsdata.io plan)')
    parser.add_argument('--full-content', action='store_true',
                        help='Request full article text (requires a paid plan)')
    parser.add_argument('--dry-run', action='store_true',
                        help='Fetch and print, but do not write to Airtable')
    return parser.parse_args()


def build_paid_params(args):
    paid = {}
    if not (args.sentiment or args.full_content):
        return paid
    if not config.ENABLE_PAID_PARAMS:
        print('Note: --sentiment/--full-content need ENABLE_PAID_PARAMS=1 and a paid '
              'newsdata.io plan; ignoring them and running on the free path.')
        return paid
    if args.sentiment:
        paid['sentiment'] = args.sentiment
    if args.full_content:
        paid['full_content'] = 1
    return paid


def badge(sentiment):
    return _BADGES.get(sentiment, '[ ]')


def print_articles(articles):
    print()
    print('Fetched ' + str(len(articles)) + ' article(s):')
    print('-' * 72)
    for art in articles:
        title = (art.get('title') or '(untitled)').strip()
        source = art.get('source_id') or '?'
        date = art.get('pubDate') or ''
        line = badge(art.get('sentiment')) + ' ' + title
        print(line)
        meta = '    ' + source
        if date:
            meta += '  |  ' + date
        print(meta)
        keywords = art.get('keywords') or []
        if keywords:
            chips = ', '.join('#' + str(k) for k in keywords[:6])
            print('    tags: ' + chips)
        summary = art.get('ai_summary')
        if summary:
            print('    summary: ' + str(summary)[:160])
    print('-' * 72)


def print_sentiment_breakdown(articles):
    counts = Counter(a.get('sentiment') for a in articles if a.get('sentiment'))
    print()
    print('Sentiment breakdown:')
    if counts:
        total = sum(counts.values())
        for label in ('positive', 'neutral', 'negative'):
            n = counts.get(label, 0)
            bar = '#' * int(round(20 * n / total)) if total else ''
            print('  ' + label.ljust(9) + ' ' + str(n).rjust(3) + '  ' + bar)
    else:
        print('  (sample - live sentiment requires a paid newsdata.io plan)')
        for label, n in (('positive', 6), ('neutral', 3), ('negative', 1)):
            print('  ' + label.ljust(9) + ' ' + str(n).rjust(3) + '  ' + '#' * n + '   [sample]')


def dedupe(articles, existing_keys):
    seen = set(existing_keys)
    fresh = []
    for art in articles:
        key = art.get('article_id') or art.get('link')
        if not key:
            continue
        key = str(key)
        if key in seen:
            continue
        seen.add(key)
        fresh.append(art)
    return fresh


def main():
    args = parse_args()
    config.require_newsdata()

    paid_params = build_paid_params(args)
    try:
        articles = fetch_latest(
            query=args.query,
            country=args.country,
            category=args.category,
            language=args.language,
            max_results=args.max_results,
            paid_params=paid_params or None,
        )
    except NewsDataError as exc:
        sys.exit(str(exc))

    if not articles:
        print('No articles returned for that query.')
        return

    print_articles(articles)
    print_sentiment_breakdown(articles)

    field_map = load_field_map()
    key_col = key_column(field_map)

    if args.dry_run:
        print()
        print('Dry run: ' + str(len(articles)) + ' article(s) fetched, nothing written.')
        return

    config.require_airtable()
    client = AirtableClient(config.AIRTABLE_API_KEY, config.AIRTABLE_BASE_ID)

    try:
        existing = client.existing_keys(args.table, key_col)
    except AirtableError as exc:
        sys.exit(str(exc))

    fresh = dedupe(articles, existing)
    skipped = len(articles) - len(fresh)
    if not fresh:
        print()
        print('Nothing new to add (' + str(skipped) + ' already in Airtable).')
        return

    records = [article_to_fields(a, field_map) for a in fresh]
    try:
        created = client.create_records(args.table, records)
    except AirtableError as exc:
        sys.exit(str(exc))

    print()
    print('Added ' + str(created) + ' new record(s) to table ' + args.table +
          '; skipped ' + str(skipped) + ' duplicate(s).')


if __name__ == '__main__':
    main()
