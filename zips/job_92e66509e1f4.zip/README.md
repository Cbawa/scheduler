# news-airtable-sync

Command-line tool that pulls the latest headlines from the newsdata.io news API
(https://newsdata.io) and writes them into an Airtable base. It maps API fields
to your own Airtable columns and deduplicates on the article id, so you can run
it on a schedule without creating duplicate rows. You'll need a free newsdata.io
API key to run it.

I built it to keep an Airtable table topped up with news on a few topics I
track, refreshed by a daily cron job.

## What it does

- Fetches latest news from newsdata.io (`/latest`), with optional query,
  country, category, and language filters.
- Follows the `nextPage` cursor to page through results up to a limit you set.
- Maps each article to your Airtable columns via a small, editable field map.
- Skips articles already in the table (dedup on the article id).
- Prints a short console summary: a per-article sentiment badge, keyword tags,
  and a sentiment breakdown for the batch.

## Requirements

- Python 3.9+
- A free newsdata.io API key (https://newsdata.io)
- An Airtable base and a personal access token

## Setup

1. Install dependencies:

   ```
   pip install -r requirements.txt
   ```

2. Create a table in your Airtable base (default name `News`). The tool writes
   to these columns by default; create the ones you want to keep:

   `Article ID`, `Title`, `URL`, `Description`, `Published`, `Source`,
   `Author`, `Image`, `Category`, `Country`, `Language`, `Keywords`,
   `Sentiment`, `AI Tags`, `AI Summary`

   `Article ID` is the dedup key. Plain single-line text fields work for all of
   them; the tool joins list values (keywords, categories) into comma-separated
   strings and sends `typecast` so Airtable accepts them.

3. Create an Airtable personal access token with `data.records:read` and
   `data.records:write` scopes on your base, and note the base id (the `app...`
   part of the base URL).

4. Set environment variables (a `.env` file in the project root also works):

   ```
   export NEWSDATA_API_KEY=pub_xxxxxxxxxxxxxxxx
   export AIRTABLE_API_KEY=pat_xxxxxxxxxxxxxxxx
   export AIRTABLE_BASE_ID=appXXXXXXXXXXXXXX
   export AIRTABLE_TABLE_NAME=News
   ```

## Usage

```
python main.py --query "climate" --language en
python main.py --country us --category technology
python main.py --query bitcoin --max-results 30
python main.py --query "elections" --dry-run
```

Options:

- `-q, --query` — search keywords
- `--country` — comma-separated country codes (e.g. `us,gb`)
- `--category` — comma-separated categories (e.g. `technology,business`)
- `--language` — comma-separated language codes (e.g. `en`)
- `--table` — Airtable table name (default `News`)
- `--max-results` — cap on how many articles to pull (default 50)
- `--dry-run` — fetch and print only, write nothing to Airtable

### Example output

```
$ python main.py --query "mars" --language en --dry-run

Fetched 5 article(s):
------------------------------------------------------------------------
[ ] NASA shares new images from the Mars rover
    space-daily  |  2026-06-11 08:12:00
    tags: #mars, #nasa, #rover
[ ] Startup plans private mission to Mars orbit
    techwire  |  2026-06-11 06:40:00
    tags: #mars, #spaceflight
...
------------------------------------------------------------------------

Sentiment breakdown:
  (sample — live sentiment requires a paid newsdata.io plan)
  positive    6  ######   [sample]
  neutral     3  ###   [sample]
  negative    1  #   [sample]

Dry run: 5 article(s) fetched, nothing written.
```

On a free API key, `sentiment`, `ai_tag`, and `ai_summary` come back empty, so
those columns are left blank and the sentiment summary shows a clearly labeled
sample. With a paid plan the same fields populate automatically — no code
changes needed.

## Custom field mapping

The default mapping lives in `mapping.py`. To override it without touching code,
drop a `field_map.json` file in the project root that maps newsdata.io field
names to your Airtable column names, for example:

```
{
  "title": "Headline",
  "link": "Article URL",
  "pubDate": "Date"
}
```

Keys are newsdata.io response fields (`article_id`, `title`, `link`,
`description`, `pubDate`, `source_id`, `creator`, `image_url`, `category`,
`country`, `language`, `keywords`, `sentiment`, `ai_tag`, `ai_summary`); values
are the column names in your table. Your overrides are merged over the defaults.

## Optional paid features

The default path uses only free-tier parameters. Two flags add paid newsdata.io
query parameters and are ignored unless `ENABLE_PAID_PARAMS=1` is set (they
require a paid plan):

- `--sentiment positive|negative|neutral` — filter results by sentiment
- `--full-content` — request full article text

If newsdata.io rejects a paid parameter, the tool retries once on the free path
so you still get results.

## Notes

- The free tier returns up to 10 articles per request; the tool pages with the
  `nextPage` cursor to reach `--max-results`.
- 401 (invalid key), 429 (rate limit, retried with backoff), and empty results
  are handled with a clear message instead of a stack trace.

## License

MIT
