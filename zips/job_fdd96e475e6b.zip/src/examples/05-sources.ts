/**
 * Example 05 — Listing news sources via GET /sources.
 *
 * Run: npm run example:sources
 */
import { NewsDataClient, NewsDataError } from '../client.js';

async function main(): Promise<void> {
  const client = new NewsDataClient();

  try {
    const response = await client.getSources({ country: 'us', language: 'en' });

    if (response.results.length === 0) {
      console.log('No sources returned for those filters.');
      return;
    }

    console.log(`Found ${response.results.length} source(s). Showing top 10:`);
    for (const source of response.results.slice(0, 10)) {
      const categories = source.category?.join(', ') ?? 'n/a';
      console.log(`\n- ${source.name} (id: ${source.id})`);
      console.log(`  url=${source.url ?? 'n/a'} | category=${categories}`);
    }
  } catch (error) {
    if (error instanceof NewsDataError) {
      console.error(`API error (HTTP ${error.status}): ${error.message}`);
      process.exit(1);
    }
    throw error;
  }
}

void main();
