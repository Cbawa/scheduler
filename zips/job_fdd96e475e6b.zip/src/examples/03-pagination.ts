/**
 * Example 03 — Paginating through results with the `nextPage` token.
 *
 * The free plan returns a `nextPage` token in each response. Pass it back as the
 * `page` parameter to fetch the next page. We cap the number of pages so we stay
 * friendly to the free-tier rate limit.
 *
 * Run: npm run example:paginate
 */
import { NewsDataClient, NewsDataError } from '../client.js';
import type { Article } from '../types.js';

const MAX_PAGES = 3;

async function main(): Promise<void> {
  const client = new NewsDataClient();

  const collected: Article[] = [];
  let page: string | undefined = undefined;
  let pageNumber = 0;

  try {
    do {
      pageNumber += 1;
      console.log(`Fetching page ${pageNumber}${page ? ` (token: ${page})` : ''}...`);

      const response = await client.getLatestNews({ language: 'en', page });
      collected.push(...response.results);

      // `nextPage` is null/absent on the last page.
      page = response.nextPage ?? undefined;
    } while (page && pageNumber < MAX_PAGES);

    console.log(`\nCollected ${collected.length} article(s) across ${pageNumber} page(s).`);
    for (const article of collected.slice(0, 10)) {
      console.log(`- ${article.title ?? '(no title)'}`);
    }

    if (page) {
      console.log(`\nStopped at the page cap (${MAX_PAGES}). More pages are available.`);
    }
  } catch (error) {
    if (error instanceof NewsDataError) {
      if (error.isRateLimited) {
        console.error('Rate limited (HTTP 429). Slow down or wait before retrying.');
      } else {
        console.error(`API error (HTTP ${error.status}): ${error.message}`);
      }
      process.exit(1);
    }
    throw error;
  }
}

void main();
