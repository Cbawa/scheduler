/**
 * Example 02 — Filtering results by keyword, country, language, and category.
 *
 * All of these parameters are available on the FREE plan.
 *
 * Run: npm run example:filter
 */
import { NewsDataClient, NewsDataError } from '../client.js';
import type { NewsQueryParams } from '../types.js';

async function main(): Promise<void> {
  const client = new NewsDataClient();

  // Tweak these to explore the API.
  const filters: NewsQueryParams = {
    q: 'technology',
    country: 'us',
    language: 'en',
    category: 'technology',
  };

  console.log('Fetching news with filters:', JSON.stringify(filters));

  try {
    const response = await client.getLatestNews(filters);

    if (response.results.length === 0) {
      console.log('No articles matched those filters. Try loosening them.');
      return;
    }

    console.log(`\nFound ${response.totalResults} total result(s). Showing top 5:`);
    for (const article of response.results.slice(0, 5)) {
      const categories = article.category?.join(', ') ?? 'n/a';
      console.log(`\n- ${article.title ?? '(no title)'}`);
      console.log(`  source=${article.source_id ?? '?'} | category=${categories}`);
      console.log(`  ${article.link ?? ''}`);
    }
  } catch (error) {
    if (error instanceof NewsDataError) {
      console.error(`API error (HTTP ${error.status}): ${error.message}`);
      process.exit(1);
    }
    throw error;
  }
}

void main();
