/**
 * Example 01 — Basic async/await fetch of the latest news.
 *
 * Run: npm run example:latest
 */
import { NewsDataClient, NewsDataError } from '../client.js';

async function main(): Promise<void> {
  const client = new NewsDataClient();

  try {
    const response = await client.getLatestNews({ language: 'en' });

    console.log(`status: ${response.status}`);
    console.log(`totalResults: ${response.totalResults}`);

    if (response.results.length === 0) {
      console.log('No articles returned.');
      return;
    }

    for (const article of response.results.slice(0, 5)) {
      console.log('\n--------------------------------------------');
      console.log(`Title : ${article.title ?? '(no title)'}`);
      console.log(`Source: ${article.source_id ?? '(unknown)'}`);
      console.log(`Date  : ${article.pubDate ?? '(unknown)'}`);
      console.log(`Link  : ${article.link ?? '(no link)'}`);
    }
  } catch (error) {
    if (error instanceof NewsDataError) {
      console.error(`API error (HTTP ${error.status}): ${error.message}`);
      process.exit(1);
    }
    throw error;
  }
}

void main();
