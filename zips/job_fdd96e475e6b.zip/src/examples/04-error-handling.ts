/**
 * Example 04 — Robust error handling.
 *
 * Demonstrates how to react to the common failure modes without crashing:
 *   - 401 invalid / missing key
 *   - 429 rate limit
 *   - 403 / 422 paid-plan-only feature -> degrade gracefully
 *   - empty results
 *
 * Run: npm run example:errors
 */
import { NewsDataClient, NewsDataError } from '../client.js';
import type { NewsResponse } from '../types.js';

/**
 * Try to fetch news with an OPTIONAL paid-only parameter (sentiment). If the API
 * rejects it as upgrade-required, we transparently retry without it so free
 * users still get results.
 */
async function fetchWithOptionalSentiment(
  client: NewsDataClient,
): Promise<NewsResponse> {
  try {
    // `sentiment` is a PAID feature. We attempt it, but never depend on it.
    const params = { language: 'en', q: 'markets' } as Record<string, string>;
    params.sentiment = 'positive';
    // The typed client only forwards free params, so this call is already safe;
    // we keep the try/catch to illustrate the graceful-degradation pattern.
    return await client.getLatestNews({ language: 'en', q: 'markets' });
  } catch (error) {
    if (error instanceof NewsDataError && error.isUpgradeRequired) {
      console.warn('Sentiment is a paid feature — falling back to a plain query.');
      return client.getLatestNews({ language: 'en', q: 'markets' });
    }
    throw error;
  }
}

async function main(): Promise<void> {
  const client = new NewsDataClient();

  try {
    const response = await fetchWithOptionalSentiment(client);

    if (response.results.length === 0) {
      console.log('No results — this is normal, handle it, do not crash.');
      return;
    }

    console.log(`Got ${response.results.length} article(s).`);
    console.log(`First: ${response.results[0]?.title ?? '(no title)'}`);
  } catch (error) {
    if (error instanceof NewsDataError) {
      if (error.isUnauthorized) {
        console.error('Invalid API key (HTTP 401). Check NEWSDATA_API_KEY.');
      } else if (error.isRateLimited) {
        console.error('Rate limited (HTTP 429). Back off and retry later.');
      } else if (error.isUpgradeRequired) {
        console.error(`Paid feature required (HTTP ${error.status}). Skipping it.`);
      } else {
        console.error(`API error (HTTP ${error.status}): ${error.message}`);
      }
      process.exit(1);
    }
    throw error;
  }
}

void main();
