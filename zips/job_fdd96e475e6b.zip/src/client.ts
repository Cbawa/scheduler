/**
 * A tiny, typed client for the newsdata.io REST API.
 *
 * - Reads the API key from the NEWSDATA_API_KEY environment variable.
 * - Targets the FREE tier: only free params are used in the core flow.
 * - Throws a typed NewsDataError so callers can react to 401 / 429 / 403, etc.
 */
import type {
  NewsQueryParams,
  NewsResponse,
  SourcesResponse,
} from './types.js';

const BASE_URL = 'https://newsdata.io/api/1';

/** Error thrown for any non-2xx API response (or transport failure). */
export class NewsDataError extends Error {
  readonly status: number;
  readonly body: unknown;

  constructor(message: string, status: number, body: unknown) {
    super(message);
    this.name = 'NewsDataError';
    this.status = status;
    this.body = body;
  }

  /** True when the API says the feature/endpoint needs a paid plan. */
  get isUpgradeRequired(): boolean {
    return this.status === 403 || this.status === 422;
  }

  get isRateLimited(): boolean {
    return this.status === 429;
  }

  get isUnauthorized(): boolean {
    return this.status === 401;
  }
}

/**
 * Read and validate the API key. Exits the process with a clear message when
 * the NEWSDATA_API_KEY environment variable is not set.
 */
export function getApiKey(): string {
  const key = process.env.NEWSDATA_API_KEY;
  if (!key || key.trim() === '') {
    console.error(
      '\nError: NEWSDATA_API_KEY is not set.\n' +
        'Get a free key at https://newsdata.io/register and export it:\n\n' +
        '  export NEWSDATA_API_KEY="your_key_here"\n',
    );
    process.exit(1);
  }
  return key.trim();
}

export class NewsDataClient {
  private readonly apiKey: string;

  constructor(apiKey: string = getApiKey()) {
    this.apiKey = apiKey;
  }

  /** Build a URL with the apikey and any provided params attached. */
  private buildUrl(path: string, params: Record<string, string | undefined>): string {
    const url = new URL(`${BASE_URL}${path}`);
    url.searchParams.set('apikey', this.apiKey);
    for (const [name, value] of Object.entries(params)) {
      if (value !== undefined && value !== '') {
        url.searchParams.set(name, value);
      }
    }
    return url.toString();
  }

  private async request<T>(
    path: string,
    params: Record<string, string | undefined>,
  ): Promise<T> {
    const url = this.buildUrl(path, params);

    let response: Response;
    try {
      response = await fetch(url);
    } catch (cause) {
      throw new NewsDataError(
        `Network error while requesting ${path}: ${(cause as Error).message}`,
        0,
        null,
      );
    }

    // Try to parse JSON either way so error bodies are surfaced.
    let body: unknown = null;
    try {
      body = await response.json();
    } catch {
      body = null;
    }

    if (!response.ok) {
      const message =
        (body as { results?: { message?: string } })?.results?.message ??
        `Request to ${path} failed with HTTP ${response.status}`;
      throw new NewsDataError(message, response.status, body);
    }

    return body as T;
  }

  /** GET /news — the primary endpoint. */
  async getLatestNews(params: NewsQueryParams = {}): Promise<NewsResponse> {
    return this.request<NewsResponse>('/news', {
      q: params.q,
      country: params.country,
      language: params.language,
      category: params.category,
      page: params.page,
    });
  }

  /** GET /sources — list available news sources. */
  async getSources(
    params: { country?: string; language?: string; category?: string } = {},
  ): Promise<SourcesResponse> {
    return this.request<SourcesResponse>('/sources', {
      country: params.country,
      language: params.language,
      category: params.category,
    });
  }
}
