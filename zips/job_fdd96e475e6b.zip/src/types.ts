/**
 * TypeScript types for the newsdata.io API.
 *
 * Only the fields used across these free-tier examples are modeled here.
 * The real API returns more fields; see https://newsdata.io/documentation
 */

/** Query parameters supported on the free tier for GET /news. */
export interface NewsQueryParams {
  /** Keyword / phrase to search for. */
  q?: string;
  /** Comma-separated 2-letter country codes, e.g. "us,gb". */
  country?: string;
  /** Comma-separated language codes, e.g. "en,es". */
  language?: string;
  /** Comma-separated categories, e.g. "technology,business". */
  category?: string;
  /** Pagination token returned as `nextPage` in a previous response. */
  page?: string;
}

/** A single news article from GET /news. */
export interface Article {
  title: string | null;
  link: string | null;
  description: string | null;
  content?: string | null;
  pubDate: string | null;
  source_id: string | null;
  image_url?: string | null;
  category?: string[] | null;
  country?: string[] | null;
  language?: string | null;
}

/** Response envelope for GET /news. */
export interface NewsResponse {
  status: string;
  totalResults: number;
  results: Article[];
  /** Token for the next page, or null/absent on the last page. */
  nextPage?: string | null;
}

/** A single source from GET /sources. */
export interface Source {
  id: string;
  name: string;
  url?: string | null;
  category?: string[] | null;
  language?: string[] | null;
  country?: string[] | null;
}

/** Response envelope for GET /sources. */
export interface SourcesResponse {
  status: string;
  totalResults?: number;
  results: Source[];
}
