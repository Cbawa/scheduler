# newsdata.io Node.js + TypeScript Examples

A small, copy-pasteable collection of **Node.js + TypeScript** examples for the
[newsdata.io](https://newsdata.io) news API. Each example is runnable on its own and
focuses on one idea: fetching with `async/await`, paginating with `nextPage`,
filtering results, handling errors gracefully, and using strong TypeScript types.

Everything here works on the **FREE plan** — no paid features are required in the core
flow.

## What's inside

| File | Shows |
|------|-------|
| `src/client.ts` | A tiny typed API client wrapping `GET /news` and `GET /sources` |
| `src/types.ts` | TypeScript types for the API request params and response shape |
| `src/examples/01-latest-news.ts` | Basic `async/await` fetch of the latest news |
| `src/examples/02-filtering.ts` | Filter by `q`, `country`, `language`, `category` |
| `src/examples/03-pagination.ts` | Page through results using the `nextPage` token |
| `src/examples/04-error-handling.ts` | Handle 401 / 429 / 403 / empty results without crashing |
| `src/examples/05-sources.ts` | List available news sources |

## Prerequisites

- Node.js 18+ (uses the built-in global `fetch`)
- A free newsdata.io API key — grab one at <https://newsdata.io/register>

## Setup

```bash
git clone https://github.com/your-account/newsdata-node-examples.git
cd newsdata-node-examples
npm install
```

The API key is **never hardcoded** — it is read from the `NEWSDATA_API_KEY`
environment variable. Set it in your shell:

```bash
export NEWSDATA_API_KEY="pub_xxxxxxxxxxxxxxxxxxxxxxxxxxxx"
```

Or copy the example env file and fill it in:

```bash
cp .env.example .env
# then edit .env and put your key there
```

If the variable is unset, every example exits immediately with a clear message.

## Running the examples

With [`tsx`](https://github.com/privatenumber/tsx) (installed as a dev dependency):

```bash
npm run example:latest        # 01-latest-news
npm run example:filter        # 02-filtering
npm run example:paginate      # 03-pagination
npm run example:errors        # 04-error-handling
npm run example:sources       # 05-sources
```

Or run any file directly:

```bash
npx tsx src/examples/01-latest-news.ts
```

Type-check the whole project without emitting:

```bash
npm run typecheck
```

## Free plan vs. paid plan

These examples deliberately stick to what the **free tier** supports:
`q`, `country`, `language`, `category`, and `page` (the `nextPage` token).

The following are **paid-plan only** and are intentionally *not* part of the core
flow. The client detects the `403`/`422` "upgrade your plan" responses and degrades
gracefully instead of crashing:

- Sentiment analysis (`sentiment`)
- AI fields (`ai_tag`, `ai_region`, `ai_org`, `ai_summary`)
- The historical `/archive` endpoint and long date ranges
- Advanced full-text query operators

See the [newsdata.io pricing page](https://newsdata.io/pricing) for details.

## API reference

- Base URL: `https://newsdata.io/api/1`
- Latest news: `GET /news`
- Sources: `GET /sources`
- Auth: pass your key as the `apikey` query parameter.

Full docs: <https://newsdata.io/documentation>

## License

MIT
