# news-agent-langchain

A small command-line assistant that answers questions about current events in plain English. It runs a LangChain tool-calling agent on top of OpenAI's chat models and hands that agent one tool: a search over the newsdata.io news API (https://newsdata.io). Ask something like "What happened in finance this week?" and the agent picks search terms, fetches recent headlines, and writes a short answer with sources.

The headlines come from the newsdata.io REST API, and the whole thing runs on a free API key.

## How it works

1. You type a question.
2. An OpenAI chat model (through LangChain's tool-calling agent) reads it and calls the `search_news` tool when it needs facts.
3. The tool queries newsdata.io's `/latest` endpoint and returns recent articles, including the keyword tags the API attaches to each story.
4. The model summarizes what it found and cites the sources and dates it used.

## Requirements

- Python 3.9 or newer
- An OpenAI API key
- A newsdata.io API key — the free tier is enough; grab one at https://newsdata.io

## Setup

```bash
git clone https://github.com/yourname/news-agent-langchain.git
cd news-agent-langchain
python -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt
```

Provide your keys, either as environment variables or by copying `.env.example` to `.env` and filling it in:

```bash
export NEWSDATA_API_KEY="your-newsdata-key"
export OPENAI_API_KEY="your-openai-key"
```

## Usage

Ask a single question:

```bash
python main.py "What happened in finance this week?"
```

Or start an interactive session:

```bash
python main.py
> what's the latest in technology in the US?
```

### Example

```text
$ python main.py "Any recent news about renewable energy?"

A few recent stories on renewable energy:
- "Solar additions reach a new high this quarter" (reuters, 2026-06-10) -
  utilities are bringing capacity online faster than forecast.
- "Offshore wind project clears final approval" (bbc, 2026-06-09) -
  construction is expected to start next year.
The keyword tags newsdata.io returned (solar, grid, investment) matched the
topic. Links are included with each item above.
```

## Configuration

All configuration is through environment variables (a `.env` file is loaded if present; real environment variables take precedence).

| Variable | Required | Default | Notes |
| --- | --- | --- | --- |
| `NEWSDATA_API_KEY` | yes | — | Free key from newsdata.io |
| `OPENAI_API_KEY` | yes | — | Your OpenAI key |
| `OPENAI_MODEL` | no | `gpt-4o-mini` | Any chat model your key can use |
| `NEWSDATA_PAID` | no | off | Set to `1` if your newsdata.io plan is paid; this lets the client request larger result pages and full article text. On a free key those parameters are skipped automatically, and if the API rejects them the request is retried without them. |
| `VERBOSE` | no | off | Set to `1` to print the agent's tool calls |

### Response fields and plans

newsdata.io returns some fields only on paid plans — per-article `sentiment`, AI tags (`ai_tag`), and an AI summary (`ai_summary`). The tool reads them when they are present and includes them in the article list; on a free key they are simply absent and left out. Keyword tags are part of the free response and are always shown.

## Notes and limits

- The free tier is rate limited. If you get a `429`, wait a moment before trying again. An invalid key returns `401`, which the tool reports clearly.
- The `/latest` endpoint covers roughly the last 48 hours, so questions phrased as "this week" lean toward the most recent end of that window.
- The answer is only as good as the keywords the agent chooses; rephrasing the question often helps.

## License

MIT
