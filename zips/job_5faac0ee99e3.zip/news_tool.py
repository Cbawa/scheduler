"""NewsData.io client and a LangChain tool wrapper.

The client targets the free tier by default: it only sends query parameters a
free API key accepts. Paid-only request parameters are added when paid=True, and
if newsdata.io rejects them the request is retried once on the free path.
"""

from __future__ import annotations

import os
from typing import Optional

import requests
from langchain_core.tools import tool

BASE_URL = "https://newsdata.io/api/1"

# Categories accepted by the /latest endpoint.
VALID_CATEGORIES = {
    "business", "crime", "domestic", "education", "entertainment",
    "environment", "food", "health", "lifestyle", "other", "politics",
    "science", "sports", "technology", "top", "tourism", "world",
}


class NewsDataError(RuntimeError):
    """Raised when a newsdata.io request fails in a way worth reporting."""


class NewsDataClient:
    """Minimal client for the newsdata.io /latest endpoint."""

    def __init__(self, api_key: Optional[str] = None, paid: bool = False, timeout: int = 30):
        self.api_key = api_key or os.environ.get("NEWSDATA_API_KEY")
        if not self.api_key:
            raise NewsDataError(
                "NEWSDATA_API_KEY is not set. Get a free key at https://newsdata.io "
                "and export it before running."
            )
        self.paid = paid
        self.timeout = timeout
        self.session = requests.Session()

    def _send(self, url, params):
        try:
            return self.session.get(url, params=params, timeout=self.timeout)
        except requests.RequestException as exc:
            raise NewsDataError(f"Network error talking to newsdata.io: {exc}") from exc

    def _check_status(self, resp):
        if resp.status_code == 401:
            raise NewsDataError("401 Unauthorized - the newsdata.io API key is invalid.")
        if resp.status_code == 429:
            raise NewsDataError("429 Too Many Requests - rate limit reached; wait and retry.")
        if resp.status_code >= 500:
            raise NewsDataError(f"newsdata.io server error ({resp.status_code}); try again later.")
        if resp.status_code >= 400:
            message = None
            try:
                payload = resp.json()
                results = payload.get("results")
                if isinstance(results, dict):
                    message = results.get("message")
                message = message or payload.get("message")
            except ValueError:
                message = None
            raise NewsDataError(message or f"Request failed ({resp.status_code}).")

    def _get(self, endpoint, params, paid_params=None):
        url = f"{BASE_URL}/{endpoint}"
        base = {k: v for k, v in params.items() if v not in (None, "")}
        base["apikey"] = self.api_key

        send = dict(base)
        used_paid = False
        if self.paid and paid_params:
            extra = {k: v for k, v in paid_params.items() if v not in (None, "")}
            if extra:
                send.update(extra)
                used_paid = True

        resp = self._send(url, send)
        if used_paid and resp.status_code in (403, 422):
            # Paid-only parameters were rejected; retry without them so a free
            # key still gets results.
            resp = self._send(url, base)

        self._check_status(resp)

        try:
            data = resp.json()
        except ValueError as exc:
            raise NewsDataError("newsdata.io returned a non-JSON response.") from exc

        if isinstance(data, dict) and data.get("status") == "error":
            results = data.get("results")
            if isinstance(results, dict):
                detail = results.get("message") or results.get("code") or "unknown error"
            else:
                detail = str(results)
            raise NewsDataError(f"newsdata.io error: {detail}")

        return data

    def latest(self, q=None, category=None, country=None, language="en", max_results=5):
        max_results = max(1, min(int(max_results or 5), 50))
        if category and category.lower() not in VALID_CATEGORIES:
            category = None

        collected = []
        page = None
        pages_fetched = 0
        while len(collected) < max_results and pages_fetched < 5:
            params = {
                "q": q,
                "category": category.lower() if category else None,
                "country": country.lower() if country else None,
                "language": language or "en",
                "page": page,  # nextPage cursor from the previous response
            }
            paid_params = None
            if self.paid:
                # size > 10 and full_content are paid-only; only sent in paid mode.
                paid_params = {"size": min(max_results, 50), "full_content": 1}

            data = self._get("latest", params, paid_params)
            results = data.get("results") or []
            collected.extend(results)
            pages_fetched += 1

            page = data.get("nextPage")
            if not page:
                break

        return collected[:max_results]


def _shorten(text, limit=300):
    text = (text or "").strip()
    if len(text) > limit:
        return text[: limit - 3] + "..."
    return text


def _format_article(article, index):
    title = article.get("title") or "(untitled)"
    source = article.get("source_id") or article.get("source_name") or "unknown source"
    date = article.get("pubDate") or ""
    link = article.get("link") or ""
    description = _shorten(article.get("description"))

    lines = [f"{index}. {title} - {source} ({date})".rstrip()]
    if description:
        lines.append(f"   {description}")
    if link:
        lines.append(f"   Link: {link}")

    keywords = article.get("keywords")
    if isinstance(keywords, list) and keywords:
        lines.append("   Keywords: " + ", ".join(str(k) for k in keywords[:8]))

    # The following fields are returned only on paid newsdata.io plans. They are
    # absent (None) on a free key, so each is shown only when present.
    sentiment = article.get("sentiment")
    if sentiment:
        lines.append(f"   Sentiment: {sentiment}")

    ai_tag = article.get("ai_tag")
    if ai_tag:
        tag = ", ".join(str(t) for t in ai_tag) if isinstance(ai_tag, list) else str(ai_tag)
        lines.append(f"   AI tags: {tag}")

    ai_summary = article.get("ai_summary")
    if ai_summary:
        lines.append(f"   AI summary: {_shorten(ai_summary, 400)}")

    return "\n".join(lines)


def format_articles(articles):
    if not articles:
        return ("No articles matched that query. Try different or broader keywords, "
                "drop the country filter, or ask about a more recent event.")
    return "\n\n".join(_format_article(a, i) for i, a in enumerate(articles, start=1))


def build_news_tool(client):
    """Return a LangChain tool bound to the given NewsDataClient."""

    @tool
    def search_news(query: str = "", category: str = "", country: str = "",
                    language: str = "en", max_articles: int = 5) -> str:
        """Search recent news headlines from the newsdata.io news API.

        Use this whenever the user asks about current events, recent headlines, or
        what is happening now in some topic, country, or category. Call it with
        focused keywords.

        Args:
            query: search keywords, e.g. "interest rates" or "olympics".
            category: optional, one of business, technology, sports, science,
                health, politics, world, entertainment, environment, food, top.
            country: optional 2-letter country code, e.g. "us", "gb", "in".
            language: 2-letter language code, default "en".
            max_articles: how many articles to return (keep it small, 1-10).
        """
        try:
            articles = client.latest(
                q=query or None,
                category=category or None,
                country=country or None,
                language=language or "en",
                max_results=max_articles,
            )
        except NewsDataError as exc:
            return f"Could not fetch news: {exc}"
        return format_articles(articles)

    return search_news
