"""Command-line news agent: a LangChain tool-calling agent over newsdata.io.

Run with a question as arguments for a one-off answer, or with no arguments for
an interactive prompt.
"""

import os
import sys

from dotenv import load_dotenv

from news_tool import NewsDataClient, NewsDataError, build_news_tool

SYSTEM_PROMPT = (
    "You are a concise news assistant. You answer questions about current events "
    "using the search_news tool, which queries the newsdata.io news API. "
    "Decide good search keywords from the user's question and call the tool; do "
    "not rely on prior knowledge for anything time-sensitive. After searching, "
    "write a short, plain answer and cite the sources and dates you used. If the "
    "tool returns keyword tags or sentiment, you may mention them. If no articles "
    "are found, say so and suggest a rephrasing instead of inventing details."
)


def env_flag(name):
    return os.environ.get(name, "").strip().lower() in ("1", "true", "yes", "on")


def build_agent():
    from langchain.agents import AgentExecutor, create_openai_tools_agent
    from langchain_core.prompts import ChatPromptTemplate, MessagesPlaceholder
    from langchain_openai import ChatOpenAI

    client = NewsDataClient(paid=env_flag("NEWSDATA_PAID"))
    news_tool = build_news_tool(client)
    tools = [news_tool]

    model = os.environ.get("OPENAI_MODEL", "gpt-4o-mini")
    llm = ChatOpenAI(model=model, temperature=0)

    prompt = ChatPromptTemplate.from_messages([
        ("system", SYSTEM_PROMPT),
        ("human", "{input}"),
        MessagesPlaceholder("agent_scratchpad"),
    ])

    agent = create_openai_tools_agent(llm, tools, prompt)
    return AgentExecutor(agent=agent, tools=tools, verbose=env_flag("VERBOSE"))


def answer(executor, question):
    try:
        result = executor.invoke({"input": question})
    except Exception as exc:  # keep the REPL alive on transient errors
        print(f"Error: {exc}")
        return
    print("\n" + (result.get("output") or "").strip())


def main():
    load_dotenv()

    missing = [v for v in ("NEWSDATA_API_KEY", "OPENAI_API_KEY") if not os.environ.get(v)]
    if missing:
        print("Missing required environment variable(s): " + ", ".join(missing))
        print("  NEWSDATA_API_KEY - free key from https://newsdata.io")
        print("  OPENAI_API_KEY   - key from https://platform.openai.com")
        sys.exit(1)

    try:
        executor = build_agent()
    except NewsDataError as exc:
        print(str(exc))
        sys.exit(1)

    question = " ".join(sys.argv[1:]).strip()
    if question:
        answer(executor, question)
        return

    print("News agent ready. Ask a question; type 'exit' or Ctrl-C to quit.")
    while True:
        try:
            line = input("\n> ").strip()
        except (EOFError, KeyboardInterrupt):
            print()
            break
        if not line:
            continue
        if line.lower() in ("exit", "quit"):
            break
        answer(executor, line)


if __name__ == "__main__":
    main()
