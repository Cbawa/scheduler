"""Minimal client for the newsdata.io news API.

Just the pieces this project needs: a GET helper with retry/backoff, and a
paginating article fetcher that drops paid-only query params and retries once
when a free key rejects them.
"""
from __future__ import annotations

import os
import time
from typing import Any, Dict, List, Optional

import requests

BASE_URL = "https://newsdata.io/api/1"

# Query params that only work on paid newsdata.io plans. Sending one of these on
# a free key makes the API reject the whole request, so on the default path we
# strip them out before calling.
PAID_QUERY_PARAMS = {
    "sentiment",
    "sentiment_score",
    "tag",
    "region",
    "organization",
    "timeframe",
    "from_date",
    "to_date",
    "full_content",
}


class NewsDataError(RuntimeError):
    """Raised for API errors; carries the HTTP status when there is one."""

    def __init__(self, message: str, status: Optional[int] = None,
                 payload: Optional[dict] = None):
        super().__init__(message)
        self.status = status
        self.payload = payload


class NewsDataClient:
    def __init__(self, api_key: Optional[str] = None, timeout: int = 30):
        self.api_key = api_key or os.environ.get("NEWSDATA_API_KEY")
        if not self.api_key:
            raise NewsDataError(
                "NEWSDATA_API_KEY is not set. Get a free key at "
                "https://newsdata.io and export it before running."
            )
        self.timeout = timeout
        self.session = requests.Session()

    def _get(self, endpoint: str, params: Dict[str, Any]) -> Dict[str, Any]:
        url = BASE_URL + "/" + endpoint.lstrip("/")
        query = {k: v for k, v in params.items() if v not in (None, "")}
        query["apikey"] = self.api_key

        last_error = None
        for attempt in range(4):
            try:
                resp = self.session.get(url, params=query, timeout=self.timeout)
            except requests.RequestException as exc:
                last_error = str(exc)
                time.sleep(1 + attempt)
                continue

            if resp.status_code == 200:
                return resp.json()

            if resp.status_code == 429:
                # Rate limited: back off and retry a few times.
                last_error = "rate limited (429)"
                time.sleep(2 ** attempt)
                continue

            raise NewsDataError(
                _error_message(resp),
                status=resp.status_code,
                payload=_safe_json(resp),
            )

        status = 429 if last_error and "429" in last_error else None
        raise NewsDataError("newsdata.io request failed: " + str(last_error), status=status)

    def fetch_articles(
        self,
        endpoint: str = "latest",
        params: Optional[Dict[str, Any]] = None,
        max_pages: int = 5,
        allow_paid: bool = False,
    ) -> List[dict]:
        """Fetch up to ``max_pages`` pages, following the nextPage cursor."""
        base_params = dict(params or {})
        if not allow_paid:
            base_params = _drop_paid(base_params)

        articles: List[dict] = []
        page = None
        pages_fetched = 0
        used_paid_retry = False

        while pages_fetched < max_pages:
            call = dict(base_params)
            if page:
                call["page"] = page
            try:
                data = self._get(endpoint, call)
            except NewsDataError as exc:
                if (
                    exc.status in (403, 422)
                    and not used_paid_retry
                    and _has_paid(base_params)
                ):
                    # Free key rejected a paid param: drop them and start over.
                    base_params = _drop_paid(base_params)
                    used_paid_retry = True
                    articles, page, pages_fetched = [], None, 0
                    continue
                raise

            results = data.get("results") or []
            articles.extend(results)
            pages_fetched += 1
            page = data.get("nextPage")
            if not page:
                break
        return articles


def _drop_paid(params: Dict[str, Any]) -> Dict[str, Any]:
    return {k: v for k, v in params.items() if k not in PAID_QUERY_PARAMS}


def _has_paid(params: Dict[str, Any]) -> bool:
    return any(k in PAID_QUERY_PARAMS for k in params)


def _safe_json(resp) -> Optional[dict]:
    try:
        return resp.json()
    except ValueError:
        return None


def _error_message(resp) -> str:
    data = _safe_json(resp) or {}
    results = data.get("results")
    if isinstance(results, dict) and results.get("message"):
        return "newsdata.io error %s: %s" % (resp.status_code, results["message"])
    if data.get("message"):
        return "newsdata.io error %s: %s" % (resp.status_code, data["message"])
    return "newsdata.io returned HTTP %s" % resp.status_code
