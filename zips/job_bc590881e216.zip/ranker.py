"""Aggregate newsdata.io articles into a per-source leaderboard."""
from __future__ import annotations

from typing import Dict, List, Optional

import pandas as pd

DEFAULT_WEIGHTS = {"volume": 0.5, "recency": 0.3, "coverage": 0.2}


def articles_to_frame(articles: List[dict]) -> pd.DataFrame:
    rows = []
    for a in articles:
        rows.append(
            {
                "source_id": a.get("source_id") or a.get("source_name") or "unknown",
                "source_name": a.get("source_name") or a.get("source_id") or "Unknown",
                "source_url": a.get("source_url") or "",
                "title": a.get("title") or "",
                "pub_date": a.get("pubDate"),
                "categories": _as_list(a.get("category")),
                "keywords": _as_list(a.get("keywords")),
                # Paid response fields; absent/None on a free key.
                "sentiment": a.get("sentiment"),
                "ai_tag": a.get("ai_tag"),
                "ai_summary": a.get("ai_summary"),
            }
        )
    df = pd.DataFrame(rows)
    if not df.empty:
        df["pub_date"] = pd.to_datetime(df["pub_date"], utc=True, errors="coerce")
    return df


def rank_sources(
    df: pd.DataFrame,
    weights: Optional[Dict[str, float]] = None,
    now: Optional[pd.Timestamp] = None,
) -> pd.DataFrame:
    if df.empty:
        return pd.DataFrame()

    weights = weights or DEFAULT_WEIGHTS
    now = now or pd.Timestamp.now(tz="UTC")

    records = []
    for source_id, group in df.groupby("source_id"):
        topics = set()
        for cats in group["categories"]:
            topics.update(_clean(cats))
        for kws in group["keywords"]:
            topics.update(_clean(kws))

        latest = group["pub_date"].max()
        if pd.notna(latest):
            age_hours = max((now - latest).total_seconds() / 3600.0, 0.0)
        else:
            age_hours = None

        records.append(
            {
                "source_id": source_id,
                "source_name": group["source_name"].iloc[0],
                "source_url": group["source_url"].iloc[0],
                "volume": int(len(group)),
                "topic_coverage": int(len(topics)),
                "age_hours": age_hours,
                "latest_article": latest,
            }
        )

    out = pd.DataFrame(records)

    out["volume_score"] = _minmax(out["volume"])
    out["coverage_score"] = _minmax(out["topic_coverage"])

    ages = out["age_hours"]
    fallback = ages.max() if ages.notna().any() else 0.0
    ages = ages.fillna(fallback)
    out["recency_score"] = _minmax(-ages)  # fresher (smaller age) scores higher

    out["score"] = (
        weights["volume"] * out["volume_score"]
        + weights["recency"] * out["recency_score"]
        + weights["coverage"] * out["coverage_score"]
    ).round(1)

    out = out.sort_values("score", ascending=False).reset_index(drop=True)
    out.insert(0, "rank", out.index + 1)
    return out


def _minmax(series: pd.Series) -> pd.Series:
    s = series.astype(float)
    lo, hi = s.min(), s.max()
    if hi == lo:
        return pd.Series([100.0] * len(s), index=s.index)
    return ((s - lo) / (hi - lo) * 100).round(1)


def _as_list(value) -> list:
    if value is None:
        return []
    if isinstance(value, list):
        return value
    return [value]


def _clean(items) -> list:
    return [str(x).strip().lower() for x in items if x]
