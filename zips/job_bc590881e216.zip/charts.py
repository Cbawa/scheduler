"""Render the source leaderboard to a self-contained HTML report."""
from __future__ import annotations

from typing import List, Tuple

import pandas as pd
import plotly.graph_objects as go
import plotly.io as pio

BAR_COLOR = "#2b6cb0"


def build_report(
    ranking: pd.DataFrame,
    df: pd.DataFrame,
    output_path: str,
    top_n: int = 15,
    header: str = "",
) -> None:
    top = ranking.head(top_n).iloc[::-1]  # reversed so #1 sits at the top

    figs = [
        _score_fig(top),
        _volume_fig(top),
        _recency_coverage_fig(ranking.head(top_n)),
    ]
    sentiment_fig, note = _sentiment_fig(df)
    figs.append(sentiment_fig)

    _write_html(figs, output_path, header, note)


def _score_fig(top: pd.DataFrame) -> go.Figure:
    fig = go.Figure(
        go.Bar(
            x=top["score"],
            y=top["source_name"],
            orientation="h",
            marker_color=BAR_COLOR,
            text=top["score"],
            textposition="auto",
        )
    )
    fig.update_layout(
        title="Composite source score (volume + recency + coverage)",
        xaxis_title="score (0-100)",
        height=max(360, 26 * len(top) + 120),
        margin=dict(l=170, r=30, t=60, b=40),
    )
    return fig


def _volume_fig(top: pd.DataFrame) -> go.Figure:
    fig = go.Figure(
        go.Bar(
            x=top["volume"],
            y=top["source_name"],
            orientation="h",
            marker_color="#38a169",
        )
    )
    fig.update_layout(
        title="Article volume per source",
        xaxis_title="articles in sample",
        height=max(360, 26 * len(top) + 120),
        margin=dict(l=170, r=30, t=60, b=40),
    )
    return fig


def _recency_coverage_fig(rows: pd.DataFrame) -> go.Figure:
    if rows["age_hours"].notna().any():
        ages = rows["age_hours"].fillna(rows["age_hours"].max())
    else:
        ages = rows["age_hours"].fillna(0)
    fig = go.Figure(
        go.Scatter(
            x=ages,
            y=rows["topic_coverage"],
            mode="markers+text",
            text=rows["source_name"],
            textposition="top center",
            marker=dict(
                size=(rows["volume"] * 6 + 8),
                color=rows["score"],
                colorscale="Blues",
                showscale=True,
                colorbar=dict(title="score"),
                line=dict(width=1, color="#333"),
            ),
        )
    )
    fig.update_layout(
        title="Freshness vs topic coverage (bubble size = volume)",
        xaxis_title="hours since latest article (lower = fresher)",
        yaxis_title="distinct topics covered",
        height=520,
        margin=dict(l=60, r=30, t=60, b=50),
    )
    return fig


def _sentiment_fig(df: pd.DataFrame) -> Tuple[go.Figure, str]:
    note = ""
    labels = None
    values = None

    if not df.empty and "sentiment" in df.columns:
        counts = (
            df["sentiment"]
            .dropna()
            .astype(str)
            .str.lower()
            .replace({"": None})
            .dropna()
            .value_counts()
        )
        if not counts.empty:
            labels = counts.index.tolist()
            values = counts.values.tolist()

    if values is None:
        labels = ["positive", "neutral", "negative"]
        values = [34, 48, 18]
        note = (
            "Sample data — live per-article sentiment requires a paid "
            "newsdata.io plan, so the sentiment chart below is illustrative "
            "and not drawn from the API response."
        )

    colors = {"positive": "#38a169", "neutral": "#718096", "negative": "#e53e3e"}
    fig = go.Figure(
        go.Bar(
            x=labels,
            y=values,
            marker_color=[colors.get(l, BAR_COLOR) for l in labels],
        )
    )
    title = "Sentiment breakdown (sample)" if note else "Sentiment breakdown"
    fig.update_layout(
        title=title,
        xaxis_title="sentiment",
        yaxis_title="articles",
        height=380,
        margin=dict(l=60, r=30, t=60, b=40),
    )
    return fig, note


def _write_html(figs: List[go.Figure], path: str, header: str, note: str) -> None:
    head = (
        "<!doctype html><html><head><meta charset='utf-8'>"
        "<title>News source ranking</title>"
        "<style>"
        "body{font-family:system-ui,Segoe UI,Arial,sans-serif;margin:24px;color:#1a202c;}"
        "h1{font-size:22px;margin-bottom:2px;}"
        ".meta{color:#666;font-size:13px;margin-bottom:16px;}"
        ".note{background:#fffbea;border:1px solid #f6e05e;padding:8px 12px;"
        "border-radius:6px;font-size:13px;margin:14px 0;color:#744210;}"
        ".chart{margin:20px 0;border:1px solid #edf2f7;border-radius:8px;padding:6px;}"
        "</style></head><body>"
    )
    blocks = ["<h1>News source ranking</h1>"]
    if header:
        blocks.append("<div class='meta'>" + header + "</div>")
    if note:
        blocks.append("<div class='note'>" + note + "</div>")
    for i, fig in enumerate(figs):
        include = "cdn" if i == 0 else False
        div = pio.to_html(fig, include_plotlyjs=include, full_html=False)
        blocks.append("<div class='chart'>" + div + "</div>")
    html = head + "".join(blocks) + "</body></html>"
    with open(path, "w", encoding="utf-8") as handle:
        handle.write(html)
