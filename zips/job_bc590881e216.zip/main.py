#!/usr/bin/env python3
"""Rank news sources by volume, recency, and topic coverage.

Pulls live headlines from the newsdata.io news API (https://newsdata.io),
groups them by source, scores each source, and writes an HTML report with
leaderboard charts.
"""
from __future__ import annotations

import argparse
import os
import sys

import pandas as pd

from charts import build_report
from newsdata_client import NewsDataClient, NewsDataError
from ranker import articles_to_frame, rank_sources


def parse_args(argv=None):
    p = argparse.ArgumentParser(
        description="Rank news sources from the newsdata.io API."
    )
    p.add_argument("-q", "--query", help="Search term (q parameter).")
    p.add_argument("--country", help="Comma-separated country codes, e.g. us,gb.")
    p.add_argument("--language", help="Comma-separated language codes, e.g. en.")
    p.add_argument("--category", help="Comma-separated categories, e.g. technology.")
    p.add_argument(
        "--pages",
        type=int,
        default=5,
        help="API pages to pull (about 10 articles each). Default: 5.",
    )
    p.add_argument("--top", type=int, default=15, help="Sources to chart. Default: 15.")
    p.add_argument(
        "-o",
        "--output",
        default="source_ranking.html",
        help="Output HTML path. Default: source_ranking.html.",
    )
    p.add_argument(
        "--archive",
        action="store_true",
        help="Use the /archive endpoint (requires a paid newsdata.io plan).",
    )
    p.add_argument("--from-date", help="from_date YYYY-MM-DD (paid, with --archive).")
    p.add_argument("--to-date", help="to_date YYYY-MM-DD (paid, with --archive).")
    return p.parse_args(argv)


def main(argv=None) -> int:
    args = parse_args(argv)

    try:
        client = NewsDataClient()
    except NewsDataError as exc:
        print("error: " + str(exc), file=sys.stderr)
        return 2

    allow_paid = bool(
        args.archive
        or args.from_date
        or args.to_date
        or os.environ.get("ENABLE_PAID")
    )
    endpoint = "archive" if args.archive else "latest"

    params = {
        "q": args.query,
        "country": args.country,
        "language": args.language,
        "category": args.category,
    }
    if args.archive:
        params["from_date"] = args.from_date
        params["to_date"] = args.to_date

    print("Fetching articles from newsdata.io /%s ..." % endpoint)
    try:
        articles = client.fetch_articles(
            endpoint=endpoint,
            params=params,
            max_pages=max(1, args.pages),
            allow_paid=allow_paid,
        )
    except NewsDataError as exc:
        if exc.status == 401:
            print(
                "error: newsdata.io rejected the key (401). Check NEWSDATA_API_KEY.",
                file=sys.stderr,
            )
        elif exc.status == 429:
            print(
                "error: rate limited by newsdata.io (429). Wait and try again.",
                file=sys.stderr,
            )
        else:
            print("error: " + str(exc), file=sys.stderr)
        return 1

    if not articles:
        print(
            "No articles returned. Try a broader query, or drop --country/--category."
        )
        return 0

    df = articles_to_frame(articles)
    ranking = rank_sources(df)

    header = _header(args, len(articles), len(ranking))
    print_leaderboard(ranking, args.top)

    build_report(ranking, df, args.output, top_n=args.top, header=header)
    print("\nSaved report to %s" % args.output)
    return 0


def _header(args, n_articles, n_sources) -> str:
    bits = ["%d articles" % n_articles, "%d sources" % n_sources]
    if args.query:
        bits.append("q=%s" % args.query)
    if args.country:
        bits.append("country=%s" % args.country)
    if args.category:
        bits.append("category=%s" % args.category)
    return " · ".join(bits)


def print_leaderboard(ranking, top_n) -> None:
    if ranking.empty:
        print("No sources to rank.")
        return
    rows = ranking.head(top_n)
    print(
        "\n%-4s %-30s %8s %6s %8s %6s"
        % ("#", "source", "score", "vol", "topics", "age(h)")
    )
    print("-" * 68)
    for _, r in rows.iterrows():
        if r["age_hours"] is None or pd.isna(r["age_hours"]):
            age = "-"
        else:
            age = "%.0f" % r["age_hours"]
        name = (r["source_name"] or "")[:30]
        print(
            "%-4d %-30s %8.1f %6d %8d %6s"
            % (r["rank"], name, r["score"], r["volume"], r["topic_coverage"], age)
        )


if __name__ == "__main__":
    raise SystemExit(main())
