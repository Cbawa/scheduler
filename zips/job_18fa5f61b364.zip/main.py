#!/usr/bin/env python3
"""competitor-news-spy: monitor competitor brand mentions in the news.

Reads brands from the command line or a file, queries the newsdata.io news API
(https://newsdata.io) for each, and prints an aggregated digest. The API key is
read from the NEWSDATA_API_KEY environment variable.
"""
import argparse
import datetime as dt
import os
import sys
from pathlib import Path

from newsdata_client import (
    NewsDataClient,
    AuthError,
    RateLimitError,
    NewsDataError,
)
from digest import build_digest, render_text, render_markdown


def read_brand_file(path):
    p = Path(path)
    if not p.exists():
        raise SystemExit(f"Brand list file not found: {path}")
    brands = []
    for line in p.read_text(encoding="utf-8").splitlines():
        line = line.strip()
        if line and not line.startswith("#"):
            brands.append(line)
    return brands


def gather_brands(args):
    brands = list(args.brand or [])
    if args.file:
        brands.extend(read_brand_file(args.file))
    elif not brands and Path("competitors.txt").exists():
        brands.extend(read_brand_file("competitors.txt"))

    seen = set()
    unique = []
    for b in brands:
        key = b.lower()
        if key not in seen:
            seen.add(key)
            unique.append(b)
    return unique


def build_parser():
    parser = argparse.ArgumentParser(
        prog="competitor-news-spy",
        description="Monitor competitor brand mentions in the news via newsdata.io.",
    )
    parser.add_argument(
        "--brand",
        action="append",
        metavar="NAME",
        help="Brand to track. Repeat for multiple brands.",
    )
    parser.add_argument(
        "--file",
        metavar="PATH",
        help="File with one brand per line (defaults to competitors.txt if present).",
    )
    parser.add_argument(
        "--language", default="en", help="Language code (default: en)."
    )
    parser.add_argument(
        "--country", help="Restrict results to a country code, e.g. us."
    )
    parser.add_argument(
        "--max-pages",
        type=int,
        default=1,
        help="Pages to fetch per brand (~10 articles each; default: 1).",
    )
    parser.add_argument(
        "--top",
        type=int,
        default=10,
        help="How many sources/keywords to show (default: 10).",
    )
    parser.add_argument(
        "--markdown",
        metavar="PATH",
        help="Also write the digest as Markdown to PATH.",
    )
    return parser


def main(argv=None):
    args = build_parser().parse_args(argv)

    api_key = os.environ.get("NEWSDATA_API_KEY")
    if not api_key:
        print("Error: NEWSDATA_API_KEY is not set.", file=sys.stderr)
        print("Get a free key at https://newsdata.io and export it:", file=sys.stderr)
        print("  export NEWSDATA_API_KEY=your_key_here", file=sys.stderr)
        return 2

    brands = gather_brands(args)
    if not brands:
        print(
            "No brands to track. Pass --brand NAME or --file competitors.txt.",
            file=sys.stderr,
        )
        return 2

    extra = {"language": args.language}
    if args.country:
        extra["country"] = args.country

    client = NewsDataClient(api_key, endpoint="latest")
    max_pages = max(1, args.max_pages)

    digests = []
    try:
        for brand in brands:
            query = f'"{brand}"' if " " in brand else brand
            articles = client.search(query, max_pages=max_pages, extra_params=extra)
            digests.append(build_digest(brand, articles, top=args.top))
    except AuthError as exc:
        print(f"Authentication failed: {exc}", file=sys.stderr)
        return 1
    except RateLimitError as exc:
        print(str(exc), file=sys.stderr)
        return 1
    except NewsDataError as exc:
        print(f"newsdata.io request failed: {exc}", file=sys.stderr)
        return 1

    generated_at = dt.datetime.now(dt.timezone.utc).strftime("%Y-%m-%d %H:%M UTC")
    print(render_text(digests, generated_at))

    if args.markdown:
        Path(args.markdown).write_text(
            render_markdown(digests, generated_at), encoding="utf-8"
        )
        print(f"\nMarkdown digest written to {args.markdown}")

    return 0


if __name__ == "__main__":
    raise SystemExit(main())
