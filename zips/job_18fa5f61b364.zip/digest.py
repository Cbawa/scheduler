"""Aggregate newsdata.io articles into per-brand digests and render them."""
from collections import Counter

SENTIMENT_BADGE = {"positive": "[+]", "negative": "[-]", "neutral": "[=]"}
SENTIMENT_ORDER = ("positive", "neutral", "negative")


def _as_list(value):
    if not value:
        return []
    if isinstance(value, list):
        return [v for v in value if v]
    return [value]


def build_digest(brand, articles, top=10):
    sources = Counter()
    keywords = Counter()
    sentiments = Counter()
    ai_tags = Counter()
    headlines = []

    for a in articles:
        source = a.get("source_name") or a.get("source_id") or "unknown"
        sources[source] += 1

        for kw in _as_list(a.get("keywords")):
            keywords[str(kw).strip().lower()] += 1

        sentiment = a.get("sentiment")
        if sentiment:
            sentiments[sentiment] += 1

        for tag in _as_list(a.get("ai_tag")):
            ai_tags[str(tag).strip().lower()] += 1

        headlines.append(
            {
                "title": (a.get("title") or "(untitled)").strip(),
                "source": source,
                "pubDate": a.get("pubDate") or "",
                "link": a.get("link") or "",
                "sentiment": sentiment,
                "ai_summary": (a.get("ai_summary") or "").strip(),
            }
        )

    return {
        "brand": brand,
        "total": len(articles),
        "sources": sources.most_common(top),
        "keywords": keywords.most_common(top),
        "sentiments": dict(sentiments),
        "ai_tags": ai_tags.most_common(top),
        "headlines": headlines,
    }


def _bar(count, total, width=24):
    if total <= 0:
        return ""
    filled = int(round(width * count / total))
    filled = max(0, min(width, filled))
    return "#" * filled + "." * (width - filled)


def render_text(digests, generated_at):
    lines = []
    lines.append("=" * 60)
    lines.append("COMPETITOR NEWS DIGEST")
    lines.append(f"Generated: {generated_at}")
    lines.append("Source: newsdata.io news API (https://newsdata.io)")
    lines.append("=" * 60)

    grand_total = sum(d["total"] for d in digests)
    lines.append(
        f"Tracking {len(digests)} brand(s) — {grand_total} matching article(s)."
    )
    lines.append("")

    for d in digests:
        lines.append("-" * 60)
        lines.append(f"## {d['brand']} — {d['total']} mention(s)")
        lines.append("-" * 60)

        if d["total"] == 0:
            lines.append("  No recent articles found.")
            lines.append("")
            continue

        lines.append("Top sources:")
        for name, cnt in d["sources"]:
            lines.append(f"  {cnt:>3}  {name}")
        lines.append("")

        lines.append("Top keywords:")
        if d["keywords"]:
            for kw, cnt in d["keywords"]:
                lines.append(f"  {cnt:>3}  {kw}")
        else:
            lines.append("  (no keywords returned for these articles)")
        lines.append("")

        lines.append("Sentiment breakdown:")
        sents = d["sentiments"]
        if sents:
            stotal = sum(sents.values())
            for label in SENTIMENT_ORDER:
                cnt = sents.get(label, 0)
                lines.append(f"  {label:<9} {cnt:>3}  {_bar(cnt, stotal)}")
        else:
            lines.append("  sample — live sentiment requires a paid newsdata.io plan")
            for label, cnt in (("positive", 5), ("neutral", 3), ("negative", 2)):
                lines.append(f"  {label:<9} {cnt:>3}  {_bar(cnt, 10)}   (sample)")
        lines.append("")

        if d["ai_tags"]:
            chips = ", ".join(f"{tag} ({cnt})" for tag, cnt in d["ai_tags"])
            lines.append(f"AI tags: {chips}")
        else:
            lines.append("AI tags: (none — requires a paid newsdata.io plan)")
        lines.append("")

        lines.append("Latest headlines:")
        for h in d["headlines"][:10]:
            badge = SENTIMENT_BADGE.get(h["sentiment"], "[?]")
            lines.append(f"  {badge} {h['title']}")
            lines.append(f"      {h['source']} · {h['pubDate']}")
            if h["link"]:
                lines.append(f"      {h['link']}")
            if h["ai_summary"]:
                lines.append(f"      summary: {h['ai_summary']}")
        lines.append("")

    return "\n".join(lines)


def render_markdown(digests, generated_at):
    md_badge = {"positive": "[+]", "negative": "[-]", "neutral": "[=]"}
    out = []
    out.append("# Competitor News Digest")
    out.append("")
    out.append(f"_Generated: {generated_at}_  ")
    out.append("Source: [newsdata.io news API](https://newsdata.io)")
    out.append("")

    grand_total = sum(d["total"] for d in digests)
    out.append(
        f"Tracking **{len(digests)}** brand(s) — **{grand_total}** matching article(s)."
    )
    out.append("")

    for d in digests:
        out.append(f"## {d['brand']} — {d['total']} mention(s)")
        out.append("")
        if d["total"] == 0:
            out.append("_No recent articles found._")
            out.append("")
            continue

        out.append("**Top sources**")
        out.append("")
        out.append("| Source | Mentions |")
        out.append("| --- | ---: |")
        for name, cnt in d["sources"]:
            out.append(f"| {name} | {cnt} |")
        out.append("")

        out.append("**Top keywords**")
        out.append("")
        if d["keywords"]:
            out.append(", ".join(f"`{kw}` ({cnt})" for kw, cnt in d["keywords"]))
        else:
            out.append("_No keywords returned._")
        out.append("")

        out.append("**Sentiment**")
        out.append("")
        sents = d["sentiments"]
        if sents:
            for label in SENTIMENT_ORDER:
                out.append(f"- {label}: {sents.get(label, 0)}")
        else:
            out.append("_Sample shown below — live sentiment requires a paid newsdata.io plan._")
            out.append("")
            out.append("- positive: 5 (sample)")
            out.append("- neutral: 3 (sample)")
            out.append("- negative: 2 (sample)")
        out.append("")

        if d["ai_tags"]:
            out.append(
                "**AI tags:** "
                + ", ".join(f"{tag} ({cnt})" for tag, cnt in d["ai_tags"])
            )
        else:
            out.append("**AI tags:** _none (requires a paid newsdata.io plan)_")
        out.append("")

        out.append("**Latest headlines**")
        out.append("")
        for h in d["headlines"][:10]:
            badge = md_badge.get(h["sentiment"], "[?]")
            if h["link"]:
                out.append(f"- {badge} [{h['title']}]({h['link']}) — {h['source']}")
            else:
                out.append(f"- {badge} {h['title']} — {h['source']}")
        out.append("")

    return "\n".join(out)
