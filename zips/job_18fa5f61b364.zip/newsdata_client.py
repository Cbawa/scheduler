"""Minimal client for the newsdata.io news API (https://newsdata.io).

Only the free-tier-safe `latest` endpoint and parameters are used on the
default path. Paid-only query parameters are stripped and the request is
retried automatically if the server rejects them, so a free API key keeps
working.
"""
import requests

BASE_URL = "https://newsdata.io/api/1"

# Query params that require a paid newsdata.io plan. Sending any of these on a
# free key fails the whole request, so they are removed before a retry.
PAID_QUERY_PARAMS = {
    "sentiment",
    "sentiment_score",
    "tag",
    "region",
    "organization",
    "timeframe",
    "from_date",
    "to_date",
    "full_content",
}


class NewsDataError(Exception):
    """Base error for newsdata.io requests."""


class AuthError(NewsDataError):
    """Raised for an invalid or missing API key."""


class RateLimitError(NewsDataError):
    """Raised when the rate limit is hit (HTTP 429)."""


class PaidPlanError(NewsDataError):
    """Raised when a request is rejected for using a paid-only feature."""


class NewsDataClient:
    def __init__(self, api_key, endpoint="latest", timeout=30, session=None):
        if not api_key:
            raise AuthError("NEWSDATA_API_KEY is not set.")
        self.api_key = api_key
        self.endpoint = endpoint
        self.timeout = timeout
        self.session = session or requests.Session()

    def search(self, query, max_pages=1, extra_params=None):
        """Fetch up to max_pages of results for a query, following nextPage."""
        base = {"q": query, "language": "en"}
        if extra_params:
            base.update(extra_params)

        articles = []
        page = None
        for _ in range(max(1, max_pages)):
            params = dict(base)
            if page:
                params["page"] = page
            data = self._get_with_paid_fallback(params)
            results = data.get("results") or []
            if isinstance(results, list):
                articles.extend(results)
            page = data.get("nextPage")
            if not page:
                break
        return articles

    def _get_with_paid_fallback(self, params):
        try:
            return self._get(params)
        except PaidPlanError:
            stripped = {k: v for k, v in params.items() if k not in PAID_QUERY_PARAMS}
            if len(stripped) == len(params):
                # Nothing paid to strip; surface as a normal error.
                raise NewsDataError(
                    "Request rejected by newsdata.io (paid feature required)."
                )
            return self._get(stripped)

    def _get(self, params):
        url = f"{BASE_URL}/{self.endpoint}"
        headers = {"X-ACCESS-KEY": self.api_key}
        try:
            resp = self.session.get(
                url, params=params, headers=headers, timeout=self.timeout
            )
        except requests.RequestException as exc:
            raise NewsDataError(f"Network error contacting newsdata.io: {exc}") from exc

        if resp.status_code == 401:
            raise AuthError("Invalid API key (HTTP 401). Check NEWSDATA_API_KEY.")
        if resp.status_code == 429:
            raise RateLimitError(
                "Rate limit reached (HTTP 429). Wait a moment and try again."
            )
        if resp.status_code in (403, 422):
            raise PaidPlanError(self._error_message(resp))
        if resp.status_code >= 400:
            raise NewsDataError(f"HTTP {resp.status_code}: {self._error_message(resp)}")

        try:
            data = resp.json()
        except ValueError as exc:
            raise NewsDataError("newsdata.io returned a non-JSON response.") from exc

        if isinstance(data, dict) and data.get("status") == "error":
            raise NewsDataError(self._error_message(resp, data))
        return data

    @staticmethod
    def _error_message(resp, data=None):
        if data is None:
            try:
                data = resp.json()
            except ValueError:
                text = (resp.text or "").strip()
                return text[:200] if text else f"HTTP {resp.status_code}"
        if isinstance(data, dict):
            results = data.get("results")
            if isinstance(results, dict):
                msg = results.get("message") or results.get("code")
                if msg:
                    return str(msg)
            if data.get("message"):
                return str(data["message"])
        return f"HTTP {resp.status_code}"
