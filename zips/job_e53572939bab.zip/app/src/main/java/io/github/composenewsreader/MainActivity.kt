package io.github.composenewsreader

import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalUriHandler
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.ViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.lifecycle.viewmodel.initializer
import androidx.lifecycle.viewmodel.viewModelFactory
import coil.compose.AsyncImage
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Locale
import java.util.TimeZone

// ---------------------------------------------------------------------------
// State
// ---------------------------------------------------------------------------

data class NewsUiState(
    val articles: List<Article> = emptyList(),
    val query: String = "",
    val category: String? = null,
    val isLoading: Boolean = false,
    val isLoadingMore: Boolean = false,
    val nextPage: String? = null,
    val totalResults: Int = 0,
    val error: NewsError? = null,
    val paidMode: Boolean = false,
) {
    val canLoadMore: Boolean
        get() = nextPage != null && !isLoading && !isLoadingMore && error == null

    /** Counts of the paid-only `sentiment` field across what is currently loaded. */
    val sentimentCounts: Map<String, Int>
        get() = articles.mapNotNull { it.sentiment }.groupingBy { it }.eachCount()

    val aiTaggedCount: Int get() = articles.count { it.aiTags.isNotEmpty() }
    val aiSummaryCount: Int get() = articles.count { !it.aiSummary.isNullOrBlank() }
}

sealed interface NewsEvent {
    data class QueryChanged(val value: String) : NewsEvent
    data object Search : NewsEvent
    data class CategorySelected(val value: String?) : NewsEvent
    data object Refresh : NewsEvent
    data object LoadMore : NewsEvent
}

val CATEGORIES = listOf(
    "top", "world", "business", "technology", "science",
    "health", "sports", "entertainment", "politics", "environment",
)

// ---------------------------------------------------------------------------
// ViewModel — the only place that talks to NewsDataClient
// ---------------------------------------------------------------------------

class NewsViewModel(
    private val client: NewsDataClient,
    paidMode: Boolean,
) : ViewModel() {

    private val _state = MutableStateFlow(NewsUiState(paidMode = paidMode))
    val state: StateFlow<NewsUiState> = _state.asStateFlow()

    private var loadJob: Job? = null

    init {
        load(reset = true)
    }

    fun onEvent(event: NewsEvent) {
        when (event) {
            is NewsEvent.QueryChanged -> _state.update { it.copy(query = event.value) }
            is NewsEvent.Search -> load(reset = true)
            is NewsEvent.CategorySelected -> {
                _state.update { it.copy(category = event.value) }
                load(reset = true)
            }
            is NewsEvent.Refresh -> load(reset = true)
            is NewsEvent.LoadMore -> load(reset = false)
        }
    }

    private fun load(reset: Boolean) {
        val current = _state.value
        if (reset) {
            loadJob?.cancel()
        } else if (current.isLoadingMore || current.isLoading || current.nextPage == null) {
            return
        }

        _state.update {
            it.copy(
                isLoading = reset,
                isLoadingMore = !reset,
                error = if (reset) null else it.error,
            )
        }

        loadJob = viewModelScope.launch {
            val snapshot = _state.value
            val result = client.latest(
                query = snapshot.query.trim().ifBlank { null },
                category = snapshot.category,
                page = if (reset) null else snapshot.nextPage,
            )

            when (result) {
                is NewsResult.Success -> _state.update { previous ->
                    val merged = if (reset) {
                        result.page.articles
                    } else {
                        (previous.articles + result.page.articles).distinctBy(Article::id)
                    }
                    previous.copy(
                        articles = merged,
                        nextPage = result.page.nextPage,
                        totalResults = result.page.totalResults,
                        isLoading = false,
                        isLoadingMore = false,
                        error = null,
                    )
                }

                is NewsResult.Failure -> _state.update {
                    it.copy(
                        articles = if (reset) emptyList() else it.articles,
                        isLoading = false,
                        isLoadingMore = false,
                        error = result.error,
                    )
                }
            }
        }
    }

    companion object {
        val Factory = viewModelFactory {
            initializer {
                NewsViewModel(
                    client = NewsDataClient(
                        apiKey = BuildConfig.NEWSDATA_API_KEY,
                        paidMode = BuildConfig.NEWSDATA_PAID_MODE,
                    ),
                    paidMode = BuildConfig.NEWSDATA_PAID_MODE,
                )
            }
        }
    }
}

// ---------------------------------------------------------------------------
// Activity + theme
// ---------------------------------------------------------------------------

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            HeadlinesTheme {
                val viewModel: NewsViewModel = viewModel(factory = NewsViewModel.Factory)
                val state by viewModel.state.collectAsStateWithLifecycle()
                NewsScreen(state = state, onEvent = viewModel::onEvent)
            }
        }
    }
}

private val LightColors = lightColorScheme(
    primary = Color(0xFF2A5DB0),
    secondary = Color(0xFF52618C),
    tertiary = Color(0xFF1F6B52),
    background = Color(0xFFFBFAFD),
)

private val DarkColors = darkColorScheme(
    primary = Color(0xFFAEC6FF),
    secondary = Color(0xFFBAC6EA),
    tertiary = Color(0xFF8ED6B6),
    background = Color(0xFF11131A),
)

@Composable
fun HeadlinesTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    dynamicColor: Boolean = true,
    content: @Composable () -> Unit,
) {
    val context = LocalContext.current
    val colorScheme = when {
        dynamicColor && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S ->
            if (darkTheme) dynamicDarkColorScheme(context) else dynamicLightColorScheme(context)
        darkTheme -> DarkColors
        else -> LightColors
    }
    MaterialTheme(colorScheme = colorScheme, content = content)
}

// ---------------------------------------------------------------------------
// UI — stateless, driven by NewsUiState + onEvent
// ---------------------------------------------------------------------------

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun NewsScreen(state: NewsUiState, onEvent: (NewsEvent) -> Unit) {
    val listState = rememberLazyListState()
    val uriHandler = LocalUriHandler.current

    val nearEnd by remember {
        derivedStateOf {
            val info = listState.layoutInfo
            val last = info.visibleItemsInfo.lastOrNull()?.index ?: -1
            info.totalItemsCount > 0 && last >= info.totalItemsCount - 3
        }
    }

    LaunchedEffect(nearEnd, state.canLoadMore) {
        if (nearEnd && state.canLoadMore) onEvent(NewsEvent.LoadMore)
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text("Headlines", fontWeight = FontWeight.SemiBold)
                        val loaded = state.articles.size
                        if (loaded > 0) {
                            Text(
                                text = "$loaded loaded" +
                                    if (state.totalResults > loaded) " of ${state.totalResults}" else "",
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                            )
                        }
                    }
                },
                actions = {
                    IconButton(onClick = { onEvent(NewsEvent.Refresh) }) {
                        Icon(Icons.Filled.Refresh, contentDescription = "Refresh")
                    }
                },
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .padding(padding)
                .fillMaxSize()
        ) {
            SearchField(
                query = state.query,
                onQueryChange = { onEvent(NewsEvent.QueryChanged(it)) },
                onSearch = { onEvent(NewsEvent.Search) },
            )
            CategoryRow(
                selected = state.category,
                onSelect = { onEvent(NewsEvent.CategorySelected(it)) },
            )

            when {
                state.isLoading && state.articles.isEmpty() -> CenteredBox {
                    CircularProgressIndicator()
                }

                state.articles.isEmpty() && state.error != null -> ErrorState(
                    error = state.error,
                    onRetry = { onEvent(NewsEvent.Refresh) },
                )

                state.articles.isEmpty() -> CenteredBox {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("Nothing came back", style = MaterialTheme.typography.titleMedium)
                        Spacer(Modifier.height(6.dp))
                        Text(
                            "The API returned an empty result set for this filter. Try another " +
                                "category or a different search term.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    }
                }

                else -> LazyColumn(
                    state = listState,
                    contentPadding = androidx.compose.foundation.layout.PaddingValues(
                        start = 16.dp, end = 16.dp, top = 8.dp, bottom = 24.dp
                    ),
                    verticalArrangement = Arrangement.spacedBy(12.dp),
                    modifier = Modifier.fillMaxSize(),
                ) {
                    item { SentimentCard(state) }

                    state.error?.let { error ->
                        item {
                            Surface(
                                color = MaterialTheme.colorScheme.errorContainer,
                                contentColor = MaterialTheme.colorScheme.onErrorContainer,
                                shape = RoundedCornerShape(12.dp),
                                modifier = Modifier.fillMaxWidth(),
                            ) {
                                Text(
                                    error.message,
                                    modifier = Modifier.padding(12.dp),
                                    style = MaterialTheme.typography.bodySmall,
                                )
                            }
                        }
                    }

                    itemsIndexed(
                        items = state.articles,
                        key = { index, article -> "$index-${article.id}" },
                    ) { _, article ->
                        ArticleCard(article) {
                            article.link?.let { link -> runCatching { uriHandler.openUri(link) } }
                        }
                    }

                    if (state.isLoadingMore) {
                        item {
                            Box(Modifier.fillMaxWidth().padding(16.dp), Alignment.Center) {
                                CircularProgressIndicator(Modifier.size(24.dp), strokeWidth = 2.dp)
                            }
                        }
                    } else if (state.nextPage == null) {
                        item {
                            Text(
                                "End of results — the nextPage cursor came back null.",
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                modifier = Modifier.fillMaxWidth().padding(12.dp),
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun SearchField(query: String, onQueryChange: (String) -> Unit, onSearch: () -> Unit) {
    OutlinedTextField(
        value = query,
        onValueChange = onQueryChange,
        singleLine = true,
        placeholder = { Text("Search headlines") },
        trailingIcon = {
            IconButton(onClick = onSearch) {
                Icon(Icons.Filled.Search, contentDescription = "Search")
            }
        },
        keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
        keyboardActions = KeyboardActions(onSearch = { onSearch() }),
        shape = RoundedCornerShape(14.dp),
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 4.dp),
    )
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun CategoryRow(selected: String?, onSelect: (String?) -> Unit) {
    Row(
        horizontalArrangement = Arrangement.spacedBy(8.dp),
        modifier = Modifier
            .fillMaxWidth()
            .horizontalScroll(rememberScrollState())
            .padding(horizontal = 16.dp, vertical = 4.dp),
    ) {
        FilterChip(
            selected = selected == null,
            onClick = { onSelect(null) },
            label = { Text("All") },
        )
        CATEGORIES.forEach { category ->
            FilterChip(
                selected = selected == category,
                onClick = { onSelect(if (selected == category) null else category) },
                label = { Text(category.replaceFirstChar { it.uppercase() }) },
            )
        }
    }
}

/**
 * Sentiment mix over the loaded page.
 *
 * `sentiment` is a paid-plan response field. When it is absent the card still
 * renders, using clearly labelled sample numbers, so the layout does not
 * collapse into a blank strip and the capability stays visible.
 */
@Composable
private fun SentimentCard(state: NewsUiState) {
    val live = state.sentimentCounts
    val isSample = live.isEmpty()

    val slices = if (isSample) {
        listOf("positive" to 4, "neutral" to 11, "negative" to 5)
    } else {
        listOf(
            "positive" to (live["positive"] ?: 0),
            "neutral" to (live["neutral"] ?: 0),
            "negative" to (live["negative"] ?: 0),
        )
    }
    val total = slices.sumOf { it.second }.coerceAtLeast(1)

    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
        ),
    ) {
        Column(Modifier.padding(14.dp)) {
            Text("Sentiment mix", style = MaterialTheme.typography.titleSmall)
            Spacer(Modifier.height(10.dp))

            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(14.dp)
                    .clip(RoundedCornerShape(7.dp))
                    .background(MaterialTheme.colorScheme.surfaceVariant)
            ) {
                slices.forEach { (label, count) ->
                    if (count > 0) {
                        Box(
                            Modifier
                                .weight(count.toFloat())
                                .fillMaxHeight()
                                .background(sentimentColor(label))
                        )
                    }
                }
            }

            Spacer(Modifier.height(8.dp))
            Text(
                slices.joinToString("  ·  ") { "${it.first} ${it.second}" },
                style = MaterialTheme.typography.labelMedium,
            )

            Spacer(Modifier.height(6.dp))
            Text(
                text = if (isSample) {
                    "sample — live sentiment requires a newsdata.io plan that includes the " +
                        "sentiment field"
                } else {
                    "based on ${total} of ${state.articles.size} loaded articles"
                },
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )

            Spacer(Modifier.height(10.dp))
            val loaded = state.articles.size.coerceAtLeast(1)
            Text(
                text = "AI tags ${state.aiTaggedCount}/$loaded  ·  " +
                    "summaries ${state.aiSummaryCount}/$loaded" +
                    if (state.aiTaggedCount == 0 && state.aiSummaryCount == 0) {
                        "  — ai_tag and ai_summary populate on plans that return them"
                    } else "",
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            if (state.paidMode) {
                Spacer(Modifier.height(4.dp))
                Text(
                    "paid mode on — requests include full_content and timeframe",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
        }
    }
}

@Composable
private fun ArticleCard(article: Article, onClick: () -> Unit) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
    ) {
        Column(Modifier.padding(14.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                if (!article.imageUrl.isNullOrBlank()) {
                    AsyncImage(
                        model = article.imageUrl,
                        contentDescription = null,
                        contentScale = ContentScale.Crop,
                        modifier = Modifier
                            .size(52.dp)
                            .clip(RoundedCornerShape(10.dp)),
                    )
                    Spacer(Modifier.width(10.dp))
                }
                Column(Modifier.weight(1f)) {
                    Text(
                        article.sourceName ?: "Unknown source",
                        style = MaterialTheme.typography.labelMedium,
                        color = MaterialTheme.colorScheme.primary,
                    )
                    relativeTime(article.pubDate)?.let {
                        Text(
                            it,
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    }
                }
                article.sentiment?.let { sentiment ->
                    Pill(
                        text = sentiment,
                        container = sentimentColor(sentiment).copy(alpha = 0.16f),
                        content = sentimentColor(sentiment),
                    )
                }
            }

            Spacer(Modifier.height(10.dp))
            Text(
                article.title,
                style = MaterialTheme.typography.titleMedium,
                maxLines = 3,
                overflow = TextOverflow.Ellipsis,
            )

            article.description?.let {
                Spacer(Modifier.height(6.dp))
                Text(
                    it,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    maxLines = 3,
                    overflow = TextOverflow.Ellipsis,
                )
            }

            article.aiSummary?.let {
                Spacer(Modifier.height(8.dp))
                Surface(
                    color = MaterialTheme.colorScheme.secondaryContainer,
                    contentColor = MaterialTheme.colorScheme.onSecondaryContainer,
                    shape = RoundedCornerShape(10.dp),
                ) {
                    Column(Modifier.padding(10.dp)) {
                        Text("AI summary", style = MaterialTheme.typography.labelSmall)
                        Spacer(Modifier.height(2.dp))
                        Text(
                            it,
                            style = MaterialTheme.typography.bodySmall,
                            maxLines = 4,
                            overflow = TextOverflow.Ellipsis,
                        )
                    }
                }
            }

            val chips = article.aiTags + article.keywords
            if (chips.isNotEmpty()) {
                Spacer(Modifier.height(10.dp))
                Row(
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState()),
                ) {
                    article.aiTags.forEach {
                        Pill(
                            text = it,
                            container = MaterialTheme.colorScheme.tertiaryContainer,
                            content = MaterialTheme.colorScheme.onTertiaryContainer,
                        )
                    }
                    article.keywords.forEach {
                        Pill(
                            text = "#" + it,
                            container = MaterialTheme.colorScheme.surfaceVariant,
                            content = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun ErrorState(error: NewsError, onRetry: () -> Unit) {
    CenteredBox {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text(
                when (error) {
                    is NewsError.MissingKey -> "No API key"
                    is NewsError.InvalidKey -> "Key rejected"
                    is NewsError.RateLimited -> "Rate limited"
                    else -> "Could not load headlines"
                },
                style = MaterialTheme.typography.titleMedium,
            )
            Spacer(Modifier.height(8.dp))
            Text(
                error.message,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            if (error !is NewsError.MissingKey) {
                Spacer(Modifier.height(16.dp))
                Button(onClick = onRetry) { Text("Try again") }
            }
        }
    }
}

@Composable
private fun CenteredBox(content: @Composable () -> Unit) {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .padding(24.dp),
        contentAlignment = Alignment.Center,
    ) { content() }
}

@Composable
private fun Pill(text: String, container: Color, content: Color) {
    Surface(color = container, contentColor = content, shape = RoundedCornerShape(8.dp)) {
        Text(
            text,
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
            style = MaterialTheme.typography.labelSmall,
            maxLines = 1,
        )
    }
}

@Composable
private fun sentimentColor(label: String): Color = when (label.lowercase()) {
    "positive" -> MaterialTheme.colorScheme.tertiary
    "negative" -> MaterialTheme.colorScheme.error
    else -> MaterialTheme.colorScheme.primary
}

/** pubDate arrives as "yyyy-MM-dd HH:mm:ss" in UTC. */
private fun relativeTime(pubDate: String?): String? {
    if (pubDate.isNullOrBlank()) return null
    val parser = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US).apply {
        timeZone = TimeZone.getTimeZone("UTC")
    }
    val parsed = runCatching { parser.parse(pubDate) }.getOrNull() ?: return pubDate
    val minutes = (System.currentTimeMillis() - parsed.time) / 60_000L
    return when {
        minutes < 0L -> pubDate
        minutes < 1L -> "just now"
        minutes < 60L -> "${minutes}m ago"
        minutes < 1_440L -> "${minutes / 60L}h ago"
        minutes < 10_080L -> "${minutes / 1_440L}d ago"
        else -> pubDate.substringBefore(' ')
    }
}
