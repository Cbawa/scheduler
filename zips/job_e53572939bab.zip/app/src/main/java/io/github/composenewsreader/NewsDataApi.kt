package io.github.composenewsreader

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.JsonArray
import kotlinx.serialization.json.JsonElement
import kotlinx.serialization.json.JsonNull
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.JsonPrimitive
import okhttp3.HttpUrl
import okhttp3.OkHttpClient
import okhttp3.Request
import java.io.IOException
import java.util.concurrent.TimeUnit

/**
 * Networking layer for the newsdata.io news API (https://newsdata.io).
 *
 * Only the free-tier-safe query parameters are sent on the default path:
 * language, q, category and the nextPage cursor. Paid-only parameters
 * (timeframe, full_content, from_date/to_date, sentiment, tag, size > 10 ...)
 * are sent only when paid mode is switched on, and a rejection falls back to
 * a plain request so the user still sees articles.
 *
 * Paid-only RESPONSE fields (sentiment, sentiment_stats, ai_tag, ai_region,
 * ai_org, ai_summary) are always read if present. On a free key they arrive
 * either missing or as the placeholder string below, which is treated as absent.
 */
private const val PLAN_PLACEHOLDER = "ONLY AVAILABLE IN"

private val json = Json {
    ignoreUnknownKeys = true
    isLenient = true
}

data class SentimentStats(
    val positive: Double,
    val neutral: Double,
    val negative: Double,
)

data class Article(
    val id: String,
    val title: String,
    val link: String?,
    val description: String?,
    val imageUrl: String?,
    val sourceName: String?,
    val pubDate: String?,
    val keywords: List<String>,
    val categories: List<String>,
    // paid-plan fields; null / empty on a free key
    val sentiment: String?,
    val sentimentStats: SentimentStats?,
    val aiTags: List<String>,
    val aiRegions: List<String>,
    val aiOrgs: List<String>,
    val aiSummary: String?,
)

data class NewsPage(
    val articles: List<Article>,
    val nextPage: String?,
    val totalResults: Int,
)

sealed class NewsError(val message: String) {
    data object MissingKey : NewsError(
        "No API key found. Set NEWSDATA_API_KEY in your environment or local.properties, then rebuild."
    )

    data object InvalidKey : NewsError(
        "newsdata.io rejected the API key (HTTP 401). Check the key you built with."
    )

    data object RateLimited : NewsError(
        "Rate limit reached (HTTP 429). The free plan allows a limited number of requests " +
            "per 15 minutes — wait a moment and pull refresh."
    )

    class PaidFeature(detail: String) : NewsError(
        "The request used a parameter this plan does not include: " + detail
    )

    class Server(code: Int, detail: String) : NewsError("newsdata.io returned HTTP $code: $detail")

    class Network(detail: String) : NewsError("Could not reach newsdata.io: $detail")
}

sealed interface NewsResult {
    data class Success(val page: NewsPage) : NewsResult
    data class Failure(val error: NewsError) : NewsResult
}

class NewsDataClient(
    private val apiKey: String,
    private val paidMode: Boolean = false,
    private val http: OkHttpClient = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(20, TimeUnit.SECONDS)
        .build(),
) {

    /** GET /1/latest. [page] is the nextPage cursor from a previous response, or null. */
    suspend fun latest(
        query: String? = null,
        category: String? = null,
        language: String = "en",
        page: String? = null,
    ): NewsResult = withContext(Dispatchers.IO) {
        if (apiKey.isBlank()) return@withContext NewsResult.Failure(NewsError.MissingKey)

        val first = fetch(query, category, language, page, withPaidParams = paidMode)
        if (paidMode && first is NewsResult.Failure && first.error is NewsError.PaidFeature) {
            // The key does not carry the entitlement — retry once without the paid params.
            fetch(query, category, language, page, withPaidParams = false)
        } else {
            first
        }
    }

    private fun fetch(
        query: String?,
        category: String?,
        language: String,
        page: String?,
        withPaidParams: Boolean,
    ): NewsResult {
        val url = buildUrl(query, category, language, page, withPaidParams)
        val request = Request.Builder()
            .url(url)
            .header("X-ACCESS-KEY", apiKey)
            .header("Accept", "application/json")
            .get()
            .build()

        return try {
            http.newCall(request).execute().use { response ->
                val body = response.body?.string().orEmpty()
                if (response.isSuccessful) {
                    parsePage(body)
                } else {
                    NewsResult.Failure(errorFor(response.code, body))
                }
            }
        } catch (e: IOException) {
            NewsResult.Failure(NewsError.Network(e.message ?: "connection failed"))
        }
    }

    private fun buildUrl(
        query: String?,
        category: String?,
        language: String,
        page: String?,
        withPaidParams: Boolean,
    ): HttpUrl {
        val builder = HttpUrl.Builder()
            .scheme("https")
            .host("newsdata.io")
            .addPathSegments("api/1/latest")
            .addQueryParameter("language", language)

        query?.trim()?.takeIf { it.isNotEmpty() }?.let { builder.addQueryParameter("q", it) }
        category?.takeIf { it.isNotBlank() }?.let { builder.addQueryParameter("category", it) }
        page?.takeIf { it.isNotBlank() }?.let { builder.addQueryParameter("page", it) }

        if (withPaidParams) {
            // Paid-plan query params. A free key answers 403/422 here, which the
            // caller turns into a single retry without them.
            builder.addQueryParameter("full_content", "1")
            builder.addQueryParameter("timeframe", "24")
        }

        return builder.build()
    }

    private fun parsePage(body: String): NewsResult {
        val root = runCatching { json.parseToJsonElement(body) as? JsonObject }.getOrNull()
            ?: return NewsResult.Failure(NewsError.Server(200, "response was not JSON"))

        if (root["status"].text().equals("error", ignoreCase = true)) {
            return NewsResult.Failure(NewsError.Server(200, messageOf(root)))
        }

        val results = root["results"] as? JsonArray
        val articles = results?.mapNotNull { it.toArticle() }.orEmpty()

        return NewsResult.Success(
            NewsPage(
                articles = articles,
                nextPage = root["nextPage"].text(),
                totalResults = root["totalResults"].int() ?: articles.size,
            )
        )
    }

    private fun errorFor(code: Int, body: String): NewsError {
        val detail = runCatching {
            messageOf(json.parseToJsonElement(body) as JsonObject)
        }.getOrNull() ?: "no detail returned"

        return when (code) {
            401 -> NewsError.InvalidKey
            429 -> NewsError.RateLimited
            403, 422 -> NewsError.PaidFeature(detail)
            else -> NewsError.Server(code, detail)
        }
    }

    private fun messageOf(root: JsonObject): String {
        (root["results"] as? JsonObject)?.let { results ->
            results["message"].text()?.let { return it }
        }
        return root["message"].text() ?: "unspecified error"
    }
}

// ---------------------------------------------------------------------------
// Tolerant JSON readers.
//
// newsdata.io returns some fields as either a string or an array of strings
// (ai_tag, country, category), and paid-only fields come back on free keys as
// the literal string "ONLY AVAILABLE IN ... PLANS". Everything below folds
// those shapes into plain Kotlin types, or null.
// ---------------------------------------------------------------------------

private fun JsonElement?.text(): String? {
    if (this == null || this is JsonNull) return null
    val primitive = this as? JsonPrimitive ?: return null
    val value = primitive.content.trim()
    if (value.isEmpty() || value.equals("null", ignoreCase = true)) return null
    if (value.uppercase().startsWith(PLAN_PLACEHOLDER)) return null
    return value
}

private fun JsonElement?.texts(): List<String> = when {
    this == null || this is JsonNull -> emptyList()
    this is JsonArray -> mapNotNull { it.text() }
    else -> listOfNotNull(text())
}

private fun JsonElement?.int(): Int? = text()?.toDoubleOrNull()?.toInt()

private fun JsonElement?.number(): Double? = text()?.toDoubleOrNull()

private fun JsonElement.toArticle(): Article? {
    val obj = this as? JsonObject ?: return null
    val title = obj["title"].text() ?: return null
    val link = obj["link"].text()

    return Article(
        id = obj["article_id"].text() ?: link ?: title.hashCode().toString(),
        title = title,
        link = link,
        description = obj["description"].text(),
        imageUrl = obj["image_url"].text(),
        sourceName = obj["source_name"].text() ?: obj["source_id"].text(),
        pubDate = obj["pubDate"].text(),
        keywords = obj["keywords"].texts().take(6),
        categories = obj["category"].texts(),
        sentiment = obj["sentiment"].text()?.lowercase(),
        sentimentStats = obj["sentiment_stats"].toSentimentStats(),
        aiTags = obj["ai_tag"].texts().take(6),
        aiRegions = obj["ai_region"].texts().take(4),
        aiOrgs = obj["ai_org"].texts().take(4),
        aiSummary = obj["ai_summary"].text(),
    )
}

private fun JsonElement?.toSentimentStats(): SentimentStats? {
    if (this == null || this is JsonNull) return null

    val obj = this as? JsonObject
        ?: text()?.let { raw ->
            runCatching { json.parseToJsonElement(raw) as? JsonObject }.getOrNull()
        }
        ?: return null

    val positive = obj["positive"].number() ?: return null
    val neutral = obj["neutral"].number() ?: return null
    val negative = obj["negative"].number() ?: return null
    return SentimentStats(positive, neutral, negative)
}
