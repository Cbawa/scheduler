# Headlines — a Compose news reader

A single-Activity Android app that lists live news headlines. Everything on screen is
Jetpack Compose: no XML layouts, no fragments, no `findViewById`. Headlines come from the
newsdata.io news API (https://newsdata.io) — a free API key is enough to run the whole app.

I wrote this while porting an older XML-layout reader to Compose and wanted a small
reference I could actually read in one sitting, so it is deliberately plain: one file for
the HTTP layer, one file for state + UI, no DI framework, no Room, no navigation library.

## What it does

- Latest headlines from `/1/latest`, with search (`q`) and category filters.
- Endless scrolling using the API's `nextPage` cursor — the cursor is stored in the
  ViewModel state and passed back as `page`; scrolling stops when it comes back `null`.
- Material 3 with dynamic color on Android 12+, a hand-picked fallback palette below that,
  and dark mode following the system setting.
- Keyword chips per article (the `keywords` field, present on every plan).
- A sentiment mix bar over the loaded page, plus per-article sentiment badges.
- An "enrichment" line showing how many of the loaded articles carry `ai_tag` /
  `ai_summary`, so it is obvious whether those fields are coming back populated.
- Explicit handling for a missing key, HTTP 401, HTTP 429 and an empty `results` array —
  each one gets its own screen instead of an empty list.

State is hoisted: `NewsScreen` is a stateless composable taking `NewsUiState` and a
`(NewsEvent) -> Unit`. The ViewModel owns a single `StateFlow<NewsUiState>` and is the only
thing that talks to `NewsDataClient`. That makes the composables previewable without a
network stack.

## Requirements

- Android Studio Koala (or newer) / Gradle 8.7+, JDK 17
- Android SDK 34, minSdk 24
- A newsdata.io API key — https://newsdata.io, the free tier works

## Setup

Clone, then supply the key. Gradle reads it at build time and puts it into `BuildConfig`;
it is never checked in.

Either export it:

```bash
export NEWSDATA_API_KEY=pub_xxxxxxxxxxxxxxxxxxxxxxxx
```

or add it to `local.properties` (already gitignored), which is easier when you launch from
the IDE and the IDE does not inherit your shell environment:

```properties
NEWSDATA_API_KEY=pub_xxxxxxxxxxxxxxxxxxxxxxxx
```

No Gradle wrapper is committed (it needs a binary jar). Android Studio generates one the
first time you open the project; from a terminal with Gradle installed you can run
`gradle wrapper` first.

## Running

```bash
# with a device or emulator attached
gradle :app:installDebug && adb shell am start -n io.github.composenewsreader/.MainActivity

# or just build the APK
gradle :app:assembleDebug
# -> app/build/outputs/apk/debug/app-debug.apk
```

If the key is missing or wrong, the app starts and tells you so on screen rather than
failing silently:

```
No API key found
Set NEWSDATA_API_KEY in your environment or local.properties, then rebuild.
```

## What a row looks like

Roughly what one list item renders as (the real thing has the thumbnail and rounded chips):

```
┌──────────────────────────────────────────────────────────┐
│ ▓▓▓▓▓▓  Reuters · 2h ago                    [ neutral ]  │
│                                                          │
│ Chipmakers post steady quarter as data-centre demand     │
│ holds up                                                 │
│ Revenue rose 4% year on year, with the bulk of growth …  │
│                                                          │
│ #semiconductors  #earnings  #data centre                 │
└──────────────────────────────────────────────────────────┘
```

Above the list there is a sentiment mix bar:

```
Sentiment mix   ████████░░░░░░░░░░░░████
                positive 4 · neutral 11 · negative 5
                sample — live sentiment requires a newsdata.io plan that
                includes the sentiment field
```

The caption changes to `based on 10 of 10 loaded articles` once real `sentiment` values
come back. Sample numbers are only ever drawn when the field is absent, and they are
always labelled as sample.

## Free tier vs paid fields

Two different things get confused a lot, so, concretely:

**Response fields** (`sentiment`, `sentiment_stats`, `ai_tag`, `ai_region`, `ai_org`,
`ai_summary`, `content`) are paid-plan only, but asking for them costs nothing — they just
come back absent, or as the literal string `ONLY AVAILABLE IN ...`. `NewsDataApi.kt` treats
that placeholder string as absent, so those UI sections either render real data or a
labelled placeholder.

**Query parameters** are the ones that break things: sending `sentiment=`, `tag=`,
`timeframe=`, `from_date=`, `full_content=`, `size=` above 10, or hitting `/archive` and
`/count` fails the entire request on a free key. So the default path sends only `apikey`
(as the `X-ACCESS-KEY` header), `language`, and optionally `q`, `category` and `page`.

Optional, off by default:

```properties
# local.properties — requires a paid newsdata.io plan
NEWSDATA_PAID_MODE=true
```

This adds `full_content=1` and `timeframe=24` to the request. If the API answers 403 or 422
the client retries the same request once with those parameters stripped, so a key without
the entitlement still gets results instead of an error screen.

## Layout

```
app/src/main/java/io/github/composenewsreader/
  NewsDataApi.kt    models, error types, OkHttp client, tolerant JSON parsing
  MainActivity.kt   UI state, ViewModel, theme, composables, Activity
```

`NewsDataApi.kt` parses `JsonElement` by hand rather than with generated serializers. That
is on purpose: several fields (`ai_tag`, `country`, `category`) come back as either a
string or an array of strings depending on the article, and `sentiment_stats` is sometimes
an object and sometimes a JSON string. Hand-rolled readers absorb that; strict serializers
throw.

## Notes

- Search runs on the keyboard action, not on every keystroke. The free plan's credit
  allowance disappears fast if you debounce-fire requests while typing.
- There is no local cache. Rotating the device keeps state because the ViewModel survives,
  but a cold start re-fetches.
- `pubDate` is UTC and formatted with `SimpleDateFormat` rather than `java.time`, to keep
  minSdk at 24 without core library desugaring.

MIT licensed — copy whatever is useful.
