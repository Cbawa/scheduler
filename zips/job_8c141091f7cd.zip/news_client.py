"""Minimal, free-tier-safe client for the newsdata.io /news endpoint.

Reads nothing global \u2014 the API key is passed in. Only uses parameters that
are available on the FREE plan (q, language, country, category, page).
"""
import time
from typing import List, Optional

import requests

BASE_URL = "https://newsdata.io/api/1/news"


class NewsDataError(Exception):
    """Raised when the newsdata.io API returns an unrecoverable error."""


class NewsDataClient:
    def __init__(self, api_key: str, timeout: int = 20):
        if not api_key:
            raise NewsDataError("A newsdata.io API key is required.")
        self.api_key = api_key
        self.timeout = timeout
        self.session = requests.Session()

    def fetch_news(
        self,
        query: Optional[str] = None,
        language: Optional[str] = None,
        country: Optional[str] = None,
        category: Optional[str] = None,
        max_pages: int = 2,
    ) -> List[dict]:
        """Fetch up to ``max_pages`` pages of recent articles.

        Returns a flat list of article dicts. Pagination uses the ``nextPage``
        token returned by the API. Errors are surfaced as ``NewsDataError``;
        empty results return an empty list rather than raising.
        """
        articles: List[dict] = []
        next_page: Optional[str] = None

        for page_num in range(max(1, max_pages)):
            params = {"apikey": self.api_key}
            if query:
                params["q"] = query
            if language:
                params["language"] = language
            if country:
                params["country"] = country
            if category:
                params["category"] = category
            if next_page:
                params["page"] = next_page

            payload = self._request(params)
            results = payload.get("results") or []
            articles.extend(results)

            next_page = payload.get("nextPage")
            if not next_page or not results:
                break
            # Be polite to the free-tier rate limits.
            if page_num < max_pages - 1:
                time.sleep(0.4)

        return articles

    def _request(self, params: dict) -> dict:
        try:
            resp = self.session.get(BASE_URL, params=params, timeout=self.timeout)
        except requests.RequestException as exc:
            raise NewsDataError(f"Network error talking to newsdata.io: {exc}") from exc

        # Handle known status codes gracefully.
        if resp.status_code == 401:
            raise NewsDataError(
                "newsdata.io rejected the API key (401). Check NEWSDATA_API_KEY."
            )
        if resp.status_code == 429:
            raise NewsDataError(
                "Rate limit reached on newsdata.io (429). Wait a moment and "
                "try again, or reduce the number of pages."
            )
        if resp.status_code in (403, 422):
            # Usually a plan-restricted parameter on the free tier.
            raise NewsDataError(
                "newsdata.io returned a plan-restriction error "
                f"({resp.status_code}). This app only uses free-tier parameters \u2014 "
                "try removing the country/category filter or simplifying the query."
            )

        try:
            payload = resp.json()
        except ValueError as exc:
            raise NewsDataError("newsdata.io returned a non-JSON response.") from exc

        if resp.status_code >= 400 or payload.get("status") == "error":
            message = "Unknown error"
            results = payload.get("results")
            if isinstance(results, dict):
                message = results.get("message", message)
            raise NewsDataError(f"newsdata.io error: {message}")

        return payload
