"""Rank articles by semantic relevance to a query.

Uses OpenAI embeddings (text-embedding-3-small) and cosine similarity when an
OpenAI key is available. Falls back to a simple keyword overlap score otherwise,
so the app always works \u2014 including for users without an OpenAI key.
"""
import math
import re
from typing import List, Optional, Tuple

EMBED_MODEL = "text-embedding-3-small"


class SemanticRanker:
    def __init__(self, openai_api_key: Optional[str] = None):
        self.openai_api_key = openai_api_key
        self._client = None
        if openai_api_key:
            try:
                from openai import OpenAI

                self._client = OpenAI(api_key=openai_api_key)
            except Exception:
                # SDK missing or failed to init \u2014 fall back to keyword scoring.
                self._client = None

    # -- public API ---------------------------------------------------------
    def rank(
        self, query: str, articles: List[dict], top_k: int = 10
    ) -> List[Tuple[dict, float]]:
        texts = [self._article_text(a) for a in articles]

        if self._client is not None:
            try:
                scored = self._rank_with_embeddings(query, articles, texts)
            except Exception:
                scored = self._rank_with_keywords(query, articles, texts)
        else:
            scored = self._rank_with_keywords(query, articles, texts)

        scored.sort(key=lambda pair: pair[1], reverse=True)
        return scored[:top_k]

    # -- embedding path -----------------------------------------------------
    def _rank_with_embeddings(
        self, query: str, articles: List[dict], texts: List[str]
    ) -> List[Tuple[dict, float]]:
        inputs = [query] + texts
        resp = self._client.embeddings.create(model=EMBED_MODEL, input=inputs)
        vectors = [item.embedding for item in resp.data]
        query_vec = vectors[0]
        article_vecs = vectors[1:]

        return [
            (article, self._cosine(query_vec, vec))
            for article, vec in zip(articles, article_vecs)
        ]

    @staticmethod
    def _cosine(a: List[float], b: List[float]) -> float:
        dot = sum(x * y for x, y in zip(a, b))
        na = math.sqrt(sum(x * x for x in a))
        nb = math.sqrt(sum(y * y for y in b))
        if na == 0 or nb == 0:
            return 0.0
        return dot / (na * nb)

    # -- keyword fallback ---------------------------------------------------
    def _rank_with_keywords(
        self, query: str, articles: List[dict], texts: List[str]
    ) -> List[Tuple[dict, float]]:
        terms = set(self._tokenize(query))
        if not terms:
            return [(a, 0.0) for a in articles]

        scored = []
        for article, text in zip(articles, texts):
            tokens = self._tokenize(text)
            if not tokens:
                scored.append((article, 0.0))
                continue
            overlap = sum(1 for t in tokens if t in terms)
            score = overlap / math.sqrt(len(tokens))
            scored.append((article, score))
        return scored

    @staticmethod
    def _tokenize(text: str) -> List[str]:
        return re.findall(r"[a-z0-9]+", (text or "").lower())

    @staticmethod
    def _article_text(article: dict) -> str:
        parts = [article.get("title") or "", article.get("description") or ""]
        return ". ".join(p for p in parts if p).strip() or "(no text)"
