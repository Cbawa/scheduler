# AI-Powered News Search

Semantic search over **live** news. This app fetches fresh articles from the
[newsdata.io](https://newsdata.io) `/news` API, turns your question and every
article into vectors with **OpenAI embeddings**, and ranks the results by
meaning — not just keyword overlap. Ask a natural-language question and get the
most relevant headlines first.

Built with **Python + Streamlit**.

![Streamlit](https://img.shields.io/badge/UI-Streamlit-FF4B4B)
![Python](https://img.shields.io/badge/Python-3.9%2B-blue)

## How it works

1. You type a natural-language query (e.g. *"how are central banks responding to inflation?"*).
2. The app pulls a batch of recent articles from `https://newsdata.io/api/1/news`
   (optionally narrowed by language / country / category, and across a few pages).
3. Each article (title + description) and your query are embedded with OpenAI's
   `text-embedding-3-small` model.
4. Articles are ranked by **cosine similarity** to your query and shown with a
   relevance score.

If no OpenAI key is configured, the app gracefully falls back to a simple
keyword score so it still runs.

## Requirements

- Python 3.9+
- A **free** newsdata.io API key — get one at <https://newsdata.io/register>
- (Optional, recommended) An OpenAI API key for true semantic ranking

## Setup

```bash
git clone https://github.com/your-username/ai-powered-news-search.git
cd ai-powered-news-search

python -m venv .venv
source .venv/bin/activate        # on Windows: .venv\Scripts\activate

pip install -r requirements.txt
```

### Configure your keys

The app reads keys from environment variables. **Never hardcode them.**

```bash
export NEWSDATA_API_KEY="your_newsdata_io_key"
export OPENAI_API_KEY="your_openai_key"   # optional but recommended
```

You can also copy `.env.example` to `.env` and fill it in — the app loads it
automatically.

```bash
cp .env.example .env
# edit .env
```

## Run

```bash
streamlit run app.py
```

Streamlit opens the app in your browser (default <http://localhost:8501>).

## Free-tier notes

This project is designed to work on the **newsdata.io FREE plan**. It only uses
the `/news` endpoint with free parameters (`q`, `language`, `country`,
`category`, and `page` pagination via the `nextPage` token).

The following newsdata.io features are **paid-only** and are intentionally **not**
required here:

- Sentiment analysis and AI fields (`ai_tag`, `ai_region`, `ai_org`, `ai_summary`)
- The historical `/archive` endpoint and long date ranges
- Advanced full-text query operators

The client handles `401` (invalid key), `429` (rate limit), `403/422`
(plan-restricted) and empty results without crashing.

The OpenAI usage is also optional — without an OpenAI key the app falls back to
keyword scoring so free users always get a working demo.

## Project layout

```
app.py            # Streamlit UI
news_client.py    # newsdata.io /news client (free-tier safe)
ranker.py         # OpenAI embeddings + cosine similarity ranking (with fallback)
requirements.txt
.env.example
.gitignore
```

## License

MIT — see below. Powered by [newsdata.io](https://newsdata.io).
