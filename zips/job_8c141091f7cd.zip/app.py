"""AI-Powered News Search — Streamlit front end.

Fetches live news from newsdata.io and ranks it semantically with OpenAI
embeddings. Runs on the newsdata.io FREE tier.
"""
import os

import streamlit as st

try:
    from dotenv import load_dotenv

    load_dotenv()
except Exception:  # python-dotenv is optional
    pass

from news_client import NewsDataClient, NewsDataError
from ranker import SemanticRanker

LANGUAGES = {
    "Any": "",
    "English": "en",
    "Spanish": "es",
    "French": "fr",
    "German": "de",
    "Hindi": "hi",
    "Portuguese": "pt",
}

CATEGORIES = [
    "any",
    "business",
    "technology",
    "science",
    "health",
    "sports",
    "politics",
    "entertainment",
    "world",
    "environment",
]


st.set_page_config(page_title="AI-Powered News Search", page_icon="\U0001F4F0", layout="wide")

st.title("\U0001F4F0 AI-Powered News Search")
st.caption(
    "Semantic search over live news \u2014 powered by "
    "[newsdata.io](https://newsdata.io) + OpenAI embeddings."
)


def _get_key(name: str) -> str:
    return (os.environ.get(name) or "").strip()


newsdata_key = _get_key("NEWSDATA_API_KEY")
openai_key = _get_key("OPENAI_API_KEY")

if not newsdata_key:
    st.error(
        "**NEWSDATA_API_KEY is not set.**\n\n"
        "Grab a free key at https://newsdata.io/register and export it:\n\n"
        "```bash\nexport NEWSDATA_API_KEY=your_key_here\n```"
    )
    st.stop()

# --- Sidebar controls ------------------------------------------------------
with st.sidebar:
    st.header("Search options")
    language_label = st.selectbox("Language", list(LANGUAGES.keys()), index=1)
    category = st.selectbox("Category", CATEGORIES, index=0)
    country = st.text_input("Country code (optional)", help="e.g. us, gb, in").strip().lower()
    pages = st.slider("Pages to fetch (more = wider pool)", 1, 5, 2)
    top_k = st.slider("Results to show", 3, 25, 10)

    if openai_key:
        st.success("OpenAI key detected \u2014 semantic ranking enabled.")
    else:
        st.info(
            "No OPENAI_API_KEY set. Falling back to keyword ranking. "
            "Set the key for true semantic search."
        )

query = st.text_input(
    "Ask a question or describe what you want to read about",
    placeholder="e.g. how are central banks responding to inflation?",
)

search = st.button("Search", type="primary")


def _render_article(rank: int, article: dict, score: float) -> None:
    title = article.get("title") or "(untitled)"
    link = article.get("link") or ""
    source = article.get("source_id") or "unknown source"
    pub = article.get("pubDate") or ""
    desc = article.get("description") or ""

    header = f"{rank}. {title}"
    if link:
        st.markdown(f"### [{header}]({link})")
    else:
        st.markdown(f"### {header}")

    meta = f"**Source:** {source}"
    if pub:
        meta += f" \u00b7 **Published:** {pub}"
    meta += f" \u00b7 **Relevance:** {score:.3f}"
    st.caption(meta)

    if desc:
        st.write(desc)
    st.divider()


if search:
    if not query.strip():
        st.warning("Please type something to search for.")
        st.stop()

    client = NewsDataClient(newsdata_key)
    ranker = SemanticRanker(openai_key or None)

    with st.spinner("Fetching live news from newsdata.io..."):
        try:
            articles = client.fetch_news(
                query=query,
                language=LANGUAGES[language_label] or None,
                category=None if category == "any" else category,
                country=country or None,
                max_pages=pages,
            )
        except NewsDataError as exc:
            st.error(str(exc))
            st.stop()

    if not articles:
        st.warning(
            "No articles came back for that query. Try broadening it, removing "
            "the country filter, or switching language to 'Any'."
        )
        st.stop()

    with st.spinner(f"Ranking {len(articles)} articles by relevance..."):
        try:
            ranked = ranker.rank(query, articles, top_k=top_k)
        except Exception as exc:  # never let ranking crash the app
            st.warning(f"Semantic ranking unavailable ({exc}); showing newest first.")
            ranked = [(a, 0.0) for a in articles[:top_k]]

    st.success(f"Showing top {len(ranked)} of {len(articles)} fetched articles.")
    for i, (article, score) in enumerate(ranked, start=1):
        _render_article(i, article, score)
else:
    st.info("Set your search options in the sidebar, enter a query, and hit **Search**.")
