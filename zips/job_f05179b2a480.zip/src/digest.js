const MAX_ARTICLES = Math.max(1, parseInt(process.env.DIGEST_SIZE || '6', 10) || 6);

// On a free key, newsdata.io returns paid fields with a placeholder string like
// "ONLY AVAILABLE IN PROFESSIONAL AND CORPORATE PLANS" instead of null. Treat
// those as absent so they never render as broken content.
const PAID_HINT = 'ONLY AVAILABLE IN';

function cleanField(value) {
  let v = value;
  if (Array.isArray(v)) v = v[0];
  if (typeof v !== 'string') return null;
  const s = v.trim();
  if (!s) return null;
  if (s.toUpperCase().includes(PAID_HINT)) return null;
  return s;
}

function cleanList(value) {
  if (value == null) return [];
  const arr = Array.isArray(value) ? value : [value];
  return arr
    .map((x) => (typeof x === 'string' ? x.trim() : ''))
    .filter((x) => x && !x.toUpperCase().includes(PAID_HINT));
}

function truncate(text, max) {
  if (text.length <= max) return text;
  return text.slice(0, max - 1).trimEnd() + '\u2026';
}

const SENTIMENT_EMOJI = { positive: '🟢', neutral: '⚪', negative: '🔴' };

function sentimentLine(articles) {
  const counts = { positive: 0, neutral: 0, negative: 0 };
  let found = 0;
  for (const a of articles) {
    const s = cleanField(a.sentiment);
    if (s && counts[s] !== undefined) {
      counts[s] += 1;
      found += 1;
    }
  }
  if (found === 0) {
    return 'Sentiment (sample — live sentiment requires a paid newsdata.io plan): 🟢 0  ⚪ 0  🔴 0';
  }
  return `Sentiment: 🟢 ${counts.positive}  ⚪ ${counts.neutral}  🔴 ${counts.negative}`;
}

function formatArticle(a, index) {
  const lines = [];
  const title = cleanField(a.title) || '(untitled)';
  lines.push(`*${index}. ${title}*`);

  const meta = [];
  const source = cleanField(a.source_id) || cleanField(a.source_name);
  if (source) meta.push(source);
  const sentiment = cleanField(a.sentiment);
  if (sentiment) meta.push(`${SENTIMENT_EMOJI[sentiment] || ''} ${sentiment}`.trim());
  if (meta.length) lines.push(`_${meta.join(' · ')}_`);

  const summary = cleanField(a.ai_summary) || cleanField(a.description);
  if (summary) lines.push(truncate(summary, 220));

  const tags = cleanList(a.ai_tag);
  if (tags.length) lines.push('🏷 ' + tags.slice(0, 4).join(', '));

  const keywords = cleanList(a.keywords);
  if (keywords.length) lines.push('🔑 ' + keywords.slice(0, 5).join(', '));

  const link = cleanField(a.link);
  if (link) lines.push(link);

  return lines.join('\n');
}

function buildDigest(results, header) {
  if (!results || results.length === 0) {
    return `*${header}*\n\nNo articles available right now. Try again later or pick another country or keyword.`;
  }
  const articles = results.slice(0, MAX_ARTICLES);
  const parts = [`*${header}*`, sentimentLine(articles), ''];
  articles.forEach((a, i) => {
    parts.push(formatArticle(a, i + 1));
    parts.push('');
  });
  parts.push('_Source: newsdata.io · send "help" for commands_');
  return parts.join('\n').trim();
}

module.exports = { buildDigest };
