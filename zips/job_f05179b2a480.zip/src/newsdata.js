const axios = require('axios');

const BASE_URL = 'https://newsdata.io/api/1';

class NewsDataError extends Error {
  constructor(message, code) {
    super(message);
    this.name = 'NewsDataError';
    this.code = code;
  }
}

function getApiKey() {
  const key = process.env.NEWSDATA_API_KEY;
  if (!key || !key.trim()) {
    throw new NewsDataError(
      'NEWSDATA_API_KEY is not set. Get a free key at https://newsdata.io and add it to your .env file.',
      'NO_KEY'
    );
  }
  return key.trim();
}

async function request(params) {
  let resp;
  try {
    resp = await axios.get(`${BASE_URL}/latest`, { params, timeout: 20000 });
  } catch (err) {
    if (err.response) {
      const status = err.response.status;
      const body = err.response.data || {};
      const apiMsg = (body.results && body.results.message) || body.message || null;
      if (status === 401) {
        throw new NewsDataError('newsdata.io rejected the API key (401). Check NEWSDATA_API_KEY.', 401);
      }
      if (status === 429) {
        throw new NewsDataError('newsdata.io rate limit reached (429). Try again in a little while.', 429);
      }
      throw new NewsDataError(apiMsg || `newsdata.io request failed (HTTP ${status}).`, status);
    }
    throw new NewsDataError(`Could not reach newsdata.io: ${err.message}`, 'NETWORK');
  }

  const data = resp.data || {};
  if (data.status === 'error') {
    const msg = (data.results && data.results.message) || 'unknown API error';
    throw new NewsDataError(`newsdata.io error: ${msg}`, 'API_ERROR');
  }

  return {
    results: Array.isArray(data.results) ? data.results : [],
    nextPage: data.nextPage || null,
    totalResults: data.totalResults || 0,
  };
}

// Fetch the latest headlines. country/q/language/page are all free-tier params.
// Paid-only query params are sent only when ENABLE_PAID=1, and on a 403/422 we
// retry once without them so a free key still gets results.
async function fetchLatest(opts = {}) {
  const { country, query, language, page } = opts;
  const apikey = getApiKey();

  const base = { apikey };
  if (language) base.language = language;
  if (country) base.country = country;
  if (query) base.q = query;
  if (page) base.page = page;

  const usePaid = process.env.ENABLE_PAID === '1';
  const params = { ...base };
  if (usePaid) {
    params.full_content = 1;
    const size = parseInt(process.env.PAID_SIZE || '0', 10);
    if (size > 0) params.size = size;
  }

  try {
    return await request(params);
  } catch (err) {
    if (usePaid && (err.code === 403 || err.code === 422)) {
      return await request(base);
    }
    throw err;
  }
}

module.exports = { fetchLatest, getApiKey, NewsDataError };
