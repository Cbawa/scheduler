const cron = require('node-cron');

const { fetchLatest } = require('./newsdata');
const { buildDigest } = require('./digest');
const store = require('./store');

const sleep = (ms) => new Promise((resolve) => setTimeout(resolve, ms));

async function runDigests(client) {
  const subs = store.all();
  const entries = Object.entries(subs);
  if (entries.length === 0) return;

  console.log(`Sending hourly digests to ${entries.length} chat(s).`);
  for (const [chatId, sub] of entries) {
    try {
      const opts = sub.mode === 'country' ? { country: sub.value } : { query: sub.value };
      const { results } = await fetchLatest({ ...opts, language: sub.language || 'en' });
      const header = sub.mode === 'country'
        ? `Hourly digest (${String(sub.value).toUpperCase()})`
        : `Hourly digest: "${sub.value}"`;
      await client.sendMessage(chatId, buildDigest(results, header));
      await sleep(1500);
    } catch (err) {
      console.error(`Digest failed for ${chatId}: ${err.message}`);
    }
  }
}

function startScheduler(client) {
  const schedule = process.env.DIGEST_CRON || '0 * * * *';
  if (!cron.validate(schedule)) {
    console.error(`Invalid DIGEST_CRON "${schedule}"; falling back to hourly.`);
    cron.schedule('0 * * * *', () => runDigests(client));
  } else {
    cron.schedule(schedule, () => runDigests(client));
  }
  console.log(`Hourly digests scheduled (${schedule}).`);
}

module.exports = { startScheduler, runDigests };
