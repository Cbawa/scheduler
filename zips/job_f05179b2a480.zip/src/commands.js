const { fetchLatest } = require('./newsdata');
const { buildDigest } = require('./digest');
const store = require('./store');

const LANGUAGE = process.env.NEWS_LANGUAGE || 'en';

// A practical subset of the two-letter country codes newsdata.io accepts. Used
// only to decide whether `subscribe <x>` means a country or a keyword.
const COUNTRY_CODES = new Set([
  'ar', 'au', 'at', 'be', 'br', 'ca', 'cl', 'cn', 'co', 'cz', 'dk', 'eg', 'fi',
  'fr', 'de', 'gr', 'hk', 'hu', 'in', 'id', 'ie', 'il', 'it', 'jp', 'kr', 'mx',
  'my', 'nl', 'nz', 'ng', 'no', 'pk', 'ph', 'pl', 'pt', 'ro', 'ru', 'sa', 'sg',
  'za', 'es', 'se', 'ch', 'tw', 'th', 'tr', 'ua', 'ae', 'gb', 'us', 've', 'vn',
]);

const HELP = [
  '*News WhatsApp bot*',
  'Commands (the leading / is optional):',
  '',
  'news <keyword>      headlines for a keyword, e.g. news ai',
  'country <code>      headlines for a country, e.g. country us',
  'subscribe <target>  hourly digest by country code or keyword',
  'status              show your subscription',
  'stop                cancel the hourly digest',
  'help                show this message',
  '',
  'Data from newsdata.io.',
].join('\n');

function parse(body) {
  const t = (body || '').trim().replace(/^\//, '');
  const parts = t.split(/\s+/);
  const cmd = (parts.shift() || '').toLowerCase();
  return { cmd, arg: parts.join(' ').trim() };
}

async function oneOff(opts, header) {
  const { results } = await fetchLatest({ ...opts, language: LANGUAGE });
  return buildDigest(results, header);
}

function subscribe(chatId, arg) {
  if (!arg) {
    return 'Usage: subscribe <country-code or keyword>\nExamples: subscribe us  |  subscribe bitcoin';
  }
  const lower = arg.toLowerCase();
  let sub;
  if (COUNTRY_CODES.has(lower)) {
    sub = { mode: 'country', value: lower, language: LANGUAGE };
  } else {
    sub = { mode: 'keyword', value: arg, language: LANGUAGE };
  }
  store.set(chatId, sub);
  const label = sub.mode === 'country' ? `country ${lower.toUpperCase()}` : `keyword "${arg}"`;
  return `Subscribed to hourly news digests for ${label}.\nSend "stop" to cancel.`;
}

function statusMessage(chatId) {
  const sub = store.get(chatId);
  if (!sub) {
    return 'You have no active subscription. Send "subscribe us" or "subscribe bitcoin" to start.';
  }
  const label = sub.mode === 'country'
    ? `country ${String(sub.value).toUpperCase()}`
    : `keyword "${sub.value}"`;
  return `You are subscribed to hourly digests for ${label}.\nSend "stop" to cancel.`;
}

async function handleMessage(body, chatId) {
  const { cmd, arg } = parse(body);
  switch (cmd) {
    case 'help':
    case 'start':
    case 'hi':
    case 'hello':
      return HELP;
    case 'news':
      if (!arg) return 'Usage: news <keyword>  e.g. news climate';
      return oneOff({ query: arg }, `Top headlines for "${arg}"`);
    case 'country':
      if (!arg) return 'Usage: country <code>  e.g. country us';
      return oneOff({ country: arg.toLowerCase() }, `Top headlines (${arg.toUpperCase()})`);
    case 'subscribe':
    case 'sub':
      return subscribe(chatId, arg);
    case 'unsubscribe':
    case 'unsub':
    case 'stop':
      store.remove(chatId);
      return 'Unsubscribed. You will no longer receive hourly digests.';
    case 'status':
      return statusMessage(chatId);
    default:
      return null;
  }
}

module.exports = { handleMessage };
