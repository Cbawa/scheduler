const fs = require('fs');
const path = require('path');

const FILE = process.env.SUBS_FILE || path.join(__dirname, '..', 'data', 'subscriptions.json');

function load() {
  try {
    const raw = fs.readFileSync(FILE, 'utf8');
    const data = JSON.parse(raw);
    return data && typeof data === 'object' ? data : {};
  } catch (_) {
    return {};
  }
}

function persist(data) {
  fs.mkdirSync(path.dirname(FILE), { recursive: true });
  const tmp = `${FILE}.tmp`;
  fs.writeFileSync(tmp, JSON.stringify(data, null, 2));
  fs.renameSync(tmp, FILE);
}

let cache = load();

module.exports = {
  all: () => cache,
  get: (id) => cache[id],
  set: (id, sub) => {
    cache[id] = sub;
    persist(cache);
  },
  remove: (id) => {
    if (cache[id]) {
      delete cache[id];
      persist(cache);
    }
  },
};
