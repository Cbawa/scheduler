# news-whatsapp-bot

A small WhatsApp bot that sends hourly news digests filtered by country or keyword, and
answers on-demand headline requests in chat. It pulls live headlines from the newsdata.io
news API (https://newsdata.io) — grab a free API key to run it. The bot runs on top of
whatsapp-web.js, so it links to a normal WhatsApp account by scanning a QR code.

## What it does

- Subscribe a chat to an hourly digest by country code or keyword.
- Ask for headlines on demand with a `news` or `country` command.
- Each article shows its source and keywords, and — when your newsdata.io plan returns
  them — a sentiment badge, AI topic tags, and a one-line AI summary.
- A short sentiment breakdown is shown at the top of each digest.

## Requirements

- Node.js 18 or newer
- A WhatsApp account to link (the bot acts as a linked device)
- A newsdata.io API key — the free tier is enough for the core features
  (https://newsdata.io)

## Setup

1. Install dependencies:

       npm install

2. Copy the example env file and add your key:

       cp .env.example .env
       # then edit .env and set NEWSDATA_API_KEY

3. Start the bot:

       npm start

   On first run a QR code is printed in the terminal. Open WhatsApp on your phone →
   Settings → Linked devices → Link a device, and scan it. The session is cached under
   `.wwebjs_auth/`, so you only scan once.

## Commands

Send these to the linked WhatsApp number (a leading slash is optional):

| Command              | What it does                                       |
|----------------------|----------------------------------------------------|
| `help`               | Show the command list                              |
| `news <keyword>`     | Headlines matching a keyword, e.g. `news ai`        |
| `country <code>`     | Headlines for a country, e.g. `country us`          |
| `subscribe <target>` | Start an hourly digest (country code or keyword)   |
| `status`             | Show your current subscription                     |
| `stop`               | Cancel the hourly digest                           |

`subscribe us` subscribes to United States headlines; `subscribe bitcoin` subscribes to a
keyword digest. Country codes are the two-letter codes newsdata.io uses (`us`, `gb`, `in`,
`de`, ...).

## Example

    > news climate

    *Top headlines for "climate"*
    Sentiment: 🟢 2  ⚪ 3  🔴 1

    *1. Nations agree on new climate finance target*
    _reuters · 🟢 positive_
    Delegates reached a late deal to raise funding for lower-income countries...
    🏷 Environment, Politics
    🔑 climate finance, summit, emissions
    https://example.com/article

    ... (more articles) ...

    _Source: newsdata.io · send "help" for commands_

On a free API key the sentiment, AI tag, and AI summary lines are simply omitted, and the
breakdown line is shown with a clearly labelled sample so the layout stays intact.

## Configuration

All settings are read from the environment (or a `.env` file):

| Variable           | Default       | Notes                                    |
|--------------------|---------------|------------------------------------------|
| `NEWSDATA_API_KEY` | —             | Required. Your newsdata.io key.          |
| `NEWS_LANGUAGE`    | `en`          | Two-letter language code.                |
| `DIGEST_CRON`      | `0 * * * *`   | Cron expression for the digest (hourly). |
| `DIGEST_SIZE`      | `6`           | Articles per digest message.             |
| `ENABLE_PAID`      | unset         | See below.                               |

### Paid newsdata.io fields

Response fields like `sentiment`, `ai_tag`, and `ai_summary` are part of newsdata.io's
paid plans. The bot reads them straight from the API response when they are present and
omits them otherwise, so it works unchanged on a free key.

A few query parameters (for example requesting more than 10 articles or full article text)
also require a paid plan and would otherwise fail the whole request. Set `ENABLE_PAID=1`
to send them; if the API rejects them, the bot retries the request without them so you
still get free results.

## Notes

- WhatsApp automation through whatsapp-web.js is unofficial; use an account you are
  comfortable linking a bot to.
- Subscriptions are stored in `data/subscriptions.json`.

## License

MIT
