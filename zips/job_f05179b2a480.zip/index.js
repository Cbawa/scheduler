require('dotenv').config();

const { Client, LocalAuth } = require('whatsapp-web.js');
const qrcode = require('qrcode-terminal');

const { getApiKey } = require('./src/newsdata');
const { handleMessage } = require('./src/commands');
const { startScheduler } = require('./src/scheduler');

// Fail fast with a clear message if the API key is missing.
try {
  getApiKey();
} catch (err) {
  console.error(err.message);
  process.exit(1);
}

const client = new Client({
  authStrategy: new LocalAuth({
    dataPath: process.env.WWEBJS_AUTH_DIR || '.wwebjs_auth',
  }),
  puppeteer: {
    args: ['--no-sandbox', '--disable-setuid-sandbox'],
  },
});

client.on('qr', (qr) => {
  console.log('Scan this QR code with WhatsApp (Settings -> Linked devices):');
  qrcode.generate(qr, { small: true });
});

client.on('ready', () => {
  console.log('WhatsApp bot is ready.');
  startScheduler(client);
});

client.on('auth_failure', (msg) => {
  console.error('Authentication failed:', msg);
});

client.on('disconnected', (reason) => {
  console.warn('Client disconnected:', reason);
});

client.on('message', async (msg) => {
  try {
    const reply = await handleMessage(msg.body, msg.from);
    if (reply) await msg.reply(reply);
  } catch (err) {
    console.error('Error handling message:', err.message);
    try {
      await msg.reply('Something went wrong fetching the news. Please try again later.');
    } catch (_) {
      // ignore secondary failures
    }
  }
});

client.initialize();
