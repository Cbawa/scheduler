// Typed client for the newsdata.io news API (https://newsdata.io).
// Server-side only: it reads NEWSDATA_API_KEY from the environment.
//
// The default path stays on the free tier — it sends only free query params
// (language, category, q, country, page) and reads the richer fields
// (sentiment, ai_summary, ai_tag, ...) straight from each result. Those fields
// are simply null on a free key, so the UI degrades cleanly.

const BASE_URL = 'https://newsdata.io/api/1/latest';

// Categories supported by the /latest endpoint that we expose as pages.
export const CATEGORIES = [
  'business',
  'technology',
  'science',
  'sports',
  'health',
  'entertainment',
  'environment',
  'food',
  'world',
  'politics',
] as const;

export interface SentimentStats {
  positive?: number;
  neutral?: number;
  negative?: number;
}

export interface Article {
  article_id: string;
  title: string;
  link: string;
  description: string | null;
  content: string | null;
  pubDate: string | null;
  image_url: string | null;
  source_id: string | null;
  source_name: string | null;
  source_url: string | null;
  source_icon: string | null;
  language: string | null;
  country: string[] | null;
  category: string[] | null;
  keywords: string[] | null;
  creator: string[] | null;
  // Paid response fields. Populated only on paid plans; null on a free key.
  sentiment: string | null;
  sentiment_stats: SentimentStats | null;
  ai_tag: string[] | string | null;
  ai_region: string[] | string | null;
  ai_org: string[] | string | null;
  ai_summary: string | null;
}

export interface NewsDataResponse {
  status: string;
  totalResults: number;
  results: Article[];
  nextPage: string | null;
}

export class NewsDataError extends Error {
  status: number;
  constructor(message: string, status: number) {
    super(message);
    this.name = 'NewsDataError';
    this.status = status;
  }
}

export interface FetchOptions {
  category?: string;
  q?: string;
  country?: string;
  language?: string;
  page?: string | null;
  // false -> no-store (SSR). number -> ISR revalidate seconds.
  revalidate?: number | false;
}

function paidEnabled(): boolean {
  return process.env.NEWSDATA_PAID === '1';
}

export async function fetchNews(opts: FetchOptions = {}): Promise<NewsDataResponse> {
  const apiKey = process.env.NEWSDATA_API_KEY;
  if (!apiKey) {
    throw new NewsDataError(
      'NEWSDATA_API_KEY is not set. Get a free key at https://newsdata.io and add it to .env.local.',
      0,
    );
  }

  const language = opts.language || process.env.NEWSDATA_LANGUAGE || 'en';

  const buildUrl = (includePaid: boolean): string => {
    const params = new URLSearchParams();
    params.set('apikey', apiKey);
    params.set('language', language);
    if (opts.category) params.set('category', opts.category);
    if (opts.country) params.set('country', opts.country);
    if (opts.q) params.set('q', opts.q);
    if (opts.page) params.set('page', opts.page);
    if (includePaid && paidEnabled()) {
      // Paid-only query params: a free key rejects these with 403/422.
      const size = process.env.NEWSDATA_PAGE_SIZE;
      if (size) params.set('size', size);
      const timeframe = process.env.NEWSDATA_TIMEFRAME;
      if (timeframe) params.set('timeframe', timeframe);
    }
    return `${BASE_URL}?${params.toString()}`;
  };

  const doFetch = (includePaid: boolean): Promise<Response> => {
    const init: RequestInit & { next?: { revalidate: number } } = {
      headers: { Accept: 'application/json' },
    };
    if (opts.revalidate === false) init.cache = 'no-store';
    else if (typeof opts.revalidate === 'number') init.next = { revalidate: opts.revalidate };
    return fetch(buildUrl(includePaid), init);
  };

  let res = await doFetch(true);

  // Free key + a paid query param -> retry once without the paid params
  // so the user still gets free results.
  if ((res.status === 403 || res.status === 422) && paidEnabled()) {
    res = await doFetch(false);
  }

  if (res.status === 401) {
    throw new NewsDataError('Invalid newsdata.io API key (401). Check NEWSDATA_API_KEY.', 401);
  }
  if (res.status === 429) {
    throw new NewsDataError(
      'Rate limit reached (429). The free plan allows a limited number of requests — wait a moment and retry.',
      429,
    );
  }
  if (!res.ok) {
    let detail = '';
    try {
      const body: any = await res.json();
      detail = body?.results?.message || body?.message || '';
    } catch {
      // ignore body parse errors
    }
    throw new NewsDataError(
      `newsdata.io request failed (${res.status})${detail ? ': ' + detail : ''}.`,
      res.status,
    );
  }

  const data = (await res.json()) as NewsDataResponse;
  if (!Array.isArray(data.results)) data.results = [];
  return data;
}

export function toArray(value: string[] | string | null | undefined): string[] {
  if (!value) return [];
  return (Array.isArray(value) ? value : [value]).filter(Boolean);
}

export interface SentimentBreakdown {
  positive: number;
  neutral: number;
  negative: number;
  total: number;
}

export function aggregateSentiment(articles: Article[]): SentimentBreakdown {
  const b: SentimentBreakdown = { positive: 0, neutral: 0, negative: 0, total: 0 };
  for (const a of articles) {
    const s = (a.sentiment || '').toLowerCase();
    if (s === 'positive' || s === 'neutral' || s === 'negative') {
      b[s] += 1;
      b.total += 1;
    }
  }
  return b;
}
