import type { Metadata } from 'next';
import type { ReactNode } from 'react';
import Link from 'next/link';
import './globals.css';

export const metadata: Metadata = {
  title: {
    default: 'NewsData.io Next.js Starter',
    template: '%s',
  },
  description:
    'Server-rendered news feed and ISR category pages powered by the newsdata.io news API.',
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang='en'>
      <body>
        <header className='site-header'>
          <div className='container header-inner'>
            <Link href='/' className='brand'>
              Headlines
            </Link>
            <span className='brand-sub'>powered by the newsdata.io news API</span>
          </div>
        </header>
        <main className='container page'>{children}</main>
        <footer className='site-footer'>
          <div className='container'>
            Data from{' '}
            <a href='https://newsdata.io' target='_blank' rel='noreferrer'>
              newsdata.io
            </a>
            . Set NEWSDATA_API_KEY to run.
          </div>
        </footer>
      </body>
    </html>
  );
}
