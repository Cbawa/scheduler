import { fetchNews, aggregateSentiment, NewsDataError, type Article } from '@/lib/newsdata';
import { CategoryNav, Feed, SentimentBreakdownBar } from '@/components/news';

// Render the home feed fresh on every request (SSR).
export const dynamic = 'force-dynamic';

export default async function HomePage() {
  let articles: Article[] = [];
  let errorMessage: string | null = null;

  try {
    const data = await fetchNews({ revalidate: false });
    articles = data.results;
  } catch (err) {
    errorMessage = err instanceof NewsDataError ? err.message : 'Could not load the news feed.';
  }

  return (
    <>
      <CategoryNav />
      <h1 className='page-title'>Latest headlines</h1>
      {errorMessage ? (
        <div className='notice notice--error'>{errorMessage}</div>
      ) : (
        <>
          <SentimentBreakdownBar breakdown={aggregateSentiment(articles)} />
          <Feed articles={articles} />
        </>
      )}
    </>
  );
}
