import { notFound } from 'next/navigation';
import {
  fetchNews,
  aggregateSentiment,
  CATEGORIES,
  NewsDataError,
  type Article,
} from '@/lib/newsdata';
import { CategoryNav, Feed, SentimentBreakdownBar, CATEGORY_LABELS } from '@/components/news';

// Incremental Static Regeneration: cache each category page for 10 minutes.
export const revalidate = 600;
export const dynamicParams = true;

export function generateStaticParams() {
  return CATEGORIES.map((category) => ({ category }));
}

export function generateMetadata({ params }: { params: { category: string } }) {
  const label = CATEGORY_LABELS[params.category] || params.category;
  return { title: `${label} news — NewsData.io Starter` };
}

export default async function CategoryPage({ params }: { params: { category: string } }) {
  const category = params.category.toLowerCase();
  if (!(CATEGORIES as readonly string[]).includes(category)) {
    notFound();
  }

  let articles: Article[] = [];
  let errorMessage: string | null = null;

  try {
    const data = await fetchNews({ category, revalidate: 600 });
    articles = data.results;
  } catch (err) {
    errorMessage = err instanceof NewsDataError ? err.message : 'Could not load this category.';
  }

  const label = CATEGORY_LABELS[category] || category;

  return (
    <>
      <CategoryNav active={category} />
      <h1 className='page-title'>{label}</h1>
      {errorMessage ? (
        <div className='notice notice--error'>{errorMessage}</div>
      ) : (
        <>
          <SentimentBreakdownBar breakdown={aggregateSentiment(articles)} />
          <Feed articles={articles} />
        </>
      )}
    </>
  );
}
