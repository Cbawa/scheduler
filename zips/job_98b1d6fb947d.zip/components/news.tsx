import Link from 'next/link';
import { CATEGORIES, toArray, type Article, type SentimentBreakdown } from '@/lib/newsdata';

export const CATEGORY_LABELS: Record<string, string> = {
  business: 'Business',
  technology: 'Technology',
  science: 'Science',
  sports: 'Sports',
  health: 'Health',
  entertainment: 'Entertainment',
  environment: 'Environment',
  food: 'Food',
  world: 'World',
  politics: 'Politics',
};

function formatDate(value: string | null): string {
  if (!value) return '';
  const iso = value.includes('T') ? value : value.replace(' ', 'T') + 'Z';
  const d = new Date(iso);
  if (isNaN(d.getTime())) return value;
  return d.toLocaleString('en-US', { dateStyle: 'medium', timeStyle: 'short' });
}

export function CategoryNav({ active }: { active?: string }) {
  return (
    <nav className='category-nav'>
      <Link className={!active ? 'cat cat--active' : 'cat'} href='/'>
        Top
      </Link>
      {CATEGORIES.map((c) => (
        <Link
          key={c}
          className={active === c ? 'cat cat--active' : 'cat'}
          href={`/category/${c}`}
        >
          {CATEGORY_LABELS[c] || c}
        </Link>
      ))}
    </nav>
  );
}

export function SentimentBadge({ sentiment }: { sentiment: string | null }) {
  const s = (sentiment || '').toLowerCase();
  if (s !== 'positive' && s !== 'neutral' && s !== 'negative') return null;
  return <span className={`badge badge-${s}`}>{s}</span>;
}

export function ArticleCard({ article }: { article: Article }) {
  const keywords = toArray(article.keywords).slice(0, 4);
  const aiTags = toArray(article.ai_tag).slice(0, 4);
  return (
    <article className='card'>
      {article.image_url ? (
        // Plain img keeps the starter config-free (no image domains to allowlist).
        // eslint-disable-next-line @next/next/no-img-element
        <img className='card-img' src={article.image_url} alt='' loading='lazy' />
      ) : (
        <div className='card-img card-img--ph' aria-hidden='true' />
      )}
      <div className='card-body'>
        <div className='card-meta'>
          <span className='src'>
            {article.source_name || article.source_id || 'Unknown source'}
          </span>
          {article.pubDate ? (
            <span className='dot-sep'>{formatDate(article.pubDate)}</span>
          ) : null}
          <SentimentBadge sentiment={article.sentiment} />
        </div>
        <h2 className='card-title'>
          <a href={article.link} target='_blank' rel='noreferrer'>
            {article.title}
          </a>
        </h2>
        {article.ai_summary ? (
          <p className='card-summary'>
            <span className='field-label'>AI summary</span> {article.ai_summary}
          </p>
        ) : article.description ? (
          <p className='card-desc'>{article.description}</p>
        ) : null}
        {keywords.length > 0 ? (
          <div className='chips'>
            {keywords.map((k) => (
              <span key={k} className='chip'>
                {k}
              </span>
            ))}
          </div>
        ) : null}
        {aiTags.length > 0 ? (
          <div className='chips'>
            {aiTags.map((t) => (
              <span key={t} className='chip chip--ai'>
                {t}
              </span>
            ))}
          </div>
        ) : null}
      </div>
    </article>
  );
}

export function Feed({ articles }: { articles: Article[] }) {
  if (!articles.length) {
    return (
      <p className='empty'>
        No articles to show right now. Try another category or check back soon.
      </p>
    );
  }
  return (
    <div className='grid'>
      {articles.map((a) => (
        <ArticleCard key={a.article_id || a.link} article={a} />
      ))}
    </div>
  );
}

export function SentimentBreakdownBar({ breakdown }: { breakdown: SentimentBreakdown }) {
  const isSample = breakdown.total === 0;
  const data = isSample ? { positive: 6, neutral: 3, negative: 2, total: 11 } : breakdown;
  const pct = (n: number) => (data.total ? Math.round((n / data.total) * 100) : 0);
  return (
    <section className='sentiment'>
      <div className='sentiment-head'>
        <h3>Sentiment breakdown</h3>
        {isSample ? (
          <span className='sample-note'>
            sample — live sentiment requires a paid newsdata.io plan
          </span>
        ) : (
          <span className='muted'>{data.total} on this page scored</span>
        )}
      </div>
      <div
        className='sentiment-bar'
        role='img'
        aria-label='Sentiment breakdown of the current articles'
      >
        <span className='seg seg-positive' style={{ width: pct(data.positive) + '%' }} />
        <span className='seg seg-neutral' style={{ width: pct(data.neutral) + '%' }} />
        <span className='seg seg-negative' style={{ width: pct(data.negative) + '%' }} />
      </div>
      <div className='sentiment-legend'>
        <span>
          <i className='dot dot-positive' /> Positive {pct(data.positive)}%
        </span>
        <span>
          <i className='dot dot-neutral' /> Neutral {pct(data.neutral)}%
        </span>
        <span>
          <i className='dot dot-negative' /> Negative {pct(data.negative)}%
        </span>
      </div>
    </section>
  );
}
