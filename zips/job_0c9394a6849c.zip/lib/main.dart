import 'package:flutter/material.dart';
import 'package:home_widget/home_widget.dart';
import 'package:intl/intl.dart';

import 'news_service.dart';

const String kApiKey = String.fromEnvironment('NEWSDATA_API_KEY');
const bool kEnablePaid =
    bool.fromEnvironment('ENABLE_PAID', defaultValue: false);
const String kAppGroupId = 'group.com.example.flutternewswidget';

void main() {
  HomeWidget.setAppGroupId(kAppGroupId);
  runApp(const NewsApp());
}

class NewsApp extends StatelessWidget {
  const NewsApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Latest News',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        useMaterial3: true,
        colorSchemeSeed: const Color(0xFF8AB4F8),
        brightness: Brightness.dark,
      ),
      home: kApiKey.isEmpty ? const MissingKeyScreen() : const HomePage(),
    );
  }
}

class MissingKeyScreen extends StatelessWidget {
  const MissingKeyScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Padding(
        padding: const EdgeInsets.all(24),
        child: Center(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: const [
              Icon(Icons.vpn_key_off, size: 48),
              SizedBox(height: 16),
              Text(
                'No API key found',
                style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
              ),
              SizedBox(height: 8),
              Text(
                'Build the app with your newsdata.io key:\n\n'
                'flutter run --dart-define=NEWSDATA_API_KEY=your_key',
                textAlign: TextAlign.center,
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class HomePage extends StatefulWidget {
  const HomePage({super.key});

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  late final NewsService _service =
      NewsService(kApiKey, enablePaid: kEnablePaid);
  final TextEditingController _searchCtrl = TextEditingController();

  final List<Article> _articles = [];
  String? _nextPage;
  String _query = '';
  bool _loading = false;
  bool _loadingMore = false;
  String? _error;

  @override
  void initState() {
    super.initState();
    _load(reset: true);
  }

  @override
  void dispose() {
    _searchCtrl.dispose();
    super.dispose();
  }

  bool get _hasEnrichment => _articles.any((a) =>
      a.sentiment != null || a.aiSummary != null || a.aiTags.isNotEmpty);

  Future<void> _load({bool reset = false}) async {
    if (_loadingMore && !reset) return;
    setState(() {
      if (reset) {
        _loading = true;
        _error = null;
        _articles.clear();
        _nextPage = null;
      } else {
        _loadingMore = true;
      }
    });
    try {
      final pageData = await _service.fetchLatest(
        query: _query,
        page: reset ? null : _nextPage,
      );
      setState(() {
        _articles.addAll(pageData.articles);
        _nextPage = pageData.nextPage;
      });
      await _syncWidget();
    } on NewsException catch (e) {
      setState(() => _error = e.message);
    } catch (e) {
      setState(() => _error = 'Something went wrong. Please try again.');
    } finally {
      setState(() {
        _loading = false;
        _loadingMore = false;
      });
    }
  }

  Future<void> _syncWidget() async {
    if (_articles.isEmpty) return;
    final top = _articles.first;
    try {
      await HomeWidget.saveWidgetData<String>('headline', top.title);
      await HomeWidget.saveWidgetData<String>('source', top.sourceName ?? '');
      await HomeWidget.saveWidgetData<String>(
          'updated', 'Updated ${DateFormat.jm().format(DateTime.now())}');
      await HomeWidget.updateWidget(
        androidName: 'NewsWidgetProvider',
        qualifiedAndroidName:
            'com.example.flutter_news_widget.NewsWidgetProvider',
        iOSName: 'NewsWidget',
      );
    } catch (_) {
      // Best-effort: ignore if the native widget side isn't wired up yet.
    }
  }

  void _runSearch() {
    setState(() => _query = _searchCtrl.text.trim());
    _load(reset: true);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Latest News'),
        bottom: PreferredSize(
          preferredSize: const Size.fromHeight(60),
          child: Padding(
            padding: const EdgeInsets.fromLTRB(12, 0, 12, 10),
            child: TextField(
              controller: _searchCtrl,
              textInputAction: TextInputAction.search,
              onSubmitted: (_) => _runSearch(),
              decoration: InputDecoration(
                hintText: 'Search headlines',
                isDense: true,
                filled: true,
                prefixIcon: const Icon(Icons.search),
                suffixIcon: IconButton(
                  icon: const Icon(Icons.arrow_forward),
                  onPressed: _runSearch,
                ),
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(12),
                  borderSide: BorderSide.none,
                ),
              ),
            ),
          ),
        ),
      ),
      body: RefreshIndicator(
        onRefresh: () => _load(reset: true),
        child: _buildBody(),
      ),
    );
  }

  Widget _buildBody() {
    if (_loading) {
      return const Center(child: CircularProgressIndicator());
    }
    if (_error != null) {
      return ListView(
        children: [
          const SizedBox(height: 120),
          Icon(Icons.cloud_off, size: 40, color: Colors.grey.shade500),
          const SizedBox(height: 12),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 32),
            child: Text(_error!, textAlign: TextAlign.center),
          ),
          const SizedBox(height: 16),
          Center(
            child: FilledButton(
              onPressed: () => _load(reset: true),
              child: const Text('Retry'),
            ),
          ),
        ],
      );
    }
    if (_articles.isEmpty) {
      return ListView(
        children: const [
          SizedBox(height: 160),
          Center(child: Text('No articles found.')),
        ],
      );
    }

    final showEnrichmentNote = !_hasEnrichment;
    final itemCount = _articles.length +
        (showEnrichmentNote ? 1 : 0) +
        (_nextPage != null ? 1 : 0);

    return ListView.builder(
      padding: const EdgeInsets.all(12),
      itemCount: itemCount,
      itemBuilder: (context, index) {
        var i = index;
        if (showEnrichmentNote) {
          if (i == 0) return _enrichmentNote();
          i -= 1;
        }
        if (i < _articles.length) {
          return _articleCard(_articles[i]);
        }
        if (!_loadingMore) {
          WidgetsBinding.instance
              .addPostFrameCallback((_) => _load(reset: false));
        }
        return const Padding(
          padding: EdgeInsets.all(16),
          child: Center(child: CircularProgressIndicator()),
        );
      },
    );
  }

  Widget _enrichmentNote() {
    return Card(
      margin: const EdgeInsets.only(bottom: 12),
      color: Colors.blueGrey.shade900,
      child: Padding(
        padding: const EdgeInsets.all(14),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                _sentimentBadge('positive'),
                const SizedBox(width: 6),
                _sentimentBadge('neutral'),
                const SizedBox(width: 6),
                _sentimentBadge('negative'),
              ],
            ),
            const SizedBox(height: 8),
            Text(
              'Sample \u2014 sentiment badges, AI tags and AI summaries appear '
              'here when your newsdata.io plan returns them. The keyword tags '
              'below come through on the free plan.',
              style: TextStyle(fontSize: 12, color: Colors.grey.shade300),
            ),
          ],
        ),
      ),
    );
  }

  Widget _sentimentBadge(String sentiment) {
    final color = _sentimentColor(sentiment);
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
      decoration: BoxDecoration(
        color: color.withOpacity(0.18),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: color),
      ),
      child: Text(
        sentiment,
        style: TextStyle(
            color: color, fontSize: 11, fontWeight: FontWeight.w600),
      ),
    );
  }

  Color _sentimentColor(String sentiment) {
    switch (sentiment) {
      case 'positive':
        return Colors.green;
      case 'negative':
        return Colors.redAccent;
      default:
        return Colors.blueGrey;
    }
  }

  Widget _articleCard(Article a) {
    return Card(
      margin: const EdgeInsets.only(bottom: 12),
      clipBehavior: Clip.antiAlias,
      child: Padding(
        padding: const EdgeInsets.all(14),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            if (a.imageUrl != null)
              Padding(
                padding: const EdgeInsets.only(bottom: 10),
                child: ClipRRect(
                  borderRadius: BorderRadius.circular(8),
                  child: Image.network(
                    a.imageUrl!,
                    height: 160,
                    width: double.infinity,
                    fit: BoxFit.cover,
                    errorBuilder: (_, __, ___) => const SizedBox.shrink(),
                  ),
                ),
              ),
            Row(
              children: [
                if (a.sentiment != null) ...[
                  _sentimentBadge(a.sentiment!),
                  const SizedBox(width: 8),
                ],
                Expanded(
                  child: Text(
                    a.sourceName ?? 'Unknown source',
                    style:
                        TextStyle(fontSize: 12, color: Colors.grey.shade400),
                  ),
                ),
                if (a.publishedAt != null)
                  Text(
                    DateFormat.MMMd().add_jm().format(a.publishedAt!.toLocal()),
                    style:
                        TextStyle(fontSize: 11, color: Colors.grey.shade500),
                  ),
              ],
            ),
            const SizedBox(height: 8),
            Text(
              a.title,
              style: const TextStyle(
                  fontSize: 16, fontWeight: FontWeight.w600, height: 1.3),
            ),
            if (a.aiSummary != null) ...[
              const SizedBox(height: 6),
              Text(
                a.aiSummary!,
                style: TextStyle(
                    fontSize: 13,
                    fontStyle: FontStyle.italic,
                    color: Colors.grey.shade300),
              ),
            ] else if (a.description != null) ...[
              const SizedBox(height: 6),
              Text(
                a.description!,
                maxLines: 3,
                overflow: TextOverflow.ellipsis,
                style: TextStyle(fontSize: 13, color: Colors.grey.shade300),
              ),
            ],
            if (a.aiTags.isNotEmpty) ...[
              const SizedBox(height: 10),
              _chipRow('AI tags', a.aiTags, Colors.purpleAccent),
            ],
            if (a.keywords.isNotEmpty) ...[
              const SizedBox(height: 10),
              _chipRow('Keywords', a.keywords.take(6).toList(),
                  Theme.of(context).colorScheme.primary),
            ],
          ],
        ),
      ),
    );
  }

  Widget _chipRow(String label, List<String> values, Color color) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          label,
          style: TextStyle(
              fontSize: 11,
              fontWeight: FontWeight.bold,
              color: Colors.grey.shade500),
        ),
        const SizedBox(height: 4),
        Wrap(
          spacing: 6,
          runSpacing: 6,
          children: values
              .map((v) => Container(
                    padding: const EdgeInsets.symmetric(
                        horizontal: 9, vertical: 4),
                    decoration: BoxDecoration(
                      color: color.withOpacity(0.14),
                      borderRadius: BorderRadius.circular(20),
                    ),
                    child:
                        Text(v, style: TextStyle(fontSize: 11, color: color)),
                  ))
              .toList(),
        ),
      ],
    );
  }
}
