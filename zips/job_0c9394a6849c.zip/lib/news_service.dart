import 'dart:convert';

import 'package:http/http.dart' as http;

/// Thrown for any error worth showing to the user (network, auth, API).
class NewsException implements Exception {
  NewsException(this.message);
  final String message;
  @override
  String toString() => message;
}

/// A single news article. Paid/enriched fields are nullable and simply absent
/// on a free newsdata.io key, so every access is guarded.
class Article {
  Article({
    required this.title,
    this.link,
    this.description,
    this.sourceName,
    this.imageUrl,
    this.publishedAt,
    this.keywords = const [],
    this.aiTags = const [],
    this.sentiment,
    this.aiSummary,
  });

  final String title;
  final String? link;
  final String? description;
  final String? sourceName;
  final String? imageUrl;
  final DateTime? publishedAt;
  final List<String> keywords;
  final List<String> aiTags;
  final String? sentiment;
  final String? aiSummary;

  static List<String> _stringList(dynamic value) {
    if (value is List) {
      return value
          .whereType<String>()
          .map((e) => e.trim())
          .where((e) => e.isNotEmpty)
          .toList();
    }
    return const [];
  }

  static String? _text(dynamic value) {
    if (value is String && value.trim().isNotEmpty) return value.trim();
    return null;
  }

  // On a free key, `sentiment` is null or a plan-notice string. Only accept the
  // known values so the UI never renders a bogus badge.
  static String? _sentiment(dynamic value) {
    if (value is String) {
      final s = value.toLowerCase().trim();
      if (s == 'positive' || s == 'negative' || s == 'neutral') return s;
    }
    return null;
  }

  factory Article.fromJson(Map<String, dynamic> json) {
    DateTime? published;
    final rawDate = json['pubDate'];
    if (rawDate is String) {
      published = DateTime.tryParse(rawDate.replaceFirst(' ', 'T'));
    }
    return Article(
      title: _text(json['title']) ?? '(untitled)',
      link: _text(json['link']),
      description: _text(json['description']),
      sourceName: _text(json['source_name']) ?? _text(json['source_id']),
      imageUrl: _text(json['image_url']),
      publishedAt: published,
      keywords: _stringList(json['keywords']),
      aiTags: _stringList(json['ai_tag']),
      sentiment: _sentiment(json['sentiment']),
      aiSummary: _text(json['ai_summary']),
    );
  }
}

/// One page of results plus the cursor for the next page (null when done).
class NewsPage {
  NewsPage(this.articles, this.nextPage);
  final List<Article> articles;
  final String? nextPage;
}

/// Thin client over the newsdata.io latest-news endpoint.
class NewsService {
  NewsService(this.apiKey, {this.enablePaid = false});

  final String apiKey;
  final bool enablePaid;

  static const String _base = 'https://newsdata.io/api/1';

  Future<NewsPage> fetchLatest({String query = '', String? page}) {
    return _request(query: query, page: page, paid: enablePaid);
  }

  Future<NewsPage> _request({
    required String query,
    String? page,
    required bool paid,
  }) async {
    final params = <String, String>{
      'apikey': apiKey,
      'language': 'en',
    };
    if (query.trim().isNotEmpty) params['q'] = query.trim();
    if (page != null) params['page'] = page;
    if (paid) {
      // Paid-only query param; errors on a free key and is retried without it.
      params['full_content'] = '1';
    }

    final uri = Uri.parse('$_base/latest').replace(queryParameters: params);

    http.Response res;
    try {
      res = await http.get(uri).timeout(const Duration(seconds: 20));
    } catch (e) {
      throw NewsException('Network error. Check your connection and retry.');
    }

    if (res.statusCode == 401) {
      throw NewsException('Invalid API key (401). Check NEWSDATA_API_KEY.');
    }
    if (res.statusCode == 429) {
      throw NewsException('Rate limit reached (429). Wait a moment, then retry.');
    }
    if ((res.statusCode == 403 || res.statusCode == 422) && paid) {
      // Paid params rejected on a free key — retry once without them.
      return _request(query: query, page: page, paid: false);
    }
    if (res.statusCode >= 400) {
      throw NewsException('Request failed (${res.statusCode}).');
    }

    dynamic body;
    try {
      body = jsonDecode(res.body);
    } catch (_) {
      throw NewsException('Could not read the response from newsdata.io.');
    }

    if (body is! Map || body['status'] != 'success') {
      final results = body is Map ? body['results'] : null;
      final msg = results is Map ? results['message'] : 'Unexpected API response';
      throw NewsException('API error: $msg');
    }

    final results = body['results'];
    final list = results is List ? results : const [];
    final articles = list
        .whereType<Map<String, dynamic>>()
        .map(Article.fromJson)
        .toList();
    final next = body['nextPage'] is String ? body['nextPage'] as String : null;
    return NewsPage(articles, next);
  }
}
