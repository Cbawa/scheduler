# flutter-news-widget

A small Flutter app with a home screen widget that shows the latest news headlines on your Android or iOS home screen. Headlines come from the newsdata.io news API (https://newsdata.io) — grab a free API key to run it.

The app lists current headlines and keeps a home screen widget in sync with the top story, so you can glance at the latest news without opening anything. Each article shows its source, publish time, and keyword tags. If your newsdata.io plan returns the enriched fields (sentiment, AI tags, AI summary), the app shows those too; on the free plan those areas fall back to a clearly labeled placeholder.

## Features

- Latest headlines from newsdata.io, with pull-to-refresh and load-more paging via the `nextPage` cursor.
- A native home screen widget (Android + iOS) showing the most recent headline; it refreshes when you reload in the app.
- Keyword tag chips on every article (available on the free plan).
- A sentiment badge, AI tag chips and a one-line AI summary when the API returns them; a labeled sample otherwise.
- Simple keyword search over headlines.

## Requirements

- Flutter 3.x / Dart 3.x
- A newsdata.io API key. Create a free one at https://newsdata.io. The key is read from the `NEWSDATA_API_KEY` value you pass at build time — it is never hardcoded into the app.

## Setup

This repo holds the Dart sources and the home screen widget files. Generate the platform folders with Flutter, then the widget files already in `android/` are picked up.

1. Clone and create the platform scaffolding:

   ```sh
   git clone <this-repo> flutter-news-widget
   cd flutter-news-widget
   flutter create --org com.example --project-name flutter_news_widget .
   ```

2. Install packages:

   ```sh
   flutter pub get
   ```

3. The Kotlin and XML widget files under `android/` ship with this repo. Register the widget in `android/app/src/main/AndroidManifest.xml`, inside the `<application>` element:

   ```xml
   <receiver
       android:name=".NewsWidgetProvider"
       android:exported="true">
       <intent-filter>
           <action android:name="android.appwidget.action.APPWIDGET_UPDATE" />
       </intent-filter>
       <meta-data
           android:name="android.appwidget.provider"
           android:resource="@xml/home_widget_info" />
   </receiver>
   ```

4. (iOS) Add a Widget Extension target in Xcode named `NewsWidget` and set an App Group `group.com.example.flutternewswidget` on both the app and the extension. The SwiftUI side of the widget follows the `home_widget` package docs.

## Run

Pass your key with `--dart-define`:

```sh
flutter run --dart-define=NEWSDATA_API_KEY=your_key_here
```

Build a release APK:

```sh
flutter build apk --dart-define=NEWSDATA_API_KEY=your_key_here
```

After the first successful load, long-press your home screen, add the "Latest News" widget, and it shows the top headline.

### Sample output

```
Latest News
[neutral]  Reuters · Jun 12, 7:42 PM
Markets steady as central banks signal a pause
Keywords:  markets  central banks  rates  economy

[ ]  BBC News · Jun 12, 7:30 PM
New telescope captures distant galaxy cluster
Keywords:  space  astronomy  telescope
```

(The `[neutral]` badge and AI fields only render when your plan returns them; otherwise a labeled sample row explains the feature.)

## Optional: paid plan fields

The default build sends only free-tier parameters. If you have a paid newsdata.io plan and want the app to request full article content, build with:

```sh
flutter run --dart-define=NEWSDATA_API_KEY=your_key --dart-define=ENABLE_PAID=true
```

Paid-only response fields (`sentiment`, `ai_tag`, `ai_summary`) are read automatically when present — no flag needed for those. If a paid request is rejected on a free key, the app retries once without the paid parameters so you still get results.

## Notes

- A `401` means the key is missing or wrong; a `429` means you hit the rate limit. Both are shown in the app instead of crashing.
- Free keys return up to 10 articles per page; the app pages through results with the `nextPage` cursor.

## License

MIT
