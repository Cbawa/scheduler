package com.example.flutter_news_widget

import android.appwidget.AppWidgetManager
import android.content.Context
import android.content.SharedPreferences
import android.widget.RemoteViews
import es.antonborri.home_widget.HomeWidgetLaunchIntent
import es.antonborri.home_widget.HomeWidgetProvider

/**
 * Home screen widget for the latest headline. Values are written by the Flutter
 * app via the home_widget plugin and read back here from SharedPreferences.
 */
class NewsWidgetProvider : HomeWidgetProvider() {
    override fun onUpdate(
        context: Context,
        appWidgetManager: AppWidgetManager,
        appWidgetIds: IntArray,
        widgetData: SharedPreferences
    ) {
        appWidgetIds.forEach { widgetId ->
            val views = RemoteViews(context.packageName, R.layout.news_widget).apply {
                val headline = widgetData.getString("headline", null)
                    ?: "Open the app to load headlines"
                val source = widgetData.getString("source", null) ?: ""
                val updated = widgetData.getString("updated", null) ?: ""

                setTextViewText(R.id.widget_headline, headline)
                setTextViewText(R.id.widget_source, source)
                setTextViewText(R.id.widget_updated, updated)

                // Tapping the widget opens the app.
                val pendingIntent = HomeWidgetLaunchIntent.getActivity(
                    context,
                    MainActivity::class.java
                )
                setOnClickPendingIntent(R.id.widget_root, pendingIntent)
            }
            appWidgetManager.updateAppWidget(widgetId, views)
        }
    }
}
