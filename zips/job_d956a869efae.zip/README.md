# ESG News Tracker

Track **ESG (Environmental, Social, Governance)** news for any company and get a
lightweight **weekly ESG score heuristic** — built on top of the
[newsdata.io](https://newsdata.io) news API and presented in a clean
[Streamlit](https://streamlit.io) dashboard.

![Python](https://img.shields.io/badge/python-3.9+-blue)
![Streamlit](https://img.shields.io/badge/streamlit-app-red)

## What it does

- Search the latest news for any company name using the newsdata.io `/news` endpoint.
- Classify every article into **E**, **S** or **G** buckets (or *General*) with a
  transparent keyword heuristic.
- Compute a **weekly ESG score** (0–100) from sentiment-bearing keywords in the
  headlines and descriptions — no paid features required.
- Browse the underlying articles with links, sources and publication dates.
- Visualise the ESG topic mix and the weekly score trend.

> **Note on the score.** The ESG score here is a *heuristic* meant for outreach /
> demo purposes. It is derived from keyword matching on free-tier news fields, not
> from an audited ESG rating methodology. Use it as a directional signal only.

## Why newsdata.io

[newsdata.io](https://newsdata.io) offers a simple, generous REST news API. This
project is intentionally built to run **entirely on the FREE plan** — see the
[Free tier & paid features](#free-tier--paid-features) section.

## Quick start

### 1. Get a free API key

Sign up at [newsdata.io](https://newsdata.io) and copy your API key from the
dashboard.

### 2. Install

```bash
git clone https://github.com/yourname/esg-news-tracker.git
cd esg-news-tracker
pip install -r requirements.txt
```

### 3. Set your API key

The key is read from the `NEWSDATA_API_KEY` environment variable. **Never commit
your key.**

```bash
# macOS / Linux
export NEWSDATA_API_KEY="pub_xxxxxxxxxxxxxxxxxxxxxxxx"

# Windows (PowerShell)
$env:NEWSDATA_API_KEY="pub_xxxxxxxxxxxxxxxxxxxxxxxx"
```

### 4. Run

```bash
streamlit run app.py
```

Your browser opens at `http://localhost:8501`. Type a company name and explore.

## How the ESG score works

1. Articles for the company are fetched from `/news` (free tier).
2. Each article is classified into **E / S / G / General** using the keyword sets
   in `esg.py`.
3. Positive and negative ESG keywords in the title + description produce a
   per-article polarity in `[-1, 1]`.
4. Articles are grouped by ISO week; each week's polarity is averaged and mapped
   onto a `0–100` score (50 = neutral).

Everything is in plain Python in `esg.py` so you can tweak the keyword lists and
weights to fit your own definition of ESG.

## Free tier & paid features

This app runs on the **free** newsdata.io plan. It deliberately avoids paid-only
capabilities:

| Feature | Plan | Used here? |
|---|---|---|
| `/news` latest news, `q`, `language`, `category`, pagination | Free | ✅ Yes |
| Built-in `sentiment` field | Paid | ❌ No — we compute our own heuristic |
| AI fields (`ai_tag`, `ai_region`, `ai_org`, `ai_summary`) | Paid | ❌ No |
| `/archive` & long historical date ranges | Paid | ❌ No |
| Advanced full-text query operators | Paid | ❌ No |

If you later upgrade, the app still works — it simply ignores fields it does not
need. The client also handles `401` (invalid key), `429` (rate limit) and empty
results gracefully so a free key never crashes the UI.

## Project layout

```
esg-news-tracker/
├── app.py            # Streamlit UI
├── newsdata.py       # Thin newsdata.io API client (free-tier safe)
├── esg.py            # ESG classification + weekly score heuristic
├── requirements.txt
├── .gitignore
└── README.md
```

## License

MIT — see below. Built as a community showcase for the newsdata.io news API.
