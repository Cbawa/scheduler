"""ESG News Tracker — Streamlit front-end.

Tracks ESG (environmental, social, governance) news for a company via the
newsdata.io news API and computes a weekly ESG score heuristic. Designed to run
entirely on the newsdata.io FREE plan.
"""
from __future__ import annotations

import os

import pandas as pd
import streamlit as st

from newsdata import NewsDataClient, NewsDataError
from esg import (
    CATEGORY_LABELS,
    classify_articles,
    weekly_esg_scores,
    topic_breakdown,
    overall_score,
)

st.set_page_config(
    page_title="ESG News Tracker",
    page_icon="\U0001F33F",
    layout="wide",
)


def get_api_key() -> str | None:
    """Read the newsdata.io key from the environment (never hardcoded)."""
    return os.environ.get("NEWSDATA_API_KEY")


@st.cache_data(show_spinner=False, ttl=900)
def fetch_company_news(company: str, language: str, max_pages: int) -> list[dict]:
    """Fetch and cache news for a company. Cached for 15 minutes per query."""
    client = NewsDataClient(get_api_key())
    return client.search_company(company, language=language, max_pages=max_pages)


def score_color(score: float) -> str:
    if score >= 60:
        return "#2e7d32"  # green
    if score >= 45:
        return "#f9a825"  # amber
    return "#c62828"      # red


def main() -> None:
    st.title("\U0001F33F ESG News Tracker")
    st.caption(
        "Track environmental, social & governance news for any company "
        "via the newsdata.io news API."
    )

    api_key = get_api_key()
    if not api_key:
        st.error(
            "**NEWSDATA_API_KEY is not set.**\n\n"
            "Get a free key at https://newsdata.io and export it before running:\n\n"
            "```bash\nexport NEWSDATA_API_KEY=\"your_key_here\"\n```"
        )
        st.stop()

    with st.sidebar:
        st.header("Search")
        company = st.text_input("Company name", value="Tesla")
        language = st.selectbox(
            "Language",
            options=["en", "de", "fr", "es", "it", "pt", "nl"],
            index=0,
        )
        max_pages = st.slider(
            "Pages to fetch",
            min_value=1,
            max_value=5,
            value=2,
            help="Each page is one free-tier API request (~10 articles).",
        )
        run = st.button("Track ESG news", type="primary", use_container_width=True)
        st.markdown("---")
        st.caption(
            "The ESG score is a keyword heuristic for demo purposes, not an "
            "audited rating. Runs on the newsdata.io free plan."
        )

    if not run:
        st.info("Enter a company name in the sidebar and click **Track ESG news**.")
        return

    if not company.strip():
        st.warning("Please enter a company name.")
        return

    with st.spinner(f"Fetching news for '{company}'\u2026"):
        try:
            articles = fetch_company_news(company.strip(), language, max_pages)
        except NewsDataError as exc:
            st.error(str(exc))
            return

    if not articles:
        st.warning(
            f"No recent news found for '{company}'. Try another company name or "
            "a different language."
        )
        return

    classified = classify_articles(articles)
    overall = overall_score(classified)
    breakdown = topic_breakdown(classified)
    weekly = weekly_esg_scores(classified)

    # --- Headline metrics -------------------------------------------------
    st.subheader(f"Results for **{company}**")
    col1, col2, col3, col4 = st.columns(4)
    col1.metric("Articles analysed", len(classified))
    color = score_color(overall)
    col2.markdown(
        f"**Overall ESG score**\n\n"
        f"<span style='font-size:2rem;color:{color};font-weight:700'>{overall:.0f}"
        f"</span> / 100",
        unsafe_allow_html=True,
    )
    esg_count = sum(
        1 for a in classified if a["esg_category"] in ("E", "S", "G")
    )
    col3.metric("ESG-relevant articles", esg_count)
    col4.metric("Weeks covered", len(weekly))

    st.markdown("---")

    # --- Charts -----------------------------------------------------------
    left, right = st.columns(2)

    with left:
        st.markdown("#### Topic mix")
        mix_df = pd.DataFrame(
            {
                "Category": [CATEGORY_LABELS[k] for k in breakdown],
                "Articles": list(breakdown.values()),
            }
        ).set_index("Category")
        st.bar_chart(mix_df)

    with right:
        st.markdown("#### Weekly ESG score trend")
        if weekly:
            trend_df = pd.DataFrame(
                {
                    "Week": list(weekly.keys()),
                    "ESG score": list(weekly.values()),
                }
            ).set_index("Week")
            st.line_chart(trend_df)
        else:
            st.caption("Not enough dated articles to build a weekly trend.")

    st.markdown("---")

    # --- Weekly table -----------------------------------------------------
    if weekly:
        st.markdown("#### Weekly ESG scores")
        weekly_table = pd.DataFrame(
            {
                "Week (ISO)": list(weekly.keys()),
                "ESG score (0\u2013100)": [round(v, 1) for v in weekly.values()],
            }
        )
        st.dataframe(weekly_table, use_container_width=True, hide_index=True)

    # --- Article list -----------------------------------------------------
    st.markdown("#### Articles")
    category_filter = st.multiselect(
        "Filter by ESG category",
        options=list(CATEGORY_LABELS.values()),
        default=list(CATEGORY_LABELS.values()),
    )
    selected_keys = {
        k for k, v in CATEGORY_LABELS.items() if v in category_filter
    }

    shown = 0
    for art in classified:
        if art["esg_category"] not in selected_keys:
            continue
        shown += 1
        label = CATEGORY_LABELS[art["esg_category"]]
        title = art.get("title") or "(untitled)"
        link = art.get("link") or ""
        source = art.get("source_id") or "unknown source"
        pub = art.get("pubDate") or ""
        polarity = art.get("esg_polarity", 0.0)
        sign = "\U0001F7E2" if polarity > 0.05 else (
            "\U0001F534" if polarity < -0.05 else "\u26AA"
        )
        with st.container(border=True):
            if link:
                st.markdown(f"**[{title}]({link})**")
            else:
                st.markdown(f"**{title}**")
            st.caption(
                f"{sign} {label}  \u2022  {source}  \u2022  {pub}"
            )
            desc = art.get("description")
            if desc:
                st.write(desc)

    if shown == 0:
        st.caption("No articles match the selected filters.")


if __name__ == "__main__":
    main()
