"""Thin, free-tier-safe client for the newsdata.io news API.

Only uses endpoints and parameters available on the FREE plan:
  - GET /news with q, language, category and `page` pagination.

The API key is read by the caller from the NEWSDATA_API_KEY environment
variable and passed in — it is never hardcoded here.
"""
from __future__ import annotations

import time
from typing import Any

import requests

BASE_URL = "https://newsdata.io/api/1"


class NewsDataError(Exception):
    """Raised for any user-facing newsdata.io error (clear, friendly message)."""


class NewsDataClient:
    """Minimal client around the newsdata.io /news endpoint."""

    def __init__(self, api_key: str | None, timeout: int = 20) -> None:
        if not api_key:
            raise NewsDataError(
                "NEWSDATA_API_KEY is not set. Get a free key at "
                "https://newsdata.io and export it as an environment variable."
            )
        self.api_key = api_key
        self.timeout = timeout
        self.session = requests.Session()

    def _get(self, endpoint: str, params: dict[str, Any]) -> dict[str, Any]:
        params = {**params, "apikey": self.api_key}
        url = f"{BASE_URL}/{endpoint}"
        try:
            resp = self.session.get(url, params=params, timeout=self.timeout)
        except requests.RequestException as exc:
            raise NewsDataError(f"Network error contacting newsdata.io: {exc}") from exc

        # Handle the well-known status codes gracefully.
        if resp.status_code == 401:
            raise NewsDataError(
                "Invalid API key (401). Double-check your NEWSDATA_API_KEY."
            )
        if resp.status_code == 429:
            raise NewsDataError(
                "Rate limit reached (429). The free plan has a request cap \u2014 "
                "please wait a moment and try again, or reduce the pages to fetch."
            )
        if resp.status_code in (403, 422):
            # Typically a request for a paid-only feature. Surface gently.
            raise NewsDataError(
                "This request needs a paid newsdata.io plan ("
                f"{resp.status_code}). This app is designed for the free plan \u2014 "
                "please remove any paid-only parameters."
            )
        if resp.status_code >= 400:
            raise NewsDataError(
                f"newsdata.io returned an error ({resp.status_code}). "
                "Please try again later."
            )

        try:
            data = resp.json()
        except ValueError as exc:
            raise NewsDataError("Could not parse the newsdata.io response.") from exc

        if data.get("status") == "error":
            message = "Unknown error"
            results = data.get("results")
            if isinstance(results, dict):
                message = results.get("message", message)
            raise NewsDataError(f"newsdata.io error: {message}")

        return data

    def search_company(
        self,
        company: str,
        language: str = "en",
        max_pages: int = 2,
    ) -> list[dict[str, Any]]:
        """Return latest-news articles mentioning `company`.

        Uses free-tier pagination via the `nextPage` token. Returns a flat list
        of article dicts (possibly empty) and never raises on empty results.
        """
        articles: list[dict[str, Any]] = []
        next_page: str | None = None
        pages = max(1, int(max_pages))

        for _ in range(pages):
            params: dict[str, Any] = {
                "q": company,
                "language": language,
            }
            if next_page:
                params["page"] = next_page

            data = self._get("news", params)
            results = data.get("results") or []
            if isinstance(results, list):
                articles.extend(results)

            next_page = data.get("nextPage")
            if not next_page:
                break
            # Be gentle with the free-tier rate limit between pages.
            time.sleep(0.4)

        return articles
