"""ESG classification and a weekly ESG score heuristic.

Everything here works on the FREE newsdata.io fields (title, description,
pubDate). No paid sentiment / ai_* fields are used \u2014 we compute a transparent
keyword-based polarity instead.
"""
from __future__ import annotations

from collections import defaultdict
from datetime import datetime
from typing import Any

CATEGORY_LABELS = {
    "E": "Environmental",
    "S": "Social",
    "G": "Governance",
    "GEN": "General",
}

# Keyword sets used to bucket an article into E / S / G.
E_KEYWORDS = {
    "climate", "carbon", "emission", "emissions", "renewable", "solar",
    "wind", "pollution", "sustainability", "sustainable", "recycling",
    "biodiversity", "deforestation", "greenhouse", "net zero", "net-zero",
    "clean energy", "environmental", "waste", "water", "ecosystem",
}
S_KEYWORDS = {
    "diversity", "inclusion", "human rights", "labor", "labour", "workers",
    "community", "safety", "health", "employee", "employees", "wages",
    "discrimination", "harassment", "privacy", "data breach", "social",
    "gender", "equality", "philanthropy", "strike", "union",
}
G_KEYWORDS = {
    "governance", "board", "executive", "compensation", "bribery",
    "corruption", "fraud", "compliance", "regulation", "regulatory",
    "audit", "shareholder", "transparency", "lawsuit", "sanction",
    "sanctions", "whistleblower", "ethics", "antitrust", "fine", "fined",
}

# Polarity keywords for the heuristic score.
POSITIVE_KEYWORDS = {
    "award", "awarded", "invest", "investment", "growth", "improve",
    "improved", "reduce", "reduced", "renewable", "clean", "pledge",
    "commit", "commitment", "sustainable", "sustainability", "donate",
    "donation", "breakthrough", "approval", "approved", "partnership",
    "transparency", "diversity", "inclusion", "net zero", "net-zero",
}
NEGATIVE_KEYWORDS = {
    "lawsuit", "fine", "fined", "fraud", "scandal", "pollution", "breach",
    "violation", "violations", "corruption", "bribery", "emission",
    "emissions", "layoff", "layoffs", "strike", "protest", "recall",
    "discrimination", "harassment", "penalty", "investigation", "spill",
    "toxic", "sanction", "sanctions", "deforestation", "controversy",
}


def _text_of(article: dict[str, Any]) -> str:
    parts = [article.get("title") or "", article.get("description") or ""]
    return " ".join(parts).lower()


def _classify_category(text: str) -> str:
    scores = {
        "E": sum(1 for kw in E_KEYWORDS if kw in text),
        "S": sum(1 for kw in S_KEYWORDS if kw in text),
        "G": sum(1 for kw in G_KEYWORDS if kw in text),
    }
    best = max(scores, key=scores.get)
    if scores[best] == 0:
        return "GEN"
    return best


def _polarity(text: str) -> float:
    """Return a polarity in [-1, 1] from keyword counts."""
    pos = sum(1 for kw in POSITIVE_KEYWORDS if kw in text)
    neg = sum(1 for kw in NEGATIVE_KEYWORDS if kw in text)
    total = pos + neg
    if total == 0:
        return 0.0
    return (pos - neg) / total


def classify_articles(articles: list[dict[str, Any]]) -> list[dict[str, Any]]:
    """Annotate each article with `esg_category` and `esg_polarity`."""
    annotated: list[dict[str, Any]] = []
    for art in articles:
        text = _text_of(art)
        enriched = dict(art)
        enriched["esg_category"] = _classify_category(text)
        enriched["esg_polarity"] = _polarity(text)
        annotated.append(enriched)
    return annotated


def topic_breakdown(classified: list[dict[str, Any]]) -> dict[str, int]:
    """Count of articles per ESG category (always includes all four keys)."""
    counts = {k: 0 for k in CATEGORY_LABELS}
    for art in classified:
        counts[art.get("esg_category", "GEN")] += 1
    return counts


def _polarity_to_score(polarity: float) -> float:
    """Map polarity [-1, 1] onto an ESG score [0, 100] (50 = neutral)."""
    return round((polarity + 1.0) * 50.0, 1)


def _iso_week(pub_date: str | None) -> str | None:
    if not pub_date:
        return None
    for fmt in ("%Y-%m-%d %H:%M:%S", "%Y-%m-%dT%H:%M:%S", "%Y-%m-%d"):
        try:
            dt = datetime.strptime(pub_date[: len(fmt) + 2].strip(), fmt)
            year, week, _ = dt.isocalendar()
            return f"{year}-W{week:02d}"
        except (ValueError, TypeError):
            continue
    return None


def weekly_esg_scores(classified: list[dict[str, Any]]) -> dict[str, float]:
    """Average polarity per ISO week, mapped to a 0\u2013100 score.

    Returns an ordered dict keyed by `YYYY-Www`. Articles without a parseable
    date are skipped. ESG-relevant articles weigh the same as general ones so a
    sparse week still yields a stable score.
    """
    buckets: dict[str, list[float]] = defaultdict(list)
    for art in classified:
        week = _iso_week(art.get("pubDate"))
        if week is None:
            continue
        buckets[week].append(float(art.get("esg_polarity", 0.0)))

    scores: dict[str, float] = {}
    for week in sorted(buckets):
        polarities = buckets[week]
        avg = sum(polarities) / len(polarities) if polarities else 0.0
        scores[week] = _polarity_to_score(avg)
    return scores


def overall_score(classified: list[dict[str, Any]]) -> float:
    """A single 0\u2013100 ESG score across all articles."""
    if not classified:
        return 50.0
    avg = sum(float(a.get("esg_polarity", 0.0)) for a in classified) / len(classified)
    return _polarity_to_score(avg)
