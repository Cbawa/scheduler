import mongoose from 'mongoose';
import { config } from '../config.js';

const { Schema } = mongoose;

/**
 * Mongoose schema mirroring the newsdata.io /news response object.
 * `strict: false` lets us transparently store any extra fields the API
 * returns (including paid-only fields like ai_tag / sentiment if you ever
 * upgrade your plan) without changing this schema.
 */
const ArticleSchema = new Schema(
  {
    article_id: { type: String, index: true },
    title: { type: String, required: true },
    // unique deduplication key
    link: { type: String, required: true, unique: true },
    keywords: { type: [String], default: [] },
    creator: { type: [String], default: [] },
    video_url: { type: String, default: null },
    description: { type: String, default: '' },
    content: { type: String, default: '' },
    pubDate: { type: String, default: '' },
    // parsed Date used for range filtering AND the TTL index
    pubDateTime: { type: Date, default: null },
    image_url: { type: String, default: null },
    source_id: { type: String, index: true },
    source_priority: { type: Number, default: null },
    source_name: { type: String, default: '' },
    source_url: { type: String, default: '' },
    source_icon: { type: String, default: '' },
    language: { type: String, default: '' },
    country: { type: [String], default: [] },
    category: { type: [String], default: [] },
  },
  {
    strict: false,
    timestamps: true,
    collection: 'articles',
  }
);

// Full-text search index across the most useful text fields.
ArticleSchema.index({
  title: 'text',
  description: 'text',
  content: 'text',
  keywords: 'text',
});

// TTL index: documents expire ~30 days after their publish time, keeping the
// archive a rolling window. `expireAfterSeconds` matches the spec (2592000).
ArticleSchema.index(
  { pubDateTime: 1 },
  { expireAfterSeconds: config.ttlSeconds }
);

export const Article =
  mongoose.models.Article || mongoose.model('Article', ArticleSchema);
