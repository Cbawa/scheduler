import express from 'express';
import { Article } from './models/Article.js';

export function createServer() {
  const app = express();
  app.use(express.json());

  // Health check
  app.get('/health', async (_req, res) => {
    try {
      const count = await Article.estimatedDocumentCount();
      res.json({ status: 'ok', articles: count });
    } catch (err) {
      res.status(500).json({ status: 'error', message: err.message });
    }
  });

  // Friendly index
  app.get('/', (_req, res) => {
    res.json({
      name: 'news-mongodb-archive',
      endpoints: ['/search', '/sources', '/health'],
      powered_by: 'newsdata.io',
    });
  });

  /**
   * GET /search?q=&category=&country=&from=&to=&page=&limit=
   * MongoDB full-text search with optional filters and pagination.
   */
  app.get('/search', async (req, res) => {
    try {
      const { q, category, country, from, to } = req.query;
      const page = Math.max(parseInt(req.query.page, 10) || 1, 1);
      const limit = Math.min(Math.max(parseInt(req.query.limit, 10) || 20, 1), 100);

      const filter = {};
      let projection = {};
      let sort = { pubDateTime: -1 };

      if (q && q.trim()) {
        filter.$text = { $search: q.trim() };
        projection = { score: { $meta: 'textScore' } };
        sort = { score: { $meta: 'textScore' }, pubDateTime: -1 };
      }
      if (category) filter.category = category.toLowerCase();
      if (country) filter.country = country.toLowerCase();

      // Date range on the parsed publish time.
      const dateFilter = {};
      if (from) {
        const d = new Date(from);
        if (!Number.isNaN(d.getTime())) dateFilter.$gte = d;
      }
      if (to) {
        const d = new Date(to);
        if (!Number.isNaN(d.getTime())) {
          // include the whole "to" day
          d.setHours(23, 59, 59, 999);
          dateFilter.$lte = d;
        }
      }
      if (Object.keys(dateFilter).length) filter.pubDateTime = dateFilter;

      const [total, results] = await Promise.all([
        Article.countDocuments(filter),
        Article.find(filter, projection)
          .sort(sort)
          .skip((page - 1) * limit)
          .limit(limit)
          .lean(),
      ]);

      res.json({
        query: { q, category, country, from, to },
        page,
        limit,
        total,
        results,
      });
    } catch (err) {
      res.status(500).json({ status: 'error', message: err.message });
    }
  });

  /**
   * GET /sources?limit=
   * Aggregate the top source_ids in the archive.
   */
  app.get('/sources', async (req, res) => {
    try {
      const limit = Math.min(Math.max(parseInt(req.query.limit, 10) || 20, 1), 200);
      const sources = await Article.aggregate([
        { $match: { source_id: { $ne: null } } },
        { $group: { _id: '$source_id', count: { $sum: 1 } } },
        { $sort: { count: -1 } },
        { $limit: limit },
        { $project: { _id: 0, source_id: '$_id', count: 1 } },
      ]);
      res.json({ total: sources.length, sources });
    } catch (err) {
      res.status(500).json({ status: 'error', message: err.message });
    }
  });

  // 404 fallback
  app.use((_req, res) => {
    res.status(404).json({ status: 'error', message: 'Not found' });
  });

  return app;
}
