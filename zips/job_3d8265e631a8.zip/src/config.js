import dotenv from 'dotenv';

dotenv.config();

const DEFAULT_CATEGORIES =
  'top,business,technology,science,health,sports,entertainment,world';

function parseList(value, fallback) {
  const raw = (value ?? fallback ?? '').trim();
  if (!raw) return [];
  return raw
    .split(',')
    .map((s) => s.trim().toLowerCase())
    .filter(Boolean);
}

function parseInteger(value, fallback) {
  const n = parseInt(value, 10);
  return Number.isFinite(n) && n > 0 ? n : fallback;
}

export const config = {
  // newsdata.io
  apiKey: process.env.NEWSDATA_API_KEY,
  baseUrl: 'https://newsdata.io/api/1',

  // MongoDB
  mongoUri: process.env.MONGODB_URI || 'mongodb://127.0.0.1:27017',
  mongoDb: process.env.MONGODB_DB || 'news_archive',

  // API server
  port: parseInteger(process.env.PORT, 3000),

  // Archiver
  categories: parseList(process.env.FETCH_CATEGORIES, DEFAULT_CATEGORIES),
  language: (process.env.FETCH_LANGUAGE || 'en').trim() || 'en',
  country: parseList(process.env.FETCH_COUNTRY, ''),
  maxPages: parseInteger(process.env.MAX_PAGES, 2),
  cronSchedule: process.env.CRON_SCHEDULE || '0 6 * * *',

  // 30 days, used for the TTL index
  ttlSeconds: 2592000,
};

/**
 * Fail fast (with a friendly message) if the API key is missing.
 * Called by the entry points that actually need to hit the API.
 */
export function requireApiKey() {
  if (!config.apiKey) {
    console.error(
      '\n[config] NEWSDATA_API_KEY is not set.\n' +
        '         Get a free key at https://newsdata.io/register and either:\n' +
        '           export NEWSDATA_API_KEY=your_key_here\n' +
        '         or copy .env.example to .env and fill it in.\n'
    );
    process.exit(1);
  }
}
