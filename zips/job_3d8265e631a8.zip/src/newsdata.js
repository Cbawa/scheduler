import axios from 'axios';
import { config } from './config.js';

const client = axios.create({
  baseURL: config.baseUrl,
  timeout: 20000,
});

/**
 * Error thrown when newsdata.io returns a paid-only / upgrade response so the
 * caller can skip that feature gracefully instead of crashing.
 */
export class UpgradeRequiredError extends Error {}

/**
 * Fetch a single page of /news.
 * Returns { results: [], nextPage: string|null }.
 * Throws UpgradeRequiredError on 403/422 (paid-only) so callers can degrade.
 */
export async function fetchNewsPage(params = {}) {
  try {
    const { data } = await client.get('/news', {
      params: { apikey: config.apiKey, ...params },
    });

    if (data && data.status === 'error') {
      const msg = data.results?.message || 'newsdata.io returned an error';
      throw new Error(msg);
    }

    return {
      results: Array.isArray(data.results) ? data.results : [],
      nextPage: data.nextPage || null,
      totalResults: data.totalResults || 0,
    };
  } catch (err) {
    const status = err.response?.status;
    const apiMessage =
      err.response?.data?.results?.message ||
      err.response?.data?.message ||
      err.message;

    if (status === 401) {
      console.error('[newsdata] 401 invalid API key — check NEWSDATA_API_KEY.');
      throw new Error('Invalid newsdata.io API key (401).');
    }
    if (status === 429) {
      console.warn('[newsdata] 429 rate limited — backing off this request.');
      return { results: [], nextPage: null, totalResults: 0 };
    }
    if (status === 403 || status === 422) {
      console.warn(
        `[newsdata] ${status} paid-only feature requested — skipping. (${apiMessage})`
      );
      throw new UpgradeRequiredError(apiMessage);
    }

    console.error(`[newsdata] request failed: ${apiMessage}`);
    throw err;
  }
}

/**
 * Fetch up to `maxPages` pages for the given query params, following the
 * `nextPage` pagination token returned by newsdata.io.
 */
export async function fetchNews(params = {}, maxPages = 1) {
  const all = [];
  let page = null;

  for (let i = 0; i < maxPages; i += 1) {
    const query = { ...params };
    if (page) query.page = page;

    let res;
    try {
      res = await fetchNewsPage(query);
    } catch (err) {
      if (err instanceof UpgradeRequiredError) break; // degrade gracefully
      throw err;
    }

    all.push(...res.results);
    if (!res.nextPage) break;
    page = res.nextPage;
  }

  return all;
}
