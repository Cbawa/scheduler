import cron from 'node-cron';
import { config, requireApiKey } from './config.js';
import { connectDB, disconnectDB } from './db.js';
import { Article } from './models/Article.js';
import { fetchNews } from './newsdata.js';

/**
 * Parse newsdata.io's "YYYY-MM-DD HH:mm:ss" pubDate into a JS Date (UTC).
 * Returns null when it can't be parsed so the document simply won't get a TTL.
 */
function parsePubDate(pubDate) {
  if (!pubDate) return null;
  const iso = pubDate.includes('T') ? pubDate : pubDate.replace(' ', 'T') + 'Z';
  const d = new Date(iso);
  return Number.isNaN(d.getTime()) ? null : d;
}

function normalizeToArray(value) {
  if (value == null) return [];
  return Array.isArray(value) ? value : [value];
}

/**
 * Map a raw newsdata.io article into our document shape and upsert it by `link`.
 */
async function upsertArticle(raw) {
  if (!raw || !raw.link) return false;

  const doc = {
    ...raw,
    keywords: normalizeToArray(raw.keywords),
    creator: normalizeToArray(raw.creator),
    country: normalizeToArray(raw.country),
    category: normalizeToArray(raw.category),
    pubDateTime: parsePubDate(raw.pubDate),
  };

  await Article.updateOne(
    { link: raw.link },
    { $set: doc },
    { upsert: true }
  );
  return true;
}

/**
 * Run one full archive pass over every configured category.
 */
export async function runArchive() {
  const categories = config.categories.length ? config.categories : ['top'];
  let upserted = 0;

  for (const category of categories) {
    const params = { language: config.language, category };
    if (config.country.length) params.country = config.country.join(',');

    try {
      const articles = await fetchNews(params, config.maxPages);
      for (const raw of articles) {
        if (await upsertArticle(raw)) upserted += 1;
      }
      console.log(
        `[archive] ${category}: fetched ${articles.length}, upserted into DB`
      );
    } catch (err) {
      // One bad category shouldn't kill the whole run.
      console.error(`[archive] ${category} failed: ${err.message}`);
    }
  }

  const total = await Article.estimatedDocumentCount();
  console.log(
    `[archive] done — processed ${upserted} articles, ${total} in archive.`
  );
  return { upserted, total };
}

/**
 * Schedule the daily archive job. Returns the cron task.
 */
export function scheduleArchive() {
  console.log(`[archive] scheduled with cron "${config.cronSchedule}"`);
  return cron.schedule(config.cronSchedule, () => {
    console.log('[archive] cron tick — starting daily archive...');
    runArchive().catch((err) =>
      console.error('[archive] cron run failed:', err.message)
    );
  });
}

// When run directly (`npm run fetch`): connect, archive once, exit.
const isMain =
  process.argv[1] && process.argv[1].endsWith('fetcher.js');

if (isMain) {
  requireApiKey();
  connectDB()
    .then(runArchive)
    .then(() => disconnectDB())
    .then(() => process.exit(0))
    .catch(async (err) => {
      console.error('[archive] fatal:', err.message);
      await disconnectDB();
      process.exit(1);
    });
}
