import { config, requireApiKey } from './config.js';
import { connectDB, disconnectDB } from './db.js';
import { createServer } from './server.js';
import { scheduleArchive } from './fetcher.js';

async function main() {
  requireApiKey();
  await connectDB();

  // Start the daily archive cron.
  scheduleArchive();

  // Start the REST API.
  const app = createServer();
  const server = app.listen(config.port, () => {
    console.log(`[api] listening on http://localhost:${config.port}`);
    console.log('[api] try: GET /search?q=technology   GET /sources   GET /health');
    console.log('[hint] run "npm run fetch" once to seed the archive.');
  });

  const shutdown = async (signal) => {
    console.log(`\n[app] received ${signal}, shutting down...`);
    server.close();
    await disconnectDB();
    process.exit(0);
  };
  process.on('SIGINT', () => shutdown('SIGINT'));
  process.on('SIGTERM', () => shutdown('SIGTERM'));
}

main().catch(async (err) => {
  console.error('[app] fatal:', err.message);
  await disconnectDB();
  process.exit(1);
});
