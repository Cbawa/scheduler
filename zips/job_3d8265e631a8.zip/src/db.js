import mongoose from 'mongoose';
import { config } from './config.js';

/**
 * Connect to MongoDB once and reuse the connection.
 */
export async function connectDB() {
  if (mongoose.connection.readyState === 1) {
    return mongoose.connection;
  }

  mongoose.set('strictQuery', true);

  await mongoose.connect(config.mongoUri, {
    dbName: config.mongoDb,
    serverSelectionTimeoutMS: 10000,
  });

  console.log(`[db] connected to ${config.mongoDb}`);
  return mongoose.connection;
}

export async function disconnectDB() {
  if (mongoose.connection.readyState !== 0) {
    await mongoose.disconnect();
    console.log('[db] disconnected');
  }
}
