# news-mongodb-archive

A small, production-shaped **Node.js + MongoDB** pipeline built around the
[newsdata.io](https://newsdata.io) news API.

It does two things:

1. **Archiver (cron job)** — once a day it fetches the latest news for every
   category from newsdata.io `/news`, then **upserts** each article into a
   MongoDB `articles` collection. A unique index on `link` deduplicates
   articles, and a **TTL index keeps each article for ~30 days**
   (`expireAfterSeconds: 2592000`) so the archive stays a rolling window.
2. **Search API (Express)** — a small REST service on top of the archive that
   exposes MongoDB **full-text search** plus filtering by category, country and
   date range.

Everything runs on the **newsdata.io FREE plan**. No paid-only features are
required.

---

## Architecture

```
  newsdata.io /news ──(node-cron, daily)──▶  fetcher.js
                                               │ upsert (unique index on link)
                                               ▼
                                       MongoDB `articles`
                                       • text index (title/description/content/keywords)
                                       • TTL index (30 days)
                                               ▲
                                               │ query
  HTTP client ───────────────────────────▶  Express API (server.js)
                                             GET /search  GET /sources  GET /health
```

---

## Requirements

- Node.js 18+
- A running MongoDB instance (local `mongodb://127.0.0.1:27017` works fine, or
  a free MongoDB Atlas cluster)
- A newsdata.io API key — get one free at <https://newsdata.io/register>

---

## Setup

```bash
git clone https://github.com/your-name/news-mongodb-archive.git
cd news-mongodb-archive
npm install

cp .env.example .env
# then edit .env and set NEWSDATA_API_KEY (and MONGODB_URI if needed)
```

### Environment variables

| Variable            | Required | Default                                   | Description                                    |
|---------------------|----------|-------------------------------------------|------------------------------------------------|
| `NEWSDATA_API_KEY`  | **yes**  | —                                         | Your newsdata.io API key.                      |
| `MONGODB_URI`       | no       | `mongodb://127.0.0.1:27017`               | MongoDB connection string.                     |
| `MONGODB_DB`        | no       | `news_archive`                            | Database name.                                 |
| `PORT`              | no       | `3000`                                    | Port for the Express API.                      |
| `FETCH_CATEGORIES`  | no       | `top,business,technology,science,...`     | Comma-separated categories to archive.         |
| `FETCH_LANGUAGE`    | no       | `en`                                      | Language code passed to newsdata.io.           |
| `FETCH_COUNTRY`     | no       | _(empty)_                                 | Optional country filter for the archiver.      |
| `MAX_PAGES`         | no       | `2`                                       | Pages to pull per category (free-tier safe).   |
| `CRON_SCHEDULE`     | no       | `0 6 * * *`                               | When the daily archive runs (cron syntax).     |

> The `NEWSDATA_API_KEY` is read from the environment and is **never** hardcoded.
> If it is missing, the app exits with a clear message.

---

## Running

### Start the API + daily cron (the normal way)

```bash
npm start
```

This launches the Express API **and** schedules the daily archive job
(`CRON_SCHEDULE`). On a brand-new database you'll want to seed it once (below)
so `/search` returns results immediately.

### Run the archiver once (seed / manual refresh)

```bash
npm run fetch
```

Fetches every configured category right now, upserts into MongoDB, and exits.
Safe to run repeatedly — duplicates are merged on `link`.

---

## API

### `GET /search`

Full-text search over the archive.

| Query param | Example          | Description                                                  |
|-------------|------------------|--------------------------------------------------------------|
| `q`         | `bitcoin`        | Full-text query (`$text` search over title/desc/content).    |
| `category`  | `technology`     | Filter by newsdata.io category.                              |
| `country`   | `us`             | Filter by country code.                                      |
| `from`      | `2026-06-01`     | Only articles published on/after this date.                  |
| `to`        | `2026-06-05`     | Only articles published on/before this date.                 |
| `page`      | `1`              | 1-based page number (default `1`).                           |
| `limit`     | `20`             | Page size (default `20`, max `100`).                         |

Example:

```bash
curl "http://localhost:3000/search?q=climate&category=environment&from=2026-06-01"
```

Response:

```json
{
  "query": { "q": "climate", "category": "environment", "from": "2026-06-01" },
  "page": 1,
  "limit": 20,
  "total": 3,
  "results": [
    {
      "title": "...",
      "link": "https://...",
      "description": "...",
      "pubDate": "2026-06-02 10:00:00",
      "source_id": "bbc",
      "category": ["environment"],
      "country": ["us"]
    }
  ]
}
```

### `GET /sources`

Top sources in the archive, aggregated by `source_id`.

```bash
curl "http://localhost:3000/sources?limit=10"
```

```json
{ "total": 10, "sources": [ { "source_id": "bbc", "count": 42 } ] }
```

### `GET /health`

Liveness + a quick document count.

---

## Free tier vs. paid plan

This project intentionally uses **only free-tier newsdata.io features**:
`q`, `category`, `country`, `language`, and `page` pagination on `/news`.

The following are **paid-only** on newsdata.io and are **not** used here:

- `sentiment` / sentiment analysis
- AI fields: `ai_tag`, `ai_region`, `ai_org`, `ai_summary`
- the historical `/archive` endpoint and long date ranges
- advanced full-text query operators

The Mongoose schema stores any extra fields the API returns (so if you later
upgrade your plan, the `ai_*`/`sentiment` fields will be archived automatically),
but nothing in the core flow depends on them. The client also detects and
gracefully skips `401` (invalid key), `403/422` ("upgrade your plan"), `429`
(rate limit) and empty `results` without crashing.

---

## License

MIT
