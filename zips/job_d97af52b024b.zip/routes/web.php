<?php

use App\Http\Controllers\HeadlinesController;
use Illuminate\Support\Facades\Route;

/*
 | The whole app is one page: the headline wall, with filters and the
 | newsdata.io `nextPage` cursor carried in the query string.
 */
Route::get('/', [HeadlinesController::class, 'index'])->name('headlines.index');
