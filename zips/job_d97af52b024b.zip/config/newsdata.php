<?php

/**
 * Settings for the newsdata.io news API client (https://newsdata.io).
 *
 * Everything here is env-driven. The only required value is NEWSDATA_API_KEY.
 */
return [

    // Read from the environment only — never commit a key.
    'key' => env('NEWSDATA_API_KEY'),

    'base_url' => env('NEWSDATA_BASE_URL', 'https://newsdata.io/api'),

    'timeout' => (int) env('NEWSDATA_TIMEOUT', 20),

    /*
     * Default filters. These three parameters are accepted on every plan,
     * including the free one.
     */
    'language' => env('NEWSDATA_LANGUAGE', 'en'),
    'country' => env('NEWSDATA_COUNTRY'),
    'category' => env('NEWSDATA_CATEGORY'),

    // Articles per API call. Clamped to 10 unless paid mode is enabled.
    'page_size' => (int) env('NEWSDATA_PAGE_SIZE', 10),

    // How many `nextPage` cursor hops to follow per page load.
    'max_pages' => (int) env('NEWSDATA_MAX_PAGES', 2),

    // Seconds. 0 disables caching entirely.
    'cache_ttl' => (int) env('NEWSDATA_CACHE_TTL', 900),

    // Cache store name, e.g. 'redis'. Null falls back to the app default store.
    'cache_store' => env('NEWSDATA_CACHE_STORE'),

    /*
     * Query parameters that a free API key cannot send. They are omitted unless
     * paid mode is switched on; if the API still rejects them, the client drops
     * them and retries the request once. Requires a paid newsdata.io plan.
     */
    'paid' => [
        'enabled' => filter_var(env('NEWSDATA_PAID_MODE', false), FILTER_VALIDATE_BOOLEAN),
        'timeframe' => env('NEWSDATA_TIMEFRAME'),
        'sentiment' => env('NEWSDATA_SENTIMENT'),
        'full_content' => filter_var(env('NEWSDATA_FULL_CONTENT', false), FILTER_VALIDATE_BOOLEAN),
        'size' => (int) env('NEWSDATA_SIZE', 0),
    ],

    // Options offered in the language dropdown.
    'languages' => [
        'en' => 'English',
        'es' => 'Spanish',
        'fr' => 'French',
        'de' => 'German',
        'it' => 'Italian',
        'pt' => 'Portuguese',
        'nl' => 'Dutch',
        'ru' => 'Russian',
        'ar' => 'Arabic',
        'hi' => 'Hindi',
        'ja' => 'Japanese',
        'zh' => 'Chinese',
    ],

];
