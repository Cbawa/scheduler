# News Wall (Laravel)

A small Laravel app that renders a wall of current headlines with search, category and language filters, cursor pagination and cached responses. It pulls live headlines from the newsdata.io news API (https://newsdata.io) — a free API key is enough to run everything described here.

This repo contains the app-specific slice of a Laravel project: one service class, one controller, one Blade view, an Artisan command, a config file and a route. Copy them over a fresh `laravel/laravel` skeleton (steps below). There is no Vite/npm step — the view ships its own CSS.

## What it does

- Reads `/1/latest` and shows the results as cards: image, source, relative publish time, description.
- Filters by free-text query, category and language; all three are plain query-string params, so the URLs are shareable.
- Follows the `nextPage` cursor. Each page load walks up to `NEWSDATA_MAX_PAGES` pages and hands the remaining cursor to a "More headlines" link, stopping when the API returns `nextPage: null`.
- Caches each filter combination through Laravel's cache (file by default, Redis if you point it there) so a browser refresh doesn't spend another API credit.
- `php artisan news:fetch` warms that cache from cron and prints what it got.
- Keyword chips on every card. Sentiment badges, a sentiment breakdown bar, AI tag/region/org chips and AI summaries appear when your plan returns those fields; when they're empty the widgets stay in place with a labelled sample so the layout doesn't collapse.
- 401, 429, network failures and empty result sets render as a readable banner instead of a stack trace.

## Requirements

PHP 8.2 or newer, Composer, and a newsdata.io API key. Redis is optional.

## Setup

```bash
# 1. fresh Laravel skeleton
composer create-project laravel/laravel news-wall

# 2. this repo
git clone https://github.com/<you>/laravel-news-wall /tmp/news-wall-src

# 3. drop the app files in (merges into the skeleton, overwrites routes/web.php)
cp -R /tmp/news-wall-src/app /tmp/news-wall-src/config \
      /tmp/news-wall-src/routes /tmp/news-wall-src/resources news-wall/

# 4. API key — get a free one at https://newsdata.io
cd news-wall
echo 'NEWSDATA_API_KEY=your_key_here' >> .env

# 5. run it
php artisan config:clear
php artisan serve
```

Open http://127.0.0.1:8000.

If `NEWSDATA_API_KEY` is missing the page still renders — it just shows a banner telling you which variable to set.

## Configuration

Everything lives in `config/newsdata.php` and is env-driven.

| Variable | Default | What it does |
| --- | --- | --- |
| `NEWSDATA_API_KEY` | — | Required. Sent as the `X-ACCESS-KEY` header, never in the URL. |
| `NEWSDATA_LANGUAGE` | `en` | Default language filter. |
| `NEWSDATA_COUNTRY` | — | Optional default country code, e.g. `us`. |
| `NEWSDATA_CATEGORY` | — | Optional default category, e.g. `technology`. |
| `NEWSDATA_PAGE_SIZE` | `10` | Articles per API call. Clamped to 10 unless paid mode is on. |
| `NEWSDATA_MAX_PAGES` | `2` | How many `nextPage` hops to follow per request. |
| `NEWSDATA_CACHE_TTL` | `900` | Cache lifetime in seconds. `0` disables caching. |
| `NEWSDATA_CACHE_STORE` | app default | Cache store name, e.g. `redis`. |
| `NEWSDATA_TIMEOUT` | `20` | HTTP timeout in seconds. |

For Redis, set the usual Laravel bits and point the client at that store:

```dotenv
REDIS_HOST=127.0.0.1
CACHE_STORE=redis
NEWSDATA_CACHE_STORE=redis
```

### Optional paid-plan settings

A few newsdata.io query parameters are rejected outright on the free plan, so they're off by default. Set `NEWSDATA_PAID_MODE=1` to send them; requires a paid newsdata.io plan.

```dotenv
NEWSDATA_PAID_MODE=1
NEWSDATA_TIMEFRAME=24        # last 24 hours
NEWSDATA_SENTIMENT=positive  # positive | negative | neutral
NEWSDATA_FULL_CONTENT=1
NEWSDATA_SIZE=50             # sizes above 10 need a paid plan
```

If the API rejects those parameters anyway, the client strips them and retries the same request once, so you still get results and the page shows a note explaining what happened.

Response *fields* are a separate matter and need no configuration: `sentiment`, `sentiment_stats`, `ai_tag`, `ai_region`, `ai_org` and `ai_summary` are requested normally and simply come back empty on the free plan. `keywords` is returned on every plan and is what the chips on each card use.

## Scheduled fetching

The Artisan command re-fetches a filter set and stores it in the cache, so the first visitor after a cron run gets a warm page.

```bash
php artisan news:fetch
php artisan news:fetch --category=technology --language=en
php artisan news:fetch --q="climate policy" --fresh
```

Add it to `routes/console.php`:

```php
use Illuminate\Support\Facades\Schedule;

Schedule::command('news:fetch')->hourly();
Schedule::command('news:fetch --category=technology')->hourly();
```

and run the scheduler however you normally do (`php artisan schedule:work` locally, a one-line crontab entry in production).

## Example

```
$ php artisan news:fetch --category=technology

Fetched 20 article(s) across 2 page(s) in 1.4s — cached for 15 min.

+--------------+------------------+-----------+-------------------------------------------------------+
| Published    | Source           | Sentiment | Headline                                              |
+--------------+------------------+-----------+-------------------------------------------------------+
| Aug 27 09:41 | Ars Technica     | —         | Chipmaker posts record quarter as data-centre dema... |
| Aug 27 09:12 | The Verge        | —         | Regulators open consultation on on-device AI discl... |
| Aug 27 08:55 | Reuters          | —         | Undersea cable repair pushes back regional rollout    |
+--------------+------------------+-----------+-------------------------------------------------------+

More results available — next cursor: 1724750460123456789
Sentiment values are empty on the free plan; the web UI shows a labelled sample chart instead.
```

## Files

```
app/Services/NewsDataClient.php            HTTP client, cursor paging, caching, error mapping
app/Http/Controllers/HeadlinesController.php  input sanitising + view data
app/Console/Commands/FetchHeadlines.php    news:fetch
config/newsdata.php                        all settings
routes/web.php                             single GET / route
resources/views/headlines/index.blade.php  the whole UI, CSS included
```

## Notes

- The API key is read from the environment only. Nothing is written to disk and the key never appears in a URL or in the cache key.
- Article fields are normalised in one place (`NewsDataClient::normalizeArticle`), including the placeholder strings the API returns for plan-restricted fields — those become `null` rather than leaking "ONLY AVAILABLE IN…" text into the page.
- Cache keys hash the full query plus cursor, so changing a filter never serves a stale list.

MIT licensed.
