<?php

namespace App\Console\Commands;

use App\Services\NewsDataClient;
use Illuminate\Console\Command;
use Illuminate\Support\Str;

/**
 * Pulls a filter set from newsdata.io and leaves it in the cache, so a scheduled
 * run keeps the web UI warm. Also useful as a quick connectivity check.
 */
class FetchHeadlines extends Command
{
    protected $signature = 'news:fetch
        {--q= : Free-text search term}
        {--category= : business, technology, sports, ... }
        {--country= : Two-letter country code, e.g. us}
        {--language= : Language code, defaults to NEWSDATA_LANGUAGE}
        {--fresh : Ignore the cached copy and re-request}';

    protected $description = 'Fetch the latest headlines from newsdata.io and warm the cache';

    public function handle(NewsDataClient $news): int
    {
        if (! $news->configured()) {
            $this->error('NEWSDATA_API_KEY is not set. Add it to your .env file and run `php artisan config:clear`.');

            return self::FAILURE;
        }

        $category = $this->option('category') ?: null;

        if ($category !== null && ! in_array($category, NewsDataClient::CATEGORIES, true)) {
            $this->error('Unknown category "'.$category.'". Valid values: '.implode(', ', NewsDataClient::CATEGORIES));

            return self::INVALID;
        }

        $filters = [
            'q' => $this->option('q') ?: null,
            'category' => $category,
            'country' => $this->option('country') ?: null,
            'language' => $this->option('language') ?: config('newsdata.language'),
            'cursor' => null,
        ];

        if ($this->option('fresh')) {
            $news->forget($filters);
        }

        $feed = $news->latest($filters);

        if ($feed['error'] !== null) {
            $this->error($feed['error']['message']);

            return self::FAILURE;
        }

        if ($feed['notice'] !== null) {
            $this->warn($feed['notice']);
        }

        if ($feed['articles'] === []) {
            $this->warn('The API returned no articles for these filters. Try dropping --q or --category.');

            return self::SUCCESS;
        }

        $ttl = (int) round(((int) config('newsdata.cache_ttl', 900)) / 60);

        $this->newLine();
        $this->info(sprintf(
            'Fetched %d article(s) across %d page(s) in %ss — cached for %d min.',
            count($feed['articles']),
            $feed['pages_fetched'],
            $feed['elapsed'],
            $ttl
        ));
        $this->newLine();

        $rows = [];

        foreach ($feed['articles'] as $article) {
            $rows[] = [
                $article['published_at']?->format('M j H:i') ?? '—',
                Str::limit($article['source'], 18),
                $article['sentiment'] ?? '—',
                Str::limit($article['title'], 52),
            ];
        }

        $this->table(['Published', 'Source', 'Sentiment', 'Headline'], $rows);

        if ($feed['next_cursor'] !== null) {
            $this->line('More results available — next cursor: '.$feed['next_cursor']);
        }

        if (! $feed['has_sentiment']) {
            $this->line('Sentiment values are empty on the free plan; the web UI shows a labelled sample chart instead.');
        }

        return self::SUCCESS;
    }
}
