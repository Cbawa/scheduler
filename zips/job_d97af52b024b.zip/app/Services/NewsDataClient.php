<?php

namespace App\Services;

use Carbon\CarbonImmutable;
use Illuminate\Http\Client\ConnectionException;
use Illuminate\Support\Arr;
use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Str;

/**
 * Client for the newsdata.io news API (https://newsdata.io).
 *
 * Only /1/latest is used, and by default only with query parameters that a free
 * API key accepts. Plan-restricted parameters are sent when paid mode is turned
 * on in config/newsdata.php, and are dropped + retried once if rejected.
 *
 * Every method returns a plain array; nothing throws on an API error. Callers
 * check the 'error' key.
 */
class NewsDataClient
{
    /** Query parameters that require a paid plan. */
    public const PAID_PARAMS = [
        'timeframe', 'sentiment', 'sentiment_score', 'full_content',
        'tag', 'region', 'organization', 'from_date', 'to_date', 'prioritydomain',
    ];

    /** Values accepted by the `category` parameter. */
    public const CATEGORIES = [
        'business', 'crime', 'domestic', 'education', 'entertainment', 'environment',
        'food', 'health', 'lifestyle', 'other', 'politics', 'science', 'sports',
        'technology', 'top', 'tourism', 'world',
    ];

    private ?string $apiKey;

    private string $baseUrl;

    public function __construct()
    {
        $key = config('newsdata.key');
        $this->apiKey = is_string($key) && trim($key) !== '' ? trim($key) : null;
        $this->baseUrl = rtrim((string) config('newsdata.base_url', 'https://newsdata.io/api'), '/');
    }

    public function configured(): bool
    {
        return $this->apiKey !== null;
    }

    /**
     * Fetch the latest headlines.
     *
     * @param  array{q?:?string,category?:?string,country?:?string,language?:?string,cursor?:?string}  $filters
     */
    public function latest(array $filters = []): array
    {
        if (! $this->configured()) {
            return $this->emptyResult([
                'type' => 'missing_key',
                'status' => 0,
                'message' => 'NEWSDATA_API_KEY is not set. Add it to your .env file — a free key from https://newsdata.io is enough.',
            ]);
        }

        $query = $this->buildQuery($filters);
        $cursor = $this->cursor($filters);
        $ttl = max(0, (int) config('newsdata.cache_ttl', 900));

        $fetch = fn (): array => $this->fetchPages($query, $cursor);

        if ($ttl === 0) {
            return $fetch();
        }

        return $this->cache()->remember($this->cacheKey($query, $cursor), $ttl, $fetch);
    }

    /** Drop the cached response for a filter set. */
    public function forget(array $filters = []): void
    {
        $this->cache()->forget($this->cacheKey($this->buildQuery($filters), $this->cursor($filters)));
    }

    /** The cache key a filter set resolves to (handy for logging). */
    public function cacheKeyFor(array $filters = []): string
    {
        return $this->cacheKey($this->buildQuery($filters), $this->cursor($filters));
    }

    // ---------------------------------------------------------------- internals

    private function cache()
    {
        return Cache::store(config('newsdata.cache_store') ?: null);
    }

    private function cursor(array $filters): ?string
    {
        $cursor = $filters['cursor'] ?? null;

        return is_string($cursor) && $cursor !== '' ? $cursor : null;
    }

    private function cacheKey(array $query, ?string $cursor): string
    {
        ksort($query);

        // The API key is deliberately not part of the key material.
        return 'newsdata:latest:'.substr(sha1(json_encode($query).'|'.(string) $cursor), 0, 32);
    }

    private function buildQuery(array $filters): array
    {
        $query = array_filter([
            'language' => $filters['language'] ?? config('newsdata.language'),
            'country' => $filters['country'] ?? config('newsdata.country'),
            'category' => $filters['category'] ?? config('newsdata.category'),
            'q' => $filters['q'] ?? null,
        ], static fn ($value) => $value !== null && $value !== '');

        $size = (int) ($filters['size'] ?? config('newsdata.page_size', 10));
        $query['size'] = max(1, min(10, $size ?: 10));

        if (config('newsdata.paid.enabled')) {
            $query = array_merge($query, $this->paidParams());
        }

        return $query;
    }

    /** Parameters that only a paid plan accepts. */
    private function paidParams(): array
    {
        $paid = array_filter([
            'timeframe' => config('newsdata.paid.timeframe'),
            'sentiment' => config('newsdata.paid.sentiment'),
        ], static fn ($value) => $value !== null && $value !== '');

        if (config('newsdata.paid.full_content')) {
            $paid['full_content'] = 1;
        }

        $size = (int) config('newsdata.paid.size', 0);
        if ($size > 10) {
            $paid['size'] = min(50, $size);
        }

        return $paid;
    }

    private function usesPaidParams(array $params): bool
    {
        if (array_intersect(array_keys($params), self::PAID_PARAMS) !== []) {
            return true;
        }

        return isset($params['size']) && (int) $params['size'] > 10;
    }

    private function withoutPaidParams(array $params): array
    {
        $clean = Arr::except($params, self::PAID_PARAMS);
        $clean['size'] = max(1, min(10, (int) ($clean['size'] ?? 10)));

        return $clean;
    }

    /**
     * Walk the `nextPage` cursor until it comes back null or the page budget runs out.
     */
    private function fetchPages(array $query, ?string $cursor): array
    {
        $maxPages = max(1, (int) config('newsdata.max_pages', 2));
        $startedAt = microtime(true);

        $articles = [];
        $total = null;
        $next = null;
        $pages = 0;
        $paidFallback = false;
        $notice = null;
        $page = $cursor;

        for ($i = 0; $i < $maxPages; $i++) {
            $params = $query;
            if ($page !== null) {
                $params['page'] = $page;
            }

            $response = $this->request($params);

            // Paid-only parameters rejected: strip them and try once more.
            if ($response['error'] !== null
                && $this->usesPaidParams($params)
                && in_array($response['error']['status'], [403, 409, 422], true)) {
                $query = $this->withoutPaidParams($query);
                $params = $this->withoutPaidParams($params);
                $response = $this->request($params);
                $paidFallback = true;
                $notice = 'Plan-restricted query parameters were rejected, so the request was retried without them.';
            }

            if ($response['error'] !== null) {
                if ($articles === []) {
                    return $this->emptyResult($response['error'], [
                        'paid_fallback' => $paidFallback,
                        'elapsed' => round(microtime(true) - $startedAt, 2),
                    ]);
                }

                $notice = $response['error']['message'].' Showing the results collected so far.';
                break;
            }

            $body = $response['body'];

            if ($total === null && is_numeric(Arr::get($body, 'totalResults'))) {
                $total = (int) Arr::get($body, 'totalResults');
            }

            foreach ((array) Arr::get($body, 'results', []) as $row) {
                if (is_array($row)) {
                    $articles[] = $this->normalizeArticle($row);
                }
            }

            $pages++;

            $nextPage = Arr::get($body, 'nextPage');
            $next = is_string($nextPage) && $nextPage !== '' ? $nextPage : null;

            if ($next === null) {
                break;
            }

            $page = $next;
        }

        $summary = ['positive' => 0, 'neutral' => 0, 'negative' => 0];
        $hasAi = false;

        foreach ($articles as $article) {
            if ($article['sentiment'] !== null) {
                $summary[$article['sentiment']]++;
            }
            if (! $hasAi && ($article['ai_tags'] || $article['ai_regions'] || $article['ai_orgs'] || $article['ai_summary'])) {
                $hasAi = true;
            }
        }

        return [
            'articles' => $articles,
            'total' => $total,
            'next_cursor' => $next,
            'error' => null,
            'notice' => $notice,
            'paid_fallback' => $paidFallback,
            'pages_fetched' => $pages,
            'sentiment_summary' => $summary,
            'has_sentiment' => array_sum($summary) > 0,
            'has_ai' => $hasAi,
            'elapsed' => round(microtime(true) - $startedAt, 2),
            'fetched_at' => CarbonImmutable::now(),
        ];
    }

    /**
     * One HTTP call. Returns ['error' => ?array, 'body' => array].
     */
    private function request(array $params): array
    {
        try {
            $response = Http::withHeaders(['X-ACCESS-KEY' => $this->apiKey])
                ->acceptJson()
                ->timeout((int) config('newsdata.timeout', 20))
                ->get($this->baseUrl.'/1/latest', $params);
        } catch (ConnectionException $e) {
            Log::warning('newsdata.io request failed: '.$e->getMessage());

            return [
                'error' => [
                    'type' => 'network',
                    'status' => 0,
                    'message' => 'Could not reach newsdata.io. Check your network connection and try again.',
                ],
                'body' => [],
            ];
        }

        $body = $response->json();
        $body = is_array($body) ? $body : [];
        $status = $response->status();

        if ($response->successful() && Arr::get($body, 'status') !== 'error') {
            return ['error' => null, 'body' => $body];
        }

        $apiMessage = Arr::get($body, 'results.message')
            ?? Arr::get($body, 'message')
            ?? $response->reason();

        $type = match (true) {
            $status === 401 => 'auth',
            $status === 429 => 'rate_limit',
            in_array($status, [403, 409, 422], true) => 'plan',
            default => 'http',
        };

        $message = match ($type) {
            'auth' => 'newsdata.io rejected the API key (401). Check the NEWSDATA_API_KEY value in your .env file.',
            'rate_limit' => 'newsdata.io rate limit reached (429). Wait for the quota window to reset, or raise NEWSDATA_CACHE_TTL so pages are served from cache for longer.',
            'plan' => 'newsdata.io refused the request ('.$status.'): '.$apiMessage,
            default => 'newsdata.io returned HTTP '.$status.': '.$apiMessage,
        };

        Log::warning('newsdata.io error response', ['status' => $status, 'message' => $apiMessage]);

        return [
            'error' => ['type' => $type, 'status' => $status, 'message' => $message],
            'body' => $body,
        ];
    }

    /**
     * Flatten one API result into the shape the views expect. Fields that a plan
     * does not include arrive as null, an empty array or a placeholder string —
     * all three end up as null/[] here.
     */
    private function normalizeArticle(array $row): array
    {
        $sentiment = is_string($row['sentiment'] ?? null) ? strtolower(trim($row['sentiment'])) : null;
        if (! in_array($sentiment, ['positive', 'negative', 'neutral'], true)) {
            $sentiment = null;
        }

        $title = $this->text($row['title'] ?? null, 200) ?? 'Untitled';

        return [
            'id' => is_string($row['article_id'] ?? null) ? $row['article_id'] : null,
            'title' => $title,
            'link' => filter_var($row['link'] ?? '', FILTER_VALIDATE_URL) ?: null,
            'description' => $this->text($row['description'] ?? null, 260),
            'published_at' => $this->date($row['pubDate'] ?? null, $row['pubDateTZ'] ?? 'UTC'),
            'image' => filter_var($row['image_url'] ?? '', FILTER_VALIDATE_URL) ?: null,
            'source' => $this->text($row['source_name'] ?? null, 60)
                ?? $this->text($row['source_id'] ?? null, 60)
                ?? 'Unknown source',
            'source_url' => filter_var($row['source_url'] ?? '', FILTER_VALIDATE_URL) ?: null,
            'source_icon' => filter_var($row['source_icon'] ?? '', FILTER_VALIDATE_URL) ?: null,
            'categories' => $this->strings($row['category'] ?? null),
            'countries' => $this->strings($row['country'] ?? null),
            'creators' => array_slice($this->strings($row['creator'] ?? null), 0, 2),
            // keywords is returned on every plan, including the free one.
            'keywords' => array_slice($this->strings($row['keywords'] ?? null), 0, 6),
            'sentiment' => $sentiment,
            'sentiment_stats' => $this->stats($row['sentiment_stats'] ?? null),
            'ai_tags' => array_slice($this->strings($row['ai_tag'] ?? null), 0, 5),
            'ai_regions' => array_slice($this->strings($row['ai_region'] ?? null), 0, 3),
            'ai_orgs' => array_slice($this->strings($row['ai_org'] ?? null), 0, 3),
            'ai_summary' => $this->text($row['ai_summary'] ?? null, 320),
        ];
    }

    /** True for the "available on higher plans" placeholders the API sends. */
    private function isPlaceholder(string $value): bool
    {
        return str_contains(strtoupper($value), 'ONLY AVAILABLE IN');
    }

    private function text(mixed $value, int $limit): ?string
    {
        if (! is_string($value)) {
            return null;
        }

        $clean = trim(html_entity_decode(strip_tags($value), ENT_QUOTES | ENT_HTML5, 'UTF-8'));

        if ($clean === '' || $this->isPlaceholder($clean)) {
            return null;
        }

        return Str::limit($clean, $limit);
    }

    /** @return array<int,string> */
    private function strings(mixed $value): array
    {
        if ($value === null) {
            return [];
        }

        $items = is_array($value) ? $value : [$value];
        $out = [];

        foreach ($items as $item) {
            if (is_array($item)) {
                $out = array_merge($out, $this->strings($item));

                continue;
            }

            if (! is_scalar($item)) {
                continue;
            }

            $clean = trim((string) $item);

            if ($clean === '' || $this->isPlaceholder($clean)) {
                continue;
            }

            $out[] = Str::limit($clean, 40);
        }

        return array_values(array_unique($out));
    }

    /** @return array<string,float> */
    private function stats(mixed $value): array
    {
        if (is_string($value)) {
            if ($this->isPlaceholder($value)) {
                return [];
            }
            $decoded = json_decode($value, true);
            $value = is_array($decoded) ? $decoded : null;
        }

        if (! is_array($value)) {
            return [];
        }

        $out = [];

        foreach (['positive', 'neutral', 'negative'] as $key) {
            if (isset($value[$key]) && is_numeric($value[$key])) {
                $out[$key] = round((float) $value[$key], 2);
            }
        }

        return $out;
    }

    private function date(mixed $value, mixed $timezone): ?CarbonImmutable
    {
        if (! is_string($value) || trim($value) === '') {
            return null;
        }

        try {
            return CarbonImmutable::parse($value, is_string($timezone) && $timezone !== '' ? $timezone : 'UTC');
        } catch (\Throwable) {
            return null;
        }
    }

    private function emptyResult(?array $error, array $extra = []): array
    {
        return array_merge([
            'articles' => [],
            'total' => null,
            'next_cursor' => null,
            'error' => $error,
            'notice' => null,
            'paid_fallback' => false,
            'pages_fetched' => 0,
            'sentiment_summary' => ['positive' => 0, 'neutral' => 0, 'negative' => 0],
            'has_sentiment' => false,
            'has_ai' => false,
            'elapsed' => 0.0,
            'fetched_at' => CarbonImmutable::now(),
        ], $extra);
    }
}
