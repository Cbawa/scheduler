<?php

namespace App\Http\Controllers;

use App\Services\NewsDataClient;
use Illuminate\Http\Request;
use Illuminate\View\View;

class HeadlinesController extends Controller
{
    public function __construct(private readonly NewsDataClient $news)
    {
    }

    public function index(Request $request): View
    {
        $filters = [
            'q' => $this->query($request, 'q', 120),
            'category' => $this->category($request),
            'language' => $this->language($request),
            'cursor' => $this->query($request, 'cursor', 256),
        ];

        $feed = $this->news->latest($filters);

        $sources = array_unique(array_column($feed['articles'], 'source'));

        return view('headlines.index', [
            'feed' => $feed,
            'filters' => $filters,
            'categories' => NewsDataClient::CATEGORIES,
            'languages' => (array) config('newsdata.languages', []),
            'sourceCount' => count($sources),
            'paidMode' => (bool) config('newsdata.paid.enabled'),
            'cacheMinutes' => (int) round(((int) config('newsdata.cache_ttl', 900)) / 60),
        ]);
    }

    private function query(Request $request, string $key, int $max): ?string
    {
        $value = $request->query($key);

        if (! is_string($value)) {
            return null;
        }

        $value = trim($value);

        return $value === '' ? null : mb_substr($value, 0, $max);
    }

    private function category(Request $request): ?string
    {
        $value = $request->query('category');

        if (! is_string($value)) {
            return null;
        }

        $value = strtolower(trim($value));

        return in_array($value, NewsDataClient::CATEGORIES, true) ? $value : null;
    }

    private function language(Request $request): ?string
    {
        $value = $request->query('language');

        if (is_string($value) && preg_match('/^[a-zA-Z]{2,5}$/', trim($value)) === 1) {
            return strtolower(trim($value));
        }

        return config('newsdata.language');
    }
}
