@php
    $articles = $feed['articles'];
    $error = $feed['error'];

    // Real counts when the plan returns sentiment; a clearly-labelled sample otherwise.
    $sentimentIsSample = ! $feed['has_sentiment'];
    $sentiment = $sentimentIsSample
        ? ['positive' => 9, 'neutral' => 14, 'negative' => 5]
        : $feed['sentiment_summary'];
    $sentimentTotal = max(1, array_sum($sentiment));

    $baseQuery = array_filter([
        'q' => $filters['q'],
        'category' => $filters['category'],
        'language' => $filters['language'],
    ]);

    $heading = $filters['category'] ? ucfirst($filters['category']).' headlines' : 'Latest headlines';
@endphp
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>News Wall — {{ $heading }}</title>
@verbatim
<style>
:root{--bg:#0e1116;--panel:#161b24;--panel2:#1b2231;--line:#28303f;--txt:#e7ecf4;--muted:#93a0b4;--accent:#7aa2f7;--pos:#4ade80;--neu:#94a3b8;--neg:#f87171}
*{box-sizing:border-box}
html{-webkit-text-size-adjust:100%}
body{margin:0;background:var(--bg);color:var(--txt);font:16px/1.55 -apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,Helvetica,Arial,sans-serif}
a{color:inherit}
code{font:13px/1.4 ui-monospace,SFMono-Regular,Menlo,Consolas,monospace;background:#0b0f16;border:1px solid var(--line);border-radius:4px;padding:1px 5px}
.wrap{max-width:1140px;margin:0 auto;padding:0 20px}
.masthead{border-bottom:1px solid var(--line);background:linear-gradient(180deg,#141a25,#0e1116);padding:30px 0 24px}
.masthead h1{margin:0;font-size:25px;letter-spacing:-.02em}
.tagline{margin:7px 0 18px;color:var(--muted);font-size:14px;max-width:70ch}
.tagline a{color:var(--accent);text-decoration:none}
.tagline a:hover{text-decoration:underline}
.filters{display:flex;flex-wrap:wrap;gap:8px;align-items:center}
.filters input,.filters select{background:var(--panel);border:1px solid var(--line);color:var(--txt);padding:9px 11px;border-radius:8px;font-size:14px;outline:none}
.filters input:focus,.filters select:focus{border-color:var(--accent)}
.filters input{flex:1 1 240px;min-width:180px}
.filters button{background:var(--accent);border:0;color:#0b1020;font-weight:600;padding:10px 18px;border-radius:8px;cursor:pointer;font-size:14px}
.reset{color:var(--muted);font-size:13px;text-decoration:none;padding:0 4px}
main{padding:22px 0 64px}
.banner{border:1px solid;border-radius:10px;padding:12px 14px;margin-bottom:18px;font-size:14px}
.banner-error{background:#251519;border-color:#5b2730;color:#fecdd3}
.banner-note{background:#1a2130;border-color:#31405c;color:#c7d6f5}
.banner code{background:#00000040}
.panels{display:grid;grid-template-columns:1.1fr 1fr;gap:16px;margin-bottom:22px}
.panel{background:var(--panel);border:1px solid var(--line);border-radius:12px;padding:16px 18px}
.panel-head{display:flex;align-items:center;gap:9px;margin-bottom:12px}
.panel-head h2{margin:0;font-size:13px;text-transform:uppercase;letter-spacing:.09em;color:var(--muted);font-weight:600}
.stats{display:flex;gap:26px;flex-wrap:wrap}
.stat b{display:block;font-size:22px;line-height:1.2}
.stat span{font-size:12px;color:var(--muted)}
.bar{display:flex;height:12px;border-radius:99px;overflow:hidden;background:var(--panel2);margin:4px 0 12px}
.seg{display:block;height:100%}
.seg-positive{background:var(--pos)}
.seg-neutral{background:var(--neu)}
.seg-negative{background:var(--neg)}
.legend{list-style:none;display:flex;gap:16px;flex-wrap:wrap;margin:0;padding:0;font-size:13px;color:var(--muted)}
.legend i{display:inline-block;width:9px;height:9px;border-radius:3px;margin-right:6px}
.note{margin:12px 0 0;font-size:12.5px;color:var(--muted);line-height:1.5}
.chips{display:flex;flex-wrap:wrap;gap:6px}
.chip{font-size:12px;background:var(--panel2);border:1px solid var(--line);color:#c3cede;border-radius:99px;padding:3px 9px}
.chip-ai{border-color:#3c4a6b;color:#b9c9ee}
.chip-flag{color:var(--muted);font-size:10px;text-transform:uppercase;letter-spacing:.06em;margin-left:5px}
.badge{font-size:11px;text-transform:uppercase;letter-spacing:.06em;border-radius:99px;padding:2px 8px;border:1px solid}
.badge-sample{color:#f4c874;border-color:#5b4620;background:#2a2113}
.badge-live{color:var(--pos);border-color:#265c39;background:#12251a}
.s-positive{color:var(--pos);border-color:#265c39;background:#12251a}
.s-neutral{color:var(--neu);border-color:#3a4454;background:#1a2029}
.s-negative{color:var(--neg);border-color:#5c2a2a;background:#251616}
.s-none{color:var(--muted);border-color:var(--line);background:transparent}
.grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(320px,1fr));gap:16px}
.card{background:var(--panel);border:1px solid var(--line);border-radius:12px;overflow:hidden;display:flex;flex-direction:column}
.thumb{display:block;line-height:0;background:var(--panel2)}
.thumb img{width:100%;height:168px;object-fit:cover}
.card-body{padding:14px 16px 16px;display:flex;flex-direction:column;gap:9px;flex:1}
.meta{display:flex;align-items:center;gap:8px;font-size:12px;color:var(--muted);flex-wrap:wrap}
.meta img{width:15px;height:15px;border-radius:3px}
.card h3{margin:0;font-size:16.5px;line-height:1.35;letter-spacing:-.01em}
.card h3 a{text-decoration:none}
.card h3 a:hover{color:var(--accent)}
.dek{margin:0;font-size:13.5px;color:#b6c0cf;line-height:1.5}
.ai-summary{margin:0;font-size:13px;color:#c6d3ea;background:var(--panel2);border-left:2px solid var(--accent);border-radius:0 6px 6px 0;padding:8px 10px}
.ai-summary b{font-size:10.5px;text-transform:uppercase;letter-spacing:.07em;color:var(--muted);display:block;margin-bottom:3px}
.card-foot{margin-top:auto;padding-top:4px}
.empty{text-align:center;color:var(--muted);border:1px dashed var(--line);border-radius:12px;padding:44px 20px}
.pager{display:flex;justify-content:center;margin-top:26px}
.pager a{background:var(--panel);border:1px solid var(--line);border-radius:9px;padding:11px 20px;text-decoration:none;font-size:14px}
.pager a:hover{border-color:var(--accent);color:var(--accent)}
footer{border-top:1px solid var(--line);color:var(--muted);font-size:13px;padding:18px 0 34px}
footer a{color:var(--muted)}
@media (max-width:820px){.panels{grid-template-columns:1fr}}
</style>
@endverbatim
</head>
<body>

<header class="masthead">
    <div class="wrap">
        <h1>News Wall</h1>
        <p class="tagline">
            {{ $heading }} pulled from the <a href="https://newsdata.io" rel="noopener">newsdata.io</a> news API.
            Results are cached for {{ $cacheMinutes }} minutes and paged with the API's <code>nextPage</code> cursor.
        </p>

        <form class="filters" method="GET" action="{{ route('headlines.index') }}">
            <input type="search" name="q" value="{{ $filters['q'] }}" placeholder="Search headlines…" aria-label="Search headlines">

            <select name="category" aria-label="Category">
                <option value="">All categories</option>
                @foreach ($categories as $category)
                    <option value="{{ $category }}" @selected($filters['category'] === $category)>{{ ucfirst($category) }}</option>
                @endforeach
            </select>

            <select name="language" aria-label="Language">
                @foreach ($languages as $code => $label)
                    <option value="{{ $code }}" @selected($filters['language'] === $code)>{{ $label }}</option>
                @endforeach
                @unless (array_key_exists($filters['language'], $languages))
                    <option value="{{ $filters['language'] }}" selected>{{ strtoupper((string) $filters['language']) }}</option>
                @endunless
            </select>

            <button type="submit">Search</button>

            @if ($filters['q'] || $filters['category'])
                <a class="reset" href="{{ route('headlines.index') }}">Clear</a>
            @endif
        </form>
    </div>
</header>

<main>
    <div class="wrap">

        @if ($error)
            <div class="banner banner-error">{{ $error['message'] }}</div>
        @endif

        @if ($feed['notice'])
            <div class="banner banner-note">{{ $feed['notice'] }}</div>
        @endif

        @if ($articles)
            <div class="panels">
                <section class="panel">
                    <div class="panel-head">
                        <h2>Sentiment breakdown</h2>
                        <span class="badge {{ $sentimentIsSample ? 'badge-sample' : 'badge-live' }}">{{ $sentimentIsSample ? 'sample' : 'live' }}</span>
                    </div>

                    <div class="bar" role="img" aria-label="Sentiment distribution">
                        @foreach ($sentiment as $label => $count)
                            <span class="seg seg-{{ $label }}" style="width: {{ round($count / $sentimentTotal * 100, 2) }}%"></span>
                        @endforeach
                    </div>

                    <ul class="legend">
                        @foreach ($sentiment as $label => $count)
                            <li><i class="seg-{{ $label }}"></i>{{ ucfirst($label) }} — {{ $count }} ({{ round($count / $sentimentTotal * 100) }}%)</li>
                        @endforeach
                    </ul>

                    @if ($sentimentIsSample)
                        <p class="note">
                            Sample values, not live output. The <code>sentiment</code> and <code>sentiment_stats</code> fields
                            come back empty on the free newsdata.io plan; on a paid plan this chart fills in from the same
                            request, no code change needed.
                        </p>
                    @else
                        <p class="note">Counted from the <code>sentiment</code> field on {{ count($articles) }} article(s) in this batch.</p>
                    @endif
                </section>

                <section class="panel">
                    <div class="panel-head">
                        <h2>This batch</h2>
                        @if ($paidMode)<span class="badge badge-live">paid mode</span>@endif
                    </div>

                    <div class="stats">
                        <div class="stat"><b>{{ count($articles) }}</b><span>articles shown</span></div>
                        <div class="stat"><b>{{ $sourceCount }}</b><span>sources</span></div>
                        <div class="stat"><b>{{ $feed['pages_fetched'] }}</b><span>API pages</span></div>
                        <div class="stat"><b>{{ $feed['total'] !== null ? number_format($feed['total']) : '—' }}</b><span>total matches</span></div>
                    </div>

                    <div class="panel-head" style="margin-top:18px">
                        <h2>Enrichment fields</h2>
                        @unless ($feed['has_ai'])<span class="badge badge-sample">example</span>@endunless
                    </div>

                    @if ($feed['has_ai'])
                        <p class="note" style="margin-top:0">Your plan is returning <code>ai_tag</code> / <code>ai_region</code> / <code>ai_org</code> — they're rendered on the cards below.</p>
                    @else
                        <div class="chips">
                            <span class="chip chip-ai">ai_tag: energy_transition<span class="chip-flag">example</span></span>
                            <span class="chip chip-ai">ai_region: north america<span class="chip-flag">example</span></span>
                            <span class="chip chip-ai">ai_org: european commission<span class="chip-flag">example</span></span>
                        </div>
                        <p class="note">
                            Placeholder chips. <code>keywords</code> is returned on the free plan and is shown on every card;
                            <code>ai_tag</code>, <code>ai_region</code>, <code>ai_org</code> and <code>ai_summary</code> require a paid
                            newsdata.io plan and arrive empty otherwise.
                        </p>
                    @endif
                </section>
            </div>

            <div class="grid">
                @foreach ($articles as $article)
                    <article class="card">
                        @if ($article['image'])
                            <a class="thumb" href="{{ $article['link'] ?? '#' }}" rel="noopener nofollow" target="_blank">
                                <img src="{{ $article['image'] }}" alt="" loading="lazy" onerror="this.closest('.thumb').remove()">
                            </a>
                        @endif

                        <div class="card-body">
                            <div class="meta">
                                @if ($article['source_icon'])
                                    <img src="{{ $article['source_icon'] }}" alt="" loading="lazy" onerror="this.remove()">
                                @endif
                                <span>{{ $article['source'] }}</span>
                                @if ($article['published_at'])
                                    <span>· {{ $article['published_at']->diffForHumans() }}</span>
                                @endif
                                @foreach ($article['categories'] as $category)
                                    <span>· {{ $category }}</span>
                                @endforeach
                            </div>

                            <h3>
                                @if ($article['link'])
                                    <a href="{{ $article['link'] }}" rel="noopener nofollow" target="_blank">{{ $article['title'] }}</a>
                                @else
                                    {{ $article['title'] }}
                                @endif
                            </h3>

                            @if ($article['description'])
                                <p class="dek">{{ $article['description'] }}</p>
                            @endif

                            @if ($article['ai_summary'])
                                <p class="ai-summary"><b>AI summary</b>{{ $article['ai_summary'] }}</p>
                            @endif

                            @if ($article['keywords'] || $article['ai_tags'])
                                <div class="chips">
                                    @foreach ($article['keywords'] as $keyword)
                                        <span class="chip">{{ $keyword }}</span>
                                    @endforeach
                                    @foreach ($article['ai_tags'] as $tag)
                                        <span class="chip chip-ai">{{ $tag }}</span>
                                    @endforeach
                                </div>
                            @endif

                            <div class="card-foot">
                                @if ($article['sentiment'])
                                    <span class="badge s-{{ $article['sentiment'] }}">
                                        {{ $article['sentiment'] }}@if (isset($article['sentiment_stats'][$article['sentiment']])) · {{ $article['sentiment_stats'][$article['sentiment']] }}%@endif
                                    </span>
                                @else
                                    <span class="badge s-none" title="The sentiment field is empty on the free newsdata.io plan">sentiment n/a</span>
                                @endif

                                @foreach ($article['ai_orgs'] as $org)
                                    <span class="badge s-none">{{ $org }}</span>
                                @endforeach
                            </div>
                        </div>
                    </article>
                @endforeach
            </div>

            @if ($feed['next_cursor'])
                <div class="pager">
                    <a href="{{ route('headlines.index', array_merge($baseQuery, ['cursor' => $feed['next_cursor']])) }}">More headlines →</a>
                </div>
            @endif

        @elseif (! $error)
            <div class="empty">
                <p>No articles came back for these filters.</p>
                <p class="note">Try a broader search term, a different category, or <a href="{{ route('headlines.index') }}">clear the filters</a>.</p>
            </div>
        @endif

    </div>
</main>

<footer>
    <div class="wrap">
        Data from the <a href="https://newsdata.io" rel="noopener">newsdata.io</a> news API ·
        fetched {{ $feed['fetched_at']->diffForHumans() }} in {{ $feed['elapsed'] }}s ·
        headlines link to the original publishers.
    </div>
</footer>

</body>
</html>
