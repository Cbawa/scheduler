#!/usr/bin/env python3
"""news-content-repurposer

Pulls today's headlines from the newsdata.io news API and rewrites each one
into a LinkedIn post, a short tweet thread, and a plain summary. Runs on a free
newsdata.io key; if OPENAI_API_KEY is set it uses GPT to do the rewriting.
"""
from __future__ import annotations

import argparse
import os
import re
import sys

from newsdata_client import NewsDataClient, NewsDataError, fetch_articles
from repurpose import repurpose

SENTIMENTS = ("positive", "neutral", "negative")


def env_flag(name):
    return os.environ.get(name, "").strip().lower() in ("1", "true", "yes", "on")


def decide_gpt(args):
    has_key = bool(os.environ.get("OPENAI_API_KEY"))
    if args.no_gpt:
        return False
    if args.gpt:
        if not has_key:
            print("warning: --gpt set but OPENAI_API_KEY is missing; "
                  "using templates instead.", file=sys.stderr)
            return False
        return True
    return has_key


def sentiment_badge(value):
    icons = {"positive": "+ positive", "neutral": "= neutral", "negative": "- negative"}
    return icons.get(value, "· n/a")


def sentiment_chart(articles):
    counts = {k: 0 for k in SENTIMENTS}
    real = False
    for a in articles:
        s = a.get("sentiment")
        if s in counts:
            counts[s] += 1
            real = True
    if not real:
        # Free key: no live sentiment. Show a clearly-labeled sample so the
        # feature stays visible without pretending the numbers are real.
        counts = {"positive": 3, "neutral": 5, "negative": 2}
    total = sum(counts.values()) or 1
    lines = ["Sentiment breakdown:"]
    for key in SENTIMENTS:
        n = counts[key]
        bar = "#" * int(round(20 * n / total))
        lines.append(f"  {key:<9} {bar:<20} {n}")
    if not real:
        lines.append("  (sample — live sentiment requires a paid newsdata.io plan)")
    return "\n".join(lines)


def chips(label, values, empty_hint):
    if values:
        return f"{label}: " + ", ".join(values)
    return f"{label}: {empty_hint}"


def render_article(index, fields, content):
    out = []
    out.append("=" * 70)
    out.append(f"[{index}] {fields['title']}")
    meta = " • ".join(
        p for p in (fields["source"], fields["pub_date"],
                    sentiment_badge(fields["sentiment"])) if p
    )
    out.append("    " + meta)
    out.append("    " + chips("keywords", fields["keywords"], "(none)"))
    out.append("    " + chips("ai tags", fields["ai_tag"],
                              "(needs a paid newsdata.io plan)"))
    if fields["ai_summary"]:
        out.append("    ai summary: " + fields["ai_summary"])
    out.append(f"    [rewritten with: {content['engine']}]")
    out.append("")
    out.append("--- LinkedIn ---")
    out.append(content["linkedin"])
    out.append("")
    out.append("--- Tweets ---")
    for i, tw in enumerate(content["tweets"], 1):
        out.append(f"{i}. {tw}  ({len(tw)} chars)")
    out.append("")
    out.append("--- Summary ---")
    out.append(content["summary"])
    out.append("")
    return "\n".join(out)


def slugify(text, fallback="article"):
    slug = re.sub(r"[^a-z0-9]+", "-", (text or "").lower()).strip("-")
    return slug[:60] or fallback


def write_markdown(directory, index, fields, content):
    os.makedirs(directory, exist_ok=True)
    name = f"{index:02d}-{slugify(fields['title'])}.md"
    path = os.path.join(directory, name)
    parts = [
        f"# {fields['title']}",
        "",
        f"Source: {fields['source']}  ",
        f"Link: {fields['link']}  ",
        f"Generated with: {content['engine']}",
        "",
        "## LinkedIn",
        "",
        content["linkedin"],
        "",
        "## Tweets",
        "",
    ]
    parts += [f"{i}. {t}" for i, t in enumerate(content["tweets"], 1)]
    parts += ["", "## Summary", "", content["summary"], ""]
    with open(path, "w", encoding="utf-8") as fh:
        fh.write("\n".join(parts))
    return path


def build_parser():
    p = argparse.ArgumentParser(
        description="Repurpose newsdata.io headlines into social posts.")
    p.add_argument("-q", "--query", help="search term (free-tier q param)")
    p.add_argument("--country", help="two-letter country code, e.g. us")
    p.add_argument("--language", default="en", help="language code (default: en)")
    p.add_argument("--category", help="e.g. technology, business, sports")
    p.add_argument("-n", "--count", type=int, default=5,
                   help="number of articles to repurpose (default: 5)")
    p.add_argument("-o", "--output", help="write each result as a markdown file here")
    p.add_argument("--gpt", action="store_true", help="force GPT rewriting")
    p.add_argument("--no-gpt", action="store_true", help="never use GPT")
    p.add_argument("--model", default=os.environ.get("OPENAI_MODEL", "gpt-4o"),
                   help="OpenAI model when GPT is used (default: gpt-4o)")
    p.add_argument("--paid", action="store_true",
                   help="send paid newsdata.io params (needs a paid plan)")
    return p


def main(argv=None):
    args = build_parser().parse_args(argv)
    use_gpt = decide_gpt(args)
    paid = args.paid or env_flag("NEWSDATA_PAID")

    try:
        client = NewsDataClient(paid_mode=paid)
        articles = fetch_articles(
            client, args.count,
            q=args.query, country=args.country,
            language=args.language, category=args.category,
        )
    except NewsDataError as exc:
        print(f"error: {exc}", file=sys.stderr)
        return 1

    if not articles:
        print("No articles came back. Try a broader query, drop --country, "
              "or check your daily quota.")
        return 0

    engine = f"GPT ({args.model})" if use_gpt else "built-in templates"
    print(f"Repurposing {len(articles)} article(s) using {engine}.\n")
    print(sentiment_chart(articles))
    print()

    for i, article in enumerate(articles, 1):
        fields, content = repurpose(article, use_gpt=use_gpt, model=args.model)
        print(render_article(i, fields, content))
        if args.output:
            path = write_markdown(args.output, i, fields, content)
            print(f"    saved -> {path}\n")

    return 0


if __name__ == "__main__":
    raise SystemExit(main())
