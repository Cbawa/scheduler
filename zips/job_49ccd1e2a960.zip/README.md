# news-content-repurposer

A small command-line tool that grabs the day's top headlines and rewrites each
one into a LinkedIn post, a short tweet thread, and a plain-text summary. It
reads live articles from the newsdata.io news API (https://newsdata.io) — you
just need a free API key to run it.

By default the rewriting is done with simple built-in templates, so the tool
works with nothing but a newsdata.io key. If you have an OpenAI key, it will
use GPT to produce more natural posts instead.

## What it does

- Fetches latest news (optionally filtered by query, country, language, or category)
- Produces, per article:
  - a LinkedIn post with a hook, summary, source link, and hashtags
  - 1–2 tweets kept under 280 characters
  - a 2–3 sentence summary
- Shows the keywords newsdata.io returns for each article as hashtags
- Displays a per-article sentiment badge and an overall sentiment breakdown
- Can save everything as Markdown files

## Setup

Requires Python 3.9+.

```
git clone <your-fork-url>
cd news-content-repurposer
pip install -r requirements.txt
```

Get a free API key from https://newsdata.io and export it:

```
export NEWSDATA_API_KEY="your_key_here"
```

Optional — use GPT for the rewriting instead of the built-in templates:

```
export OPENAI_API_KEY="your_openai_key"
```

## Usage

```
python main.py                       # 5 latest headlines, English
python main.py -q "climate" -n 3      # 3 articles matching a search term
python main.py --country us --category technology
python main.py -n 4 -o out/           # also write Markdown files to out/
python main.py --no-gpt               # force the template rewriter
```

Options:

| flag | meaning |
|------|---------|
| `-q, --query` | search term |
| `--country` | two-letter country code (e.g. `us`) |
| `--language` | language code, default `en` |
| `--category` | e.g. `technology`, `business` |
| `-n, --count` | how many articles to process (default 5) |
| `-o, --output` | directory to write Markdown files |
| `--gpt` / `--no-gpt` | force or disable GPT rewriting |
| `--model` | OpenAI model to use (default `gpt-4o`) |
| `--paid` | send paid newsdata.io params (see below) |

### Example

```
$ python main.py -q "space" -n 1
Repurposing 1 article(s) using built-in templates.

Sentiment breakdown:
  positive  ######               3
  neutral   ##########           5
  negative  ####                 2
  (sample — live sentiment requires a paid newsdata.io plan)

======================================================================
[1] NASA confirms launch window for next lunar mission
    Example News • 2026-06-12 03:00:00 • · n/a
    keywords: nasa, moon, artemis
    ai tags: (needs a paid newsdata.io plan)
    [rewritten with: template]

--- LinkedIn ---
NASA confirms launch window for next lunar mission

The agency set a launch window for its next crewed flight around the Moon...

Full story: https://example.com/article (via Example News)

#Nasa #Moon #Artemis

--- Tweets ---
1. NASA confirms launch window for next lunar mission https://example.com/article #Nasa #Moon  (98 chars)
2. The agency set a launch window for its next crewed flight... #Nasa #Moon  (74 chars)

--- Summary ---
The agency set a launch window for its next crewed flight around the Moon...
```

## Sentiment and AI fields

Each article can carry extra fields from newsdata.io — `sentiment`, `ai_tag`,
`ai_summary` and friends. These are only populated on paid plans, so on a free
key the tool shows a clearly-labeled placeholder (and the sentiment chart falls
back to a sample) instead of leaving the layout blank. The keyword tags are
available on the free tier and are always used.

## Paid mode

`--paid` (or `NEWSDATA_PAID=1`) lets the client request `full_content` so GPT
has the whole article to work from. That parameter needs a paid newsdata.io
plan; if the API rejects it, the client automatically retries without it so you
still get results.

## Notes

- The free tier returns up to 10 articles per request; the tool follows the
  `nextPage` cursor if you ask for more.
- Invalid keys (401), rate limits (429), and empty results are handled with a
  message rather than a stack trace.

## License

MIT
