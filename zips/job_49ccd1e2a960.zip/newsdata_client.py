"""Minimal client for the newsdata.io news API (https://newsdata.io).

Stays on the free tier by default: it only sends paid query params when
paid_mode is enabled, and retries once without them if the API says no.
"""
from __future__ import annotations

import os
import time

import requests

BASE_URL = "https://newsdata.io/api/1"

# Query params that require a paid plan. Sending one on a free key fails the
# whole request, so they are opt-in only.
PAID_PARAMS = ("full_content",)


class NewsDataError(Exception):
    """Something went wrong talking to newsdata.io."""


class PaidParamError(NewsDataError):
    """The API rejected a request, most likely a paid-only parameter."""


def _safe_message(resp):
    try:
        body = resp.json()
    except ValueError:
        return resp.text[:200]
    if isinstance(body, dict):
        result = body.get("results") or body.get("message") or body
        return str(result)[:200]
    return str(body)[:200]


class NewsDataClient:
    def __init__(self, api_key=None, paid_mode=False, timeout=30, max_retries=4):
        self.api_key = api_key or os.environ.get("NEWSDATA_API_KEY")
        if not self.api_key:
            raise NewsDataError(
                "NEWSDATA_API_KEY is not set. Grab a free key at "
                "https://newsdata.io and export it first."
            )
        self.paid_mode = paid_mode
        self.timeout = timeout
        self.max_retries = max_retries
        self.session = requests.Session()

    def _get(self, endpoint, params):
        query = {k: v for k, v in params.items() if v not in (None, "")}
        query["apikey"] = self.api_key
        url = BASE_URL + endpoint
        last_err = None
        for attempt in range(self.max_retries):
            try:
                resp = self.session.get(url, params=query, timeout=self.timeout)
            except requests.RequestException as exc:
                last_err = exc
                time.sleep(min(2 ** attempt, 8))
                continue
            if resp.status_code == 200:
                return resp.json()
            if resp.status_code == 401:
                raise NewsDataError("Invalid API key (401). Check NEWSDATA_API_KEY.")
            if resp.status_code == 429:
                last_err = NewsDataError("Rate limited (429).")
                time.sleep(min(2 ** attempt, 8))
                continue
            if resp.status_code in (403, 422):
                raise PaidParamError(_safe_message(resp))
            raise NewsDataError(
                f"Request failed ({resp.status_code}): {_safe_message(resp)}"
            )
        raise last_err or NewsDataError("Request failed after retries.")

    def latest(self, q=None, country=None, language="en", category=None,
               size=None, page=None):
        params = {
            "q": q,
            "country": country,
            "language": language,
            "category": category,
            "page": page,
        }
        if size:
            params["size"] = int(size) if self.paid_mode else min(int(size), 10)
        if self.paid_mode:
            params["full_content"] = 1
        try:
            return self._get("/latest", params)
        except PaidParamError:
            # Drop paid params and try once more so free keys still get results.
            for key in PAID_PARAMS:
                params.pop(key, None)
            self.paid_mode = False
            return self._get("/latest", params)


def fetch_articles(client, count, **kwargs):
    """Pull `count` articles, following the nextPage cursor as needed."""
    collected = []
    page = None
    while len(collected) < count:
        data = client.latest(page=page, **kwargs)
        results = data.get("results") or []
        if not results:
            break
        collected.extend(results)
        page = data.get("nextPage")
        if not page:
            break
    return collected[:count]
