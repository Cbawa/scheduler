"""Turn a newsdata.io article into a LinkedIn post, tweets, and a summary.

Default path is template-based and needs no extra services, so it runs on a
free newsdata.io key alone. If OPENAI_API_KEY is available the same article is
rewritten with GPT for a more natural result.
"""
from __future__ import annotations

import json
import re

SYSTEM_PROMPT = (
    "You are a social media editor. You repurpose a single news article into "
    "ready-to-post content. Keep facts accurate, never invent details, and "
    "stay neutral in tone. Reply with JSON only."
)


def _as_list(value):
    if not value:
        return []
    if isinstance(value, list):
        return [str(v) for v in value if v]
    return [str(value)]


def article_fields(a):
    """Pull the fields we use, guarding the paid/AI ones that may be absent."""
    return {
        "title": (a.get("title") or "").strip(),
        "description": (a.get("description") or "").strip(),
        "content": (a.get("content") or "").strip(),
        "link": a.get("link") or "",
        "source": a.get("source_name") or a.get("source_id") or "",
        "pub_date": a.get("pubDate") or "",
        "keywords": [k for k in (a.get("keywords") or []) if k],
        "category": _as_list(a.get("category")),
        # Paid / AI response fields — simply None on a free key.
        "sentiment": a.get("sentiment"),
        "sentiment_stats": a.get("sentiment_stats"),
        "ai_summary": (a.get("ai_summary") or "").strip(),
        "ai_tag": _as_list(a.get("ai_tag")),
        "ai_region": _as_list(a.get("ai_region")),
        "ai_org": _as_list(a.get("ai_org")),
    }


def clip(text, limit):
    text = " ".join((text or "").split())
    if len(text) <= limit:
        return text
    if limit <= 1:
        return text[:limit]
    cut = text[: limit - 1].rsplit(" ", 1)[0]
    return (cut or text[: limit - 1]).rstrip() + "…"


def to_hashtags(words, limit=5):
    tags = []
    for word in words[:limit]:
        token = "".join(
            part.capitalize() for part in re.split(r"[^A-Za-z0-9]+", word) if part
        )
        if token and not token[0].isdigit():
            tags.append("#" + token)
    return tags


def _fit_tweet(body, link, tail):
    budget = 280
    reserve = len(tail)
    if link:
        reserve += len(link) + 1
    body = clip(body, max(0, budget - reserve - 1))
    parts = [body] if body else []
    if link:
        parts.append(link)
    return (" ".join(parts) + tail).strip()


def template_repurpose(f):
    summary_src = f["ai_summary"] or f["description"] or f["title"]
    tag_words = f["keywords"] or f["ai_tag"]
    hashtags = to_hashtags(tag_words)

    # LinkedIn
    li_parts = [f["title"].rstrip(".")]
    li_parts.append("")
    li_parts.append(clip(summary_src, 600))
    if f["link"]:
        via = f" (via {f['source']})" if f["source"] else ""
        li_parts += ["", f"Full story: {f['link']}{via}"]
    if hashtags:
        li_parts += ["", " ".join(hashtags)]
    linkedin = "\n".join(li_parts).strip()

    # Tweets
    short_tags = " ".join(to_hashtags(tag_words, limit=2))
    tail = (" " + short_tags) if short_tags else ""
    tweets = [_fit_tweet(f["title"].rstrip("."), f["link"], tail)]
    body = f["ai_summary"] or f["description"]
    if body and body.strip() != f["title"].strip():
        tweets.append(_fit_tweet(body, "", tail))

    return {
        "linkedin": linkedin,
        "tweets": tweets,
        "summary": clip(summary_src, 400),
    }


def _build_user_prompt(f):
    keywords = ", ".join(f["keywords"]) or "(none)"
    body = f["content"] or f["ai_summary"] or f["description"]
    return (
        "Repurpose this article. Return JSON with keys: linkedin (string), "
        "tweets (array of strings, each <= 280 chars), summary (string, 2-3 "
        "sentences).\n\n"
        f"Title: {f['title']}\n"
        f"Source: {f['source']}\n"
        f"Keywords: {keywords}\n"
        f"Link: {f['link']}\n\n"
        f"Article: {clip(body, 2000)}"
    )


def gpt_repurpose(f, model):
    from openai import OpenAI

    client = OpenAI()
    resp = client.chat.completions.create(
        model=model,
        temperature=0.7,
        response_format={"type": "json_object"},
        messages=[
            {"role": "system", "content": SYSTEM_PROMPT},
            {"role": "user", "content": _build_user_prompt(f)},
        ],
    )
    data = json.loads(resp.choices[0].message.content)
    tweets = [str(t).strip() for t in (data.get("tweets") or []) if str(t).strip()]
    return {
        "linkedin": str(data.get("linkedin", "")).strip(),
        "tweets": tweets or template_repurpose(f)["tweets"],
        "summary": str(data.get("summary", "")).strip(),
    }


def repurpose(article, use_gpt=False, model="gpt-4o"):
    f = article_fields(article)
    if use_gpt:
        try:
            content = gpt_repurpose(f, model)
            content["engine"] = f"openai:{model}"
        except Exception as exc:  # fall back so the run never dies
            content = template_repurpose(f)
            content["engine"] = f"template (GPT unavailable: {exc})"
    else:
        content = template_repurpose(f)
        content["engine"] = "template"
    return f, content
