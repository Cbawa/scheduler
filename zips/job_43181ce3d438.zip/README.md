# NewsData.io — Postman Collection

A complete, ready-to-run **Postman collection** for the [NewsData.io](https://newsdata.io) news API. It ships with **40+ pre-built requests** covering every endpoint — latest news, sources, and crypto news — plus a Postman **environment**, collection **variables**, and automatic **test scripts** (status assertions + automatic `nextPage` pagination capture).

Everything here works on the **FREE** NewsData.io plan. Paid-only parameters are included for completeness but are **disabled by default** and clearly labelled, so a brand-new free user can import the collection and start sending requests immediately.

## What's inside

| File | Purpose |
| --- | --- |
| `NewsData.io.postman_collection.json` | The collection — 43 requests across 4 folders |
| `NewsData.io.postman_environment.json` | Environment with `baseUrl`, `apikey`, `nextPage` |
| `package.json` | Optional [Newman](https://github.com/postmanlabs/newman) CLI runner |
| `.gitignore` | Standard Node / report ignores |

Folders:

- **📰 Latest News (`/news`)** — 26 requests: keyword search, title/meta search, country/language/category filters, domain filters, timeframe, timezone, page size, dedupe, media filters, pagination, and combined examples.
- **🌐 Sources (`/sources`)** — 5 requests: list and filter the available news publishers.
- **🪙 Crypto News (`/crypto`)** — 10 requests: coin filters, keyword/title search, timeframe, and pagination.
- **🔁 Pagination Workflow** — 2 requests demonstrating the `nextPage` token flow end to end.

## Requirements

- A free NewsData.io API key — grab one at <https://newsdata.io/register>.
- [Postman](https://www.postman.com/downloads/) (desktop or web), **or** Node.js 18+ if you want to run it from the command line with Newman.

## Quick start (Postman GUI)

1. **Import** both JSON files: in Postman click **Import** and select `NewsData.io.postman_collection.json` and `NewsData.io.postman_environment.json`.
2. In the top-right environment dropdown, select **NewsData.io Environment**.
3. Open the environment (the eye icon), set the **`apikey`** value to your real key, and save.
4. Open any request (start with **Get latest news**) and hit **Send**. ✅

The collection reads the key from the `{{apikey}}` variable and sends it as the `apikey` query parameter on every request — your key is never hardcoded in a request.

## Run from the command line (Newman)

The key is read from the **`NEWSDATA_API_KEY`** environment variable so nothing secret is committed:

```bash
npm install                       # installs newman locally
export NEWSDATA_API_KEY="your_key_here"
npm test                          # runs the whole collection
```

Under the hood that runs:

```bash
newman run NewsData.io.postman_collection.json \
  -e NewsData.io.postman_environment.json \
  --env-var "apikey=$NEWSDATA_API_KEY"
```

## Built-in test scripts

Every request inherits collection-level scripts that:

- assert the HTTP status is `200`,
- assert the JSON body has `status: "success"` and a `results` array,
- automatically save the response's `nextPage` token into the `{{nextPage}}` variable so the next paginated call just works,
- warn (without failing the run) on `403`/`422` responses, which usually mean a parameter requires a paid plan.

The collection pre-request script also warns you in the console if the `apikey` variable is still unset.

## Free plan vs. paid plan

This collection is built around the **free tier**. The following requests/parameters are **paid-only** and are included but **disabled by default** — enabling them on a free key returns an "upgrade your plan" error, which the test scripts surface gracefully:

- `sentiment` (sentiment analysis) on `/news` and `/crypto`
- AI fields such as `ai_tag` / `tag` filtering
- `prioritydomain` advanced priority filtering
- the historical `/archive` endpoint and long date ranges
- advanced boolean full-text query operators in `q`

Free-plan reminders also worth knowing: `size` is capped at **10** results per page on the free tier, and you paginate using the **`nextPage`** token returned in each response (not numeric page offsets).

## Endpoints reference

- Base URL: `https://newsdata.io/api/1`
- `GET /news` — latest news (primary endpoint)
- `GET /sources` — available news sources
- `GET /crypto` — crypto-specific news
- Auth: append `apikey=<YOUR_KEY>` as a query parameter.

Full parameter docs: <https://newsdata.io/documentation>

## License

MIT — see below. Not affiliated with NewsData.io; provided as a community showcase.
