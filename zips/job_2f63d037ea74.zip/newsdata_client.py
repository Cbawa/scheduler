"""A small, free-tier-safe client for the newsdata.io news API.

Reads the API key from the ``NEWSDATA_API_KEY`` environment variable and exposes
a single :func:`fetch_news` helper that returns a flat list of article dicts.

The client deliberately uses only endpoints/parameters available on the FREE
plan and degrades gracefully when the API reports that a feature requires an
upgrade.
"""

from __future__ import annotations

import os
import time
from typing import Any, Dict, List, Optional

import requests

API_BASE = "https://newsdata.io/api/1"
NEWS_ENDPOINT = f"{API_BASE}/news"

# Number of pages to fetch per refresh (each page == 10 articles == 1 credit).
MAX_PAGES = int(os.environ.get("MAX_PAGES", "3"))


class NewsDataError(RuntimeError):
    """Raised for unrecoverable problems talking to newsdata.io."""


class MissingApiKeyError(NewsDataError):
    """Raised when the NEWSDATA_API_KEY environment variable is not set."""


def get_api_key() -> str:
    """Return the API key or raise a clear error if it is missing."""
    key = os.environ.get("NEWSDATA_API_KEY", "").strip()
    if not key:
        raise MissingApiKeyError(
            "NEWSDATA_API_KEY is not set. Get a free key at "
            "https://newsdata.io/register and export it:\n"
            "    export NEWSDATA_API_KEY='pub_xxxxxxxx'"
        )
    return key


def _clean_params(params: Dict[str, Any]) -> Dict[str, Any]:
    """Drop empty/None values so we never send blank query params."""
    return {k: v for k, v in params.items() if v not in (None, "", [])}


def fetch_news(
    query: Optional[str] = None,
    country: Optional[str] = None,
    language: Optional[str] = None,
    category: Optional[str] = None,
    max_pages: int = MAX_PAGES,
    timeout: int = 20,
) -> List[Dict[str, Any]]:
    """Fetch latest news from newsdata.io and return a flat list of articles.

    Pagination follows the ``nextPage`` token returned in each response. All
    parameters are optional and only free-tier filters are used.

    Raises
    ------
    MissingApiKeyError
        If ``NEWSDATA_API_KEY`` is unset.
    NewsDataError
        For an invalid key (401) or other unrecoverable API errors.
    """
    api_key = get_api_key()

    base_params = _clean_params(
        {
            "apikey": api_key,
            "q": query,
            "country": country,
            "language": language,
            "category": category,
        }
    )

    articles: List[Dict[str, Any]] = []
    next_page: Optional[str] = None
    pages = max(1, int(max_pages))

    for _ in range(pages):
        params = dict(base_params)
        if next_page:
            params["page"] = next_page

        try:
            resp = requests.get(NEWS_ENDPOINT, params=params, timeout=timeout)
        except requests.RequestException as exc:
            raise NewsDataError(f"Network error contacting newsdata.io: {exc}") from exc

        # --- Handle the documented error statuses gracefully --------------
        if resp.status_code == 401:
            raise NewsDataError(
                "newsdata.io rejected the API key (401). "
                "Check that NEWSDATA_API_KEY is correct."
            )
        if resp.status_code == 429:
            # Rate limited: stop paginating and return whatever we have.
            print("[newsdata] Rate limit hit (429) — returning partial results.")
            break
        if resp.status_code in (403, 422):
            # Typically a paid-only parameter. Free-tier flow shouldn't hit
            # this, but if it does we surface a readable message instead of
            # crashing the dashboard.
            print(
                f"[newsdata] Request rejected ({resp.status_code}); "
                "a requested feature may require a paid plan. Skipping."
            )
            break

        try:
            payload = resp.json()
        except ValueError:
            raise NewsDataError("newsdata.io returned a non-JSON response.")

        if payload.get("status") == "error":
            message = (
                payload.get("results", {}).get("message")
                if isinstance(payload.get("results"), dict)
                else payload.get("message")
            )
            print(f"[newsdata] API error: {message or 'unknown error'}")
            break

        results = payload.get("results") or []
        if not results:
            # Empty result set — perfectly valid, just stop.
            break

        articles.extend(results)

        next_page = payload.get("nextPage")
        if not next_page:
            break

        # Be gentle with the free-tier rate limit between pages.
        time.sleep(0.4)

    return articles
