# News Analytics Dashboard

A real-time, interactive analytics dashboard that visualizes the global news
stream from the [newsdata.io](https://newsdata.io) news API. Track **news
volume over time**, **category trends**, and **source distribution** — all
from a single Plotly [Dash](https://dash.plotly.com/) web app.

![Built with Dash](https://img.shields.io/badge/built%20with-Plotly%20Dash-3b5998)
![Python](https://img.shields.io/badge/python-3.9%2B-blue)

## Features

- **Volume timeline** — articles published per hour from the latest results.
- **Category breakdown** — donut chart of how stories distribute across
  newsdata.io categories (business, technology, sports, …).
- **Top sources** — horizontal bar chart of the most active publishers.
- **Language mix** — quick view of the languages in the current result set.
- **Live filters** — keyword search, country, language and category, plus a
  one-click refresh.
- **Headline feed** — a scrollable table of the most recent matching stories
  with links back to the original articles.
- **Free-tier safe** — uses only endpoints and fields available on the
  newsdata.io **FREE** plan and degrades gracefully on rate limits or empty
  results.

## Live data source

This project is a showcase for the newsdata.io REST API. It calls the
`GET /news` endpoint (`https://newsdata.io/api/1/news`) and aggregates the
returned articles entirely client-side, so it works for brand-new accounts on
the free tier.

## Quick start

### 1. Get a free API key

Sign up at [newsdata.io](https://newsdata.io/register) and copy your API key
from the dashboard.

### 2. Install dependencies

```bash
git clone https://github.com/your-username/news-analytics-dashboard.git
cd news-analytics-dashboard
python -m venv .venv
source .venv/bin/activate      # On Windows: .venv\Scripts\activate
pip install -r requirements.txt
```

### 3. Set your API key

The app reads the key from the `NEWSDATA_API_KEY` environment variable. It is
**never** hardcoded.

```bash
export NEWSDATA_API_KEY="pub_xxxxxxxxxxxxxxxxxxxxxxxxxxxx"   # macOS / Linux
# setx NEWSDATA_API_KEY "pub_xxxx"                          # Windows (new shell)
```

You can also copy `.env.example` to `.env` and fill in your key — the app loads
it automatically.

### 4. Run the dashboard

```bash
python app.py
```

Then open <http://127.0.0.1:8050> in your browser.

## Configuration

| Variable             | Required | Default | Description                              |
|----------------------|----------|---------|------------------------------------------|
| `NEWSDATA_API_KEY`   | yes      | —       | Your newsdata.io API key.                |
| `MAX_PAGES`          | no       | `3`     | Pages to pull per refresh (10 articles each). |
| `HOST`               | no       | `127.0.0.1` | Host to bind the Dash server to.     |
| `PORT`               | no       | `8050`  | Port for the Dash server.                |

Keep `MAX_PAGES` low (2–3) on the free tier to stay within the daily credit
limit — each page is one API credit.

## Free tier vs. paid plan

This dashboard intentionally relies **only** on free-tier functionality:
`q`, `country`, `language`, `category` filters and `page`-based pagination on
the `/news` endpoint.

The following newsdata.io features are **paid-only** and are deliberately *not*
required by this project:

- Sentiment analysis (`sentiment`)
- AI-enriched fields (`ai_tag`, `ai_region`, `ai_org`, `ai_summary`)
- The historical `/archive` endpoint and long date ranges
- Advanced full-text query operators

If newsdata.io returns a `403`/`422` “upgrade your plan” response for an
optional parameter, the client logs a warning and continues without it, so the
app keeps working. Invalid keys (`401`), rate limits (`429`) and empty result
sets are all handled without crashing.

## Project layout

```
news-analytics-dashboard/
├─ app.py                # Dash app: layout, callbacks and charts
├─ newsdata_client.py    # Thin, free-tier-safe newsdata.io API client
├─ requirements.txt
├─ .env.example
└─ README.md
```

## License

MIT — see the badge above. Built as an open showcase for the newsdata.io API.
