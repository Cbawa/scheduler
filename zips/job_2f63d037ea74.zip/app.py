"""Real-time news analytics dashboard powered by newsdata.io and Plotly Dash.

Run with:
    export NEWSDATA_API_KEY='pub_xxxx'
    python app.py

Then open http://127.0.0.1:8050
"""

from __future__ import annotations

import os
from collections import Counter
from datetime import datetime
from typing import Any, Dict, List

import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
from dash import Dash, Input, Output, State, dash_table, dcc, html

# Load a local .env if python-dotenv is available (optional convenience).
try:  # pragma: no cover - optional dependency
    from dotenv import load_dotenv

    load_dotenv()
except Exception:  # noqa: BLE001
    pass

from newsdata_client import MissingApiKeyError, NewsDataError, fetch_news

# --- Filter option lists (all valid on the free tier) --------------------
CATEGORIES = [
    "business", "crime", "domestic", "education", "entertainment",
    "environment", "food", "health", "lifestyle", "other", "politics",
    "science", "sports", "technology", "top", "tourism", "world",
]
COUNTRIES = {
    "": "Any country", "us": "United States", "gb": "United Kingdom",
    "in": "India", "ca": "Canada", "au": "Australia", "de": "Germany",
    "fr": "France", "jp": "Japan", "br": "Brazil", "za": "South Africa",
}
LANGUAGES = {
    "": "Any language", "en": "English", "es": "Spanish", "fr": "French",
    "de": "German", "hi": "Hindi", "pt": "Portuguese", "ar": "Arabic",
}

EMPTY_FIG_TEXT = "No data — try a broader filter or refresh."


def _empty_figure(message: str = EMPTY_FIG_TEXT) -> go.Figure:
    fig = go.Figure()
    fig.add_annotation(
        text=message, showarrow=False, font=dict(size=15, color="#888"),
        xref="paper", yref="paper", x=0.5, y=0.5,
    )
    fig.update_layout(
        template="plotly_white", margin=dict(l=20, r=20, t=40, b=20),
        xaxis=dict(visible=False), yaxis=dict(visible=False),
    )
    return fig


def _to_dataframe(articles: List[Dict[str, Any]]) -> pd.DataFrame:
    """Normalise the raw newsdata.io articles into a tidy DataFrame."""
    rows = []
    for a in articles:
        category = a.get("category") or []
        if isinstance(category, list):
            category = category[0] if category else "unknown"
        rows.append(
            {
                "title": a.get("title") or "(untitled)",
                "source": a.get("source_id") or "unknown",
                "category": category or "unknown",
                "language": a.get("language") or "unknown",
                "pubDate": a.get("pubDate"),
                "link": a.get("link") or "",
            }
        )
    df = pd.DataFrame(rows)
    if not df.empty:
        df["pubDate"] = pd.to_datetime(df["pubDate"], errors="coerce")
    return df


def build_volume_figure(df: pd.DataFrame) -> go.Figure:
    if df.empty or df["pubDate"].isna().all():
        return _empty_figure()
    series = (
        df.dropna(subset=["pubDate"])
        .set_index("pubDate")
        .assign(count=1)["count"]
        .resample("1H")
        .sum()
    )
    fig = px.area(
        x=series.index, y=series.values,
        labels={"x": "Published (hourly)", "y": "Articles"},
    )
    fig.update_traces(line_color="#2a6df4", fillcolor="rgba(42,109,244,0.15)")
    fig.update_layout(
        template="plotly_white", margin=dict(l=20, r=20, t=40, b=20),
        title="News volume over time",
    )
    return fig


def build_category_figure(df: pd.DataFrame) -> go.Figure:
    if df.empty:
        return _empty_figure()
    counts = df["category"].value_counts()
    fig = px.pie(
        names=counts.index, values=counts.values, hole=0.45,
        color_discrete_sequence=px.colors.qualitative.Set2,
    )
    fig.update_layout(
        template="plotly_white", margin=dict(l=20, r=20, t=40, b=20),
        title="Category distribution",
    )
    return fig


def build_source_figure(df: pd.DataFrame) -> go.Figure:
    if df.empty:
        return _empty_figure()
    counts = df["source"].value_counts().head(10).sort_values()
    fig = px.bar(
        x=counts.values, y=counts.index, orientation="h",
        labels={"x": "Articles", "y": "Source"},
        color=counts.values, color_continuous_scale="Blues",
    )
    fig.update_layout(
        template="plotly_white", margin=dict(l=20, r=20, t=40, b=20),
        title="Top sources", coloraxis_showscale=False,
    )
    return fig


def build_language_figure(df: pd.DataFrame) -> go.Figure:
    if df.empty:
        return _empty_figure()
    counts = df["language"].value_counts()
    fig = px.bar(
        x=counts.index, y=counts.values,
        labels={"x": "Language", "y": "Articles"},
        color_discrete_sequence=["#7048e8"],
    )
    fig.update_layout(
        template="plotly_white", margin=dict(l=20, r=20, t=40, b=20),
        title="Language mix",
    )
    return fig


# --- Dash app -----------------------------------------------------------
app = Dash(__name__, title="News Analytics Dashboard")
server = app.server  # exposed for WSGI / gunicorn deployments


def _dropdown_options(mapping: Dict[str, str]):
    return [{"label": label, "value": value} for value, label in mapping.items()]


app.layout = html.Div(
    style={"maxWidth": "1180px", "margin": "0 auto", "padding": "24px",
           "fontFamily": "Segoe UI, Roboto, Helvetica, Arial, sans-serif"},
    children=[
        html.H1("📰 News Analytics Dashboard",
                style={"marginBottom": "4px"}),
        html.P(
            [
                "Live news volume, category trends and source distribution via ",
                html.A("newsdata.io", href="https://newsdata.io",
                       target="_blank"),
                ".",
            ],
            style={"color": "#555", "marginTop": "0"},
        ),
        html.Div(
            style={"display": "grid",
                   "gridTemplateColumns": "repeat(auto-fit, minmax(180px, 1fr))",
                   "gap": "12px", "alignItems": "end", "marginBottom": "12px"},
            children=[
                html.Div([
                    html.Label("Keyword"),
                    dcc.Input(id="f-query", type="text", placeholder="e.g. economy",
                              debounce=True, style={"width": "100%"}),
                ]),
                html.Div([
                    html.Label("Country"),
                    dcc.Dropdown(id="f-country",
                                 options=_dropdown_options(COUNTRIES),
                                 value="", clearable=False),
                ]),
                html.Div([
                    html.Label("Language"),
                    dcc.Dropdown(id="f-language",
                                 options=_dropdown_options(LANGUAGES),
                                 value="en", clearable=False),
                ]),
                html.Div([
                    html.Label("Category"),
                    dcc.Dropdown(
                        id="f-category",
                        options=[{"label": "Any category", "value": ""}]
                        + [{"label": c.title(), "value": c} for c in CATEGORIES],
                        value="", clearable=False),
                ]),
                html.Div([
                    html.Button("🔄 Refresh", id="refresh-btn", n_clicks=0,
                                style={"width": "100%", "padding": "8px",
                                       "background": "#2a6df4", "color": "white",
                                       "border": "none", "borderRadius": "6px",
                                       "cursor": "pointer"}),
                ]),
            ],
        ),
        html.Div(id="status-bar",
                 style={"margin": "6px 0 16px", "color": "#666",
                        "minHeight": "20px"}),
        html.Div(
            style={"display": "grid",
                   "gridTemplateColumns": "2fr 1fr", "gap": "16px"},
            children=[
                dcc.Graph(id="g-volume", figure=_empty_figure("Loading…")),
                dcc.Graph(id="g-category", figure=_empty_figure("Loading…")),
            ],
        ),
        html.Div(
            style={"display": "grid",
                   "gridTemplateColumns": "1fr 1fr", "gap": "16px",
                   "marginTop": "16px"},
            children=[
                dcc.Graph(id="g-source", figure=_empty_figure("Loading…")),
                dcc.Graph(id="g-language", figure=_empty_figure("Loading…")),
            ],
        ),
        html.H3("Latest headlines", style={"marginTop": "24px"}),
        dash_table.DataTable(
            id="headlines",
            columns=[
                {"name": "Published", "id": "pubDate"},
                {"name": "Source", "id": "source"},
                {"name": "Category", "id": "category"},
                {"name": "Title", "id": "title", "presentation": "markdown"},
            ],
            data=[],
            page_size=10,
            style_cell={"textAlign": "left", "padding": "8px",
                        "fontFamily": "inherit", "maxWidth": "480px",
                        "whiteSpace": "normal", "height": "auto"},
            style_header={"fontWeight": "bold", "background": "#f4f6fb"},
            style_data_conditional=[
                {"if": {"row_index": "odd"}, "backgroundColor": "#fafbfe"}
            ],
        ),
        html.Footer(
            "Free-tier friendly — no paid sentiment/AI fields required.",
            style={"marginTop": "28px", "color": "#999", "fontSize": "13px",
                   "textAlign": "center"},
        ),
    ],
)


@app.callback(
    Output("g-volume", "figure"),
    Output("g-category", "figure"),
    Output("g-source", "figure"),
    Output("g-language", "figure"),
    Output("headlines", "data"),
    Output("status-bar", "children"),
    Input("refresh-btn", "n_clicks"),
    State("f-query", "value"),
    State("f-country", "value"),
    State("f-language", "value"),
    State("f-category", "value"),
)
def update_dashboard(_clicks, query, country, language, category):
    try:
        articles = fetch_news(
            query=query or None,
            country=country or None,
            language=language or None,
            category=category or None,
        )
    except MissingApiKeyError as exc:
        msg = f"⚠️ {exc}"
        empty = _empty_figure("Set NEWSDATA_API_KEY and refresh.")
        return empty, empty, empty, empty, [], msg
    except NewsDataError as exc:
        msg = f"⚠️ {exc}"
        empty = _empty_figure("API error — see status message above.")
        return empty, empty, empty, empty, [], msg

    df = _to_dataframe(articles)

    if df.empty:
        empty = _empty_figure()
        return (empty, empty, empty, empty, [],
                "No articles matched these filters. Try broadening them.")

    table = (
        df.assign(
            pubDate=df["pubDate"].dt.strftime("%Y-%m-%d %H:%M").fillna("—"),
            title=df.apply(
                lambda r: f"[{r['title']}]({r['link']})" if r["link"]
                else r["title"], axis=1),
        )[["pubDate", "source", "category", "title"]]
        .to_dict("records")
    )

    stamp = datetime.now().strftime("%H:%M:%S")
    status = f"✅ Loaded {len(df)} articles • updated {stamp}"

    return (
        build_volume_figure(df),
        build_category_figure(df),
        build_source_figure(df),
        build_language_figure(df),
        table,
        status,
    )


if __name__ == "__main__":
    host = os.environ.get("HOST", "127.0.0.1")
    port = int(os.environ.get("PORT", "8050"))
    # Fail fast with a friendly message if the key is missing.
    if not os.environ.get("NEWSDATA_API_KEY", "").strip():
        print(
            "\n⚠️  NEWSDATA_API_KEY is not set.\n"
            "   Get a free key at https://newsdata.io/register then run:\n"
            "       export NEWSDATA_API_KEY='pub_xxxxxxxx'\n"
            "   The dashboard will start, but charts stay empty until it is set.\n"
        )
    app.run(host=host, port=port, debug=True)
