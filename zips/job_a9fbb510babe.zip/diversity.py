"""Fetches articles from newsdata.io and computes a media diversity score."""
import hashlib
import json
import os
import time
from collections import Counter
from pathlib import Path

import requests

API_BASE = "https://newsdata.io/api/1"
CACHE_DIR = Path(__file__).resolve().parent / ".cache"
CACHE_TTL_SECONDS = 3600

# Ceilings used to normalize raw counts into a 0-1 scale. These are just
# reasonable defaults for "a lot of coverage" - tune freely.
SOURCE_CEILING = 25
COUNTRY_CEILING = 12
LANGUAGE_CEILING = 8

SAMPLE_SENTIMENT = {"positive": 34, "neutral": 46, "negative": 20}


def _get_api_key():
    key = os.environ.get("NEWSDATA_API_KEY")
    if not key:
        raise RuntimeError(
            "NEWSDATA_API_KEY is not set. Get a free key at https://newsdata.io and "
            "export it: export NEWSDATA_API_KEY=your_key_here"
        )
    return key


def _cache_path(topic, language, country):
    digest = hashlib.sha256(f"{topic}|{language}|{country}".encode("utf-8")).hexdigest()[:16]
    return CACHE_DIR / f"{digest}.json"


def _load_cache(topic, language, country):
    path = _cache_path(topic, language, country)
    if not path.exists():
        return None
    try:
        data = json.loads(path.read_text())
    except (json.JSONDecodeError, OSError):
        return None
    if time.time() - data.get("_cached_at", 0) > CACHE_TTL_SECONDS:
        return None
    return data.get("articles")


def _save_cache(topic, language, country, articles):
    try:
        CACHE_DIR.mkdir(exist_ok=True)
        path = _cache_path(topic, language, country)
        path.write_text(json.dumps({"_cached_at": time.time(), "articles": articles}))
    except OSError:
        pass  # cache is a nice-to-have, never fatal


def _paid_params_enabled():
    return os.environ.get("ENABLE_PAID_PARAMS") == "1"


def fetch_articles(topic, max_pages=10, language=None, country=None, use_cache=True):
    """Fetch up to max_pages of /1/latest results for topic, paginating via nextPage."""
    if use_cache:
        cached = _load_cache(topic, language, country)
        if cached is not None:
            print(f"Using cached results for: {topic} (delete .cache/ or pass --no-cache to refresh)")
            return cached

    api_key = _get_api_key()
    articles = []
    page_token = None
    paid_mode = _paid_params_enabled()

    print(f"Fetching articles for: {topic}")
    for page_num in range(1, max_pages + 1):
        params = {"apikey": api_key, "q": topic}
        if language:
            params["language"] = language
        if country:
            params["country"] = country
        if page_token:
            params["page"] = page_token
        if paid_mode:
            params["sentiment"] = "positive"  # example paid filter; adjust as needed

        resp = requests.get(f"{API_BASE}/latest", params=params, timeout=20)

        if resp.status_code == 401:
            raise RuntimeError("newsdata.io rejected the API key (401). Check NEWSDATA_API_KEY.")
        if resp.status_code == 429:
            print(f"  page {page_num}: rate limited (429), stopping here")
            break
        if resp.status_code in (403, 422) and paid_mode:
            # Paid query params rejected on this key - retry once without them.
            paid_mode = False
            params.pop("sentiment", None)
            resp = requests.get(f"{API_BASE}/latest", params=params, timeout=20)

        if resp.status_code != 200:
            raise RuntimeError(f"newsdata.io returned HTTP {resp.status_code}: {resp.text[:200]}")

        body = resp.json()
        if body.get("status") != "success":
            message = body.get("results", {}).get("message") if isinstance(body.get("results"), dict) else None
            raise RuntimeError(f"newsdata.io returned an error: {message or body}")

        results = body.get("results") or []
        articles.extend(results)
        print(f"  page {page_num}: {len(results)} articles")

        page_token = body.get("nextPage")
        if not page_token or not results:
            break

    if use_cache:
        _save_cache(topic, language, country, articles)

    return articles


def _norm(value, ceiling):
    if ceiling <= 0:
        return 0.0
    return min(value, ceiling) / ceiling


def _as_list(value):
    """newsdata.io sometimes returns country/language as a list, sometimes a scalar."""
    if value is None:
        return []
    if isinstance(value, list):
        return [v for v in value if v]
    return [value]


def build_report(topic, max_pages=10, language=None, country=None, use_cache=True):
    articles = fetch_articles(topic, max_pages=max_pages, language=language, country=country, use_cache=use_cache)

    sources = Counter()
    countries = Counter()
    languages = Counter()
    keywords = Counter()
    sentiments = Counter()
    has_real_sentiment = False

    article_summaries = []

    for art in articles:
        source = art.get("source_id") or art.get("source_name") or "unknown source"
        sources[source] += 1

        for c in _as_list(art.get("country")):
            countries[str(c).lower()] += 1
        for l in _as_list(art.get("language")):
            languages[str(l).lower()] += 1

        for kw in (art.get("keywords") or []):
            if kw:
                keywords[kw.lower()] += 1

        sentiment = art.get("sentiment")
        if sentiment:
            has_real_sentiment = True
            sentiments[sentiment] += 1

        article_summaries.append(
            {
                "title": art.get("title") or "(untitled)",
                "source": source,
                "country": _as_list(art.get("country")),
                "language": art.get("language"),
                "keywords": (art.get("keywords") or [])[:5],
                "sentiment": sentiment,
                "ai_summary": art.get("ai_summary"),
            }
        )

    score = (
        40 * _norm(len(sources), SOURCE_CEILING)
        + 35 * _norm(len(countries), COUNTRY_CEILING)
        + 25 * _norm(len(languages), LANGUAGE_CEILING)
    )

    if has_real_sentiment:
        total = sum(sentiments.values()) or 1
        sentiment_breakdown = {k: round(100 * v / total) for k, v in sentiments.items()}
        sentiment_is_sample = False
    else:
        sentiment_breakdown = SAMPLE_SENTIMENT
        sentiment_is_sample = True

    return {
        "topic": topic,
        "article_count": len(articles),
        "unique_sources": len(sources),
        "unique_countries": len(countries),
        "unique_languages": len(languages),
        "score": round(score),
        "top_countries": countries.most_common(6),
        "top_languages": languages.most_common(6),
        "top_keywords": keywords.most_common(8),
        "sentiment_breakdown": sentiment_breakdown,
        "sentiment_is_sample": sentiment_is_sample,
        "articles": article_summaries[:10],
    }
