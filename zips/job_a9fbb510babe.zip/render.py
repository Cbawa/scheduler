"""Plain-text rendering of a diversity report (terminal bar charts, tag chips)."""

BAR_WIDTH = 10


def _bar(count, max_count):
    if max_count <= 0:
        return ""
    filled = max(1, round(BAR_WIDTH * count / max_count))
    return "#" * filled


def _print_bars(title, items):
    print(title)
    if not items:
        print("  (no data)")
        return
    max_count = max(count for _, count in items)
    for label, count in items:
        bar = _bar(count, max_count).ljust(BAR_WIDTH)
        print(f"  {label:<15}{bar} {count}")


def print_report(report):
    print(f"\n=== Diversity report: {report['topic']} ===")
    print(f"Articles analyzed:   {report['article_count']}")
    print(f"Unique sources:      {report['unique_sources']}")
    print(f"Unique countries:    {report['unique_countries']}")
    print(f"Unique languages:    {report['unique_languages']}")
    print(f"\nDiversity score: {report['score']} / 100")

    print()
    _print_bars("Top countries:", report["top_countries"])
    print()
    _print_bars("Top languages:", report["top_languages"])

    print("\nTop keywords:")
    if report["top_keywords"]:
        line = "  " + "  ".join(f"{kw} ({count})" for kw, count in report["top_keywords"])
        print(line)
    else:
        print("  (none returned for this query)")

    sample_marker = "*" if report["sentiment_is_sample"] else ""
    print("\nSentiment breakdown" + (" (sample)" if report["sentiment_is_sample"] else "") + ":")
    for label, pct in report["sentiment_breakdown"].items():
        print(f"  {label:<10}{pct}%{sample_marker}")

    print("\nRecent articles:")
    if not report["articles"]:
        print("  (no results - try a broader query)")
    for art in report["articles"]:
        sentiment_label = art["sentiment"] or "unknown"
        badge = f"[{sentiment_label}{sample_marker}]"
        countries = ", ".join(art["country"]) if art["country"] else "unknown"
        print(f"  {badge} {art['title']}")
        print(f"      {art['source']} | {countries} | {art['language'] or 'unknown'}")
        if art["keywords"]:
            print(f"      tags: {', '.join(art['keywords'])}")
        if art["ai_summary"]:
            print(f"      summary: {art['ai_summary']}")

    if report["sentiment_is_sample"]:
        print(f"\n* sample sentiment - live sentiment requires a paid newsdata.io plan")
