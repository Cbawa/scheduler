#!/usr/bin/env python3
"""CLI entry point for news-diversity-score."""
import argparse
import json
import sys

from diversity import build_report
from render import print_report


def parse_args(argv):
    parser = argparse.ArgumentParser(
        description="Score how diverse the news coverage of a topic is, using the newsdata.io news API."
    )
    parser.add_argument("topic", help="search query, e.g. 'artemis moon landing'")
    parser.add_argument(
        "--pages", type=int, default=10, help="max number of result pages to fetch (default: 10, ~10 articles/page)"
    )
    parser.add_argument("--language", default=None, help="restrict to a language code, e.g. en")
    parser.add_argument("--country", default=None, help="restrict to a country code, e.g. us")
    parser.add_argument("--no-cache", action="store_true", help="skip the local response cache")
    parser.add_argument("--json", action="store_true", help="print the report as JSON instead of text")
    return parser.parse_args(argv)


def main(argv=None):
    args = parse_args(argv if argv is not None else sys.argv[1:])

    try:
        report = build_report(
            topic=args.topic,
            max_pages=args.pages,
            language=args.language,
            country=args.country,
            use_cache=not args.no_cache,
        )
    except RuntimeError as exc:
        print(f"Error: {exc}", file=sys.stderr)
        return 1

    if args.json:
        print(json.dumps(report, indent=2, default=str))
    else:
        print_report(report)

    return 0


if __name__ == "__main__":
    raise SystemExit(main())
