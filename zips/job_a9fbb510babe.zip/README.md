# news-diversity-score

A small command-line tool that scores how broadly a topic is covered in the
news. Give it a search term and it queries the [newsdata.io](https://newsdata.io)
news API, pulls back matching articles, and reports how many distinct sources,
countries, and languages are actually writing about it. A topic covered by one
outlet in one country gets a low diversity score; a topic covered by dozens of
outlets across many countries and languages gets a high one.

The idea started from wanting a quick gut-check on whether a story was a real
global story or a single-newsroom echo. Source count alone is misleading (a lot
of outlets syndicate the same wire copy), so this weighs country and language
spread too.

## How the score works

For each article returned, the tool collects:

- `source_id` (or `source_name` as fallback) -> unique sources
- `country` (list per article) -> unique countries
- `language` -> unique languages
- `keywords` -> aggregated into a simple tag cloud for the topic

The diversity score is a 0-100 blend:

```
score = 40 * norm(unique_sources) + 35 * norm(unique_countries) + 25 * norm(unique_languages)
```

where `norm(x)` caps each count at a reasonable ceiling (25 sources, 12
countries, 8 languages) and scales it to 0-1. The ceilings are just there so
one freak outlier doesn't blow out the scale; they're constants at the top of
`diversity.py` if you want to tune them.

## Features

- Pulls up to 100 recent articles per topic (10 pages of the free-tier max of
  10 results/page) from `/1/latest`
- Breaks down coverage by source, country, and language with counts
- Renders a plain-text bar chart of the top countries/languages in the terminal
- Shows each article's `keywords` as tag chips (always present on the free
  tier) to give a feel for sub-topics within the story
- Per-article sentiment badges when available, with a clearly labeled sample
  breakdown when the API key doesn't return sentiment (see "Paid fields"
  below)
- Results are cached to a local JSON file per query so re-running the same
  topic within an hour doesn't burn API calls

## Setup

```bash
git clone https://github.com/<you>/news-diversity-score.git
cd news-diversity-score
pip install -r requirements.txt
```

Get a free API key at https://newsdata.io (sign-up gives you a key
immediately, no card required) and export it:

```bash
export NEWSDATA_API_KEY="your_key_here"
```

The tool reads the key only from that environment variable. If it's unset, it
exits with a message telling you to set it rather than failing halfway
through.

## Usage

```bash
python main.py "artemis moon landing"
```

Sample output:

```
Fetching articles for: artemis moon landing
  page 1: 10 articles
  page 2: 10 articles
  page 3: 4 articles (no more pages)

=== Diversity report: artemis moon landing ===
Articles analyzed:   24
Unique sources:      17
Unique countries:    9
Unique languages:    4

Diversity score: 61 / 100

Top countries:
  united states  ########## 9
  india          ######     6
  united kingdom ####       4
  germany        ##         2

Top languages:
  english   ################ 19
  german    ##                2
  hindi     ##                2
  french    #                 1

Top keywords:
  nasa (11)  moon (9)  spacex (6)  artemis ii (5)  orion (4)

Recent articles:
  [neutral*] NASA confirms Artemis II crew timeline
      Reuters | united states | english
      tags: nasa, moon, artemis ii
  [positive*] India's ISRO to support Artemis lunar relay
      The Hindu | india | english
      tags: isro, nasa, moon

* sample sentiment - live sentiment requires a paid newsdata.io plan
```

Useful flags:

```bash
python main.py "ukraine grain deal" --pages 3       # fetch fewer pages (faster, less API quota)
python main.py "election" --language en --country us  # narrow the query before scoring
python main.py "election" --no-cache                 # skip the local cache
python main.py "election" --json                     # print the raw report as JSON
```

## Paid fields

newsdata.io's free plan returns `keywords` on every article, which is what the
tag cloud and per-article tags are built from. Fields like `sentiment` and the
`ai_*` fields (`ai_tag`, `ai_region`, `ai_summary`) are only populated on paid
plans - on a free key they come back empty, and the tool notices this and
falls back to a clearly-marked sample sentiment distribution instead of
leaving that part of the report blank. If your key does return sentiment, the
real values are used automatically and the `*` sample marker disappears.

No paid query parameters (`sentiment=`, `tag=`, `from_date=`, etc.) are sent
by default, since those error out entirely on a free key. Set
`ENABLE_PAID_PARAMS=1` to opt into sending `sentiment` as a query filter if
you're on a plan that supports it; if the API rejects the request, the tool
retries once without the paid parameters so you still get a result.

## Notes

- The tool paginates using the API's `nextPage` cursor and stops once it's
  null, once `--pages` is reached, or once the free-tier rate limit is hit
  (HTTP 429), whichever comes first.
- A 401 response (bad key) prints a short explanation instead of a stack
  trace.
- Country/language fields are sometimes lists in the API response (an article
  can be tagged with more than one); the tool counts each value in the list
  rather than picking just the first.

## License

MIT
