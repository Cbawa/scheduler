#!/usr/bin/env python3
'''Terminal preview of the feed the Kodular app shows.

This sends the same /1/latest request as the app's Web1 component, so you can
check that a key works and see what each card will contain before using a
phone. It reads the key from NEWSDATA_API_KEY.

    python check_feed.py --category science --pages 2
'''

import argparse
import os
import sys
import textwrap

import requests

API_URL = 'https://newsdata.io/api/1/latest'
CATEGORIES = ['top', 'world', 'business', 'technology', 'science', 'health',
              'sports', 'entertainment', 'politics']
SENTIMENTS = ('positive', 'neutral', 'negative')
# Shown, with a clear label, when the key's plan returns no sentiment field.
SAMPLE_SENTIMENT = {'positive': 3, 'neutral': 5, 'negative': 2}
# Paid-only query parameter. Sent only with --paid or NEWSDATA_PAID=1.
PAID_PARAMS = {'timeframe': '24'}


class ApiError(Exception):
    pass


def clean(value):
    '''Same rules as the cleanText / isRealText blocks in the app.'''
    if value is None or isinstance(value, (list, dict)):
        return ''
    text = str(value).strip()
    lowered = text.lower()
    if lowered in ('null', 'none') or lowered.startswith('only available'):
        return ''
    return text


def text_list(value):
    if not isinstance(value, list):
        return []
    return [clean(v) for v in value if clean(v)]


def shorten(text, width):
    return textwrap.shorten(text, width=width, placeholder='…')


def error_message(resp):
    try:
        body = resp.json()
    except ValueError:
        return resp.text[:200].strip()
    results = body.get('results') if isinstance(body, dict) else None
    if isinstance(results, dict):
        return clean(results.get('message')) or str(results)
    return clean(results)


def request_page(session, key, category, language, token, paid):
    params = {'language': language, 'category': category}
    if token:
        params['page'] = token
    if paid:
        params.update(PAID_PARAMS)
    try:
        # Sending the key in a header keeps it out of URLs that might appear in error messages.
        return session.get(API_URL, params=params, headers={'X-ACCESS-KEY': key}, timeout=20)
    except requests.RequestException as exc:
        raise ApiError(f'network problem: {exc}') from None


def get_page(session, key, category, language, token, paid):
    '''Fetch one page. Returns (results, next_page_token, paid_still_enabled).'''
    resp = request_page(session, key, category, language, token, paid)
    if paid and resp.status_code in (403, 422):
        print(f'paid-plan filter refused (HTTP {resp.status_code}: {error_message(resp)}); '
              'retrying without it', file=sys.stderr)
        paid = False
        resp = request_page(session, key, category, language, token, paid)
    if resp.status_code == 401:
        raise ApiError('newsdata.io rejected the API key (HTTP 401). Check NEWSDATA_API_KEY.')
    if resp.status_code == 429:
        raise ApiError('rate limit reached (HTTP 429). Free keys have a request quota; wait and try again.')
    if resp.status_code != 200:
        raise ApiError(f'request failed (HTTP {resp.status_code}): {error_message(resp)}')
    try:
        body = resp.json()
    except ValueError:
        raise ApiError('the response was not JSON') from None
    results = body.get('results')
    if not isinstance(results, list):
        results = []
    return results, clean(body.get('nextPage')), paid


def print_card(number, art):
    '''Print one article with the same layout as an app card. Returns its sentiment or None.'''
    title = clean(art.get('title')) or '(no title)'
    source = clean(art.get('source_name')) or clean(art.get('source_id'))
    published = clean(art.get('pubDate'))
    print(f'[{number:>2}] {title}')
    print(f'     {source}  ·  {published}')

    summary = clean(art.get('ai_summary'))
    description = clean(art.get('description'))
    if summary:
        print(f'     AI summary: {shorten(summary, 160)}')
    elif description:
        print(f'     {shorten(description, 160)}')

    keywords = text_list(art.get('keywords'))
    if keywords:
        print('     keywords: ' + ', '.join(keywords[:6]))

    sentiment = clean(art.get('sentiment')).lower()
    if sentiment not in SENTIMENTS:
        sentiment = None
    sentiment_text = sentiment or 'n/a (paid plan)'
    stats = art.get('sentiment_stats')
    if sentiment and isinstance(stats, dict):
        scores = ', '.join(f'{k} {v}' for k, v in stats.items())
        sentiment_text += f' ({scores})'
    chips = text_list(art.get('ai_tag')) + text_list(art.get('ai_region')) + text_list(art.get('ai_org'))
    chip_text = ', '.join(chips[:5]) if chips else 'n/a (paid plan)'
    print(f'     sentiment: {sentiment_text}   AI tags: {chip_text}')

    link = clean(art.get('link'))
    if link:
        print(f'     {link}')
    print()
    return sentiment


def print_sentiment(counts):
    real = sum(counts.values()) > 0
    data = counts if real else SAMPLE_SENTIMENT
    total = sum(data.values())
    if real:
        print('Sentiment across the fetched articles')
    else:
        print('Sentiment (SAMPLE - live sentiment requires a paid newsdata.io plan)')
    for name in SENTIMENTS:
        bar = '#' * round(30 * data[name] / total)
        print(f'  {name:<9} {bar:<30} {data[name]}')


def main():
    parser = argparse.ArgumentParser(description='Preview the newsdata.io feed used by the Kodular app.')
    parser.add_argument('-c', '--category', default='top', choices=CATEGORIES)
    parser.add_argument('-l', '--language', default='en', help='language code(s), comma separated (default: en)')
    parser.add_argument('-p', '--pages', type=int, default=1,
                        help='number of pages to follow via nextPage (default: 1)')
    parser.add_argument('--paid', action='store_true',
                        help='add the paid-plan timeframe=24 filter (NEWSDATA_PAID=1 does the same)')
    args = parser.parse_args()

    key = os.environ.get('NEWSDATA_API_KEY', '').strip()
    if not key:
        sys.exit('NEWSDATA_API_KEY is not set. Get a free key at https://newsdata.io, then run: '
                 'export NEWSDATA_API_KEY=your_key')

    paid = args.paid or os.environ.get('NEWSDATA_PAID', '').strip().lower() in ('1', 'true', 'yes')
    counts = dict.fromkeys(SENTIMENTS, 0)
    token = ''
    shown = 0
    more = False
    exit_code = 0

    with requests.Session() as session:
        for page in range(1, max(args.pages, 1) + 1):
            try:
                results, token, paid = get_page(session, key, args.category, args.language, token, paid)
            except ApiError as exc:
                print(f'error: {exc}', file=sys.stderr)
                exit_code = 1
                more = False
                break
            if not results:
                print(f'No articles for category {args.category!r} on page {page}.')
                more = False
                break
            print(f'--- {args.category} · page {page} · {len(results)} articles ---')
            print()
            for art in results:
                shown += 1
                sentiment = print_card(shown, art if isinstance(art, dict) else {})
                if sentiment:
                    counts[sentiment] += 1
            more = bool(token)
            if not token:
                break

    if shown:
        print_sentiment(counts)
    if more:
        print(f'\nmore available: run with --pages {args.pages + 1} to follow nextPage')
    return exit_code


if __name__ == '__main__':
    sys.exit(main())
