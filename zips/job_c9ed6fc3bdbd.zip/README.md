# kodular-newsdata-reader

A drag-and-drop Android news reader made in Kodular. It has category tabs, image cards that show the source and publish time, and Previous/Next paging. Headlines come from the newsdata.io news API (https://newsdata.io), and a free API key is enough to run it.

No Java or Kotlin was written by hand. The app is made of normal Kodular blocks. The only unusual part is how the project is stored. The repo has no binary `.aia` file. Instead, `build_aia.py` writes the designer and blocks files from Python and zips them, so every change shows up as a readable diff. If you just want the app, download the built `.aia` from the latest Actions run and import it. You don't need to write any code.

## What the app does

- **Category tabs:** Top, World, Business, Technology, Science, Health, Sports, Entertainment, Politics. Each tab sets the `category` parameter on `/1/latest`.
- **Cards:** each card shows an image, the headline, the source and publish time, a short description, a keyword line, and a *Read article* button that opens the original link in the browser.
- **Paging:** *Next page* follows the `nextPage` cursor from the response. *Previous* goes back through a stack of cursors that the app keeps. When `nextPage` is null, *Next page* is disabled.
- **Sentiment strip and badges:** a three-colour bar above the feed, plus a badge on each card, filled from each article's `sentiment` field.
- **AI line:** the `ai_tag`, `ai_region` and `ai_org` values are joined on each card. When `ai_summary` is present, it replaces the description.
- **Error states:** a 401 (bad key) reopens the key panel. A 429 shows a rate-limit message. An empty category shows a message instead of blank cards.
- You type the API key once in the app. It is saved in TinyDB on the device.

The free plan doesn't return the sentiment and AI fields. The widgets stay on screen with plain labels instead. Each card says `sentiment: paid plan`, and the bar shows a fixed 3/5/2 split with the caption *Sample only — live sentiment requires a paid newsdata.io plan*. The layout doesn't look broken, and sample numbers are never shown as live data. Keywords are included on the free plan and are shown as returned.

## Getting the .aia

**Without installing anything:** open the Actions tab, pick the latest `build-aia` run, and download the `NewsdataKodular-aia` artifact. GitHub delivers it as a zip that contains `NewsdataKodular.aia`.

**Building it yourself** needs Python 3.9 or newer and nothing outside the standard library:

```bash
python build_aia.py
# wrote dist/NewsdataKodular.aia (37 top-level blocks, ... blocks total, language=en)
```

Useful flags:

- `--language en,fr` changes the language filter. The default is `en`.
- `--emit-sources build/` also writes the raw `Screen1.scm`, `Screen1.bky` and `project.properties` so you can read them.
- `--app-name "My News"` changes the app label.

## Import into Kodular and run

1. Open https://creator.kodular.io, go to **My Projects → Import project**, and pick `NewsdataKodular.aia`.
2. Test it with the Kodular Companion app, or use **Export → Android App (.apk)** and install it.
3. The key panel opens on first launch. Paste your newsdata.io API key and tap **Save key**. The Top category then loads.

The app uses only stock components (Web, TinyDB, ActivityStarter, arrangements, labels, images, buttons, a checkbox), so the same file also imports into MIT App Inventor.

## API key

Sign up at https://newsdata.io to get a free key.

- **In the app:** paste the key into the key panel. The **API key** button in the top bar opens the panel again later.
- **For the Python tools:** they read the key from the `NEWSDATA_API_KEY` environment variable.

```bash
export NEWSDATA_API_KEY=your_key_here
```

If only you will install the build, `python build_aia.py --embed-key` uses `NEWSDATA_API_KEY` as the app's default key, so you don't have to paste it on the phone. The key is stored in plain text inside the blocks, so don't share or publish that `.aia`. That's why `*.aia` is listed in `.gitignore`.

## Checking a key from the terminal

`check_feed.py` sends the same request as the app and prints what each card would show. Use it to confirm that a key works and that a category has articles before you start debugging on a phone.

```bash
pip install -r requirements.txt
export NEWSDATA_API_KEY=your_key_here
python check_feed.py --category technology --pages 2
```

On a free key the output looks like this (trimmed, with placeholder headlines):

```
--- technology · page 1 · 10 articles ---

[ 1] Chipmaker outlines plans for a new packaging plant
     example-news  ·  2026-10-07 08:41:12
     The company said the facility would start volume production in…
     keywords: semiconductors, manufacturing
     sentiment: n/a (paid plan)   AI tags: n/a (paid plan)
     https://example.com/tech/chip-packaging-plant

[ 2] ...

Sentiment (SAMPLE - live sentiment requires a paid newsdata.io plan)
  positive  #########                      3
  neutral   ###############                5
  negative  ######                         2

more available: run with --pages 3 to follow nextPage
```

A bad key exits with a 401 message, a rate limit with a 429 message, and an empty category says so. None of them print a traceback.

## The request

```
GET https://newsdata.io/api/1/latest?apikey=KEY&language=en&category=technology
GET https://newsdata.io/api/1/latest?apikey=KEY&language=en&category=technology&page=<nextPage>
```

By default the app sends only parameters that work on the free plan. It reads these fields from each result: `title`, `link`, `source_name` (falling back to `source_id`), `pubDate`, `image_url`, `description` and `keywords`. When the plan includes them, it also reads `sentiment`, `ai_tag`, `ai_region`, `ai_org` and `ai_summary`. If a value is missing, null, or a placeholder string, it is shown as an empty or labelled state.

## Optional paid-plan filter

The **Paid-plan filter** checkbox under the sentiment strip adds `timeframe=24`, which limits results to the last 24 hours. This parameter needs a paid newsdata.io plan. If the API rejects it with a 403 or 422, the app requests the same page once more without it, so a free key still gets headlines. `check_feed.py --paid` (or `NEWSDATA_PAID=1`) works the same way.

## Changing the app

After importing, you can edit everything in Kodular's designer and blocks editor like any other project. `docs/blocks.md` explains what each procedure and event does.

If you'd rather change the source, the settings you're most likely to change are at the top of `build_aia.py`:

- `CATEGORIES`
- `CARD_COUNT`
- the colour constants
- `PAID_PARAMS`

Before it writes anything, the script checks that every block refers to a component, global variable or procedure that exists.

## Notes and limits

- There are 10 card slots because the free plan returns up to 10 results per request.
- The project files declare older format versions on purpose (`YA_VERSION` in `build_aia.py`). Kodular upgrades older projects when you import them but refuses projects that claim to be newer. If an import fails anyway, please open an issue with the exact error text.
- Images load directly from `image_url`. Some publishers block hotlinking, and those cards show an empty image area.

## Layout

```
build_aia.py                     generates dist/NewsdataKodular.aia
check_feed.py                    terminal preview of the same request
docs/blocks.md                   walkthrough of the blocks
.github/workflows/build-aia.yml  CI build that publishes the .aia as an artifact
```

## License

MIT, see `LICENSE`.
