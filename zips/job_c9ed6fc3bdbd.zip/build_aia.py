#!/usr/bin/env python3
'''Build the Kodular / App Inventor project (.aia) for the news reader.

An .aia file is a zip that holds three text files:

    youngandroidproject/project.properties
    src/<package>/<project>/Screen1.scm   designer: components and properties (JSON)
    src/<package>/<project>/Screen1.bky   blocks (Blockly XML)

The repo doesn't commit a binary. This script writes those files from Python,
so changes to the app can be reviewed in a diff, and then zips them. It only
uses the standard library. Run `python build_aia.py --help` to see the options.
'''

import argparse
import json
import os
import random
import sys
import xml.etree.ElementTree as ET
import zipfile
from pathlib import Path

PROJECT_NAME = 'NewsdataKodular'
PACKAGE = 'appinventor.ai_newsdata'
APP_TITLE = 'Headlines'

# Kodular and App Inventor upgrade older project files on import, but they
# refuse files that claim to be newer than the server. These are kept low on
# purpose.
YA_VERSION = '175'
BLOCKS_LANGUAGE_VERSION = '25'
COMPONENT_VERSIONS = {
    'Form': '20',
    'Label': '3',
    'Button': '6',
    'Image': '3',
    'Web': '4',
    'TextBox': '5',
    'CheckBox': '2',
    'TinyDB': '1',
    'ActivityStarter': '5',
    'VerticalArrangement': '3',
    'HorizontalArrangement': '3',
    'HorizontalScrollArrangement': '1',
    'VerticalScrollArrangement': '1',
}

API_BASE = 'https://newsdata.io/api/1/latest?'
# Sent only when the in-app 'Paid-plan filter' checkbox is ticked.
PAID_PARAMS = '&timeframe=24'
CARD_COUNT = 10  # the free plan returns up to 10 articles per request
KEY_TAG = 'newsdata_api_key'

# (button label, newsdata.io category value)
CATEGORIES = [
    ('Top', 'top'),
    ('World', 'world'),
    ('Business', 'business'),
    ('Technology', 'technology'),
    ('Science', 'science'),
    ('Health', 'health'),
    ('Sports', 'sports'),
    ('Entertainment', 'entertainment'),
    ('Politics', 'politics'),
]

# Designer colours. App Inventor stores colours as &HAARRGGBB.
SCREEN_BG = '&HFFF1F3F4'
WHITE = '&HFFFFFFFF'
INK = '&HFF1F2937'
MUTED = '&HFF6B7280'
ACCENT = '&HFF2563EB'
CHIP = '&HFFE5E7EB'
POSITIVE = '&HFF2E7D32'
NEUTRAL = '&HFF607D8B'
NEGATIVE = '&HFFC62828'
FILL = '-2'  # 'Fill parent' in the designer

# Global list name -> (component type, name prefix) for the card slots.
CARD_PARTS = [
    ('cardBoxes', 'VerticalArrangement', 'Card'),
    ('cardImages', 'Image', 'CardImg'),
    ('cardTitles', 'Label', 'CardTitle'),
    ('cardMetas', 'Label', 'CardMeta'),
    ('cardSummaries', 'Label', 'CardSummary'),
    ('cardKeywords', 'Label', 'CardKw'),
    ('cardSentiments', 'Label', 'CardSent'),
    ('cardTags', 'Label', 'CardTags'),
    ('cardOpens', 'Button', 'CardOpen'),
]


# ------------------------------------------------------------------ designer

_uuid = random.Random(2026)  # fixed seed so repeated builds produce the same file


def component(ctype, name, props=None, children=None):
    data = {
        '$Name': name,
        '$Type': ctype,
        '$Version': COMPONENT_VERSIONS[ctype],
        'Uuid': str(_uuid.randint(-2**31, 2**31 - 1)),
    }
    for key, value in (props or {}).items():
        data[key] = str(value)
    if children is not None:
        data['$Components'] = children
    return data


def label(name, text='', **props):
    props.setdefault('Width', FILL)
    return component('Label', name, dict(Text=text, **props))


def flat_button(name, text, bg=CHIP, fg=INK, size='12'):
    return component('Button', name, {
        'Text': text, 'BackgroundColor': bg, 'TextColor': fg, 'FontSize': size, 'Shape': '1',
    })


def card(i):
    return component('VerticalArrangement', f'Card{i}', {
        'Width': FILL, 'BackgroundColor': WHITE, 'Visible': 'False',
    }, [
        component('Image', f'CardImg{i}', {'Width': FILL, 'Height': '180', 'ScalePictureToFit': 'True'}),
        label(f'CardTitle{i}', FontSize='16', FontBold='True', TextColor=INK),
        label(f'CardMeta{i}', FontSize='12', TextColor=MUTED),
        label(f'CardSummary{i}', FontSize='13', TextColor=INK),
        label(f'CardKw{i}', FontSize='12', TextColor=ACCENT),
        component('HorizontalArrangement', f'CardBadges{i}', {'Width': FILL, 'AlignVertical': '2'}, [
            component('Label', f'CardSent{i}', {'FontSize': '11', 'BackgroundColor': CHIP, 'TextColor': INK}),
            label(f'CardTags{i}', FontSize='11', TextColor=MUTED),
        ]),
        flat_button(f'CardOpen{i}', 'Read article'),
        label(f'CardGap{i}', Height='10', BackgroundColor=SCREEN_BG),
    ])


def sentiment_bar(name, colour):
    return component('Label', name, {
        'Height': '20', 'FontSize': '11', 'TextAlignment': '1', 'TextColor': WHITE, 'BackgroundColor': colour,
    })


def build_form(app_name):
    top_bar = component('HorizontalArrangement', 'TopBar', {
        'Width': FILL, 'BackgroundColor': INK, 'AlignVertical': '2',
    }, [
        label('AppTitle', CATEGORIES[0][0], FontSize='20', FontBold='True', TextColor=WHITE),
        flat_button('KeyToggle', 'API key', bg=INK, fg=WHITE),
        flat_button('RefreshButton', 'Refresh', bg=INK, fg=WHITE),
    ])
    key_panel = component('VerticalArrangement', 'KeyPanel', {
        'Width': FILL, 'BackgroundColor': WHITE, 'Visible': 'False',
    }, [
        label('KeyHint', 'Paste your newsdata.io API key. It is saved in TinyDB on this device only.',
              FontSize='13', TextColor=MUTED),
        component('TextBox', 'KeyBox', {'Width': FILL, 'Hint': 'newsdata.io API key'}),
        flat_button('SaveKeyButton', 'Save key', bg=ACCENT, fg=WHITE),
    ])
    category_bar = component('HorizontalScrollArrangement', 'CategoryBar', {
        'Width': FILL, 'BackgroundColor': WHITE,
    }, [flat_button(f'Cat{title}', title) for title, _ in CATEGORIES])
    sentiment_panel = component('VerticalArrangement', 'SentPanel', {
        'Width': FILL, 'BackgroundColor': WHITE,
    }, [
        label('SentTitle', 'Sentiment', FontSize='13', FontBold='True', TextColor=INK),
        component('HorizontalArrangement', 'SentBar', {'Width': FILL}, [
            sentiment_bar('BarPos', POSITIVE),
            sentiment_bar('BarNeu', NEUTRAL),
            sentiment_bar('BarNeg', NEGATIVE),
        ]),
        label('SentCaption', '', FontSize='11', TextColor=MUTED),
    ])
    paid_check = component('CheckBox', 'PaidCheck', {
        'Text': 'Paid-plan filter: last 24 hours only', 'FontSize': '12',
    })
    status = label('StatusLabel', '', FontSize='12', TextColor=MUTED)
    nav = component('HorizontalArrangement', 'NavBar', {
        'Width': FILL, 'AlignHorizontal': '3', 'AlignVertical': '2',
    }, [
        component('Button', 'PrevButton', {'Text': 'Previous', 'Enabled': 'False', 'FontSize': '13'}),
        component('Label', 'PageLabel', {'Text': 'Page 1', 'FontSize': '12', 'TextColor': MUTED}),
        component('Button', 'NextButton', {'Text': 'Next page', 'Enabled': 'False', 'FontSize': '13'}),
    ])
    feed = component('VerticalScrollArrangement', 'Feed', {'Width': FILL, 'Height': FILL},
                     [card(i) for i in range(1, CARD_COUNT + 1)] + [nav])
    return {
        '$Name': 'Screen1',
        '$Type': 'Form',
        '$Version': COMPONENT_VERSIONS['Form'],
        'Uuid': '0',
        'AppName': app_name,
        'Title': APP_TITLE,
        'BackgroundColor': SCREEN_BG,
        'Sizing': 'Responsive',
        '$Components': [
            top_bar, key_panel, category_bar, sentiment_panel, paid_check, status, feed,
            component('Web', 'Web1'),
            component('TinyDB', 'TinyDB1'),
            component('ActivityStarter', 'ActivityStarter1'),
        ],
    }


def scm_text(form):
    payload = {
        'authURL': ['ai2.appinventor.mit.edu'],
        'YaVersion': YA_VERSION,
        'Source': 'Form',
        'Properties': form,
    }
    return '#|\n$JSON\n' + json.dumps(payload, separators=(',', ':')) + '\n|#\n'


# -------------------------------------------------------------------- blocks
#
# Small helpers that emit Blockly XML in the same shape App Inventor and
# Kodular save it. Plain Python values (str / int / bool) become text, number
# and boolean blocks, and a Python list of statements becomes a block chain.

def B(btype, fields=None, values=None, stmts=None, mutation=None, mut_children=None):
    el = ET.Element('block', {'type': btype})
    if mutation is not None or mut_children:
        mut = ET.SubElement(el, 'mutation', {k: str(v) for k, v in (mutation or {}).items()})
        for tag, attrs in mut_children or []:
            ET.SubElement(mut, tag, attrs)
    for name, value in (fields or {}).items():
        ET.SubElement(el, 'field', {'name': name}).text = str(value)
    for name, value in (values or {}).items():
        ET.SubElement(el, 'value', {'name': name}).append(_v(value))
    for name, body in (stmts or {}).items():
        body = _s(body)
        if body is not None:
            ET.SubElement(el, 'statement', {'name': name}).append(body)
    return el


def _v(x):
    if isinstance(x, ET.Element):
        return x
    if isinstance(x, bool):
        return B('logic_boolean', fields={'BOOL': 'TRUE' if x else 'FALSE'})
    if isinstance(x, (int, float)):
        return B('math_number', fields={'NUM': x})
    if isinstance(x, str):
        return B('text', fields={'TEXT': x})
    raise TypeError(f'cannot turn {x!r} into a block')


def _s(x):
    if isinstance(x, (list, tuple)):
        return seq(*x)
    return x


def seq(*blocks):
    chain = [b for b in blocks if b is not None]
    if not chain:
        return None
    for prev, nxt in zip(chain, chain[1:]):
        tail = prev
        while tail.find('next') is not None:
            tail = tail.find('next')[0]
        ET.SubElement(tail, 'next').append(nxt)
    return chain[0]


# variables
def gget(name):
    return B('lexical_variable_get', fields={'VAR': 'global ' + name})


def gset(name, value):
    return B('lexical_variable_set', fields={'VAR': 'global ' + name}, values={'VALUE': value})


def get(name):
    return B('lexical_variable_get', fields={'VAR': name})


def let(name, value):
    return B('lexical_variable_set', fields={'VAR': name}, values={'VALUE': value})


def local(pairs, body):
    return B('local_declaration_statement', mutation={},
             mut_children=[('localname', {'name': n}) for n, _ in pairs],
             fields={f'VAR{i}': n for i, (n, _) in enumerate(pairs)},
             values={f'DECL{i}': v for i, (_, v) in enumerate(pairs)},
             stmts={'STACK': body})


def local_expr(pairs, expr):
    values = {f'DECL{i}': v for i, (_, v) in enumerate(pairs)}
    values['RETURN'] = expr
    return B('local_declaration_expression', mutation={},
             mut_children=[('localname', {'name': n}) for n, _ in pairs],
             fields={f'VAR{i}': n for i, (n, _) in enumerate(pairs)},
             values=values)


# text
def join(*parts):
    return B('text_join', mutation={'items': len(parts)},
             values={f'ADD{i}': p for i, p in enumerate(parts)})


def is_empty(t):
    return B('text_isEmpty', values={'VALUE': t})


def text_len(t):
    return B('text_length', values={'VALUE': t})


def trim(t):
    return B('text_trim', values={'TEXT': t})


def downcase(t):
    return B('text_changeCase', fields={'OP': 'DOWNCASE'}, values={'TEXT': t})


def starts_at(t, piece):
    return B('text_starts_at', values={'TEXT': t, 'PIECE': piece})


def segment(t, start, count):
    return B('text_segment', values={'TEXT': t, 'START': start, 'LENGTH': count})


# logic and math
def eq(a, b):
    return B('logic_compare', fields={'OP': 'EQ'}, values={'A': a, 'B': b})


def not_(a):
    return B('logic_negate', values={'BOOL': a})


def cmp(op, a, b):
    return B('math_compare', fields={'OP': op}, values={'A': a, 'B': b})


def add(a, b):
    return B('math_add', mutation={'items': 2}, values={'NUM0': a, 'NUM1': b})


def mul(a, b):
    return B('math_multiply', mutation={'items': 2}, values={'NUM0': a, 'NUM1': b})


def quotient(a, b):
    return B('math_divide', fields={'OP': 'QUOTIENT'}, values={'DIVIDEND': a, 'DIVISOR': b})


def choose(test, then, other):
    return B('controls_choose', values={'TEST': test, 'THENRETURN': then, 'ELSERETURN': other})


def rgb(r, g, b):
    return B('color_make_color', values={'COLORLIST': list_of(r, g, b)})


# lists
def list_of(*items):
    return B('lists_create_with', mutation={'items': len(items)},
             values={f'ADD{i}': x for i, x in enumerate(items)})


def select(lst, index):
    return B('lists_select_item', values={'LIST': lst, 'NUM': index})


def length(lst):
    return B('lists_length', values={'LIST': lst})


def append(lst, item):
    return B('lists_add_items', mutation={'items': 1}, values={'LIST': lst, 'ITEM0': item})


def remove_at(lst, index):
    return B('lists_remove_item', values={'LIST': lst, 'INDEX': index})


def is_list(x):
    return B('lists_is_list', values={'ITEM': x})


def list_empty(lst):
    return B('lists_is_empty', values={'LIST': lst})


def index_in(x, lst):
    return B('lists_position_in', values={'ITEM': x, 'LIST': lst})


def lookup(key, pairs, missing):
    return B('lists_lookup_in_pairs', values={'KEY': key, 'LIST': pairs, 'NOTFOUND': missing})


# control
def if_(*clauses, else_=None):
    '''if_(cond0, body0, cond1, body1, ..., else_=body)'''
    pairs = list(zip(clauses[0::2], clauses[1::2]))
    mutation = {}
    if len(pairs) > 1:
        mutation['elseif'] = len(pairs) - 1
    if else_ is not None:
        mutation['else'] = 1
    values = {f'IF{i}': cond for i, (cond, _) in enumerate(pairs)}
    stmts = {f'DO{i}': body for i, (_, body) in enumerate(pairs)}
    if else_ is not None:
        stmts['ELSE'] = else_
    return B('controls_if', values=values, stmts=stmts, mutation=mutation or None)


def for_range(var, start, end, body):
    return B('controls_forRange', fields={'VAR': var},
             values={'START': start, 'END': end, 'STEP': 1}, stmts={'DO': body})


def for_each(var, lst, body):
    return B('controls_forEach', fields={'VAR': var}, values={'LIST': lst}, stmts={'DO': body})


def do_return(body, value):
    return B('controls_do_then_return', stmts={'STM': body}, values={'VALUE': value})


# procedures: name -> (parameter names, returns a value?)
SIGNATURES = {
    'cleanText': (['v'], True),
    'fieldText': (['item', 'key'], True),
    'isRealText': (['t'], True),
    'joinList': (['items', 'sep'], True),
    'truncate': (['t', 'n'], True),
    'buildUrl': (['token', 'includePaid'], True),
    'errorText': (['parsed'], True),
    'addAll': (['target', 'src'], False),
    'fetchPage': (['token', 'includePaid'], False),
    'loadFresh': ([], False),
    'showError': (['code', 'content'], False),
    'renderResults': (['parsed'], False),
    'fillCard': (['i', 'art'], False),
    'setBar': (['bar', 'n', 'total'], False),
    'updateSentimentBar': ([], False),
    'updateNav': ([], False),
    'highlightCategory': (['btn'], False),
    'openLink': (['url'], False),
}


def define(name, body):
    params, returns = SIGNATURES[name]
    slot = {'values': {'RETURN': body}} if returns else {'stmts': {'STACK': body}}
    return B('procedures_defreturn' if returns else 'procedures_defnoreturn',
             mutation={}, mut_children=[('arg', {'name': p}) for p in params],
             fields={'NAME': name, **{f'VAR{i}': p for i, p in enumerate(params)}},
             **slot)


def call(name, *args):
    params, returns = SIGNATURES[name]
    if len(args) != len(params):
        raise ValueError(f'{name} expects {len(params)} argument(s), got {len(args)}')
    return B('procedures_callreturn' if returns else 'procedures_callnoreturn',
             mutation={'name': name}, mut_children=[('arg', {'name': p}) for p in params],
             fields={'PROCNAME': name},
             values={f'ARG{i}': a for i, a in enumerate(args)})


# components
def comp(ctype, name):
    return B('component_component_block', mutation={'component_type': ctype, 'instance_name': name},
             fields={'COMPONENT_SELECTOR': name})


def setp(ctype, name, prop, value):
    return B('component_set_get', mutation={
        'component_type': ctype, 'set_or_get': 'set', 'property_name': prop,
        'is_generic': 'false', 'instance_name': name,
    }, fields={'COMPONENT_SELECTOR': name, 'PROP': prop}, values={'VALUE': value})


def getp(ctype, name, prop):
    return B('component_set_get', mutation={
        'component_type': ctype, 'set_or_get': 'get', 'property_name': prop,
        'is_generic': 'false', 'instance_name': name,
    }, fields={'COMPONENT_SELECTOR': name, 'PROP': prop})


def any_set(ctype, target, prop, value):
    return B('component_set_get', mutation={
        'component_type': ctype, 'set_or_get': 'set', 'property_name': prop, 'is_generic': 'true',
    }, fields={'PROP': prop}, values={'COMPONENT': target, 'VALUE': value})


def method(ctype, name, meth, *args):
    return B('component_method', mutation={
        'component_type': ctype, 'method_name': meth, 'is_generic': 'false', 'instance_name': name,
    }, fields={'COMPONENT_SELECTOR': name}, values={f'ARG{i}': a for i, a in enumerate(args)})


def on(ctype, name, event, body):
    return B('component_event', mutation={
        'component_type': ctype, 'is_generic': 'false', 'instance_name': name, 'event_name': event,
    }, fields={'COMPONENT_SELECTOR': name}, stmts={'DO': body})


def on_any(ctype, event, body):
    return B('component_event', mutation={
        'component_type': ctype, 'is_generic': 'true', 'event_name': event,
    }, stmts={'DO': body})


# shorthands used by the program below
def status(text):
    return setp('Label', 'StatusLabel', 'Text', text)


def paid_checked():
    return getp('CheckBox', 'PaidCheck', 'Checked')


def nth(list_name, index):
    return select(gget(list_name), index)


def uri(x):
    return method('Web', 'Web1', 'UriEncode', x)


def decode(x):
    return method('Web', 'Web1', 'JsonTextDecode', x)


# ------------------------------------------------------------------- program

def build_blocks(language, default_key):
    blocks = []

    def declare(name, value):
        blocks.append(B('global_declaration', fields={'NAME': name}, values={'VALUE': value}))

    for name, value in [
        ('apiKey', ''), ('category', CATEGORIES[0][1]), ('currentToken', ''), ('nextToken', ''),
        ('paidRetried', False), ('lastPaid', False), ('realSentiment', False),
        ('posCount', 0), ('neuCount', 0), ('negCount', 0),
    ]:
        declare(name, value)
    for name in ['pageStack', 'articleLinks', 'catButtons', 'catKeys', 'catLabels'] + [p[0] for p in CARD_PARTS]:
        declare(name, list_of())

    def field(key):
        return call('fieldText', get('art'), key)

    def card_set(list_name, ctype, prop, value):
        return any_set(ctype, nth(list_name, get('i')), prop, value)

    # --- value helpers ------------------------------------------------------
    # On a free key, paid fields come back as null or as a placeholder string
    # such as 'ONLY AVAILABLE IN ... PLANS'. Both are treated as empty.
    blocks.append(define('cleanText', choose(
        is_list(get('v')), '', choose(eq(get('v'), 'null'), '', get('v')))))
    blocks.append(define('fieldText', call('cleanText', lookup(get('key'), get('item'), ''))))
    blocks.append(define('isRealText', choose(
        is_empty(get('t')), False, cmp('EQ', starts_at(downcase(get('t')), 'only available'), 0))))
    blocks.append(define('joinList', local_expr([('out', '')], do_return(
        for_each('x', get('items'), if_(
            is_empty(get('out')), let('out', get('x')),
            else_=let('out', join(get('out'), get('sep'), get('x'))))),
        get('out')))))
    blocks.append(define('truncate', choose(
        cmp('GT', text_len(get('t')), get('n')),
        join(segment(get('t'), 1, get('n')), '…'),
        get('t'))))
    blocks.append(define('addAll', if_(is_list(get('src')), for_each('x', get('src'), if_(
        call('isRealText', call('cleanText', get('x'))), append(get('target'), get('x')))))))

    # --- requests -----------------------------------------------------------
    blocks.append(define('buildUrl', join(
        API_BASE, 'apikey=', uri(gget('apiKey')),
        '&language=', language,
        '&category=', gget('category'),
        choose(is_empty(get('token')), '', join('&page=', uri(get('token')))),
        choose(get('includePaid'), PAID_PARAMS, ''))))
    blocks.append(define('fetchPage', if_(
        is_empty(gget('apiKey')),
        [setp('VerticalArrangement', 'KeyPanel', 'Visible', True),
         status('Add your newsdata.io API key to load headlines.')],
        else_=[
            gset('currentToken', get('token')),
            gset('lastPaid', get('includePaid')),
            status('Loading…'),
            setp('Button', 'PrevButton', 'Enabled', False),
            setp('Button', 'NextButton', 'Enabled', False),
            setp('Web', 'Web1', 'Url', call('buildUrl', get('token'), get('includePaid'))),
            method('Web', 'Web1', 'Get'),
        ])))
    blocks.append(define('loadFresh', [
        gset('pageStack', list_of()),
        gset('paidRetried', False),
        call('fetchPage', '', paid_checked()),
    ]))
    blocks.append(define('errorText', local_expr(
        [('res', lookup('results', get('parsed'), ''))],
        choose(is_list(get('res')),
               call('cleanText', lookup('message', get('res'), '')),
               call('cleanText', get('res'))))))
    blocks.append(define('showError', local([('msg', '')], [
        if_(cmp('EQ', starts_at(trim(get('content')), '{'), 1),
            let('msg', call('errorText', decode(get('content'))))),
        status(join('Request failed (HTTP ', get('code'), '). ', get('msg'))),
        call('updateNav'),
    ])))

    # --- rendering ----------------------------------------------------------
    blocks.append(define('renderResults', local([('results', lookup('results', get('parsed'), list_of()))], [
        gset('nextToken', call('cleanText', lookup('nextPage', get('parsed'), ''))),
        gset('articleLinks', list_of()),
        gset('posCount', 0),
        gset('neuCount', 0),
        gset('negCount', 0),
        gset('realSentiment', False),
        if_(not_(is_list(get('results'))), let('results', list_of())),
        for_range('i', 1, CARD_COUNT, if_(
            cmp('LTE', get('i'), length(get('results'))),
            call('fillCard', get('i'), select(get('results'), get('i'))),
            else_=any_set('VerticalArrangement', nth('cardBoxes', get('i')), 'Visible', False))),
        if_(list_empty(get('results')),
            status(join('No articles in ', gget('category'), ' right now. Try another category or tap Refresh.')),
            else_=status(join('Page ', add(length(gget('pageStack')), 1), '  ·  ',
                              length(get('results')), ' stories'))),
        call('updateSentimentBar'),
        call('updateNav'),
    ])))

    blocks.append(define('fillCard', local([
        ('title', field('title')),
        ('src', field('source_name')),
        ('img', field('image_url')),
        ('kw', lookup('keywords', get('art'), '')),
        ('sent', downcase(field('sentiment'))),
        ('chips', list_of()),
        ('aiSum', field('ai_summary')),
        ('desc', field('description')),
    ], [
        if_(is_empty(get('src')), let('src', field('source_id'))),
        card_set('cardBoxes', 'VerticalArrangement', 'Visible', True),
        card_set('cardTitles', 'Label', 'Text', get('title')),
        card_set('cardMetas', 'Label', 'Text', join(get('src'), '  ·  ', field('pubDate'))),
        if_(is_empty(get('img')),
            card_set('cardImages', 'Image', 'Visible', False),
            else_=[card_set('cardImages', 'Image', 'Picture', get('img')),
                   card_set('cardImages', 'Image', 'Visible', True)]),
        # ai_summary is a paid field. Without it, show the plain description.
        if_(call('isRealText', get('aiSum')),
            [card_set('cardSummaries', 'Label', 'Text', join('AI summary: ', get('aiSum'))),
             card_set('cardSummaries', 'Label', 'Visible', True)],
            not_(is_empty(get('desc'))),
            [card_set('cardSummaries', 'Label', 'Text', call('truncate', get('desc'), 200)),
             card_set('cardSummaries', 'Label', 'Visible', True)],
            else_=card_set('cardSummaries', 'Label', 'Visible', False)),
        # keywords come with the free plan when the publisher provides them
        if_(is_list(get('kw')),
            if_(list_empty(get('kw')),
                card_set('cardKeywords', 'Label', 'Visible', False),
                else_=[card_set('cardKeywords', 'Label', 'Text', join(
                           'Keywords: ', call('truncate', call('joinList', get('kw'), ' · '), 120))),
                       card_set('cardKeywords', 'Label', 'Visible', True)]),
            else_=card_set('cardKeywords', 'Label', 'Visible', False)),
        # sentiment badge: live value when the plan returns one, otherwise a labelled placeholder
        if_(cmp('GT', index_in(get('sent'), list_of('positive', 'neutral', 'negative')), 0),
            [gset('realSentiment', True),
             card_set('cardSentiments', 'Label', 'Text', join(' ', get('sent'), ' ')),
             card_set('cardSentiments', 'Label', 'TextColor', rgb(255, 255, 255)),
             if_(eq(get('sent'), 'positive'),
                 [gset('posCount', add(gget('posCount'), 1)),
                  card_set('cardSentiments', 'Label', 'BackgroundColor', rgb(46, 125, 50))],
                 eq(get('sent'), 'neutral'),
                 [gset('neuCount', add(gget('neuCount'), 1)),
                  card_set('cardSentiments', 'Label', 'BackgroundColor', rgb(96, 125, 139))],
                 else_=[gset('negCount', add(gget('negCount'), 1)),
                        card_set('cardSentiments', 'Label', 'BackgroundColor', rgb(198, 40, 40))])],
            else_=[card_set('cardSentiments', 'Label', 'Text', ' sentiment: paid plan '),
                   card_set('cardSentiments', 'Label', 'BackgroundColor', rgb(229, 231, 235)),
                   card_set('cardSentiments', 'Label', 'TextColor', rgb(75, 85, 99))]),
        call('addAll', get('chips'), lookup('ai_tag', get('art'), '')),
        call('addAll', get('chips'), lookup('ai_region', get('art'), '')),
        call('addAll', get('chips'), lookup('ai_org', get('art'), '')),
        if_(list_empty(get('chips')),
            [card_set('cardTags', 'Label', 'Text', 'AI tags / regions / orgs: paid plan'),
             card_set('cardTags', 'Label', 'TextColor', rgb(156, 163, 175))],
            else_=[card_set('cardTags', 'Label', 'Text', join(
                       'AI: ', call('truncate', call('joinList', get('chips'), ', '), 140))),
                   card_set('cardTags', 'Label', 'TextColor', rgb(55, 65, 81))]),
        append(gget('articleLinks'), field('link')),
    ])))

    blocks.append(define('setBar', if_(
        cmp('EQ', get('n'), 0),
        any_set('Label', get('bar'), 'Visible', False),
        else_=[
            any_set('Label', get('bar'), 'Visible', True),
            # 98 rather than 100 so the three segments never wrap
            any_set('Label', get('bar'), 'WidthPercent', quotient(mul(get('n'), 98), get('total'))),
            any_set('Label', get('bar'), 'Text', get('n')),
        ])))
    bars = [('BarPos', 'posCount', 3), ('BarNeu', 'neuCount', 5), ('BarNeg', 'negCount', 2)]
    blocks.append(define('updateSentimentBar', if_(
        gget('realSentiment'),
        [local([('total', add(add(gget('posCount'), gget('neuCount')), gget('negCount')))],
               [call('setBar', comp('Label', bar), gget(var), get('total')) for bar, var, _ in bars]),
         setp('Label', 'SentTitle', 'Text', 'Sentiment on this page'),
         setp('Label', 'SentCaption', 'Text', join(
             gget('posCount'), ' positive · ', gget('neuCount'), ' neutral · ',
             gget('negCount'), ' negative (from the sentiment field of each article)'))],
        else_=[call('setBar', comp('Label', bar), sample, 10) for bar, _, sample in bars] + [
            setp('Label', 'SentTitle', 'Text', 'Sentiment (sample)'),
            setp('Label', 'SentCaption', 'Text',
                 'Sample only — live sentiment requires a paid newsdata.io plan.'),
        ])))
    blocks.append(define('updateNav', [
        setp('Button', 'PrevButton', 'Enabled', cmp('GT', length(gget('pageStack')), 0)),
        setp('Button', 'NextButton', 'Enabled', not_(is_empty(gget('nextToken')))),
        setp('Label', 'PageLabel', 'Text', join('Page ', add(length(gget('pageStack')), 1))),
    ]))
    blocks.append(define('highlightCategory', [
        for_each('b', gget('catButtons'), [
            any_set('Button', get('b'), 'BackgroundColor', rgb(229, 231, 235)),
            any_set('Button', get('b'), 'TextColor', rgb(31, 41, 55)),
        ]),
        any_set('Button', get('btn'), 'BackgroundColor', rgb(37, 99, 235)),
        any_set('Button', get('btn'), 'TextColor', rgb(255, 255, 255)),
    ]))
    blocks.append(define('openLink', if_(not_(is_empty(get('url'))), [
        setp('ActivityStarter', 'ActivityStarter1', 'Action', 'android.intent.action.VIEW'),
        setp('ActivityStarter', 'ActivityStarter1', 'DataUri', get('url')),
        method('ActivityStarter', 'ActivityStarter1', 'StartActivity'),
    ])))

    # --- events -------------------------------------------------------------
    init = [gset(list_name, list_of(*[comp(ctype, f'{prefix}{i}') for i in range(1, CARD_COUNT + 1)]))
            for list_name, ctype, prefix in CARD_PARTS]
    init += [
        gset('catButtons', list_of(*[comp('Button', f'Cat{title}') for title, _ in CATEGORIES])),
        gset('catKeys', list_of(*[key for _, key in CATEGORIES])),
        gset('catLabels', list_of(*[title for title, _ in CATEGORIES])),
        gset('apiKey', trim(method('TinyDB', 'TinyDB1', 'GetValue', KEY_TAG, default_key))),
        call('highlightCategory', comp('Button', f'Cat{CATEGORIES[0][0]}')),
        call('updateSentimentBar'),
        if_(is_empty(gget('apiKey')),
            [setp('VerticalArrangement', 'KeyPanel', 'Visible', True),
             status('Paste your newsdata.io API key above to load headlines.')],
            else_=call('loadFresh')),
    ]
    blocks.append(on('Form', 'Screen1', 'Initialize', init))

    def show_error():
        return call('showError', get('responseCode'), get('responseContent'))

    blocks.append(on('Web', 'Web1', 'GotText', if_(
        cmp('EQ', get('responseCode'), 200),
        call('renderResults', decode(get('responseContent'))),
        cmp('EQ', get('responseCode'), 401),
        [status('newsdata.io rejected the API key (HTTP 401). Tap API key and paste it again.'),
         setp('VerticalArrangement', 'KeyPanel', 'Visible', True),
         call('updateNav')],
        cmp('EQ', get('responseCode'), 429),
        [status('Rate limit reached (HTTP 429). Free keys have a request quota; wait a little, then tap Refresh.'),
         call('updateNav')],
        cmp('GT', index_in(get('responseCode'), list_of(403, 422)), 0),
        # A 403 or 422 after sending a paid-only parameter: retry once without it.
        if_(gget('lastPaid'),
            if_(not_(gget('paidRetried')),
                [gset('paidRetried', True),
                 status('The paid-plan filter was refused for this key. Retrying without it…'),
                 call('fetchPage', gget('currentToken'), False)],
                else_=show_error()),
            else_=show_error()),
        else_=show_error())))

    # One handler for the category tabs and every Read article button.
    blocks.append(on_any('Button', 'Click', local(
        [('catIdx', index_in(get('component'), gget('catButtons'))),
         ('cardIdx', index_in(get('component'), gget('cardOpens')))],
        if_(cmp('GT', get('catIdx'), 0),
            [gset('category', select(gget('catKeys'), get('catIdx'))),
             setp('Label', 'AppTitle', 'Text', select(gget('catLabels'), get('catIdx'))),
             call('highlightCategory', get('component')),
             call('loadFresh')],
            cmp('GT', get('cardIdx'), 0),
            if_(cmp('LTE', get('cardIdx'), length(gget('articleLinks'))),
                call('openLink', select(gget('articleLinks'), get('cardIdx'))))))))

    blocks.append(on('Button', 'KeyToggle', 'Click', [
        setp('TextBox', 'KeyBox', 'Text', gget('apiKey')),
        setp('VerticalArrangement', 'KeyPanel', 'Visible',
             not_(getp('VerticalArrangement', 'KeyPanel', 'Visible'))),
    ]))
    blocks.append(on('Button', 'SaveKeyButton', 'Click', [
        gset('apiKey', trim(getp('TextBox', 'KeyBox', 'Text'))),
        if_(is_empty(gget('apiKey')),
            status('The key field is empty.'),
            else_=[method('TinyDB', 'TinyDB1', 'StoreValue', KEY_TAG, gget('apiKey')),
                   setp('VerticalArrangement', 'KeyPanel', 'Visible', False),
                   call('loadFresh')]),
    ]))
    blocks.append(on('Button', 'RefreshButton', 'Click', [
        gset('paidRetried', False),
        call('fetchPage', gget('currentToken'), paid_checked()),
    ]))
    blocks.append(on('Button', 'PrevButton', 'Click', if_(
        cmp('GT', length(gget('pageStack')), 0),
        local([('tok', select(gget('pageStack'), length(gget('pageStack'))))], [
            remove_at(gget('pageStack'), length(gget('pageStack'))),
            gset('paidRetried', False),
            call('fetchPage', get('tok'), paid_checked()),
        ]))))
    blocks.append(on('Button', 'NextButton', 'Click', if_(
        not_(is_empty(gget('nextToken'))), [
            append(gget('pageStack'), gget('currentToken')),
            gset('paidRetried', False),
            call('fetchPage', gget('nextToken'), paid_checked()),
        ])))
    blocks.append(on('CheckBox', 'PaidCheck', 'Changed', call('loadFresh')))
    blocks.append(on('Form', 'Screen1', 'ErrorOccurred', [
        status(join('Something went wrong: ', get('message'))),
        call('updateNav'),
    ]))
    return blocks


# --------------------------------------------------------------- packaging

def field_value(block, name):
    for f in block.findall('field'):
        if f.get('name') == name:
            return f.text
    return None


def check_references(form, blocks):
    '''Catch typos before Kodular does: unknown components, globals or procedures.'''
    names = set()

    def walk(c):
        names.add(c['$Name'])
        for child in c.get('$Components', []):
            walk(child)

    walk(form)
    globals_ = {field_value(b, 'NAME') for b in blocks if b.get('type') == 'global_declaration'}
    defined = {field_value(b, 'NAME') for b in blocks if b.get('type', '').startswith('procedures_def')}
    problems = [f'procedure {name} is never defined' for name in sorted(set(SIGNATURES) - defined)]
    for top in blocks:
        for el in top.iter('block'):
            btype = el.get('type')
            selector = field_value(el, 'COMPONENT_SELECTOR')
            if selector is not None and selector not in names:
                problems.append(f'unknown component {selector} in {btype}')
            var = field_value(el, 'VAR') or ''
            if btype.startswith('lexical_variable') and var.startswith('global ') and var[7:] not in globals_:
                problems.append(f'undeclared global {var[7:]}')
            if btype.startswith('procedures_call') and field_value(el, 'PROCNAME') not in defined:
                problems.append(f'call to undefined procedure {field_value(el, "PROCNAME")}')
    return problems


def bky_text(blocks):
    root = ET.Element('xml', {'xmlns': 'http://www.w3.org/1999/xhtml'})
    y = 20
    for block in blocks:
        block.set('x', '20')
        block.set('y', str(y))
        y += 40 + 26 * sum(1 for _ in block.iter('block'))
        root.append(block)
    ET.SubElement(root, 'yacodeblocks', {
        'ya-version': YA_VERSION, 'language-version': BLOCKS_LANGUAGE_VERSION,
    })
    return ET.tostring(root, encoding='unicode')


def properties_text(app_name):
    lines = [
        f'main={PACKAGE}.{PROJECT_NAME}.Screen1',
        f'name={PROJECT_NAME}',
        'assets=../assets',
        'source=../src',
        'build=../build',
        'versioncode=1',
        'versionname=1.0',
        'useslocation=False',
        f'aname={app_name}',
        'sizing=Responsive',
        'showlistsasjson=True',
    ]
    return '\n'.join(lines) + '\n'


def main():
    parser = argparse.ArgumentParser(description='Build the Kodular news reader (.aia) from source.')
    parser.add_argument('--out', default=f'dist/{PROJECT_NAME}.aia', help='output path (default: %(default)s)')
    parser.add_argument('--language', default='en',
                        help='newsdata.io language code(s), comma separated (default: en)')
    parser.add_argument('--app-name', default=APP_TITLE, help='Android app label (default: %(default)s)')
    parser.add_argument('--emit-sources', metavar='DIR',
                        help='also write the raw .scm / .bky / project.properties into DIR')
    parser.add_argument('--embed-key', action='store_true',
                        help='use NEWSDATA_API_KEY as the default key inside the app (keep that .aia private)')
    args = parser.parse_args()

    default_key = ''
    if args.embed_key:
        default_key = os.environ.get('NEWSDATA_API_KEY', '').strip()
        if not default_key:
            sys.exit('--embed-key was given but NEWSDATA_API_KEY is not set. '
                     'Run: export NEWSDATA_API_KEY=your_key')
        print('note: the API key is stored in plain text in the blocks; do not share this .aia.',
              file=sys.stderr)

    form = build_form(args.app_name)
    blocks = build_blocks(args.language.replace(' ', ''), default_key)
    problems = check_references(form, blocks)
    if problems:
        sys.exit('refusing to build:' + ''.join('\n  - ' + p for p in problems))

    pkg_path = PACKAGE.replace('.', '/')
    src_dir = f'src/{pkg_path}/{PROJECT_NAME}'
    files = {
        'youngandroidproject/project.properties': properties_text(args.app_name),
        f'{src_dir}/Screen1.scm': scm_text(form),
        f'{src_dir}/Screen1.bky': bky_text(blocks),
    }

    out = Path(args.out)
    out.parent.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(out, 'w', zipfile.ZIP_DEFLATED) as zf:
        for name, text in files.items():
            zf.writestr(name, text.encode('utf-8'))

    if args.emit_sources:
        for name, text in files.items():
            target = Path(args.emit_sources) / name
            target.parent.mkdir(parents=True, exist_ok=True)
            target.write_text(text, encoding='utf-8')

    total = sum(1 for b in blocks for _ in b.iter('block'))
    print(f'wrote {out} ({len(blocks)} top-level blocks, {total} blocks total, language={args.language})')


if __name__ == '__main__':
    main()
