# How the blocks work

This is a tour of `Screen1` for anyone who imported the `.aia` and wants to change it in Kodular's blocks editor. You can rearrange the canvas with right-click → *Arrange Blocks Vertically*.

## Globals

| Global | Holds |
|---|---|
| `apiKey` | the newsdata.io key, loaded from TinyDB tag `newsdata_api_key` |
| `category` | current category value sent to the API (`top`, `business`, ...) |
| `currentToken` / `nextToken` | the `page` value used for the current page, and the `nextPage` value from the last response |
| `pageStack` | tokens of the pages before this one, which *Previous* pops |
| `lastPaid` / `paidRetried` | whether the last request included the paid-only parameter, and whether it was already retried without it |
| `posCount`, `neuCount`, `negCount`, `realSentiment` | sentiment totals for the current page |
| `cardBoxes`, `cardTitles`, `cardImages`, ... | lists of the 10 card components, so a procedure can address card *i* with `select list item` |
| `catButtons`, `catKeys`, `catLabels` | category buttons and the API value / title for each |
| `articleLinks` | the link of each card on the current page |

## Startup: `when Screen1.Initialize`

1. Fills the component lists above.
2. Reads the saved key from TinyDB.
3. Highlights the *Top* tab and draws the sentiment strip. The strip shows the labelled sample until real data arrives.
4. Calls `loadFresh` if there is a key. Otherwise it opens the key panel.

## Loading a page

- `buildUrl(token, includePaid)` builds `https://newsdata.io/api/1/latest?apikey=...&language=...&category=...`. It adds `&page=<token>` when a token is given, and `&timeframe=24` only when `includePaid` is true.
- `fetchPage(token, includePaid)` stores the token, disables the nav buttons, sets `Web1.Url` and calls `Web1.Get`.
- `loadFresh` clears `pageStack` and fetches page one. Category taps, saving a key and ticking the paid checkbox all use it.

## `when Web1.GotText`

| responseCode | What happens |
|---|---|
| 200 | `renderResults` with the decoded JSON |
| 401 | message about the key, and the key panel opens |
| 429 | rate-limit message |
| 403 / 422 | if the request included the paid parameter and hasn't been retried yet, the same page is requested again without it; otherwise `showError` |
| anything else | `showError` shows the HTTP code and the `results.message` text from the API |

Network failures go through `when Screen1.ErrorOccurred`, which writes the message to the status line. Without that handler, Kodular would show a pop-up.

## Rendering

`renderResults` reads `results` and `nextPage`, then loops over the 10 slots. Slots with an article go to `fillCard`, and the rest are hidden. An empty `results` list produces a *No articles in ...* status message.

`fillCard(i, art)` reads each field through `fieldText`. `fieldText` calls `cleanText`, which turns JSON null and lists into empty text. Then `fillCard`:

- shows the image only when `image_url` is present;
- uses `ai_summary` when `isRealText` says it's real, and otherwise a shortened `description`;
- joins `keywords` into one line, or hides it;
- sets the sentiment badge from `sentiment`. Values other than positive/neutral/negative get the grey *sentiment: paid plan* badge;
- collects `ai_tag`, `ai_region` and `ai_org` with `addAll`. When none are present, it shows *AI tags / regions / orgs: paid plan*.

`isRealText` treats empty text, and anything starting with *only available*, as missing. That covers the placeholder strings some plans return in place of paid fields.

`updateSentimentBar` sizes the three bar labels with `WidthPercent` (via `setBar`) from the page's counts. With no real sentiment values, it uses a fixed 3/5/2 split and says so in the title and caption.

## Paging and taps

- *Next page* pushes `currentToken` onto `pageStack` and fetches `nextToken`.
- *Previous* pops the last token and fetches it.
- `updateNav` enables or disables both buttons and updates the page number.
- `when any Button.Click` handles the category tabs and every *Read article* button with one block. It looks up the clicked button's position in `catButtons` or `cardOpens`. A tab changes `category`, and a card button sends its link to `openLink`, which opens it through ActivityStarter.
