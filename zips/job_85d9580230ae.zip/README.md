# VC Deal News Tracker

A small, dependency-light Python tool that monitors **venture capital funding
announcements, mergers & acquisitions, and IPO coverage** using the
[newsdata.io](https://newsdata.io) news API. It collects matching articles,
classifies each one into a deal type (`funding` / `m&a` / `ipo`), and exports a
tidy, de-duplicated table to CSV using [pandas](https://pandas.pydata.org/).

> Built to run out-of-the-box on the **newsdata.io FREE plan** — no paid
> features are required.

## Features

- 🔎 Queries the newsdata.io `/news` endpoint for deal-related keywords.
- 🏷️ Heuristically classifies each article as **funding**, **m&a**, or **ipo**.
- 📄 Paginates through results using the `nextPage` token (with a configurable cap).
- 🧹 De-duplicates by article link and sorts by publish date.
- 📊 Exports a clean CSV via pandas, and prints a quick summary table.
- 🛡️ Gracefully handles invalid keys (401), rate limits (429), empty results,
  and paid-only upgrade responses (403/422).

## Requirements

- Python 3.9+
- A free newsdata.io API key — get one at <https://newsdata.io/register>

## Setup

```bash
git clone https://github.com/your-username/vc-deal-news-tracker.git
cd vc-deal-news-tracker

python -m venv .venv
source .venv/bin/activate   # on Windows: .venv\Scripts\activate

pip install -r requirements.txt
```

### Configure your API key

The key is read from the `NEWSDATA_API_KEY` environment variable. It is **never**
hardcoded.

```bash
export NEWSDATA_API_KEY="pub_xxxxxxxxxxxxxxxxxxxxxxxxxxxx"
```

On Windows (PowerShell):

```powershell
$env:NEWSDATA_API_KEY="pub_xxxxxxxxxxxxxxxxxxxxxxxxxxxx"
```

## Usage

```bash
# Default run: latest English deal news -> deals.csv
python main.py

# Filter by deal type and country, change the output file
python main.py --type funding --country us --output funding.csv

# Broaden the search and pull more pages (each page = up to 10 articles on free tier)
python main.py --language en --max-pages 5 --output deals.csv

# Narrow with your own keyword on top of the deal terms
python main.py --query "artificial intelligence" --type funding
```

### Command-line options

| Flag | Description | Default |
|------|-------------|---------|
| `--type` | Deal type to keep: `all`, `funding`, `m&a`, `ipo` | `all` |
| `--query` | Extra keyword to AND with the deal terms | none |
| `--country` | Comma-separated country codes (e.g. `us,gb`) | none |
| `--language` | Language code (e.g. `en`) | `en` |
| `--max-pages` | Max number of result pages to fetch | `3` |
| `--output` | CSV output path | `deals.csv` |

## Output columns

`deal_type, title, source_id, published, country, link, description`

## Free vs. paid plans

This project intentionally relies **only on free-tier features** of newsdata.io:
the `/news` endpoint with the `q`, `country`, `language`, and `page` parameters.

The following are **paid-only** and are *not* used by the core flow:

- Sentiment analysis and the `ai_tag` / `ai_region` / `ai_org` / `ai_summary` fields
- The historical `/archive` endpoint and long date ranges
- Advanced full-text query operators

If newsdata.io returns a 403/422 "upgrade your plan" response for any optional
parameter, the tool logs a warning and continues without that feature.

## License

MIT
