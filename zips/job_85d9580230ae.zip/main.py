#!/usr/bin/env python3
"""VC Deal News Tracker.

Monitors funding announcements, M&A news, and IPO coverage using the
newsdata.io news API and exports the collected deals to CSV with pandas.

Designed to run on the newsdata.io FREE tier. The API key is read from the
NEWSDATA_API_KEY environment variable and is never hardcoded.
"""
from __future__ import annotations

import argparse
import os
import sys
import time
from typing import Dict, List, Optional

import pandas as pd
import requests

API_URL = "https://newsdata.io/api/1/news"

# Keyword groups used both to query the API and to classify each article.
DEAL_KEYWORDS: Dict[str, List[str]] = {
    "funding": [
        "funding", "raises", "raised", "seed round", "series a", "series b",
        "series c", "venture capital", "investment round", "valuation",
    ],
    "m&a": [
        "acquisition", "acquires", "acquired", "merger", "merges", "buyout",
        "takeover", "to acquire",
    ],
    "ipo": [
        "ipo", "initial public offering", "goes public", "public listing",
        "stock market debut", "files to go public",
    ],
}

CSV_COLUMNS = [
    "deal_type", "title", "source_id", "published", "country", "link", "description",
]


class NewsDataError(Exception):
    """Raised for unrecoverable API problems."""


def get_api_key() -> str:
    key = os.environ.get("NEWSDATA_API_KEY", "").strip()
    if not key:
        print(
            "ERROR: NEWSDATA_API_KEY is not set.\n"
            "Get a free key at https://newsdata.io/register and run:\n"
            "  export NEWSDATA_API_KEY='your_key_here'",
            file=sys.stderr,
        )
        sys.exit(1)
    return key


def build_query(deal_type: str, extra_query: Optional[str]) -> str:
    """Build a newsdata.io `q` value from the selected deal type.

    Uses simple OR'd terms (free-tier friendly) rather than advanced operators.
    """
    if deal_type == "all":
        terms = []
        for words in DEAL_KEYWORDS.values():
            terms.extend(words[:3])  # keep the query compact for the free tier
    else:
        terms = DEAL_KEYWORDS[deal_type][:5]

    query = " OR ".join(f'"{t}"' for t in terms)
    if extra_query:
        query = f"({query}) AND {extra_query}"
    return query


def classify(text: str) -> str:
    """Classify an article into a deal type based on keyword matches."""
    lowered = (text or "").lower()
    scores = {dtype: 0 for dtype in DEAL_KEYWORDS}
    for dtype, words in DEAL_KEYWORDS.items():
        for word in words:
            if word in lowered:
                scores[dtype] += 1
    best = max(scores, key=scores.get)
    return best if scores[best] > 0 else "other"


def fetch_page(
    session: requests.Session,
    params: Dict[str, str],
    page_token: Optional[str],
) -> dict:
    """Fetch a single page of results, handling common error statuses."""
    call_params = dict(params)
    if page_token:
        call_params["page"] = page_token

    try:
        resp = session.get(API_URL, params=call_params, timeout=30)
    except requests.RequestException as exc:
        raise NewsDataError(f"Network error contacting newsdata.io: {exc}") from exc

    if resp.status_code == 401:
        raise NewsDataError("Invalid API key (401). Check your NEWSDATA_API_KEY.")
    if resp.status_code == 429:
        raise NewsDataError("Rate limit reached (429). Wait a bit and try again.")
    if resp.status_code in (403, 422):
        # Likely a paid-only parameter. Surface a clear message instead of crashing.
        raise NewsDataError(
            "newsdata.io rejected the request (paid-only feature or invalid "
            f"parameter, HTTP {resp.status_code}). Body: {resp.text[:200]}"
        )

    try:
        resp.raise_for_status()
    except requests.HTTPError as exc:
        raise NewsDataError(f"Unexpected API error: {exc}") from exc

    try:
        return resp.json()
    except ValueError as exc:
        raise NewsDataError("Could not decode the API response as JSON.") from exc


def collect_deals(
    api_key: str,
    deal_type: str,
    extra_query: Optional[str],
    country: Optional[str],
    language: str,
    max_pages: int,
) -> List[dict]:
    """Page through the /news endpoint and collect classified deal rows."""
    params: Dict[str, str] = {
        "apikey": api_key,
        "q": build_query(deal_type, extra_query),
        "language": language,
    }
    if country:
        params["country"] = country

    session = requests.Session()
    rows: List[dict] = []
    seen_links = set()
    page_token: Optional[str] = None

    for page_num in range(1, max_pages + 1):
        print(f"Fetching page {page_num}/{max_pages} ...")
        data = fetch_page(session, params, page_token)

        if data.get("status") != "success":
            message = data.get("results", {})
            raise NewsDataError(f"API returned a non-success status: {message}")

        results = data.get("results") or []
        if not results:
            print("No more results returned.")
            break

        for article in results:
            link = article.get("link")
            if not link or link in seen_links:
                continue
            seen_links.add(link)

            text = " ".join(
                str(article.get(field, ""))
                for field in ("title", "description")
            )
            dtype = classify(text)
            if deal_type != "all" and dtype != deal_type:
                continue

            countries = article.get("country") or []
            rows.append(
                {
                    "deal_type": dtype,
                    "title": article.get("title", ""),
                    "source_id": article.get("source_id", ""),
                    "published": article.get("pubDate", ""),
                    "country": ", ".join(countries) if isinstance(countries, list) else countries,
                    "link": link,
                    "description": (article.get("description") or "").strip(),
                }
            )

        page_token = data.get("nextPage")
        if not page_token:
            print("Reached the last page.")
            break

        time.sleep(1)  # be gentle with the free-tier rate limit

    return rows


def export_csv(rows: List[dict], output_path: str) -> pd.DataFrame:
    """Write the collected rows to CSV and return the DataFrame."""
    df = pd.DataFrame(rows, columns=CSV_COLUMNS)
    if not df.empty:
        df = df.sort_values("published", ascending=False).reset_index(drop=True)
    df.to_csv(output_path, index=False)
    return df


def parse_args(argv: Optional[List[str]] = None) -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Track VC funding, M&A, and IPO news via newsdata.io and export to CSV."
    )
    parser.add_argument(
        "--type",
        dest="deal_type",
        choices=["all", "funding", "m&a", "ipo"],
        default="all",
        help="Deal type to keep (default: all).",
    )
    parser.add_argument("--query", default=None, help="Extra keyword AND'd with the deal terms.")
    parser.add_argument("--country", default=None, help="Comma-separated country codes, e.g. us,gb.")
    parser.add_argument("--language", default="en", help="Language code (default: en).")
    parser.add_argument("--max-pages", type=int, default=3, help="Max result pages to fetch (default: 3).")
    parser.add_argument("--output", default="deals.csv", help="CSV output path (default: deals.csv).")
    return parser.parse_args(argv)


def main(argv: Optional[List[str]] = None) -> int:
    args = parse_args(argv)
    api_key = get_api_key()

    if args.max_pages < 1:
        print("ERROR: --max-pages must be at least 1.", file=sys.stderr)
        return 1

    try:
        rows = collect_deals(
            api_key=api_key,
            deal_type=args.deal_type,
            extra_query=args.query,
            country=args.country,
            language=args.language,
            max_pages=args.max_pages,
        )
    except NewsDataError as exc:
        print(f"ERROR: {exc}", file=sys.stderr)
        return 1

    if not rows:
        print("No matching deal news found. Try a different --type, --country, or --query.")
        # Still write an (empty) CSV so downstream tooling has a predictable file.
        export_csv(rows, args.output)
        return 0

    df = export_csv(rows, args.output)

    print(f"\nSaved {len(df)} deals to {args.output}\n")
    print("Deal type breakdown:")
    print(df["deal_type"].value_counts().to_string())
    print("\nMost recent deals:")
    preview = df[["deal_type", "published", "title"]].head(10)
    print(preview.to_string(index=False))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
