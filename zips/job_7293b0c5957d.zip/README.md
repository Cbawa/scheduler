# SwiftUI NewsData Headlines

A polished **SwiftUI** iOS app that fetches the latest headlines from the
[newsdata.io](https://newsdata.io) news API. It ships with category browsing,
full-text search, bookmarks, a native iOS share sheet, infinite scrolling
(via the API's `nextPage` token), and an adaptive light/dark mode.

> This project is a community showcase for the newsdata.io API. It is designed to
> run end-to-end on the **FREE** plan — no paid features are required.

## Features

- 📰 **Latest headlines** from the `/news` endpoint (the free-tier primary endpoint).
- 🗂 **Categories** — top, world, business, technology, sports, science, health, etc.
- 🔎 **Search** by keyword (`q` query parameter).
- 🔖 **Bookmarks** persisted locally with `UserDefaults` (offline-friendly).
- 📤 **Share sheet** — share any article link with the system `UIActivityViewController`.
- 🌗 **Adaptive dark mode** — follow the system, or force light/dark from the toolbar.
- ♾ **Pagination** using the `nextPage` token returned by the API.
- 🛟 **Graceful errors** — invalid key (401), rate limit (429), plan limits (403/422),
  and empty results never crash the app; the user gets a friendly message + retry.

## Requirements

- macOS with **Xcode 15+**
- iOS **16.0+** (simulator or device)
- A free newsdata.io API key — grab one at <https://newsdata.io/register>
- (Optional) [XcodeGen](https://github.com/yonsm/XcodeGen) to generate the Xcode project from `project.yml`

## API key — `NEWSDATA_API_KEY`

The key is **never hardcoded**. The app reads it from the `NEWSDATA_API_KEY`
environment variable (see `APIConfig` in `Sources/App.swift`), with an optional
fallback to an `Info.plist` value of the same name.

When running from Xcode, set it on the scheme:

1. **Product ▸ Scheme ▸ Edit Scheme… ▸ Run ▸ Arguments**
2. Under **Environment Variables** add `NEWSDATA_API_KEY` = `your_key_here`

The included `project.yml` already declares the variable on the generated scheme —
just fill in the value (or export it before generating).

If the key is missing, the app shows a clear "set NEWSDATA_API_KEY" message instead
of crashing.

## Getting started

```bash
# 1. Clone
git clone https://github.com/your-account/swiftui-newsdata-headlines.git
cd swiftui-newsdata-headlines

# 2. (Recommended) generate the Xcode project
brew install xcodegen
xcodegen generate

# 3. Open it
open NewsApp.xcodeproj
```

Then set `NEWSDATA_API_KEY` on the scheme (above) and hit **Run** (⌘R).

> No XcodeGen? Create a new "App" project in Xcode, drag the `Sources/` files in,
> and add the scheme environment variable.

## Project layout

```
Sources/
  App.swift     # @main App entry, appearance handling, APIConfig (reads the env var)
  Core.swift    # Models, NewsDataService (networking + error mapping), view models, bookmarks
  Views.swift   # SwiftUI screens: headlines, detail, bookmarks, share sheet
project.yml     # XcodeGen project definition (target + scheme env var)
```

## Free plan vs. paid plan

This app deliberately sticks to **free-tier** functionality. The following
newsdata.io capabilities are **paid-only** and are intentionally *not* part of the
core flow:

| Feature | Plan | Notes |
|---|---|---|
| `sentiment` analysis | Paid | Not requested. |
| AI fields (`ai_tag`, `ai_region`, `ai_org`, `ai_summary`) | Paid | Not requested; decoded only if present. |
| `/archive` endpoint & long date ranges | Paid | Not used — only `/news`. |
| Advanced full-text query operators | Paid | Plain `q` keyword search only. |

If the API ever returns a `403`/`422` "upgrade your plan" response, the service maps
it to a friendly message and the app keeps working.

## License

MIT — free to use as a starting point for your own newsdata.io powered app.
