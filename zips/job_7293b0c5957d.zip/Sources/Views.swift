import SwiftUI

// MARK: - Root

struct ContentView: View {
    @StateObject private var vm = NewsViewModel()
    @StateObject private var bookmarks = BookmarksStore()
    @AppStorage("appearance") private var appearance: String = "system"

    var body: some View {
        TabView {
            NewsTab(vm: vm, bookmarks: bookmarks, appearance: $appearance)
                .tabItem { Label("Headlines", systemImage: "newspaper") }
            BookmarksTab(bookmarks: bookmarks)
                .tabItem { Label("Bookmarks", systemImage: "bookmark") }
        }
    }
}

// MARK: - Headlines

struct NewsTab: View {
    @ObservedObject var vm: NewsViewModel
    @ObservedObject var bookmarks: BookmarksStore
    @Binding var appearance: String

    var body: some View {
        NavigationStack {
            content
                .navigationTitle("Headlines")
                .navigationDestination(for: Article.self) { article in
                    ArticleDetailView(article: article, bookmarks: bookmarks)
                }
                .toolbar {
                    ToolbarItem(placement: .navigationBarTrailing) {
                        appearanceMenu
                    }
                }
                .searchable(text: $vm.query, prompt: "Search headlines")
                .onSubmit(of: .search) { Task { await vm.reload() } }
                .safeAreaInset(edge: .top) { CategoryBar(vm: vm) }
                .refreshable { await vm.reload() }
                .task { if vm.articles.isEmpty { await vm.reload() } }
        }
    }

    @ViewBuilder private var content: some View {
        if let message = vm.errorMessage, vm.articles.isEmpty {
            ErrorStateView(message: message) { Task { await vm.reload() } }
        } else if vm.articles.isEmpty && vm.isLoading {
            ProgressView("Loading headlines…")
                .frame(maxWidth: .infinity, maxHeight: .infinity)
        } else if vm.articles.isEmpty {
            EmptyStateView(title: "No articles",
                           systemImage: "tray",
                           message: "Try another search term or category.")
        } else {
            List {
                ForEach(vm.articles) { article in
                    NavigationLink(value: article) {
                        ArticleRow(article: article)
                    }
                    .swipeActions(edge: .trailing) {
                        Button {
                            bookmarks.toggle(article)
                        } label: {
                            Label(bookmarks.isBookmarked(article) ? "Remove" : "Save",
                                  systemImage: bookmarks.isBookmarked(article) ? "bookmark.slash" : "bookmark")
                        }
                        .tint(.accentColor)
                    }
                }
                if vm.canLoadMore {
                    HStack { Spacer(); ProgressView(); Spacer() }
                        .listRowSeparator(.hidden)
                        .onAppear { Task { await vm.loadMore() } }
                }
            }
            .listStyle(.plain)
        }
    }

    private var appearanceMenu: some View {
        Menu {
            Picker("Appearance", selection: $appearance) {
                Label("System", systemImage: "circle.lefthalf.filled").tag("system")
                Label("Light", systemImage: "sun.max").tag("light")
                Label("Dark", systemImage: "moon").tag("dark")
            }
        } label: {
            Image(systemName: "paintbrush")
        }
    }
}

struct CategoryBar: View {
    @ObservedObject var vm: NewsViewModel

    var body: some View {
        ScrollView(.horizontal, showsIndicators: false) {
            HStack(spacing: 8) {
                ForEach(vm.categories, id: \.self) { category in
                    let selected = vm.category == category
                    Button {
                        if vm.category != category { vm.category = category }
                    } label: {
                        Text(category.capitalized)
                            .font(.subheadline.weight(selected ? .semibold : .regular))
                            .padding(.horizontal, 14)
                            .padding(.vertical, 8)
                            .background(selected ? Color.accentColor : Color(.secondarySystemBackground))
                            .foregroundColor(selected ? .white : .primary)
                            .clipShape(Capsule())
                    }
                    .buttonStyle(.plain)
                }
            }
            .padding(.horizontal)
            .padding(.vertical, 8)
        }
        .background(.bar)
    }
}

struct ArticleRow: View {
    let article: Article

    var body: some View {
        HStack(alignment: .top, spacing: 12) {
            thumbnail
            VStack(alignment: .leading, spacing: 4) {
                Text(article.title)
                    .font(.headline)
                    .lineLimit(3)
                if let description = article.description, !description.isEmpty {
                    Text(description)
                        .font(.subheadline)
                        .foregroundColor(.secondary)
                        .lineLimit(2)
                }
                HStack(spacing: 6) {
                    if let source = article.sourceId {
                        Text(source.uppercased())
                            .font(.caption2.weight(.semibold))
                            .foregroundColor(.accentColor)
                    }
                    if let date = article.prettyDate {
                        Text(date)
                            .font(.caption2)
                            .foregroundColor(.secondary)
                    }
                }
            }
        }
        .padding(.vertical, 4)
    }

    @ViewBuilder private var thumbnail: some View {
        if let imageString = article.imageUrl, let url = URL(string: imageString) {
            AsyncImage(url: url) { phase in
                switch phase {
                case .success(let image):
                    image.resizable().scaledToFill()
                default:
                    Color(.tertiarySystemFill)
                }
            }
            .frame(width: 72, height: 72)
            .clipShape(RoundedRectangle(cornerRadius: 8))
        }
    }
}

// MARK: - Detail

struct ArticleDetailView: View {
    let article: Article
    @ObservedObject var bookmarks: BookmarksStore
    @State private var showShare = false

    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 16) {
                if let imageString = article.imageUrl, let url = URL(string: imageString) {
                    AsyncImage(url: url) { phase in
                        switch phase {
                        case .success(let image): image.resizable().scaledToFill()
                        default: Color(.tertiarySystemFill)
                        }
                    }
                    .frame(height: 220)
                    .frame(maxWidth: .infinity)
                    .clipped()
                    .clipShape(RoundedRectangle(cornerRadius: 12))
                }

                Text(article.title).font(.title2.bold())

                HStack(spacing: 8) {
                    if let source = article.sourceId {
                        Text(source.uppercased())
                            .font(.caption.weight(.semibold))
                            .foregroundColor(.accentColor)
                    }
                    if let date = article.prettyDate {
                        Text(date).font(.caption).foregroundColor(.secondary)
                    }
                }

                if let description = article.description, !description.isEmpty {
                    Text(description).font(.body)
                }

                if let url = article.url {
                    Link(destination: url) {
                        Label("Read full story", systemImage: "safari")
                            .frame(maxWidth: .infinity)
                            .padding()
                            .background(Color.accentColor)
                            .foregroundColor(.white)
                            .clipShape(RoundedRectangle(cornerRadius: 12))
                    }
                }
            }
            .padding()
        }
        .navigationTitle(article.sourceId?.capitalized ?? "Article")
        .navigationBarTitleDisplayMode(.inline)
        .toolbar {
            ToolbarItemGroup(placement: .navigationBarTrailing) {
                Button {
                    bookmarks.toggle(article)
                } label: {
                    Image(systemName: bookmarks.isBookmarked(article) ? "bookmark.fill" : "bookmark")
                }
                Button {
                    showShare = true
                } label: {
                    Image(systemName: "square.and.arrow.up")
                }
                .disabled(article.url == nil)
            }
        }
        .sheet(isPresented: $showShare) {
            if let url = article.url {
                ShareSheet(items: [article.title, url])
            }
        }
    }
}

// MARK: - Bookmarks tab

struct BookmarksTab: View {
    @ObservedObject var bookmarks: BookmarksStore

    var body: some View {
        NavigationStack {
            Group {
                if bookmarks.items.isEmpty {
                    EmptyStateView(title: "No bookmarks yet",
                                   systemImage: "bookmark",
                                   message: "Swipe a headline or tap the bookmark icon to save it here.")
                } else {
                    List {
                        ForEach(bookmarks.items) { article in
                            NavigationLink(value: article) {
                                ArticleRow(article: article)
                            }
                        }
                        .onDelete { bookmarks.remove(at: $0) }
                    }
                    .listStyle(.plain)
                }
            }
            .navigationTitle("Bookmarks")
            .navigationDestination(for: Article.self) { article in
                ArticleDetailView(article: article, bookmarks: bookmarks)
            }
        }
    }
}

// MARK: - Reusable states

struct ErrorStateView: View {
    let message: String
    let retry: () -> Void

    var body: some View {
        VStack(spacing: 16) {
            Image(systemName: "exclamationmark.triangle")
                .font(.largeTitle)
                .foregroundColor(.orange)
            Text(message)
                .multilineTextAlignment(.center)
                .foregroundColor(.secondary)
                .padding(.horizontal)
            Button("Try again", action: retry)
                .buttonStyle(.borderedProminent)
        }
        .frame(maxWidth: .infinity, maxHeight: .infinity)
        .padding()
    }
}

struct EmptyStateView: View {
    let title: String
    let systemImage: String
    let message: String

    var body: some View {
        VStack(spacing: 12) {
            Image(systemName: systemImage)
                .font(.largeTitle)
                .foregroundColor(.secondary)
            Text(title).font(.headline)
            Text(message)
                .font(.subheadline)
                .foregroundColor(.secondary)
                .multilineTextAlignment(.center)
                .padding(.horizontal)
        }
        .frame(maxWidth: .infinity, maxHeight: .infinity)
        .padding()
    }
}

// MARK: - Share sheet bridge

struct ShareSheet: UIViewControllerRepresentable {
    let items: [Any]

    func makeUIViewController(context: Context) -> UIActivityViewController {
        UIActivityViewController(activityItems: items, applicationActivities: nil)
    }

    func updateUIViewController(_ controller: UIActivityViewController, context: Context) {}
}
