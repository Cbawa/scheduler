import Foundation

// MARK: - Models

struct NewsResponse: Decodable {
    let status: String?
    let totalResults: Int?
    let results: [Article]?
    let nextPage: String?
}

/// A single article. Only free-tier fields are required; paid AI fields are
/// decoded opportunistically and are never relied upon.
struct Article: Identifiable, Hashable, Codable {
    let id: String
    let title: String
    let link: String
    let description: String?
    let pubDate: String?
    let sourceId: String?
    let imageUrl: String?

    enum CodingKeys: String, CodingKey {
        case articleId = "article_id"
        case title, link, description, pubDate
        case sourceId = "source_id"
        case imageUrl = "image_url"
    }

    init(from decoder: Decoder) throws {
        let c = try decoder.container(keyedBy: CodingKeys.self)
        let articleId = try c.decodeIfPresent(String.self, forKey: .articleId)
        let link = try c.decodeIfPresent(String.self, forKey: .link)
        self.link = link ?? ""
        self.id = articleId ?? link ?? UUID().uuidString
        self.title = (try c.decodeIfPresent(String.self, forKey: .title)) ?? "Untitled"
        self.description = try c.decodeIfPresent(String.self, forKey: .description)
        self.pubDate = try c.decodeIfPresent(String.self, forKey: .pubDate)
        self.sourceId = try c.decodeIfPresent(String.self, forKey: .sourceId)
        self.imageUrl = try c.decodeIfPresent(String.self, forKey: .imageUrl)
    }

    func encode(to encoder: Encoder) throws {
        var c = encoder.container(keyedBy: CodingKeys.self)
        try c.encode(id, forKey: .articleId)
        try c.encode(title, forKey: .title)
        try c.encode(link, forKey: .link)
        try c.encodeIfPresent(description, forKey: .description)
        try c.encodeIfPresent(pubDate, forKey: .pubDate)
        try c.encodeIfPresent(sourceId, forKey: .sourceId)
        try c.encodeIfPresent(imageUrl, forKey: .imageUrl)
    }

    var url: URL? { URL(string: link) }

    var prettyDate: String? {
        guard let pubDate else { return nil }
        let parser = DateFormatter()
        parser.dateFormat = "yyyy-MM-dd HH:mm:ss"
        parser.timeZone = TimeZone(identifier: "UTC")
        guard let date = parser.date(from: pubDate) else { return pubDate }
        let out = DateFormatter()
        out.dateStyle = .medium
        out.timeStyle = .short
        return out.string(from: date)
    }
}

// MARK: - Errors

enum NewsError: LocalizedError, Equatable {
    case missingKey
    case invalidKey
    case rateLimited
    case planRestricted
    case http(Int)
    case decoding
    case network(String)

    var errorDescription: String? {
        switch self {
        case .missingKey:
            return "No API key found. Set the NEWSDATA_API_KEY environment variable on your Xcode scheme."
        case .invalidKey:
            return "Your newsdata.io API key was rejected (401). Double-check NEWSDATA_API_KEY."
        case .rateLimited:
            return "Rate limit reached (429). The free plan has a request cap — please wait a moment and retry."
        case .planRestricted:
            return "That request needs a paid plan. Showing only free-tier content."
        case .http(let code):
            return "The server returned an unexpected status (\(code)). Please try again."
        case .decoding:
            return "Could not read the response from newsdata.io."
        case .network(let msg):
            return "Network problem: \(msg)"
        }
    }
}

// MARK: - Service

/// Thin async wrapper around the newsdata.io `/news` endpoint (free tier).
struct NewsDataService {
    private let baseURL = "https://newsdata.io/api/1"
    private let session: URLSession = .shared

    func fetchLatest(query: String?,
                     category: String?,
                     language: String? = "en",
                     country: String? = nil,
                     page: String? = nil) async throws -> NewsResponse {
        guard let key = APIConfig.apiKey else { throw NewsError.missingKey }

        guard var components = URLComponents(string: baseURL + "/news") else {
            throw NewsError.network("Could not build request URL.")
        }
        var items = [URLQueryItem(name: "apikey", value: key)]
        if let q = query?.trimmingCharacters(in: .whitespaces), !q.isEmpty {
            items.append(URLQueryItem(name: "q", value: q))
        }
        if let category, !category.isEmpty, category != "top" {
            items.append(URLQueryItem(name: "category", value: category))
        }
        if let language, !language.isEmpty {
            items.append(URLQueryItem(name: "language", value: language))
        }
        if let country, !country.isEmpty {
            items.append(URLQueryItem(name: "country", value: country))
        }
        if let page, !page.isEmpty {
            items.append(URLQueryItem(name: "page", value: page))
        }
        components.queryItems = items

        guard let url = components.url else { throw NewsError.network("Invalid URL.") }

        do {
            let (data, response) = try await session.data(from: url)
            guard let http = response as? HTTPURLResponse else {
                throw NewsError.network("No HTTP response.")
            }
            switch http.statusCode {
            case 200:
                break
            case 401:
                throw NewsError.invalidKey
            case 429:
                throw NewsError.rateLimited
            case 403, 422:
                throw NewsError.planRestricted
            default:
                throw NewsError.http(http.statusCode)
            }
            do {
                return try JSONDecoder().decode(NewsResponse.self, from: data)
            } catch {
                throw NewsError.decoding
            }
        } catch let error as NewsError {
            throw error
        } catch {
            throw NewsError.network(error.localizedDescription)
        }
    }
}

// MARK: - View Model

@MainActor
final class NewsViewModel: ObservableObject {
    @Published var articles: [Article] = []
    @Published var isLoading = false
    @Published var errorMessage: String?
    @Published var query: String = ""
    @Published var category: String = "top" { didSet { Task { await reload() } } }

    let categories = ["top", "world", "business", "technology", "sports",
                      "science", "health", "entertainment", "politics"]

    private let service = NewsDataService()
    private var nextPage: String?
    private(set) var canLoadMore = false

    func reload() async {
        isLoading = true
        errorMessage = nil
        nextPage = nil
        canLoadMore = false
        do {
            let response = try await service.fetchLatest(query: query, category: category, page: nil)
            articles = response.results ?? []
            nextPage = response.nextPage
            canLoadMore = response.nextPage != nil && !articles.isEmpty
        } catch {
            articles = []
            errorMessage = (error as? NewsError)?.errorDescription ?? error.localizedDescription
        }
        isLoading = false
    }

    func loadMore() async {
        guard canLoadMore, !isLoading, let page = nextPage else { return }
        isLoading = true
        do {
            let response = try await service.fetchLatest(query: query, category: category, page: page)
            let incoming = response.results ?? []
            // De-duplicate by id to keep the list stable.
            let known = Set(articles.map { $0.id })
            articles.append(contentsOf: incoming.filter { !known.contains($0.id) })
            nextPage = response.nextPage
            canLoadMore = response.nextPage != nil && !incoming.isEmpty
        } catch {
            // A pagination failure should not wipe what we already have.
            canLoadMore = false
            if articles.isEmpty {
                errorMessage = (error as? NewsError)?.errorDescription ?? error.localizedDescription
            }
        }
        isLoading = false
    }
}

// MARK: - Bookmarks

@MainActor
final class BookmarksStore: ObservableObject {
    @Published private(set) var items: [Article] = []
    private let key = "bookmarked_articles"

    init() { load() }

    func isBookmarked(_ article: Article) -> Bool {
        items.contains { $0.id == article.id }
    }

    func toggle(_ article: Article) {
        if let index = items.firstIndex(where: { $0.id == article.id }) {
            items.remove(at: index)
        } else {
            items.insert(article, at: 0)
        }
        save()
    }

    func remove(at offsets: IndexSet) {
        items.remove(atOffsets: offsets)
        save()
    }

    private func load() {
        guard let data = UserDefaults.standard.data(forKey: key) else { return }
        items = (try? JSONDecoder().decode([Article].self, from: data)) ?? []
    }

    private func save() {
        if let data = try? JSONEncoder().encode(items) {
            UserDefaults.standard.set(data, forKey: key)
        }
    }
}
