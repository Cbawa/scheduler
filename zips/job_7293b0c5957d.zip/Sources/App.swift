import SwiftUI

@main
struct NewsDataApp: App {
    // "system" | "light" | "dark" — drives adaptive dark mode.
    @AppStorage("appearance") private var appearance: String = "system"

    var body: some Scene {
        WindowGroup {
            ContentView()
                .preferredColorScheme(resolvedScheme)
        }
    }

    private var resolvedScheme: ColorScheme? {
        switch appearance {
        case "light": return .light
        case "dark": return .dark
        default: return nil // follow the system
        }
    }
}

/// Reads the newsdata.io API key. The key is NEVER hardcoded: it comes from the
/// `NEWSDATA_API_KEY` environment variable (set it on the Xcode scheme), with an
/// optional `Info.plist` fallback of the same name.
enum APIConfig {
    static var apiKey: String? {
        if let env = ProcessInfo.processInfo.environment["NEWSDATA_API_KEY"],
           !env.trimmingCharacters(in: .whitespaces).isEmpty {
            return env
        }
        if let plist = Bundle.main.object(forInfoDictionaryKey: "NEWSDATA_API_KEY") as? String,
           !plist.trimmingCharacters(in: .whitespaces).isEmpty {
            return plist
        }
        return nil
    }
}
