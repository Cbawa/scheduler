#!/usr/bin/env python3
"""Call the newsdata.io latest endpoint the way the app does and print the fields it reads.

Usage: python check_api.py [category]
"""
import os
import sys

import requests

URL = "https://newsdata.io/api/1/latest"


def main() -> int:
    key = os.environ.get("NEWSDATA_API_KEY")
    if not key:
        print("NEWSDATA_API_KEY is not set. Export it first.", file=sys.stderr)
        return 1
    category = sys.argv[1] if len(sys.argv) > 1 else "top"
    try:
        resp = requests.get(
            URL,
            params={"apikey": key, "language": "en", "category": category},
            timeout=20,
        )
    except requests.RequestException as exc:
        print(f"network error: {exc}", file=sys.stderr)
        return 1

    if resp.status_code == 401:
        print("401: the API key was rejected.", file=sys.stderr)
        return 1
    if resp.status_code == 429:
        print("429: rate limit reached, try again later.", file=sys.stderr)
        return 1
    if resp.status_code != 200:
        print(f"request failed: HTTP {resp.status_code} {resp.text[:200]}", file=sys.stderr)
        return 1

    data = resp.json()
    results = data.get("results") or []
    print(f"status: {data.get('status')}, {len(results)} articles")
    if not results:
        print("no articles for this category")
        return 0
    for i, art in enumerate(results, 1):
        keywords = art.get("keywords")
        if isinstance(keywords, list):
            keywords = ", ".join(keywords)
        sentiment = art.get("sentiment") or "(not in response - paid plan field)"
        print(f"{i:2}. {art.get('title') or '(untitled)'}")
        print(f"    source: {art.get('source_name') or 'unknown'} | keywords: {keywords or 'none'}")
        print(f"    sentiment: {sentiment}")
    print(f"next page cursor: {data.get('nextPage')}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
