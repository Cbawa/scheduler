# Blocks for Screen1

Open Screen1 > Blocks. Components already exist after importing the project: `StatusLabel`, `BtnTop`, `BtnTech`, `BtnBusiness`, `BtnSports`, `BtnScience`, `NewsList` (ListView), `Web1`, `Notifier1`.

## Globals

- `initialize global apiKey to "PASTE_KEY_HERE"`
- `initialize global articles to create empty list`

## Procedure `loadCategory` (parameter `cat`)

1. `set StatusLabel.Text to join("Loading ", get cat, "...")`
2. `set Web1.Url to join("https://newsdata.io/api/1/latest?language=en&category=", get cat, "&apikey=", get global apiKey)`
3. `call Web1.Get`

## Category buttons

Five `when BtnXxx.Click` handlers, each calling `loadCategory` with:

| Button | cat |
|---|---|
| BtnTop | `top` |
| BtnTech | `technology` |
| BtnBusiness | `business` |
| BtnSports | `sports` |
| BtnScience | `science` |

Also call `loadCategory "top"` from `when Screen1.Initialize`.

## when Web1.GotText (url, responseCode, responseType, responseContent)

- If `responseCode = 401`: `set StatusLabel.Text to "Invalid API key"` and stop.
- Else if `responseCode = 429`: `set StatusLabel.Text to "Rate limit reached, wait a bit"` and stop.
- Else if `responseCode  ≠ 200`: `set StatusLabel.Text to join("Request failed: ", get responseCode)` and stop.
- Otherwise:
  1. `set global articles to look up in pairs key "results" pairs (call Web1.JsonTextDecodeWithDictionaries get responseContent) notFound create empty list`
  2. If `is list empty? get global articles`: `set StatusLabel.Text to "No articles for this category"`; `set NewsList.Elements to create empty list`.
  3. Else: `set StatusLabel.Text to "Top stories"` and
     `set NewsList.Elements to` a `for each item in list (get global articles)` loop that builds a list of `look up in pairs key "title" pairs (get item) notFound "(untitled)"`. A simple way is the `map` block from the Lists drawer.

## when NewsList.AfterPicking

Let `item = select list item (get global articles) index NewsList.SelectionIndex`.

Build the message with `join`:

- title, a newline
- `"Source: "` + `look up in pairs key "source_name" ... notFound "unknown"`
- `"Keywords: "` + keywords. `keywords` can be null, so look it up with `notFound "none"`; if the result is a list, use `join with separator ", "`.
- sentiment line only if `is in dictionary? key "sentiment"` is true and the value is not null (not returned on the free plan).

Then `call Notifier1.ShowChooseDialog` with message above, title `Article`, button1 `Open`, button2 `Close`, cancelable true.

## when Notifier1.AfterChoosing (choice)

If `choice = "Open"`: set `ActivityStarter1.DataUri` to the item's `link` and call `StartActivity`. (Add an ActivityStarter component with Action `android.intent.action.VIEW` if it isn't already there. It isn't in the .scm, to keep the file minimal.)

Tip: store the selected `item` in a global `selected` so AfterChoosing can read its link.
