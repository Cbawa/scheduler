# newsdata-appinventor-news-app

An Android news reader built with MIT App Inventor. It pulls live headlines from the newsdata.io news API (https://newsdata.io) using App Inventor's Web component, shows them in a scrolling list, and opens the full story in the phone's browser. You need a free API key to run it.

The repo keeps the app as plain text so it diffs and reviews like normal code. An `.aia` is a zip, so `build_aia.py` packages the sources into one you can import. No binary is checked in.

## What the app does

- Five category buttons: Top, Technology, Business, Sports, Science
- Scrollable list of headlines (ListView)
- Tap a headline to see its source and keywords, with a button to open the article in the browser
- Shows a message when the key is rejected (401), the rate limit is hit (429), or a category returns no articles
- Sentiment is shown only if the API returns it; on a free key it is simply left out

## Layout

```
aia-src/                         # contents of the .aia, as plain text
  youngandroidproject/project.properties
  src/appinventor/ai_newsdata/NewsDataReader/Screen1.scm   # UI components (JSON)
BLOCKS.md                        # the block logic, step by step
build_aia.py                     # zips aia-src/ into NewsDataReader.aia
check_api.py                     # checks your key and prints the fields the app reads
```

`Screen1.scm` defines the screen: status label, category buttons, ListView, Web1, and a Notifier. The event handling lives in the blocks (`Screen1.bky`), which is a Blockly XML file that is easy to get wrong by hand. `BLOCKS.md` lists every block to assemble, which takes about ten minutes in the designer.

## Setup

1. Get a free API key from newsdata.io (https://newsdata.io).
2. Optional sanity check of the key from a terminal:

   ```bash
   pip install -r requirements.txt
   export NEWSDATA_API_KEY=your_key_here
   python check_api.py technology
   ```

3. Build the project file:

   ```bash
   python build_aia.py
   ```

   This writes `NewsDataReader.aia`.
4. Go to https://ai2.appinventor.mit.edu, choose Projects > Import project (.aia) from my computer, and select the file.
5. Open the Blocks view and follow `BLOCKS.md`. Put your key in the `apiKey` global variable.
6. Run it with the MIT AI2 Companion app, or Build > Android App (.apk).

### API key note

App Inventor has no environment variables, so the key lives inside the app. Don't export an `.aia` or `.apk` with your key in it and share it publicly. `build_aia.py` and `check_api.py` read `NEWSDATA_API_KEY` from the environment and never write it to disk.

## Requests the app makes

```
GET https://newsdata.io/api/1/latest?apikey=KEY&language=en&category=technology
```

Only `apikey`, `language` and `category` are sent, so it works on the free plan as is. Free responses return up to 10 articles per page; the app shows the first page.

Fields read from each article: `title`, `link`, `source_name`, `keywords` (may be null), and `sentiment` (absent on the free plan).

## Example check_api.py output

```
$ python check_api.py technology
status: success, 10 articles
 1. Chipmakers weigh new export rules
    source: example-news | keywords: semiconductors, exports, trade
    sentiment: (not in response - paid plan field)
 2. ...
next page cursor: 1730000000abcd
```

## Optional paid fields

On a paid newsdata.io plan the response includes `sentiment` per article. The blocks check for the key and show it in the details dialog when present. Nothing else needs changing.

## Limitations

- Only the first page is loaded. The `nextPage` cursor could be passed back as `page` for more.
- The free plan is rate limited, so rapidly switching categories can return 429.
