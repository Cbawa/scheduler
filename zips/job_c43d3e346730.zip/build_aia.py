#!/usr/bin/env python3
"""Package aia-src/ into NewsDataReader.aia (an .aia is just a zip file)."""
import sys
import zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parent
SRC = ROOT / "aia-src"
OUT = ROOT / "NewsDataReader.aia"


def main() -> int:
    if not SRC.is_dir():
        print(f"missing source directory: {SRC}", file=sys.stderr)
        return 1
    files = sorted(p for p in SRC.rglob("*") if p.is_file())
    if not files:
        print("aia-src/ is empty", file=sys.stderr)
        return 1
    with zipfile.ZipFile(OUT, "w", zipfile.ZIP_DEFLATED) as zf:
        for path in files:
            arcname = path.relative_to(SRC).as_posix()
            zf.write(path, arcname)
            print(f"added {arcname}")
    print(f"wrote {OUT.name} ({len(files)} files)")
    return 0


if __name__ == "__main__":
    sys.exit(main())
