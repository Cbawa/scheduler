import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'
import { handleApiRequest, requireApiKey } from './server/newsdata.js'

const PORT = Number(process.env.PORT || 5173)

/**
 * The dev server mounts the same JSON API the production server uses, so the
 * newsdata.io key is only ever read in Node and never shipped to the browser.
 */
const newsdataApi = {
  name: 'newsdata-api-middleware',
  configureServer(server) {
    requireApiKey()
    server.middlewares.use((req, res, next) => {
      if (!req.url || !req.url.startsWith('/api/')) return next()
      handleApiRequest(req, res)
    })
  },
}

export default defineConfig({
  plugins: [react(), newsdataApi],
  server: {
    host: '127.0.0.1',
    port: PORT,
  },
  preview: {
    host: '127.0.0.1',
    port: PORT,
  },
  build: {
    outDir: 'dist',
    sourcemap: false,
  },
})
