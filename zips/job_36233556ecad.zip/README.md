# newsdata-react-query


## Screenshots

![newsdata-react-query](docs/screenshots/home.png)

A small React news reader I built while working out a set of TanStack Query patterns I kept
rewriting from scratch: cursor pagination, background refetching, cache invalidation when a
filter changes, and optimistic mutations. Headlines come from the newsdata.io news API
(https://newsdata.io) — a free API key is enough to run everything in here.

The app renders live headlines on first load (no clicks, no login), lets you switch category,
search, page through results with the `nextPage` cursor, and save articles to a bookmark list
that updates optimistically before the request resolves.

## What's actually being demonstrated

| Pattern | Where |
|---|---|
| `useInfiniteQuery` with an opaque cursor | `src/useNewsQuery.js` — `getNextPageParam` returns `nextPage`, stops at `null` |
| Structured query keys | `newsKeys.list({ category, q, sentiment })` |
| Keep-previous-data on filter change | `placeholderData: (prev) => prev` — the grid never flashes empty |
| Invalidation on category switch | `queryClient.invalidateQueries({ queryKey: newsKeys.all, refetchType: 'none' })` |
| Background refetching | "Live" toggle sets `refetchInterval` to 60s |
| Optimistic updates + rollback | `useToggleBookmark` — `onMutate` / `onError` / `onSettled` |
| Not retrying unrecoverable errors | 401 and 429 fail fast instead of burning quota |

The `useNewsQuery` hook has no dependencies on the rest of the UI, so it can be copied into
another project as-is; it only expects the `/api/news` endpoint from `server/newsdata.js`.

## Why there's a server

An API key does not belong in browser JavaScript. `server/newsdata.js` is a dependency-free
Node module that talks to newsdata.io, normalises each article, and exposes a small JSON API.
It's mounted twice — as Vite middleware in dev, and by `server.js` in production — so the key
stays on the server in both modes.

## Setup

Node 18 or newer (the server uses the built-in `fetch`).

```bash
git clone https://github.com/<you>/newsdata-react-query.git
cd newsdata-react-query
npm install
export NEWSDATA_API_KEY=your_key_here
npm run dev
```

The key is read from the `NEWSDATA_API_KEY` environment variable; a free key from
https://newsdata.io works. The process exits with a message if the variable is missing —
nothing is ever read from a file or baked into the bundle.

Open http://127.0.0.1:5173.

For a production-ish run (static build + Node server, same port):

```bash
npm start        # builds into dist/ then serves it
PORT=8080 npm start
```

## Environment variables

| Variable | Default | Notes |
|---|---|---|
| `NEWSDATA_API_KEY` | — | Required. |
| `PORT` | `5173` | Both the dev server and `server.js` bind `127.0.0.1` on this port. |
| `ENABLE_PAID_PARAMS` | unset | Set to `1` to send query parameters that require a paid newsdata.io plan (`size=25`, `sentiment=`). On a free key those parameters make the request fail, so they are omitted by default; if the server gets a 403/422 with them enabled it retries once without them. |

## Free vs. paid fields

Every article is requested the same way regardless of plan. Some *response* fields
(`sentiment`, `sentiment_stats`, `ai_tag`, `ai_region`, `ai_org`, `ai_summary`) are only
populated on paid newsdata.io plans — on a free key the API returns a placeholder string
instead, which `server/newsdata.js` scrubs to `null`.

The UI keeps those widgets on screen either way. When the data isn't there, the sentiment
chart and AI-tag panel render an obviously-labelled sample so the layout holds and the shape
of the feature is visible; the caption says plainly that it's a sample. Keyword tags come from
the free `keywords` field and are always real.

## Usage example

The JSON endpoint is usable on its own:

```bash
curl -s 'http://127.0.0.1:5173/api/news?category=technology&q=chip' | head -c 700
```

```json
{
  "results": [
    {
      "id": "a1f2c9...",
      "title": "Chipmaker raises outlook on data-centre demand",
      "link": "https://example-news.test/chip-outlook",
      "description": "The company lifted its full-year revenue guidance...",
      "image": "https://example-news.test/img/chip.jpg",
      "published": "2026-08-13 09:41:22",
      "source": { "name": "Example Wire", "url": "https://example-news.test" },
      "keywords": ["semiconductors", "earnings", "data centre"],
      "sentiment": null,
      "sentimentStats": null,
      "aiTag": null,
      "aiSummary": null
    }
  ],
  "nextPage": "1723544482123456789",
  "totalResults": 214,
  "paidMode": false,
  "fields": { "sentiment": false, "aiTag": false, "aiSummary": false }
}
```

Pass `nextPage` back as `page` for the following page; the app does this through
`getNextPageParam` and stops when it comes back `null`.

Dropping the hook into another app:

```jsx
import { useNewsQuery } from './useNewsQuery.js'

function Feed() {
  const { data, fetchNextPage, hasNextPage, isFetching } = useNewsQuery({
    category: 'business',
    refetchInterval: 60_000,
  })

  const articles = (data?.pages ?? []).flatMap((p) => p.results)

  return (
    <>
      {articles.map((a) => <a key={a.id} href={a.link}>{a.title}</a>)}
      {hasNextPage && <button onClick={() => fetchNextPage()} disabled={isFetching}>More</button>}
    </>
  )
}
```

## Layout

```
server/newsdata.js   newsdata.io client, field scrubbing, JSON routes, bookmark store
server.js            production static server + /api mount
vite.config.js       dev server, mounts the same /api handler as middleware
src/useNewsQuery.js   the reusable hooks (news, bookmarks, toggle mutation)
src/App.jsx          UI
src/styles.css       styles
```

Bookmarks live in memory in the server process, so they reset on restart. Swapping the
`bookmarks` Map in `server/newsdata.js` for a real store is a contained change.

## Notes and limitations

- The free plan returns 10 articles per page and rate-limits fairly aggressively; a 429 is
  surfaced as a readable message rather than an empty screen, and the query is not retried.
- Search uses the `q` parameter against the `/1/latest` endpoint. Advanced boolean operators
  and the `/1/archive` endpoint are paid-only and aren't used here.
- `language=en` is hard-coded in the server request. Change it in `fetchNews` if you want
  another language.

## Licence

MIT.
