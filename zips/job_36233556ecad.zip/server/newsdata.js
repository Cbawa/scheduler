/**
 * newsdata.io client + a tiny JSON API, with no dependencies.
 *
 * Mounted by vite.config.js in development and by server.js in production, so
 * the API key stays server-side in both modes.
 *
 * Endpoints:
 *   GET  /api/news?category=&q=&page=&sentiment=
 *   GET  /api/bookmarks
 *   POST /api/bookmarks/toggle    body: { id, title, link, source, published }
 */

const BASE_URL = 'https://newsdata.io/api/1'

// Paid *query parameters* break the whole request on a free key, so they are
// opt-in. Paid *response fields* are always requested — they simply come back
// empty on a free plan.
const PAID_MODE = /^(1|true|yes|on)$/i.test(process.env.ENABLE_PAID_PARAMS || '')

// On free plans newsdata.io fills paid fields with a notice string rather than
// omitting them. Anything matching this is treated as "not available".
const PLACEHOLDER = /only available in .*(plan|subscription)/i

export function getApiKey() {
  return String(process.env.NEWSDATA_API_KEY || '').trim()
}

export function requireApiKey() {
  const key = getApiKey()
  if (!key) {
    console.error(
      [
        '',
        'NEWSDATA_API_KEY is not set.',
        '',
        'Create a free key at https://newsdata.io and export it before starting:',
        '',
        '    export NEWSDATA_API_KEY=your_key_here',
        '',
      ].join('\n')
    )
    process.exit(1)
  }
  return key
}

class ApiError extends Error {
  constructor(status, message, code) {
    super(message || 'Request failed')
    this.status = status || 500
    this.code = code || null
  }
}

/* ------------------------------------------------------------------ *
 * Field normalisation
 * ------------------------------------------------------------------ */

function cleanString(value) {
  if (typeof value !== 'string') return null
  const trimmed = value.trim()
  if (!trimmed || PLACEHOLDER.test(trimmed)) return null
  return trimmed
}

function cleanList(value) {
  if (!Array.isArray(value)) return null
  const out = value.map(cleanString).filter(Boolean)
  return out.length ? out : null
}

function cleanStats(value) {
  if (!value || typeof value !== 'object' || Array.isArray(value)) return null
  const out = {}
  for (const key of ['positive', 'neutral', 'negative']) {
    const n = Number(value[key])
    if (Number.isFinite(n)) out[key] = n
  }
  return Object.keys(out).length ? out : null
}

function cleanSentiment(value) {
  const s = cleanString(value)
  if (!s) return null
  const lower = s.toLowerCase()
  return ['positive', 'neutral', 'negative'].includes(lower) ? lower : null
}

function normalizeArticle(raw) {
  return {
    id: cleanString(raw.article_id) || cleanString(raw.link) || cleanString(raw.title) || 'unknown',
    title: cleanString(raw.title) || 'Untitled',
    link: cleanString(raw.link),
    description: cleanString(raw.description),
    image: cleanString(raw.image_url),
    published: cleanString(raw.pubDate),
    language: cleanString(raw.language),
    country: cleanList(raw.country),
    category: cleanList(raw.category),
    creator: cleanList(raw.creator),
    source: {
      name: cleanString(raw.source_name) || cleanString(raw.source_id) || 'Unknown source',
      url: cleanString(raw.source_url),
      icon: cleanString(raw.source_icon),
    },
    // Free on every plan — the UI leans on this.
    keywords: (cleanList(raw.keywords) || []).slice(0, 8),
    // Paid response fields: null on a free key, rendered as placeholders.
    sentiment: cleanSentiment(raw.sentiment),
    sentimentStats: cleanStats(raw.sentiment_stats),
    aiTag: cleanList(raw.ai_tag),
    aiRegion: cleanList(raw.ai_region),
    aiOrg: cleanList(raw.ai_org),
    aiSummary: cleanString(raw.ai_summary),
  }
}

/* ------------------------------------------------------------------ *
 * HTTP
 * ------------------------------------------------------------------ */

async function request(path, params) {
  const url = new URL(BASE_URL + path)
  for (const [key, value] of Object.entries(params)) {
    if (value === undefined || value === null || value === '') continue
    url.searchParams.set(key, String(value))
  }

  let res
  try {
    res = await fetch(url, {
      headers: {
        'X-ACCESS-KEY': getApiKey(),
        Accept: 'application/json',
        'User-Agent': 'newsdata-react-query',
      },
    })
  } catch (err) {
    throw new ApiError(502, `Could not reach newsdata.io: ${err.message}`)
  }

  let body = null
  try {
    body = await res.json()
  } catch {
    body = null
  }

  if (!res.ok || (body && body.status === 'error')) {
    const detail =
      (body && body.results && body.results.message) ||
      (body && body.message) ||
      res.statusText ||
      'Unknown error'
    const code = (body && body.results && body.results.code) || null
    throw new ApiError(res.status || 500, detail, code)
  }

  return body || {}
}

/**
 * Fetch one page of the /1/latest endpoint.
 * `page` is the opaque nextPage cursor from the previous response.
 */
export async function fetchNews({ category, q, page, sentiment } = {}) {
  const freeParams = { language: 'en' }
  if (category) freeParams.category = category
  if (q) freeParams.q = q
  if (page) freeParams.page = page

  // Opt-in only: these fail the entire request on a free key.
  const paidParams = {}
  if (PAID_MODE) {
    paidParams.size = 25
    if (sentiment) paidParams.sentiment = sentiment
  }

  let body
  let downgraded = false

  try {
    body = await request('/latest', { ...freeParams, ...paidParams })
  } catch (err) {
    const usedPaid = Object.keys(paidParams).length > 0
    if (!usedPaid || ![403, 409, 422].includes(err.status)) throw err
    // Plan rejected the paid parameters — fall back so the user still gets news.
    console.warn('[newsdata] paid parameters rejected, retrying without them:', err.message)
    downgraded = true
    body = await request('/latest', freeParams)
  }

  const raw = Array.isArray(body.results) ? body.results : []
  const results = raw.map(normalizeArticle)

  return {
    results,
    nextPage: body.nextPage || null,
    totalResults: Number.isFinite(Number(body.totalResults))
      ? Number(body.totalResults)
      : results.length,
    paidMode: PAID_MODE,
    downgraded,
    fields: {
      sentiment: results.some((a) => a.sentiment || a.sentimentStats),
      aiTag: results.some((a) => a.aiTag),
      aiSummary: results.some((a) => a.aiSummary),
    },
  }
}

/* ------------------------------------------------------------------ *
 * Bookmarks (in-memory; resets with the process)
 * ------------------------------------------------------------------ */

const bookmarks = new Map()

function listBookmarks() {
  return [...bookmarks.values()]
}

function toggleBookmark(article) {
  const id = cleanString(article && article.id)
  if (!id) throw new ApiError(400, 'A bookmark needs an article id')
  if (bookmarks.has(id)) {
    bookmarks.delete(id)
    return false
  }
  bookmarks.set(id, {
    id,
    title: cleanString(article.title) || 'Untitled',
    link: cleanString(article.link),
    source: cleanString(article.source) || 'Unknown source',
    published: cleanString(article.published),
  })
  return true
}

/* ------------------------------------------------------------------ *
 * Request handling
 * ------------------------------------------------------------------ */

function json(res, status, payload) {
  const text = JSON.stringify(payload)
  res.writeHead(status, {
    'Content-Type': 'application/json; charset=utf-8',
    'Cache-Control': 'no-store',
    'Content-Length': Buffer.byteLength(text),
  })
  res.end(text)
}

function readBody(req) {
  return new Promise((resolve, reject) => {
    let data = ''
    req.on('data', (chunk) => {
      data += chunk
      if (data.length > 64 * 1024) {
        reject(new ApiError(413, 'Request body too large'))
        req.destroy()
      }
    })
    req.on('end', () => {
      if (!data) return resolve({})
      try {
        resolve(JSON.parse(data))
      } catch {
        reject(new ApiError(400, 'Invalid JSON body'))
      }
    })
    req.on('error', () => reject(new ApiError(400, 'Could not read request body')))
  })
}

function friendlyMessage(err) {
  switch (err.status) {
    case 401:
      return 'newsdata.io rejected the API key (401). Check the NEWSDATA_API_KEY value and restart.'
    case 403:
      return `newsdata.io refused this request (403): ${err.message}`
    case 429:
      return 'Rate limit reached on this newsdata.io key (429). Wait a moment, then refresh.'
    default:
      return err.message || 'Something went wrong talking to newsdata.io.'
  }
}

export async function handleApiRequest(req, res) {
  const url = new URL(req.url || '/', 'http://127.0.0.1')

  try {
    if (req.method === 'GET' && url.pathname === '/api/news') {
      const data = await fetchNews({
        category: url.searchParams.get('category') || undefined,
        q: url.searchParams.get('q') || undefined,
        page: url.searchParams.get('page') || undefined,
        sentiment: url.searchParams.get('sentiment') || undefined,
      })
      return json(res, 200, data)
    }

    if (req.method === 'GET' && url.pathname === '/api/bookmarks') {
      return json(res, 200, { items: listBookmarks() })
    }

    if (req.method === 'POST' && url.pathname === '/api/bookmarks/toggle') {
      const body = await readBody(req)
      const saved = toggleBookmark(body)
      return json(res, 200, { items: listBookmarks(), saved })
    }

    return json(res, 404, { error: `No route for ${req.method} ${url.pathname}` })
  } catch (err) {
    const status = err instanceof ApiError ? err.status : 500
    if (status >= 500) console.error('[newsdata]', err)
    return json(res, status, { error: friendlyMessage(err), code: err.code || null })
  }
}
