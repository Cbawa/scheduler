/**
 * Production server: serves the built app from dist/ and mounts the same JSON
 * API used by the Vite dev middleware. Binds 127.0.0.1 and reads PORT.
 */
import http from 'node:http'
import fs from 'node:fs'
import path from 'node:path'
import { fileURLToPath } from 'node:url'
import { handleApiRequest, requireApiKey } from './server/newsdata.js'

const __dirname = path.dirname(fileURLToPath(import.meta.url))
const DIST = path.join(__dirname, 'dist')
const PORT = Number(process.env.PORT || 5173)
const HOST = '127.0.0.1'

const MIME = {
  '.html': 'text/html; charset=utf-8',
  '.js': 'text/javascript; charset=utf-8',
  '.mjs': 'text/javascript; charset=utf-8',
  '.css': 'text/css; charset=utf-8',
  '.json': 'application/json; charset=utf-8',
  '.svg': 'image/svg+xml',
  '.png': 'image/png',
  '.jpg': 'image/jpeg',
  '.jpeg': 'image/jpeg',
  '.webp': 'image/webp',
  '.ico': 'image/x-icon',
  '.woff': 'font/woff',
  '.woff2': 'font/woff2',
  '.map': 'application/json; charset=utf-8',
}

requireApiKey()

const indexFile = path.join(DIST, 'index.html')
if (!fs.existsSync(indexFile)) {
  console.error('dist/ is missing. Build the app first:\n\n    npm run build\n')
  process.exit(1)
}

const server = http.createServer((req, res) => {
  const url = new URL(req.url || '/', `http://${HOST}:${PORT}`)

  if (url.pathname.startsWith('/api/')) {
    handleApiRequest(req, res)
    return
  }

  let rel
  try {
    rel = decodeURIComponent(url.pathname)
  } catch {
    rel = url.pathname
  }
  if (rel.endsWith('/')) rel += 'index.html'

  const target = path.join(DIST, path.normalize(rel).replace(/^[\\/]+/, ''))
  let file = target

  if (!file.startsWith(DIST)) {
    res.writeHead(403, { 'Content-Type': 'text/plain' })
    res.end('Forbidden')
    return
  }

  if (!fs.existsSync(file) || fs.statSync(file).isDirectory()) {
    file = indexFile // SPA fallback
  }

  const type = MIME[path.extname(file).toLowerCase()] || 'application/octet-stream'
  const cache = file === indexFile ? 'no-store' : 'public, max-age=3600'
  res.writeHead(200, { 'Content-Type': type, 'Cache-Control': cache })
  fs.createReadStream(file)
    .on('error', () => {
      res.destroy()
    })
    .pipe(res)
})

server.listen(PORT, HOST, () => {
  console.log(`Newsroom listening on http://${HOST}:${PORT}`)
})
