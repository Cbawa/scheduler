import { useMemo, useState } from 'react'
import { useQueryClient } from '@tanstack/react-query'
import {
  newsKeys,
  useBookmarks,
  useNewsQuery,
  useToggleBookmark,
} from './useNewsQuery.js'

const CATEGORIES = [
  { id: 'top', label: 'Top' },
  { id: 'world', label: 'World' },
  { id: 'business', label: 'Business' },
  { id: 'technology', label: 'Technology' },
  { id: 'science', label: 'Science' },
  { id: 'health', label: 'Health' },
  { id: 'sports', label: 'Sports' },
  { id: 'entertainment', label: 'Entertainment' },
]

// Shown only when the API returns no sentiment data (i.e. on a free plan), and
// always labelled as a sample so it can't be mistaken for live output.
const SAMPLE_SENTIMENT = { positive: 38, neutral: 44, negative: 18 }
const SAMPLE_TAGS = ['market moves', 'elections', 'clinical trials', 'transfers']

function timeAgo(pubDate) {
  if (!pubDate) return ''
  const parsed = new Date(pubDate.includes('T') ? pubDate : `${pubDate.replace(' ', 'T')}Z`)
  if (Number.isNaN(parsed.getTime())) return ''
  const seconds = Math.max(0, (Date.now() - parsed.getTime()) / 1000)
  if (seconds < 90) return 'just now'
  const minutes = Math.round(seconds / 60)
  if (minutes < 60) return `${minutes}m ago`
  const hours = Math.round(minutes / 60)
  if (hours < 24) return `${hours}h ago`
  return `${Math.round(hours / 24)}d ago`
}

export default function App() {
  const [category, setCategory] = useState('top')
  const [term, setTerm] = useState('')
  const [search, setSearch] = useState('')
  const [live, setLive] = useState(false)
  const queryClient = useQueryClient()

  const news = useNewsQuery({
    category,
    q: search,
    refetchInterval: live ? 60_000 : 0,
  })

  const bookmarks = useBookmarks()
  const toggleBookmark = useToggleBookmark()
  const savedIds = useMemo(
    () => new Set((bookmarks.data?.items ?? []).map((item) => item.id)),
    [bookmarks.data]
  )

  const articles = useMemo(() => {
    const seen = new Set()
    const out = []
    for (const page of news.data?.pages ?? []) {
      for (const article of page.results ?? []) {
        if (seen.has(article.id)) continue
        seen.add(article.id)
        out.push(article)
      }
    }
    return out
  }, [news.data])

  const meta = news.data?.pages?.[0]

  const sentiment = useMemo(() => {
    const counts = { positive: 0, neutral: 0, negative: 0 }
    let total = 0
    for (const article of articles) {
      if (article.sentiment && counts[article.sentiment] !== undefined) {
        counts[article.sentiment] += 1
        total += 1
      }
    }
    if (!total) return null
    return {
      positive: Math.round((counts.positive / total) * 100),
      neutral: Math.round((counts.neutral / total) * 100),
      negative: Math.round((counts.negative / total) * 100),
      total,
    }
  }, [articles])

  const topKeywords = useMemo(() => {
    const counts = new Map()
    for (const article of articles) {
      for (const keyword of article.keywords ?? []) {
        const key = keyword.toLowerCase()
        counts.set(key, (counts.get(key) || 0) + 1)
      }
    }
    return [...counts.entries()].sort((a, b) => b[1] - a[1]).slice(0, 14)
  }, [articles])

  const aiTags = useMemo(() => {
    const counts = new Map()
    for (const article of articles) {
      for (const tag of article.aiTag ?? []) {
        const key = tag.toLowerCase()
        counts.set(key, (counts.get(key) || 0) + 1)
      }
    }
    return [...counts.entries()].sort((a, b) => b[1] - a[1]).slice(0, 10)
  }, [articles])

  function selectCategory(next) {
    if (next === category) return
    setCategory(next)
    // Mark every cached news list stale without refetching them all; the list
    // that mounts next refetches on its own.
    queryClient.invalidateQueries({ queryKey: newsKeys.all, refetchType: 'none' })
  }

  function submitSearch(event) {
    event.preventDefault()
    setSearch(term.trim())
  }

  function clearSearch() {
    setTerm('')
    setSearch('')
  }

  const refreshing = news.isFetching && !news.isFetchingNextPage

  return (
    <div className="shell">
      <header className="masthead">
        <div className="masthead-left">
          <h1>Newsroom</h1>
          <p>
            Headlines from the <code>/1/latest</code> endpoint of the{' '}
            <a href="https://newsdata.io" target="_blank" rel="noreferrer">
              newsdata.io
            </a>{' '}
            news API, cached and paginated with TanStack Query.
          </p>
        </div>
        <div className="masthead-right">
          <span className={`pulse ${refreshing ? 'on' : ''}`} />
          <span className="status-text">
            {refreshing ? 'fetching…' : `${articles.length} articles cached`}
          </span>
        </div>
      </header>

      <nav className="tabs">
        {CATEGORIES.map((item) => (
          <button
            key={item.id}
            type="button"
            className={item.id === category ? 'tab active' : 'tab'}
            onClick={() => selectCategory(item.id)}
          >
            {item.label}
          </button>
        ))}
      </nav>

      <div className="toolbar">
        <form className="search" onSubmit={submitSearch}>
          <input
            type="search"
            value={term}
            placeholder="Search headlines (q parameter)…"
            onChange={(event) => setTerm(event.target.value)}
            aria-label="Search headlines"
          />
          <button type="submit">Search</button>
          {search ? (
            <button type="button" className="ghost" onClick={clearSearch}>
              Clear
            </button>
          ) : null}
        </form>

        <div className="toolbar-right">
          <label className="switch">
            <input
              type="checkbox"
              checked={live}
              onChange={(event) => setLive(event.target.checked)}
            />
            <span>Background refetch (60s)</span>
          </label>
          <button
            type="button"
            className="ghost"
            onClick={() => queryClient.invalidateQueries({ queryKey: newsKeys.all })}
          >
            Invalidate cache
          </button>
        </div>
      </div>

      {search ? (
        <p className="filter-note">
          Filtering on <strong>{search}</strong> — the search term is part of the query key, so
          each term keeps its own cache entry.
        </p>
      ) : null}

      <div className="layout">
        <main>
          {news.isError ? (
            <ErrorBox error={news.error} onRetry={() => news.refetch()} />
          ) : null}

          {news.isPending ? <SkeletonGrid /> : null}

          {!news.isPending && !news.isError && articles.length === 0 ? (
            <div className="panel empty">
              <h3>No articles came back</h3>
              <p>
                newsdata.io returned an empty result set for this filter combination. Try another
                category, or a broader search term.
              </p>
            </div>
          ) : null}

          <div className="grid">
            {articles.map((article) => (
              <ArticleCard
                key={article.id}
                article={article}
                saved={savedIds.has(article.id)}
                onToggle={() =>
                  toggleBookmark.mutate({
                    id: article.id,
                    title: article.title,
                    link: article.link,
                    source: article.source.name,
                    published: article.published,
                  })
                }
              />
            ))}
          </div>

          {articles.length > 0 ? (
            <div className="pager">
              <button
                type="button"
                onClick={() => news.fetchNextPage()}
                disabled={!news.hasNextPage || news.isFetchingNextPage}
              >
                {news.isFetchingNextPage
                  ? 'Loading…'
                  : news.hasNextPage
                    ? 'Load next page'
                    : 'End of results'}
              </button>
              <span className="pager-note">
                {news.data?.pages?.length ?? 0} page(s) fetched via the nextPage cursor
                {meta?.totalResults ? ` · ${meta.totalResults.toLocaleString()} matches` : ''}
              </span>
            </div>
          ) : null}
        </main>

        <aside>
          <SentimentPanel live={sentiment} />
          <TagPanel
            title="AI tags"
            hint="ai_tag field"
            entries={aiTags}
            samples={SAMPLE_TAGS}
            note="Sample values — ai_tag is populated on paid newsdata.io plans."
          />
          <section className="panel">
            <h2>
              Keywords <span className="hint">keywords field</span>
            </h2>
            {topKeywords.length ? (
              <div className="chips">
                {topKeywords.map(([keyword, count]) => (
                  <span key={keyword} className="chip">
                    {keyword}
                    <em>{count}</em>
                  </span>
                ))}
              </div>
            ) : (
              <p className="muted">Keywords appear once articles load.</p>
            )}
          </section>
          <BookmarkPanel
            items={bookmarks.data?.items ?? []}
            onRemove={(item) => toggleBookmark.mutate(item)}
          />
        </aside>
      </div>

      <footer className="footer">
        <span>
          Data: <a href="https://newsdata.io">newsdata.io</a> · client cache: TanStack Query v5
        </span>
        <span>
          {meta?.paidMode ? 'paid query params enabled' : 'free-plan request path'}
          {meta?.downgraded ? ' · fell back to free params' : ''}
        </span>
      </footer>
    </div>
  )
}

function ArticleCard({ article, saved, onToggle }) {
  const summary = article.aiSummary || article.description

  return (
    <article className="card">
      {article.image ? (
        <div className="thumb">
          <img
            src={article.image}
            alt=""
            loading="lazy"
            onError={(event) => {
              event.currentTarget.parentElement.style.display = 'none'
            }}
          />
        </div>
      ) : null}

      <div className="card-body">
        <div className="card-meta">
          <span className="source">{article.source.name}</span>
          <span className="dot">·</span>
          <span>{timeAgo(article.published)}</span>
          {article.sentiment ? (
            <span className={`badge ${article.sentiment}`}>{article.sentiment}</span>
          ) : (
            <span className="badge muted" title="sentiment requires a paid newsdata.io plan">
              sentiment n/a
            </span>
          )}
        </div>

        <h3>
          {article.link ? (
            <a href={article.link} target="_blank" rel="noreferrer">
              {article.title}
            </a>
          ) : (
            article.title
          )}
        </h3>

        {summary ? (
          <p className="summary">
            {article.aiSummary ? <span className="tagline">ai_summary</span> : null}
            {summary}
          </p>
        ) : null}

        {article.keywords.length ? (
          <div className="chips small">
            {article.keywords.slice(0, 4).map((keyword) => (
              <span key={keyword} className="chip">
                {keyword}
              </span>
            ))}
          </div>
        ) : null}

        <div className="card-actions">
          <button
            type="button"
            className={saved ? 'save on' : 'save'}
            onClick={onToggle}
            aria-pressed={saved}
          >
            {saved ? 'Saved' : 'Save'}
          </button>
          {article.aiTag ? <span className="mini">ai_tag: {article.aiTag[0]}</span> : null}
        </div>
      </div>
    </article>
  )
}

function SentimentPanel({ live }) {
  const data = live || SAMPLE_SENTIMENT
  const isSample = !live

  return (
    <section className="panel">
      <h2>
        Sentiment mix <span className="hint">sentiment field</span>
      </h2>
      <div className="bars">
        {['positive', 'neutral', 'negative'].map((key) => (
          <div key={key} className={`bar-row ${isSample ? 'sample' : ''}`}>
            <span className="bar-label">{key}</span>
            <span className="bar-track">
              <span className={`bar-fill ${key}`} style={{ width: `${data[key] || 0}%` }} />
            </span>
            <span className="bar-value">{data[key] || 0}%</span>
          </div>
        ))}
      </div>
      <p className="muted">
        {isSample
          ? 'Sample figures — live sentiment requires a paid newsdata.io plan.'
          : `Across ${live.total} article(s) in the current cache.`}
      </p>
    </section>
  )
}

function TagPanel({ title, hint, entries, samples, note }) {
  const hasData = entries.length > 0

  return (
    <section className="panel">
      <h2>
        {title} <span className="hint">{hint}</span>
      </h2>
      <div className="chips">
        {hasData
          ? entries.map(([tag, count]) => (
              <span key={tag} className="chip">
                {tag}
                <em>{count}</em>
              </span>
            ))
          : samples.map((tag) => (
              <span key={tag} className="chip sample">
                {tag}
              </span>
            ))}
      </div>
      {hasData ? null : <p className="muted">{note}</p>}
    </section>
  )
}

function BookmarkPanel({ items, onRemove }) {
  return (
    <section className="panel">
      <h2>
        Saved <span className="hint">optimistic mutation</span>
      </h2>
      {items.length === 0 ? (
        <p className="muted">
          Nothing saved yet. Saving writes to the query cache first and reconciles with the
          server afterwards.
        </p>
      ) : (
        <ul className="saved-list">
          {items.map((item) => (
            <li key={item.id} className={item.pending ? 'pending' : ''}>
              <a href={item.link || '#'} target="_blank" rel="noreferrer">
                {item.title}
              </a>
              <div className="saved-meta">
                <span>{item.source}</span>
                <button type="button" onClick={() => onRemove(item)}>
                  remove
                </button>
              </div>
            </li>
          ))}
        </ul>
      )}
    </section>
  )
}

function ErrorBox({ error, onRetry }) {
  const status = error?.status
  return (
    <div className="panel error">
      <h3>{status ? `Request failed (${status})` : 'Request failed'}</h3>
      <p>{error?.message || 'Unknown error.'}</p>
      {status === 401 ? (
        <p className="muted">
          Check that NEWSDATA_API_KEY holds a valid key, then restart the server.
        </p>
      ) : null}
      {status === 429 ? (
        <p className="muted">
          The free plan has a low request ceiling. Waiting a minute usually clears it.
        </p>
      ) : null}
      <button type="button" onClick={onRetry}>
        Try again
      </button>
    </div>
  )
}

function SkeletonGrid() {
  return (
    <div className="grid">
      {Array.from({ length: 6 }).map((_, index) => (
        <div key={index} className="card skeleton">
          <div className="sk sk-thumb" />
          <div className="card-body">
            <div className="sk sk-line short" />
            <div className="sk sk-line" />
            <div className="sk sk-line" />
            <div className="sk sk-line short" />
          </div>
        </div>
      ))}
    </div>
  )
}
