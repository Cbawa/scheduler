import {
  useInfiniteQuery,
  useMutation,
  useQuery,
  useQueryClient,
} from '@tanstack/react-query'

/**
 * Query key factory. Keeping keys in one place makes partial invalidation
 * (`newsKeys.all`) safe to do from anywhere in the tree.
 */
export const newsKeys = {
  all: ['news'],
  list: (filters) => ['news', 'list', filters],
  bookmarks: () => ['bookmarks'],
}

async function requestJson(url, options = {}) {
  const res = await fetch(url, {
    headers: { 'Content-Type': 'application/json' },
    ...options,
  })

  let body = null
  try {
    body = await res.json()
  } catch {
    body = null
  }

  if (!res.ok) {
    const error = new Error((body && body.error) || `Request failed (${res.status})`)
    error.status = res.status
    error.code = (body && body.code) || null
    throw error
  }
  return body
}

function buildNewsUrl({ category, q, sentiment, page }) {
  const params = new URLSearchParams()
  if (category) params.set('category', category)
  if (q) params.set('q', q)
  if (sentiment) params.set('sentiment', sentiment)
  if (page) params.set('page', page)
  const qs = params.toString()
  return qs ? `/api/news?${qs}` : '/api/news'
}

/**
 * Paginated headlines.
 *
 * The cursor is newsdata.io's `nextPage` token, handed straight back as the
 * `page` parameter; when it comes back null there are no more pages.
 *
 * @param {object}  options
 * @param {string}  options.category        newsdata.io category (top, business, ...)
 * @param {string}  options.q               free-text search
 * @param {string}  options.sentiment       only sent when the server runs in paid mode
 * @param {number}  options.refetchInterval ms between background refetches (0 = off)
 */
export function useNewsQuery({
  category = 'top',
  q = '',
  sentiment = '',
  refetchInterval = 0,
} = {}) {
  const filters = { category, q: q.trim().toLowerCase(), sentiment }

  return useInfiniteQuery({
    queryKey: newsKeys.list(filters),
    queryFn: ({ pageParam, signal }) =>
      requestJson(buildNewsUrl({ ...filters, q: q.trim(), page: pageParam }), { signal }),
    initialPageParam: null,
    getNextPageParam: (lastPage) => lastPage?.nextPage ?? undefined,
    // Show the previous category's articles while the new ones load, instead
    // of tearing the layout down to a spinner.
    placeholderData: (previous) => previous,
    refetchInterval: refetchInterval > 0 ? refetchInterval : false,
    refetchIntervalInBackground: false,
    // A bad key or an exhausted quota will not fix itself on retry.
    retry: (failureCount, error) =>
      error?.status === 401 || error?.status === 429 ? false : failureCount < 1,
  })
}

export function useBookmarks() {
  return useQuery({
    queryKey: newsKeys.bookmarks(),
    queryFn: () => requestJson('/api/bookmarks'),
    staleTime: Infinity,
  })
}

/**
 * Optimistic bookmark toggle: the cache is updated before the request goes
 * out, rolled back if it fails, and reconciled with the server afterwards.
 */
export function useToggleBookmark() {
  const queryClient = useQueryClient()

  return useMutation({
    mutationFn: (article) =>
      requestJson('/api/bookmarks/toggle', {
        method: 'POST',
        body: JSON.stringify(article),
      }),
    onMutate: async (article) => {
      await queryClient.cancelQueries({ queryKey: newsKeys.bookmarks() })
      const previous = queryClient.getQueryData(newsKeys.bookmarks())

      queryClient.setQueryData(newsKeys.bookmarks(), (old) => {
        const items = old?.items ?? []
        const exists = items.some((item) => item.id === article.id)
        return {
          items: exists
            ? items.filter((item) => item.id !== article.id)
            : [{ ...article, pending: true }, ...items],
        }
      })

      return { previous }
    },
    onError: (_error, _article, context) => {
      if (context?.previous) {
        queryClient.setQueryData(newsKeys.bookmarks(), context.previous)
      }
    },
    onSettled: () => {
      queryClient.invalidateQueries({ queryKey: newsKeys.bookmarks() })
    },
  })
}
