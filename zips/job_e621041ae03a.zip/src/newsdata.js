const BASE_URL = 'https://newsdata.io/api/1';
const MAX_ARTICLES = 6;
const SENTIMENTS = new Set(['positive', 'negative', 'neutral']);

class NewsError extends Error {
  constructor(message, userMessage) {
    super(message);
    this.name = 'NewsError';
    this.userMessage = userMessage;
  }
}

async function request(params) {
  const url = `${BASE_URL}/latest?${params.toString()}`;

  let res;
  try {
    res = await fetch(url);
  } catch (err) {
    throw new NewsError(`network error: ${err.message}`, 'Could not reach the newsdata.io API. Check your connection and try again.');
  }

  if (res.status === 401) {
    throw new NewsError('401 unauthorized', 'Invalid newsdata.io API key (401). Check the NEWSDATA_API_KEY value.');
  }
  if (res.status === 429) {
    throw new NewsError('429 rate limited', 'newsdata.io rate limit reached (429). Wait a moment and try again.');
  }

  let body;
  try {
    body = await res.json();
  } catch {
    throw new NewsError('invalid json response', 'newsdata.io returned an unexpected response.');
  }

  if (!res.ok || body.status === 'error') {
    const detail = body?.results?.message || body?.message || `HTTP ${res.status}`;
    const err = new NewsError(`api error: ${detail}`, `newsdata.io request failed: ${detail}`);
    err.status = res.status;
    throw err;
  }

  return body;
}

export async function fetchNews(topic) {
  const apiKey = process.env.NEWSDATA_API_KEY;
  if (!apiKey) {
    throw new NewsError('missing api key', 'NEWSDATA_API_KEY is not set on the server.');
  }

  const base = new URLSearchParams({ apikey: apiKey, language: 'en' });
  if (topic) base.set('q', topic);

  // Paid query params (timeframe, size > 10, ...) reject the whole request on a
  // free key, so attach them only when paid mode is explicitly enabled.
  const paidEnabled = process.env.ENABLE_PAID === '1';
  const withPaid = new URLSearchParams(base);
  if (paidEnabled) {
    if (process.env.NEWS_TIMEFRAME) withPaid.set('timeframe', process.env.NEWS_TIMEFRAME);
    if (process.env.NEWS_SIZE) withPaid.set('size', process.env.NEWS_SIZE);
  }

  let body;
  try {
    body = await request(withPaid);
  } catch (err) {
    const sentPaid = paidEnabled && withPaid.toString() !== base.toString();
    if (sentPaid && (err.status === 403 || err.status === 422)) {
      // Retry once without paid params so free-key users still get results.
      body = await request(base);
    } else {
      throw err;
    }
  }

  const results = Array.isArray(body.results) ? body.results : [];
  const articles = results.slice(0, MAX_ARTICLES).map(normalize);
  const hasSentiment = articles.some((a) => a.sentiment);

  return { articles, hasSentiment, total: body.totalResults ?? results.length };
}

function normalize(r) {
  return {
    title: r.title || 'Untitled',
    link: r.link || null,
    description: clean(r.description),
    source: r.source_name || r.source_id || 'unknown source',
    pubDate: r.pubDate || null,
    keywords: Array.isArray(r.keywords) ? r.keywords.filter(Boolean) : [],
    // Paid response fields: present only on paid plans, absent/placeholder on free.
    sentiment: SENTIMENTS.has(r.sentiment) ? r.sentiment : null,
    sentimentStats: r.sentiment_stats && typeof r.sentiment_stats === 'object' ? r.sentiment_stats : null,
    aiTag: Array.isArray(r.ai_tag) ? r.ai_tag.filter(Boolean) : [],
    aiRegion: Array.isArray(r.ai_region) ? r.ai_region.filter(Boolean) : [],
    aiOrg: Array.isArray(r.ai_org) ? r.ai_org.filter(Boolean) : [],
    aiSummary: paidString(r.ai_summary),
  };
}

function clean(text) {
  if (typeof text !== 'string') return '';
  return text.replace(/\s+/g, ' ').trim();
}

function paidString(value) {
  if (typeof value !== 'string') return null;
  if (/only available|upgrade|paid plan/i.test(value)) return null;
  return value.trim() || null;
}
