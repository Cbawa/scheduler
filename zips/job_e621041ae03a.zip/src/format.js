const SENTIMENT_BADGE = {
  positive: '🟢 positive',
  negative: '🔴 negative',
  neutral: '⚪ neutral',
};
const SAMPLE_SENTIMENT = '🟢 45%  ⚪ 40%  🔴 15%';

export function buildBlocks({ topic, summary, articles, hasSentiment }) {
  const blocks = [
    {
      type: 'header',
      text: { type: 'plain_text', text: trunc(`📰 News on "${topic}"`, 150), emoji: true },
    },
    {
      type: 'section',
      text: { type: 'mrkdwn', text: trunc(summary, 2900) },
    },
    sentimentBlock(articles, hasSentiment),
    { type: 'divider' },
  ];

  for (const article of articles) {
    blocks.push(...articleBlocks(article));
  }

  blocks.push({
    type: 'context',
    elements: [{ type: 'mrkdwn', text: 'Headlines via the newsdata.io news API · summary by GPT-4' }],
  });

  return blocks.slice(0, 48);
}

function sentimentBlock(articles, hasSentiment) {
  if (hasSentiment) {
    const counts = { positive: 0, neutral: 0, negative: 0 };
    for (const a of articles) {
      if (a.sentiment && counts[a.sentiment] !== undefined) counts[a.sentiment] += 1;
    }
    const text = `*Sentiment across these stories:* 🟢 ${counts.positive}  ⚪ ${counts.neutral}  🔴 ${counts.negative}`;
    return { type: 'context', elements: [{ type: 'mrkdwn', text }] };
  }

  return {
    type: 'context',
    elements: [
      {
        type: 'mrkdwn',
        text: `*Sentiment (sample):* ${SAMPLE_SENTIMENT}  ·  _live sentiment requires a paid newsdata.io plan_`,
      },
    ],
  };
}

function articleBlocks(a) {
  const title = trunc(a.title, 220);
  const heading = a.link ? `*<${a.link}|${escape(title)}>*` : `*${escape(title)}*`;

  const lines = [heading];
  if (a.description) lines.push(escape(trunc(a.description, 400)));
  if (a.aiSummary) lines.push(`> _AI summary:_ ${escape(trunc(a.aiSummary, 300))}`);

  const meta = [`*${escape(a.source)}*`];
  if (a.pubDate) meta.push(fmtDate(a.pubDate));
  if (a.sentiment && SENTIMENT_BADGE[a.sentiment]) meta.push(SENTIMENT_BADGE[a.sentiment]);

  const context = [{ type: 'mrkdwn', text: meta.join('  ·  ') }];
  const tags = [...a.keywords, ...a.aiTag].slice(0, 6);
  if (tags.length) {
    context.push({
      type: 'mrkdwn',
      text: tags.map((t) => '`' + escape(String(t)) + '`').join('  '),
    });
  }

  return [
    { type: 'section', text: { type: 'mrkdwn', text: lines.join('\n') } },
    { type: 'context', elements: context },
  ];
}

function trunc(text, max) {
  const s = String(text || '');
  return s.length > max ? `${s.slice(0, max - 1)}…` : s;
}

function escape(text) {
  return String(text || '')
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;');
}

function fmtDate(pubDate) {
  const datePart = String(pubDate).split(' ')[0];
  return datePart || String(pubDate);
}
