import OpenAI from 'openai';

export async function summarize(topic, articles) {
  const apiKey = process.env.OPENAI_API_KEY;
  if (!apiKey) return fallbackSummary(articles);

  const bullets = articles
    .map((a, i) => `${i + 1}. ${a.title}${a.description ? ' — ' + a.description : ''}`)
    .join('\n');

  try {
    const client = new OpenAI({ apiKey });
    const model = process.env.OPENAI_MODEL || 'gpt-4';
    const resp = await client.chat.completions.create({
      model,
      temperature: 0.3,
      max_tokens: 220,
      messages: [
        {
          role: 'system',
          content: 'You are a concise news editor. Write a neutral 2-3 sentence briefing that summarizes the supplied headlines. No preamble, no bullet points.',
        },
        {
          role: 'user',
          content: `Topic: ${topic}\n\nHeadlines:\n${bullets}`,
        },
      ],
    });
    return resp.choices?.[0]?.message?.content?.trim() || fallbackSummary(articles);
  } catch (err) {
    console.error('summarize fell back to extractive summary:', err.message);
    return fallbackSummary(articles);
  }
}

function fallbackSummary(articles) {
  const withDesc = articles.find((a) => a.description);
  const lead = (withDesc && withDesc.description) || (articles[0] && articles[0].title) || '';
  const count = articles.length;
  return `${count} recent article${count === 1 ? '' : 's'} found. ${lead}`.trim();
}
