import 'dotenv/config';
import pkg from '@slack/bolt';
import { fetchNews } from './src/newsdata.js';
import { summarize } from './src/summarize.js';
import { buildBlocks } from './src/format.js';

const { App } = pkg;

const REQUIRED = ['SLACK_BOT_TOKEN', 'SLACK_APP_TOKEN', 'NEWSDATA_API_KEY'];
const missing = REQUIRED.filter((key) => !process.env[key]);
if (missing.length) {
  console.error(`Missing required environment variables: ${missing.join(', ')}`);
  console.error('Copy .env.example to .env and fill in the values, then start again.');
  process.exit(1);
}

const app = new App({
  token: process.env.SLACK_BOT_TOKEN,
  appToken: process.env.SLACK_APP_TOKEN,
  socketMode: true,
});

app.command('/news', async ({ command, ack, respond }) => {
  await ack();

  const topic = (command.text || '').trim();
  const label = topic || 'top headlines';

  try {
    const { articles, hasSentiment } = await fetchNews(topic);

    if (!articles.length) {
      await respond(`No recent news found for *${label}*. Try a different or broader term.`);
      return;
    }

    const summary = await summarize(label, articles);
    const blocks = buildBlocks({ topic: label, summary, articles, hasSentiment });

    await respond({
      response_type: 'in_channel',
      blocks,
      text: `News summary for ${label}`,
    });
  } catch (err) {
    console.error('news command failed:', err.message);
    const message = err.userMessage || 'Something went wrong fetching the news. Please try again.';
    await respond(`:warning: ${message}`);
  }
});

(async () => {
  await app.start();
  console.log('⚡️ news-slack-summarizer is running (Socket Mode)');
})();
