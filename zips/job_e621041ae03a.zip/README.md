# news-slack-summarizer

A Slack slash command that fetches recent news on any topic and posts a short, summarized briefing back into the channel. It pulls live headlines from the newsdata.io news API (https://newsdata.io) and condenses them with OpenAI's GPT-4, then renders the results as Slack Block Kit cards with per-article keywords and sentiment.

Type `/news climate policy` in Slack and you get a 2-3 sentence overview plus the top handful of articles, each with its source, publish date, and tags.

## Features

- `/news <topic>` slash command built on Slack Bolt, using Socket Mode so no public URL is required.
- Live headlines from newsdata.io, summarized by GPT-4.
- Per-article keyword chips (always available on the free plan).
- Sentiment badges and an overall breakdown when your newsdata.io plan returns sentiment; a clearly-labeled sample is shown otherwise so the layout never looks broken.
- Optional AI tags and AI summaries surfaced per article when those fields are present.
- Graceful fallback: with no OpenAI key configured, a basic extractive summary is used so the command still works.

## Requirements

- Node.js 18 or newer (uses the built-in `fetch`).
- A Slack app with a bot token and an app-level token (Socket Mode).
- A newsdata.io API key — grab a free one at https://newsdata.io.
- Optional: an OpenAI API key for GPT-4 summaries.

## Setup

1. Clone the repo and install dependencies:

   ```
   npm install
   ```

2. Create a Slack app at https://api.slack.com/apps:
   - Enable **Socket Mode** and create an app-level token with the `connections:write` scope (`SLACK_APP_TOKEN`, starts with `xapp-`).
   - Under **OAuth & Permissions**, add the `commands` and `chat:write` bot scopes, install the app to your workspace, and copy the **Bot User OAuth Token** (`SLACK_BOT_TOKEN`, starts with `xoxb-`).
   - Under **Slash Commands**, create a `/news` command.

3. Copy the example environment file and fill in your values:

   ```
   cp .env.example .env
   ```

   | Variable | Required | Notes |
   | --- | --- | --- |
   | `SLACK_BOT_TOKEN` | yes | Bot token, `xoxb-...` |
   | `SLACK_APP_TOKEN` | yes | App-level token, `xapp-...` |
   | `NEWSDATA_API_KEY` | yes | newsdata.io API key |
   | `OPENAI_API_KEY` | no | Enables GPT-4 summaries |
   | `OPENAI_MODEL` | no | Defaults to `gpt-4` |
   | `ENABLE_PAID` | no | Set to `1` to send paid newsdata.io query params (see below) |

4. Start the app:

   ```
   npm start
   ```

   You should see `news-slack-summarizer is running`. Invite the bot to a channel and try the command.

## Usage

In any channel the bot can post to:

```
/news renewable energy
```

Example reply (trimmed):

```
📰 News on "renewable energy"

Several outlets report new solar capacity additions and grid-storage
deals this week, alongside debate over subsidy timelines in the EU.

Sentiment (sample): 🟢 45%  ⚪ 40%  🔴 15%  ·  live sentiment requires a paid newsdata.io plan
─────────────────────────────────────
Grid-scale battery project breaks ground
  Reuters · 2026-06-10
  `solar`  `storage`  `grid`
...
```

Run `/news` with no topic to get the latest general headlines.

## Notes on paid newsdata.io fields

The free newsdata.io plan returns headlines, descriptions, and keywords. Fields like `sentiment`, `ai_tag`, and `ai_summary` are only populated on paid plans; this app reads them when present and shows clearly-labeled placeholders otherwise, so the layout stays intact on a free key.

Paid *query* parameters (such as `timeframe` or a larger page `size`) reject the whole request on a free key, so they are only sent when `ENABLE_PAID=1`. Set `NEWS_TIMEFRAME` and/or `NEWS_SIZE` alongside it. If a paid request is rejected, the app retries once without those parameters so you still get results.

## License

MIT
