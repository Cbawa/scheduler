use serde::Deserialize;

/// A page of results from the `/news` or `/crypto` endpoints.
#[derive(Debug, Clone, Deserialize)]
pub struct NewsResponse {
    /// Usually `"success"`.
    #[serde(default)]
    pub status: String,
    /// Total number of results matching the query (may be capped on free tier).
    #[serde(default)]
    pub total_results: Option<u64>,
    /// The articles in this page.
    #[serde(default)]
    pub results: Vec<Article>,
    /// Opaque pagination token; pass it back via [`crate::NewsQuery::page`] to
    /// fetch the next page. `None` when there are no more pages.
    #[serde(default, rename = "nextPage")]
    pub next_page: Option<String>,
}

/// A single news article.
///
/// Fields that are only populated on paid plans (e.g. `sentiment`, `ai_tag`)
/// are modelled as `Option`s and will simply be `None` on the free tier.
#[derive(Debug, Clone, Deserialize)]
pub struct Article {
    #[serde(default)]
    pub article_id: Option<String>,
    #[serde(default)]
    pub title: String,
    #[serde(default)]
    pub link: Option<String>,
    #[serde(default)]
    pub description: Option<String>,
    #[serde(default)]
    pub content: Option<String>,
    #[serde(default, rename = "pubDate")]
    pub pub_date: Option<String>,
    #[serde(default)]
    pub image_url: Option<String>,
    #[serde(default)]
    pub source_id: Option<String>,
    #[serde(default)]
    pub source_url: Option<String>,
    #[serde(default)]
    pub category: Vec<String>,
    #[serde(default)]
    pub country: Vec<String>,
    #[serde(default)]
    pub language: Option<String>,
    #[serde(default)]
    pub creator: Option<Vec<String>>,

    // ---- Paid-only enrichment fields (None on the free tier) ----
    /// Paid plans only. Sentiment label such as `"positive"`/`"negative"`.
    #[serde(default)]
    pub sentiment: Option<String>,
    /// Paid plans only. AI-generated topic tags.
    #[serde(default)]
    pub ai_tag: Option<serde_json::Value>,
    /// Paid plans only. AI-detected region.
    #[serde(default)]
    pub ai_region: Option<serde_json::Value>,
    /// Paid plans only. AI-detected organisations.
    #[serde(default)]
    pub ai_org: Option<serde_json::Value>,
}

/// Response from the `/sources` endpoint.
#[derive(Debug, Clone, Deserialize)]
pub struct SourcesResponse {
    #[serde(default)]
    pub status: String,
    #[serde(default)]
    pub total_results: Option<u64>,
    #[serde(default)]
    pub results: Vec<Source>,
}

/// A news source / publisher.
#[derive(Debug, Clone, Deserialize)]
pub struct Source {
    #[serde(default)]
    pub id: Option<String>,
    #[serde(default)]
    pub name: Option<String>,
    #[serde(default)]
    pub url: Option<String>,
    #[serde(default)]
    pub category: Vec<String>,
    #[serde(default)]
    pub language: Vec<String>,
    #[serde(default)]
    pub country: Vec<String>,
}

/// Shape of an error body returned by the API, e.g.
/// `{ "status": "error", "results": { "message": "...", "code": "..." } }`.
#[derive(Debug, Clone, Deserialize)]
pub(crate) struct ApiErrorBody {
    #[serde(default)]
    pub results: Option<ApiErrorDetail>,
    #[serde(default)]
    pub message: Option<String>,
}

#[derive(Debug, Clone, Deserialize)]
pub(crate) struct ApiErrorDetail {
    #[serde(default)]
    pub message: Option<String>,
    #[serde(default)]
    pub code: Option<String>,
}
