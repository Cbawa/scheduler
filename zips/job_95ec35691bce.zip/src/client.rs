use std::time::Duration;

use reqwest::StatusCode;
use serde::de::DeserializeOwned;

use crate::error::Error;
use crate::models::{ApiErrorBody, NewsResponse, SourcesResponse};
use crate::Result;

const DEFAULT_BASE_URL: &str = "https://newsdata.io/api/1";
const ENV_KEY: &str = "NEWSDATA_API_KEY";

/// A typed query for the `/news` and `/crypto` endpoints.
///
/// Only free-tier-safe parameters are exposed as first-class builder methods.
/// Use [`NewsQuery::param`] to add any additional raw query parameter.
#[derive(Debug, Clone, Default)]
pub struct NewsQuery {
    params: Vec<(String, String)>,
}

impl NewsQuery {
    /// Create an empty query.
    pub fn new() -> Self {
        Self::default()
    }

    fn set(mut self, key: &str, value: impl Into<String>) -> Self {
        self.params.retain(|(k, _)| k != key);
        self.params.push((key.to_string(), value.into()));
        self
    }

    /// Search keyword(s). Maps to the `q` parameter.
    pub fn query(self, q: impl Into<String>) -> Self {
        self.set("q", q)
    }

    /// Restrict to a 2-letter country code, e.g. `"us"`.
    pub fn country(self, country: impl Into<String>) -> Self {
        self.set("country", country)
    }

    /// Restrict to a language code, e.g. `"en"`.
    pub fn language(self, language: impl Into<String>) -> Self {
        self.set("language", language)
    }

    /// Restrict to a category, e.g. `"technology"`.
    pub fn category(self, category: impl Into<String>) -> Self {
        self.set("category", category)
    }

    /// Pagination token returned as `next_page` in a previous response.
    pub fn page(self, page: impl Into<String>) -> Self {
        self.set("page", page)
    }

    /// Add an arbitrary raw query parameter. Useful for parameters not yet
    /// covered by a dedicated builder method.
    pub fn param(self, key: &str, value: impl Into<String>) -> Self {
        self.set(key, value)
    }

    fn pairs(&self) -> &[(String, String)] {
        &self.params
    }
}

/// Async client for the newsdata.io API.
///
/// The client wraps a single [`reqwest::Client`], which maintains an internal
/// connection pool. Construct it once and share it (it is cheap to `clone`,
/// and clones share the same pool) across tasks for best performance.
#[derive(Debug, Clone)]
pub struct NewsDataClient {
    http: reqwest::Client,
    api_key: String,
    base_url: String,
}

impl NewsDataClient {
    /// Build a client with the given API key and sensible defaults
    /// (a pooled HTTP client with a 30s timeout).
    pub fn new(api_key: impl Into<String>) -> Result<Self> {
        let http = reqwest::Client::builder()
            .timeout(Duration::from_secs(30))
            .pool_max_idle_per_host(8)
            .pool_idle_timeout(Duration::from_secs(90))
            .user_agent(concat!("newsdata-client/", env!("CARGO_PKG_VERSION")))
            .build()
            .map_err(|e| Error::ClientBuild(e.to_string()))?;
        Ok(Self::with_http_client(api_key, http))
    }

    /// Build a client, reading the API key from the `NEWSDATA_API_KEY`
    /// environment variable. Returns [`Error::MissingApiKey`] if it is unset.
    pub fn from_env() -> Result<Self> {
        let key = std::env::var(ENV_KEY).map_err(|_| Error::MissingApiKey)?;
        if key.trim().is_empty() {
            return Err(Error::MissingApiKey);
        }
        Self::new(key)
    }

    /// Build a client from an existing [`reqwest::Client`]. This lets you fully
    /// control connection pooling, timeouts, proxies, and TLS — and share one
    /// pool across multiple API clients in your application.
    pub fn with_http_client(api_key: impl Into<String>, http: reqwest::Client) -> Self {
        Self {
            http,
            api_key: api_key.into(),
            base_url: DEFAULT_BASE_URL.to_string(),
        }
    }

    /// Override the API base URL (useful for testing against a mock server).
    pub fn with_base_url(mut self, base_url: impl Into<String>) -> Self {
        self.base_url = base_url.into();
        self
    }

    /// Fetch the latest news (`GET /news`).
    pub async fn latest_news(&self, query: &NewsQuery) -> Result<NewsResponse> {
        self.get_json("/news", query.pairs()).await
    }

    /// Fetch the list of available sources (`GET /sources`).
    ///
    /// Pass an optional 2-letter country code to filter.
    pub async fn sources(&self, country: Option<&str>) -> Result<SourcesResponse> {
        let mut params: Vec<(String, String)> = Vec::new();
        if let Some(c) = country {
            params.push(("country".to_string(), c.to_string()));
        }
        self.get_json("/sources", &params).await
    }

    /// Fetch crypto news (`GET /crypto`). Availability depends on your plan.
    pub async fn crypto_news(&self, query: &NewsQuery) -> Result<NewsResponse> {
        self.get_json("/crypto", query.pairs()).await
    }

    /// Perform a GET request and decode the JSON body, mapping HTTP errors to
    /// rich [`Error`] variants.
    async fn get_json<T: DeserializeOwned>(
        &self,
        path: &str,
        params: &[(String, String)],
    ) -> Result<T> {
        let url = format!("{}{}", self.base_url, path);

        // newsdata.io authenticates via the `apikey` query parameter.
        let mut all: Vec<(&str, &str)> = vec![("apikey", self.api_key.as_str())];
        for (k, v) in params {
            all.push((k.as_str(), v.as_str()));
        }

        let resp = self.http.get(&url).query(&all).send().await?;
        let status = resp.status();
        let body = resp.text().await?;

        if status.is_success() {
            return serde_json::from_str::<T>(&body).map_err(|e| Error::Decode(e.to_string()));
        }

        // Try to extract a human-readable message from the error body.
        let message = parse_error_message(&body)
            .unwrap_or_else(|| body.trim().chars().take(300).collect());

        match status {
            StatusCode::UNAUTHORIZED => Err(Error::Unauthorized),
            StatusCode::TOO_MANY_REQUESTS => Err(Error::RateLimited),
            StatusCode::FORBIDDEN | StatusCode::UNPROCESSABLE_ENTITY => {
                if looks_like_upgrade(&message) {
                    Err(Error::PaidFeature(message))
                } else {
                    Err(Error::Api {
                        status: status.as_u16(),
                        message,
                    })
                }
            }
            _ => Err(Error::Api {
                status: status.as_u16(),
                message,
            }),
        }
    }
}

fn parse_error_message(body: &str) -> Option<String> {
    let parsed: ApiErrorBody = serde_json::from_str(body).ok()?;
    if let Some(detail) = parsed.results {
        if let Some(msg) = detail.message {
            return Some(msg);
        }
        if let Some(code) = detail.code {
            return Some(code);
        }
    }
    parsed.message
}

fn looks_like_upgrade(message: &str) -> bool {
    let m = message.to_ascii_lowercase();
    m.contains("upgrade")
        || m.contains("paid")
        || m.contains("not available")
        || m.contains("subscription")
        || m.contains("plan")
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn query_builder_overwrites_duplicates() {
        let q = NewsQuery::new().query("a").query("b").language("en");
        let pairs = q.pairs();
        assert_eq!(pairs.iter().filter(|(k, _)| k == "q").count(), 1);
        assert!(pairs.iter().any(|(k, v)| k == "q" && v == "b"));
        assert!(pairs.iter().any(|(k, v)| k == "language" && v == "en"));
    }

    #[test]
    fn detects_upgrade_messages() {
        assert!(looks_like_upgrade("Please upgrade your plan"));
        assert!(looks_like_upgrade("This is a PAID feature"));
        assert!(!looks_like_upgrade("invalid country code"));
    }
}
