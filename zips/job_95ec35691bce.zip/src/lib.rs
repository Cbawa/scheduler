//! # newsdata-client
//!
//! An ergonomic, async Rust client for the [newsdata.io](https://newsdata.io) news API.
//!
//! Built on [`tokio`] and [`reqwest`], it exposes strongly-typed responses and a
//! reusable, connection-pooling HTTP client.
//!
//! ## Quick start
//!
//! ```no_run
//! use newsdata_client::{NewsDataClient, NewsQuery};
//!
//! #[tokio::main]
//! async fn main() -> Result<(), Box<dyn std::error::Error>> {
//!     // Reads the NEWSDATA_API_KEY environment variable.
//!     let client = NewsDataClient::from_env()?;
//!
//!     let query = NewsQuery::new()
//!         .query("technology")
//!         .language("en")
//!         .country("us");
//!
//!     let page = client.latest_news(&query).await?;
//!     println!("got {} articles", page.results.len());
//!     for article in &page.results {
//!         println!("- {}", article.title);
//!     }
//!     Ok(())
//! }
//! ```
//!
//! ## Free tier
//!
//! This crate is designed to work out-of-the-box on the **free** newsdata.io plan.
//! Paid-only fields (sentiment, the `ai_*` enrichment fields) are modelled as
//! `Option`s, and paid-only requests that are rejected with an "upgrade your plan"
//! response surface as [`Error::PaidFeature`] instead of crashing.

mod client;
mod error;
mod models;

pub use client::{NewsDataClient, NewsQuery};
pub use error::Error;
pub use models::{Article, NewsResponse, Source, SourcesResponse};

/// Convenient `Result` alias used throughout the crate.
pub type Result<T> = std::result::Result<T, Error>;
