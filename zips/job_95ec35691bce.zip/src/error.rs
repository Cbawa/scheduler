use thiserror::Error;

/// Errors that can occur when talking to the newsdata.io API.
#[derive(Debug, Error)]
pub enum Error {
    /// The `NEWSDATA_API_KEY` environment variable was not set.
    #[error("the NEWSDATA_API_KEY environment variable is not set")]
    MissingApiKey,

    /// Failed to build the underlying HTTP client.
    #[error("failed to build HTTP client: {0}")]
    ClientBuild(String),

    /// A transport-level error (DNS, TLS, timeouts, connection reset, ...).
    #[error("HTTP transport error: {0}")]
    Http(#[from] reqwest::Error),

    /// Failed to decode the JSON response body.
    #[error("failed to decode response body: {0}")]
    Decode(String),

    /// The API key was rejected (HTTP 401).
    #[error("invalid or unauthorized API key (HTTP 401)")]
    Unauthorized,

    /// The free-tier rate limit was hit (HTTP 429). Back off and retry later.
    #[error("rate limit exceeded (HTTP 429) — slow down and retry later")]
    RateLimited,

    /// The request used a feature that requires a paid plan (HTTP 403/422).
    ///
    /// On the free tier this is returned for things like sentiment analysis,
    /// the `ai_*` enrichment fields, the `/archive` endpoint, and advanced
    /// full-text query operators. Callers can match on this and degrade
    /// gracefully.
    #[error("this feature requires a paid newsdata.io plan: {0}")]
    PaidFeature(String),

    /// Any other error reported by the API.
    #[error("newsdata.io API error (HTTP {status}): {message}")]
    Api { status: u16, message: String },
}
