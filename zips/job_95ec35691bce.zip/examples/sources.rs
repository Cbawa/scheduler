//! List available news sources for a country.
//!
//! Run with:
//!   NEWSDATA_API_KEY=your_key cargo run --example sources

use newsdata_client::NewsDataClient;

#[tokio::main]
async fn main() -> Result<(), Box<dyn std::error::Error>> {
    let client = NewsDataClient::from_env()?;

    let resp = client.sources(Some("us")).await?;
    println!("found {} sources", resp.results.len());
    for source in resp.results.iter().take(20) {
        let name = source.name.as_deref().unwrap_or("(unknown)");
        let id = source.id.as_deref().unwrap_or("-");
        println!("- {name} ({id})");
    }

    Ok(())
}
