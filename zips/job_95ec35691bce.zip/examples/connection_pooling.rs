//! Demonstrates sharing a single connection-pooled client across many
//! concurrent Tokio tasks.
//!
//! `reqwest::Client` keeps an internal connection pool, so the cheapest and
//! fastest approach is to build it once and clone/share it. Here we build a
//! tuned HTTP client, wrap it in our typed `NewsDataClient`, and fan out
//! several requests concurrently — they reuse pooled TCP/TLS connections.
//!
//! Run with:
//!   NEWSDATA_API_KEY=your_key cargo run --example connection_pooling

use std::sync::Arc;
use std::time::Duration;

use newsdata_client::{NewsDataClient, NewsQuery};

#[tokio::main]
async fn main() -> Result<(), Box<dyn std::error::Error>> {
    let api_key = std::env::var("NEWSDATA_API_KEY").map_err(|_| {
        "please set the NEWSDATA_API_KEY environment variable".to_string()
    })?;

    // Build a reqwest client with explicit pool tuning and reuse it everywhere.
    let http = reqwest::Client::builder()
        .pool_max_idle_per_host(16)
        .pool_idle_timeout(Duration::from_secs(90))
        .timeout(Duration::from_secs(30))
        .build()?;

    // The NewsDataClient is cheap to clone; clones share the same pool.
    let client = Arc::new(NewsDataClient::with_http_client(api_key, http));

    let topics = ["technology", "business", "sports", "science"];

    let mut handles = Vec::new();
    for topic in topics {
        let client = Arc::clone(&client);
        handles.push(tokio::spawn(async move {
            let query = NewsQuery::new().query(topic).language("en");
            let result = client.latest_news(&query).await;
            (topic, result)
        }));
    }

    for handle in handles {
        match handle.await? {
            (topic, Ok(page)) => {
                println!("[{topic}] {} articles", page.results.len());
            }
            (topic, Err(e)) => {
                eprintln!("[{topic}] error: {e}");
            }
        }
    }

    Ok(())
}
