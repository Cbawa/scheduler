//! Fetch and print the latest news.
//!
//! Run with:
//!   NEWSDATA_API_KEY=your_key cargo run --example latest_news

use newsdata_client::{Error, NewsDataClient, NewsQuery};

#[tokio::main]
async fn main() {
    let client = match NewsDataClient::from_env() {
        Ok(c) => c,
        Err(Error::MissingApiKey) => {
            eprintln!("error: please set the NEWSDATA_API_KEY environment variable");
            std::process::exit(1);
        }
        Err(e) => {
            eprintln!("error: {e}");
            std::process::exit(1);
        }
    };

    let query = NewsQuery::new()
        .query("technology")
        .language("en")
        .country("us");

    match client.latest_news(&query).await {
        Ok(page) => {
            println!(
                "status={} total_results={:?} returned={}",
                page.status,
                page.total_results,
                page.results.len()
            );
            if page.results.is_empty() {
                println!("(no articles matched this query)");
            }
            for (i, article) in page.results.iter().enumerate() {
                println!("\n{}. {}", i + 1, article.title);
                if let Some(src) = &article.source_id {
                    println!("   source: {src}");
                }
                if let Some(link) = &article.link {
                    println!("   link:   {link}");
                }
            }
            if let Some(next) = page.next_page {
                println!("\nnext page token: {next}");
                println!("(pass it via NewsQuery::page to fetch the next page)");
            }
        }
        Err(Error::RateLimited) => {
            eprintln!("hit the rate limit — wait a moment and try again");
        }
        Err(Error::Unauthorized) => {
            eprintln!("the API key was rejected — double-check NEWSDATA_API_KEY");
        }
        Err(e) => eprintln!("request failed: {e}"),
    }
}
