# news-n8n-workflows

Three importable [n8n](https://n8n.io) workflows that pull live headlines from the
newsdata.io news API (https://newsdata.io) and turn them into keyword alerts, a daily
digest email, and a CRM enrichment endpoint. Grab a free newsdata.io API key to run them.

Each workflow is a plain n8n export in `workflows/`. Import one, set two environment
variables, connect your own notification or SMTP credential, and activate it.

## Workflows

- **Keyword alerts** — `workflows/keyword-alerts.json`
  Runs hourly, searches the latest news for a keyword, skips articles it has already
  seen (tracked in workflow static data), and posts new matches to a Slack, Discord, or
  Teams incoming webhook.

- **News digest email** — `workflows/news-digest-email.json`
  Runs each morning, builds an HTML digest of recent headlines with a sentiment
  breakdown, and sends it over SMTP.

- **CRM enrichment** — `workflows/crm-enrichment.json`
  A webhook that takes a company name, looks up recent coverage, and returns top
  keywords, recent headlines, and a sentiment summary as JSON you can write back to a CRM.

## Requirements

- A running n8n instance (self-hosted or cloud), version 1.x.
- A newsdata.io API key. Sign up at https://newsdata.io and copy the key from the
  dashboard; the free plan is enough to run all three workflows.

## Setup

1. Set environment variables on your n8n instance:

   ```
   NEWSDATA_API_KEY=your_key_here
   ALERT_WEBHOOK_URL=https://hooks.slack.com/services/xxx   # keyword alerts only
   ```

   The workflows read these in node expressions as `{{ $env.NEWSDATA_API_KEY }}`. If your
   instance sets `N8N_BLOCK_ENV_ACCESS_IN_NODE=true`, change it to `false` so expressions
   can read the key.

2. In n8n, open **Workflows → Import from File** and choose a file from `workflows/`.

3. Open the imported workflow and adjust the details:
   - **Keyword alerts**: edit the `q` value on the *NewsData: Latest News* node to your
     keyword.
   - **News digest email**: set the From/To addresses and pick your SMTP credential on
     the *Send Email* node.
   - **CRM enrichment**: nothing required; the company name comes from the request body.

4. Save and activate.

## Free tier and paid fields

The workflows only send query parameters that work on the free newsdata.io plan:
`apikey`, `q`, and `language`. The default page size (10 results) and the `/latest`
endpoint are also free.

Richer fields are read straight from each article when present:

| Field | Plan | Used for |
| --- | --- | --- |
| `keywords` | free | keyword chips, top-keyword aggregation |
| `sentiment` | paid | per-article sentiment, digest breakdown |
| `ai_tag` | paid | extra tags on alerts |
| `ai_org` | paid | organizations in CRM enrichment |
| `ai_summary` | paid | one-line summary in the digest |

On the free plan the paid fields come back empty, and each workflow falls back to a
clearly labeled placeholder (for example the digest prints a sample sentiment line
captioned as a sample). Nothing breaks, and no workflow edits are needed once you move
to a paid plan — the fields simply start populating.

These workflows never send paid-only query parameters (`sentiment=`, `tag=`,
`from_date=`, `timeframe=`, `size` above 10, the `/archive` or `/count` endpoints), so a
brand-new free key works out of the box.

## Example: CRM enrichment

Request:

```
curl -X POST https://your-n8n-host/webhook/crm-enrich \
  -H 'Content-Type: application/json' \
  -d '{"company": "Nvidia"}'
```

Response on a free key:

```json
{
  "company": "Nvidia",
  "articleCount": 10,
  "topKeywords": ["nvidia", "ai", "gpu", "earnings", "data center"],
  "organizations": [],
  "recentHeadlines": [
    {
      "title": "Nvidia announces new data-center GPUs",
      "link": "https://example.com/article",
      "pubDate": "2026-06-12 09:00:00"
    }
  ],
  "sentiment": null,
  "sentimentNote": "Sentiment requires a paid newsdata.io plan",
  "generatedFrom": "newsdata.io"
}
```

With a paid plan, `sentiment` becomes a count object and `organizations` is filled from
the `ai_org` field.

## Layout

```
workflows/
  keyword-alerts.json
  news-digest-email.json
  crm-enrichment.json
.env.example
```

## License

MIT
