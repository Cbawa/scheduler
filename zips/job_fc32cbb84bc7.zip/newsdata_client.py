"""Minimal client for the newsdata.io REST API (FREE-tier safe).

Reads the API key from the NEWSDATA_API_KEY environment variable and passes it as
the `apikey` query parameter. Builds around the /news endpoint and paginates with
the `nextPage` token. Handles 401 / 429 / 403 / 422 and empty results gracefully.
"""
import os
import time

import requests

BASE_URL = "https://newsdata.io/api/1"


class NewsDataError(Exception):
    """Raised for any recoverable newsdata.io API or configuration problem."""


class NewsDataClient:
    def __init__(self, api_key=None, timeout=30):
        self.api_key = api_key or os.environ.get("NEWSDATA_API_KEY")
        if not self.api_key:
            raise NewsDataError(
                "NEWSDATA_API_KEY is not set. Get a free key at "
                "https://newsdata.io/register and export it:\n"
                "  export NEWSDATA_API_KEY='your_key_here'"
            )
        self.timeout = timeout
        self.session = requests.Session()

    def _get(self, endpoint, params):
        params = dict(params)
        params["apikey"] = self.api_key
        url = f"{BASE_URL}/{endpoint}"

        for attempt in range(4):
            try:
                resp = self.session.get(url, params=params, timeout=self.timeout)
            except requests.RequestException as e:
                raise NewsDataError(f"Network error contacting NewsData.io: {e}")

            if resp.status_code == 200:
                return resp.json()
            if resp.status_code == 401:
                raise NewsDataError(
                    "Invalid API key (401). Check the NEWSDATA_API_KEY value."
                )
            if resp.status_code == 429:
                # Rate limited — exponential backoff, then retry.
                time.sleep(2 ** attempt)
                continue
            if resp.status_code in (403, 422):
                # Often a paid-only feature/param on a free key, or a bad param.
                raise NewsDataError(
                    f"Request rejected ({resp.status_code}): {self._message(resp)}"
                )
            raise NewsDataError(
                f"Unexpected status {resp.status_code}: {resp.text[:200]}"
            )

        raise NewsDataError("Rate limited (429) — retries exhausted. Try again later.")

    @staticmethod
    def _message(resp):
        try:
            body = resp.json()
            results = body.get("results")
            if isinstance(results, dict):
                return results.get("message", resp.text[:200])
            return body.get("message", resp.text[:200])
        except ValueError:
            return resp.text[:200]

    def fetch_news(self, query, language="en", country=None, category=None,
                   max_pages=5):
        """Fetch latest-news articles for `query`, following `nextPage` pagination.

        Returns a list of raw article dicts (possibly empty).
        """
        results = []
        next_page = None

        for _ in range(max(1, max_pages)):
            params = {"q": query, "language": language}
            if country:
                params["country"] = country
            if category:
                params["category"] = category
            if next_page:
                params["page"] = next_page

            data = self._get("news", params)
            batch = data.get("results") or []
            results.extend(batch)

            next_page = data.get("nextPage")
            if not next_page or not batch:
                break
            time.sleep(0.8)  # be gentle with free-tier rate limits

        return results
