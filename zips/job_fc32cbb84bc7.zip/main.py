#!/usr/bin/env python3
"""News-Stock Correlation CLI.

Correlate newsdata.io news sentiment with stock price movements (yfinance).
Free-tier safe: sentiment is computed locally, so a brand-new FREE key works.
"""
import argparse
import sys
from datetime import date, timedelta

from newsdata_client import NewsDataClient, NewsDataError
from sentiment import score_articles, daily_sentiment
from correlation import fetch_prices, build_dataset, run_correlation, plot_scatter


def parse_args(argv=None):
    p = argparse.ArgumentParser(
        description="Correlate NewsData.io news sentiment with stock price movements."
    )
    p.add_argument("--ticker", required=True, help="Stock ticker, e.g. AAPL")
    p.add_argument("--query", help="News search query (defaults to the ticker)")
    p.add_argument("--days", type=int, default=14,
                   help="Lookback window in days (default: 14)")
    p.add_argument("--language", default="en", help="News language code (default: en)")
    p.add_argument("--country", default=None, help="Optional country filter, e.g. us")
    p.add_argument("--max-pages", type=int, default=5,
                   help="Max news pages to paginate (default: 5)")
    p.add_argument("--prefer-api-sentiment", action="store_true",
                   help="Use NewsData.io's sentiment field if present (PAID plans only)")
    p.add_argument("--output", default="correlation.png",
                   help="Scatter plot output path (default: correlation.png)")
    return p.parse_args(argv)


def main(argv=None):
    args = parse_args(argv)
    query = args.query or args.ticker

    try:
        client = NewsDataClient()
    except NewsDataError as e:
        print(f"Error: {e}", file=sys.stderr)
        return 1

    print(f"Fetching news for '{query}' ...")
    try:
        articles = client.fetch_news(
            query=query,
            language=args.language,
            country=args.country,
            max_pages=args.max_pages,
        )
    except NewsDataError as e:
        print(f"Error fetching news: {e}", file=sys.stderr)
        return 1

    if not articles:
        print("No news articles returned for this query. Try a broader --query.")
        return 0
    print(f"  -> {len(articles)} articles fetched.")

    scored = score_articles(articles, prefer_api=args.prefer_api_sentiment)
    sent = daily_sentiment(scored)
    if not sent:
        print("Could not extract dated sentiment from the articles.")
        return 0

    end = date.today() + timedelta(days=1)
    start = end - timedelta(days=args.days + 1)
    print(f"Fetching prices for {args.ticker} ({start} to {end}) ...")
    try:
        prices = fetch_prices(args.ticker, start, end)
    except Exception as e:  # yfinance raises a variety of errors
        print(f"Error fetching prices: {e}", file=sys.stderr)
        return 1

    try:
        merged = build_dataset(sent, prices)
    except ValueError as e:
        print(f"Error: {e}", file=sys.stderr)
        return 1

    if merged.empty:
        print("No overlapping dates between news sentiment and trading days.")
        print("Free NewsData.io keys return only recent news — try a smaller --days window.")
        return 0

    stats = run_correlation(merged)
    print("\n=== Correlation results ===")
    print(merged.to_string())
    print(f"\nOverlapping days : {stats['n']}")
    if stats["r"] is None:
        print("Not enough overlapping days (need >= 3) for a reliable R².")
        return 0

    print(f"Pearson r        : {stats['r']:.4f}")
    print(f"R^2              : {stats['r2']:.4f}")
    print(f"Regression slope : {stats['slope']:.4f}")
    out = plot_scatter(merged, stats, args.ticker, args.output)
    print(f"Scatter plot saved -> {out}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
