# News–Stock Correlation

Does the news mood around a company line up with how its stock moves? This tool
pulls recent headlines for a query from the [newsdata.io](https://newsdata.io) news
API, scores their sentiment, aligns the daily sentiment with daily stock returns
from [`yfinance`](https://github.com/ranaroussi/yfinance), and reports the
correlation (Pearson **r** and **R²**) plus a scatter plot with a regression line.

```
Daily news sentiment  ──┐
                         ├──►  inner-join on date  ──►  Pearson r / R²  ──►  scatter.png
Daily stock returns   ──┘
```

## Free-tier friendly by design

This project runs on a **brand-new newsdata.io FREE API key**. NewsData.io's own
`sentiment` field is a **paid-only** feature, so sentiment here is computed
**locally** with a small built-in positive/negative finance lexicon over each
article's title + description. Nothing in the core flow depends on a paid plan.

If you *do* have a paid key that returns the `sentiment` field, you can opt into it
with `--prefer-api-sentiment`; the code falls back to the local lexicon whenever the
field is absent, so it never breaks free users.

| Feature | Plan |
| --- | --- |
| `/news` latest headlines + pagination (`nextPage`) | **Free** ✅ |
| Local lexicon sentiment | **Free** ✅ (built into this repo) |
| `sentiment` field (`--prefer-api-sentiment`) | Paid 💳 (optional, degrades gracefully) |
| Long historical ranges / `/archive` | Paid 💳 (not used) |

> **Note on history:** free keys return only *recent* news, so meaningful
> correlation works best over a short window (the default `--days 14`). yfinance
> price history is not limited.

## Setup

```bash
git clone https://github.com/yourname/news-stock-correlation.git
cd news-stock-correlation
python3 -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt
```

Get a free key at <https://newsdata.io/register> and export it (the app reads the
`NEWSDATA_API_KEY` environment variable and exits with a clear message if unset):

```bash
export NEWSDATA_API_KEY='your_free_key_here'
```

## Usage

```bash
# Apple: search news for "Apple", correlate against AAPL over the last 14 days
python main.py --ticker AAPL --query "Apple"

# Tesla, wider window, save plot to a custom path
python main.py --ticker TSLA --query "Tesla" --days 21 --output tsla.png

# Opt into the API's paid sentiment field (falls back to local scoring if absent)
python main.py --ticker NVDA --query "Nvidia" --prefer-api-sentiment
```

### Options

| Flag | Default | Description |
| --- | --- | --- |
| `--ticker` | *(required)* | Stock symbol, e.g. `AAPL` |
| `--query` | the ticker | News search query (`q` param) |
| `--days` | `14` | Lookback window in days |
| `--language` | `en` | News language code |
| `--country` | *(none)* | Optional country filter, e.g. `us` |
| `--max-pages` | `5` | Max news pages to paginate |
| `--prefer-api-sentiment` | off | Use the paid `sentiment` field when present |
| `--output` | `correlation.png` | Scatter plot output path |

### Sample output

```
Fetching news for 'Apple' ...
  -> 48 articles fetched.
Fetching prices for AAPL (2026-05-27 to 2026-06-11) ...

=== Correlation results ===
            sentiment  return_pct
date
2026-05-28      0.250        1.12
2026-05-29     -0.100       -0.84
...

Overlapping days : 9
Pearson r        : 0.4137
R^2              : 0.1712
Regression slope : 2.8044
Scatter plot saved -> correlation.png
```

## How it works

1. **`newsdata_client.py`** — thin client for `GET /news`. Sends the key as the
   `apikey` query param, paginates with the `nextPage` token, and handles `401`
   (bad key), `429` (rate limit, with backoff), and `403/422` (paid feature / bad
   param) without crashing.
2. **`sentiment.py`** — parses each article's `pubDate`, scores title+description
   with a finance lexicon to a value in `[-1, +1]`, and averages per calendar day.
3. **`correlation.py`** — downloads adjusted closes with yfinance, computes daily
   percent returns, inner-joins on date, then runs a least-squares fit (`numpy`).
4. **`main.py`** — CLI glue and reporting.

## Caveats

This is an educational/illustrative tool, **not** financial advice. Lexicon
sentiment is coarse, free-tier news coverage is shallow, and correlation over a few
days is not causation. Treat the numbers as a starting point for exploration.

## License

MIT
