"""Merge daily news sentiment with daily stock returns, regress, and plot."""
import matplotlib

matplotlib.use("Agg")  # headless-safe backend

import matplotlib.pyplot as plt  # noqa: E402
import numpy as np  # noqa: E402
import pandas as pd  # noqa: E402
import yfinance as yf  # noqa: E402


def fetch_prices(ticker, start, end):
    """Download adjusted closes and return a date-indexed daily % return frame."""
    df = yf.download(ticker, start=start, end=end, progress=False, auto_adjust=True)
    if df is None or df.empty:
        raise ValueError(f"No price data returned for ticker '{ticker}'.")

    close = df["Close"]
    if isinstance(close, pd.DataFrame):  # multi-column when given a list of tickers
        close = close.iloc[:, 0]

    returns = close.pct_change() * 100.0
    out = pd.DataFrame({"return_pct": returns})
    out.index = pd.to_datetime(out.index).date
    out.index.name = "date"
    return out.dropna()


def build_dataset(daily_sent, prices):
    """Inner-join sentiment-by-date with returns-by-date."""
    sent_df = pd.DataFrame(
        [{"date": d, "sentiment": s} for d, s in daily_sent.items()]
    )
    if sent_df.empty:
        raise ValueError("No dated sentiment data to correlate.")
    sent_df = sent_df.set_index("date")
    merged = sent_df.join(prices, how="inner").dropna()
    return merged.sort_index()


def run_correlation(merged):
    """Compute Pearson r, R² and a least-squares line. Needs >= 3 points."""
    if len(merged) < 3:
        return {"n": len(merged), "r": None, "r2": None,
                "slope": None, "intercept": None}
    x = merged["sentiment"].to_numpy(dtype=float)
    y = merged["return_pct"].to_numpy(dtype=float)
    if np.std(x) == 0 or np.std(y) == 0:
        return {"n": int(len(merged)), "r": None, "r2": None,
                "slope": None, "intercept": None}
    r = float(np.corrcoef(x, y)[0, 1])
    slope, intercept = np.polyfit(x, y, 1)
    return {
        "n": int(len(merged)),
        "r": r,
        "r2": r * r,
        "slope": float(slope),
        "intercept": float(intercept),
    }


def plot_scatter(merged, stats, ticker, output):
    """Render a sentiment-vs-return scatter with the fitted regression line."""
    x = merged["sentiment"].to_numpy(dtype=float)
    y = merged["return_pct"].to_numpy(dtype=float)

    fig, ax = plt.subplots(figsize=(8, 6))
    ax.scatter(x, y, c="#2b6cb0", alpha=0.85, edgecolors="white", s=70)

    if stats.get("slope") is not None and len(x) > 1:
        xs = np.linspace(x.min(), x.max(), 100)
        ax.plot(xs, stats["slope"] * xs + stats["intercept"], "r--",
                label=f"fit (R²={stats['r2']:.3f})")
        ax.legend()

    ax.axhline(0, color="gray", lw=0.8)
    ax.axvline(0, color="gray", lw=0.8)
    ax.set_xlabel("Daily news sentiment (-1 = negative, +1 = positive)")
    ax.set_ylabel("Daily stock return (%)")
    ax.set_title(f"{ticker}: News Sentiment vs. Price Movement")
    fig.tight_layout()
    fig.savefig(output, dpi=120)
    plt.close(fig)
    return output
