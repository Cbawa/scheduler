"""Local, lexicon-based sentiment scoring — FREE-tier safe.

NewsData.io's own `sentiment` field requires a PAID plan, so polarity is derived
locally from each article's title + description and mapped to [-1, +1]. If a paid
key returns a `sentiment` label, `score_articles(prefer_api=True)` will use it and
silently fall back to the local lexicon whenever the field is missing.
"""
import re
from collections import defaultdict
from datetime import datetime

POSITIVE = {
    "gain", "gains", "surge", "surges", "soar", "soars", "soaring", "rise", "rises",
    "rally", "boom", "beat", "beats", "record", "growth", "profit", "profits",
    "upgrade", "bullish", "strong", "strength", "win", "wins", "success", "boost",
    "jump", "jumps", "outperform", "optimism", "positive", "rebound", "recovery",
    "expand", "expands", "high", "higher", "breakthrough", "momentum",
}
NEGATIVE = {
    "loss", "losses", "fall", "falls", "drop", "drops", "plunge", "plunges", "slump",
    "crash", "miss", "misses", "decline", "declines", "weak", "weakness", "downgrade",
    "bearish", "fear", "fears", "risk", "risks", "cut", "cuts", "lawsuit", "fraud",
    "warning", "slowdown", "recession", "negative", "tumble", "selloff", "low",
    "lower", "concern", "concerns", "layoff", "layoffs", "probe", "downturn",
}

_TOKEN_RE = re.compile(r"[a-z']+")
_API_MAP = {"positive": 1.0, "neutral": 0.0, "negative": -1.0}


def _text_score(text):
    if not text:
        return 0.0
    tokens = _TOKEN_RE.findall(text.lower())
    if not tokens:
        return 0.0
    pos = sum(1 for t in tokens if t in POSITIVE)
    neg = sum(1 for t in tokens if t in NEGATIVE)
    if pos + neg == 0:
        return 0.0
    return (pos - neg) / (pos + neg)


def _parse_date(article):
    raw = (article.get("pubDate") or "")[:19]
    for fmt in ("%Y-%m-%d %H:%M:%S", "%Y-%m-%d"):
        try:
            return datetime.strptime(raw[:len("YYYY-MM-DD HH:MM:SS") if fmt.endswith('S') else 10], fmt).date()
        except ValueError:
            continue
    return None


def _api_sentiment(article):
    """Return numeric sentiment from the PAID `sentiment` field, or None."""
    label = article.get("sentiment")
    if isinstance(label, str) and label.lower() in _API_MAP:
        return _API_MAP[label.lower()]
    return None


def score_articles(articles, prefer_api=False):
    """Score each dated article. Returns list of {date, score, title}."""
    scored = []
    for a in articles:
        d = _parse_date(a)
        if d is None:
            continue
        score = _api_sentiment(a) if prefer_api else None
        if score is None:
            text = f"{a.get('title', '')} {a.get('description', '')}"
            score = _text_score(text)
        scored.append({"date": d, "score": score, "title": a.get("title")})
    return scored


def daily_sentiment(scored):
    """Average article scores per calendar day. Returns {date: mean_score}."""
    buckets = defaultdict(list)
    for item in scored:
        buckets[item["date"]].append(item["score"])
    return {d: sum(v) / len(v) for d, v in buckets.items()}
