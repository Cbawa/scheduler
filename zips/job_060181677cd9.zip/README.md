# 📰 Breaking News Alert

A lightweight Python bot that polls the [newsdata.io](https://newsdata.io) news API
every few minutes and pushes **breaking news alerts** to your choice of channel:
**Telegram**, **Discord**, or **email**.

It remembers which articles it has already seen (in a small local state file), so
you only ever get notified about genuinely new headlines — no duplicate spam.

```
┌────────────┐     poll /news every 5 min     ┌─────────────┐
│ newsdata.io│  ───────────────────────────▶  │  this bot   │
└────────────┘                                 └──────┬──────┘
                                                      │ new articles only
                          ┌───────────────────────────┼───────────────────────────┐
                          ▼                            ▼                           ▼
                     Telegram                       Discord                      Email
```

## Features

- 🔔 Polls the newsdata.io `/news` endpoint on a configurable interval (default 5 min).
- 🧠 De-duplicates articles using their `article_id`/`link` so you never get the same alert twice.
- 📨 Pluggable notifiers: **Telegram**, **Discord**, **email (SMTP)** — enable any combination.
- 🔎 Filter the feed by keyword (`q`), country, language and category.
- 🆓 **Works on the newsdata.io FREE plan** — uses only free-tier endpoints, parameters and fields.
- 🛡️ Graceful handling of invalid keys (401), rate limits (429), plan-upgrade errors (403/422) and empty results.
- 🏃 Run it once (great for cron) or as a long-running loop.

## 1. Get a free API key

Create a free account at <https://newsdata.io/register> and copy your API key from the dashboard.

## 2. Install

```bash
git clone https://github.com/your-name/breaking-news-alert.git
cd breaking-news-alert
pip install -r requirements.txt
```

## 3. Configure

The API key is **never hardcoded** — it is read from the `NEWSDATA_API_KEY`
environment variable. Copy the example env file and fill it in:

```bash
cp .env.example .env
# then edit .env
```

### Required

| Variable | Description |
| --- | --- |
| `NEWSDATA_API_KEY` | Your newsdata.io API key. |

### Feed filters (all optional)

| Variable | Default | Description |
| --- | --- | --- |
| `NEWS_QUERY` | _(empty)_ | Keyword(s) to search for, e.g. `bitcoin`. |
| `NEWS_COUNTRY` | _(empty)_ | Comma-separated country codes, e.g. `us,gb`. |
| `NEWS_LANGUAGE` | `en` | Comma-separated language codes. |
| `NEWS_CATEGORY` | _(empty)_ | e.g. `top,business,technology`. |
| `POLL_INTERVAL` | `300` | Seconds between polls when running as a loop. |
| `MAX_ALERTS_PER_POLL` | `5` | Cap on alerts sent per poll (avoids floods on first run). |

### Notifiers (enable any combination)

**Telegram**

| Variable | Description |
| --- | --- |
| `TELEGRAM_BOT_TOKEN` | Token from [@BotFather](https://t.me/BotFather). |
| `TELEGRAM_CHAT_ID` | Your chat / channel id. |

**Discord**

| Variable | Description |
| --- | --- |
| `DISCORD_WEBHOOK_URL` | A channel webhook URL. |

**Email (SMTP)**

| Variable | Description |
| --- | --- |
| `SMTP_HOST` | e.g. `smtp.gmail.com` |
| `SMTP_PORT` | e.g. `587` |
| `SMTP_USERNAME` | SMTP login. |
| `SMTP_PASSWORD` | SMTP password / app password. |
| `EMAIL_FROM` | Sender address. |
| `EMAIL_TO` | Comma-separated recipient(s). |

If you don't configure any notifier, alerts are printed to the console so you can
test the setup before wiring up a channel.

## 4. Run

Run a single poll (ideal for cron):

```bash
python main.py --once
```

Run continuously, polling every `POLL_INTERVAL` seconds:

```bash
python main.py
```

Useful flags:

```bash
python main.py --query "earthquake" --country us --once
python main.py --interval 600         # poll every 10 minutes
python main.py --dry-run --once       # fetch but don't send (prints to console)
```

### Example cron entry (every 5 minutes)

```cron
*/5 * * * * cd /path/to/breaking-news-alert && NEWSDATA_API_KEY=xxx python main.py --once >> alerts.log 2>&1
```

## Free vs. paid plan

This project is built to run entirely on the **free tier**. The following
newsdata.io capabilities are **paid-only** and are intentionally **not** required
by the core flow:

- Sentiment analysis and the `ai_tag` / `ai_region` / `ai_org` / `ai_summary` fields.
- The historical `/archive` endpoint and long date ranges.
- Advanced full-text query operators.

If the API ever returns a `403`/`422` "upgrade your plan" response (for example if
you enable a premium parameter), the bot logs a clear message and keeps running
with the free-tier feed instead of crashing.

## License

MIT
