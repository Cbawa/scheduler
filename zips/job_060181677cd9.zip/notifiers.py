"""Notification channels for breaking-news-alert.

Each notifier is enabled purely by the presence of its environment variables,
so a user can mix and match Telegram, Discord and email.
"""
from __future__ import annotations

import os
import smtplib
from dataclasses import dataclass
from email.message import EmailMessage

import requests


@dataclass
class Article:
    title: str
    link: str
    description: str
    source: str
    pub_date: str

    def as_text(self) -> str:
        parts = [f"\U0001F6A8 {self.title}"]
        if self.source:
            parts.append(f"Source: {self.source}")
        if self.pub_date:
            parts.append(f"Published: {self.pub_date}")
        if self.description:
            desc = self.description.strip()
            if len(desc) > 280:
                desc = desc[:277] + "..."
            parts.append(desc)
        if self.link:
            parts.append(self.link)
        return "\n".join(parts)


class TelegramNotifier:
    name = "telegram"

    def __init__(self, token: str, chat_id: str):
        self.token = token
        self.chat_id = chat_id

    def send(self, article: Article) -> None:
        url = f"https://api.telegram.org/bot{self.token}/sendMessage"
        payload = {
            "chat_id": self.chat_id,
            "text": article.as_text(),
            "disable_web_page_preview": False,
        }
        resp = requests.post(url, json=payload, timeout=20)
        resp.raise_for_status()


class DiscordNotifier:
    name = "discord"

    def __init__(self, webhook_url: str):
        self.webhook_url = webhook_url

    def send(self, article: Article) -> None:
        embed = {
            "title": article.title[:256],
            "url": article.link or None,
            "description": (article.description or "")[:2000],
            "footer": {"text": f"{article.source} \u2022 {article.pub_date}".strip(" \u2022")},
        }
        payload = {"content": "\U0001F6A8 Breaking news", "embeds": [embed]}
        resp = requests.post(self.webhook_url, json=payload, timeout=20)
        resp.raise_for_status()


class EmailNotifier:
    name = "email"

    def __init__(self, host: str, port: int, username: str, password: str, sender: str, recipients: list[str]):
        self.host = host
        self.port = port
        self.username = username
        self.password = password
        self.sender = sender
        self.recipients = recipients

    def send(self, article: Article) -> None:
        msg = EmailMessage()
        msg["Subject"] = f"\U0001F6A8 {article.title}"[:200]
        msg["From"] = self.sender
        msg["To"] = ", ".join(self.recipients)
        msg.set_content(article.as_text())
        with smtplib.SMTP(self.host, self.port, timeout=30) as server:
            server.starttls()
            if self.username:
                server.login(self.username, self.password)
            server.send_message(msg)


def build_notifiers() -> list:
    """Construct every notifier whose env vars are present."""
    notifiers: list = []

    tg_token = os.getenv("TELEGRAM_BOT_TOKEN", "").strip()
    tg_chat = os.getenv("TELEGRAM_CHAT_ID", "").strip()
    if tg_token and tg_chat:
        notifiers.append(TelegramNotifier(tg_token, tg_chat))

    discord_url = os.getenv("DISCORD_WEBHOOK_URL", "").strip()
    if discord_url:
        notifiers.append(DiscordNotifier(discord_url))

    smtp_host = os.getenv("SMTP_HOST", "").strip()
    email_to = os.getenv("EMAIL_TO", "").strip()
    if smtp_host and email_to:
        recipients = [r.strip() for r in email_to.split(",") if r.strip()]
        notifiers.append(
            EmailNotifier(
                host=smtp_host,
                port=int(os.getenv("SMTP_PORT", "587")),
                username=os.getenv("SMTP_USERNAME", "").strip(),
                password=os.getenv("SMTP_PASSWORD", ""),
                sender=os.getenv("EMAIL_FROM", os.getenv("SMTP_USERNAME", "")).strip(),
                recipients=recipients,
            )
        )

    return notifiers
