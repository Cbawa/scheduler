#!/usr/bin/env python3
"""Breaking News Alert — poll newsdata.io and push new headlines to Telegram/Discord/email.

Designed to work on the newsdata.io FREE plan: it only uses the free `/news`
endpoint with free-tier parameters and never depends on paid-only fields.
"""
from __future__ import annotations

import argparse
import os
import sys
import time
import json
import signal
from pathlib import Path

import requests

from notifiers import build_notifiers, Article

API_URL = "https://newsdata.io/api/1/news"
STATE_FILE = Path(os.getenv("STATE_FILE", "seen_articles.json"))
MAX_SEEN = 2000  # cap the state file so it can't grow forever


def load_env_file(path: str = ".env") -> None:
    """Minimal .env loader (no external dependency). Real env vars take precedence."""
    p = Path(path)
    if not p.exists():
        return
    for raw in p.read_text(encoding="utf-8").splitlines():
        line = raw.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        key, _, value = line.partition("=")
        key = key.strip()
        value = value.strip().strip('"').strip("'")
        if key and key not in os.environ:
            os.environ[key] = value


def require_api_key() -> str:
    key = os.getenv("NEWSDATA_API_KEY", "").strip()
    if not key:
        sys.stderr.write(
            "ERROR: NEWSDATA_API_KEY is not set.\n"
            "Get a free key at https://newsdata.io/register and export it:\n"
            "    export NEWSDATA_API_KEY=your_key_here\n"
        )
        sys.exit(1)
    return key


def load_seen() -> set[str]:
    if not STATE_FILE.exists():
        return set()
    try:
        return set(json.loads(STATE_FILE.read_text(encoding="utf-8")))
    except (json.JSONDecodeError, OSError):
        return set()


def save_seen(seen: set[str]) -> None:
    # Keep only the most recent ids to bound the file size.
    trimmed = list(seen)[-MAX_SEEN:]
    tmp = STATE_FILE.with_suffix(".tmp")
    try:
        tmp.write_text(json.dumps(trimmed), encoding="utf-8")
        tmp.replace(STATE_FILE)
    except OSError as exc:
        sys.stderr.write(f"WARNING: could not write state file: {exc}\n")


def build_params(args: argparse.Namespace, api_key: str) -> dict:
    params = {"apikey": api_key}
    query = args.query or os.getenv("NEWS_QUERY", "")
    country = args.country or os.getenv("NEWS_COUNTRY", "")
    language = args.language or os.getenv("NEWS_LANGUAGE", "en")
    category = args.category or os.getenv("NEWS_CATEGORY", "")
    if query:
        params["q"] = query
    if country:
        params["country"] = country
    if language:
        params["language"] = language
    if category:
        params["category"] = category
    return params


def fetch_latest(params: dict) -> list[dict]:
    """Call the free /news endpoint and return the list of result dicts.

    Handles auth, rate-limit, plan-upgrade and empty-result cases gracefully.
    """
    try:
        resp = requests.get(API_URL, params=params, timeout=30)
    except requests.RequestException as exc:
        sys.stderr.write(f"WARNING: network error contacting newsdata.io: {exc}\n")
        return []

    if resp.status_code == 401:
        sys.stderr.write("ERROR: 401 Unauthorized — your NEWSDATA_API_KEY is invalid.\n")
        sys.exit(1)
    if resp.status_code == 429:
        sys.stderr.write("WARNING: 429 rate limited by newsdata.io. Backing off this poll.\n")
        return []
    if resp.status_code in (403, 422):
        # Typically a paid-only feature was requested. Degrade gracefully.
        sys.stderr.write(
            "WARNING: newsdata.io rejected a parameter as paid-only "
            f"({resp.status_code}). Skipping this feature; free feed continues.\n"
        )
        return []
    if resp.status_code != 200:
        sys.stderr.write(f"WARNING: unexpected status {resp.status_code} from newsdata.io.\n")
        return []

    try:
        data = resp.json()
    except ValueError:
        sys.stderr.write("WARNING: could not decode JSON response.\n")
        return []

    if data.get("status") != "success":
        message = data.get("results", {}) or data.get("message", "unknown error")
        sys.stderr.write(f"WARNING: API returned non-success status: {message}\n")
        return []

    results = data.get("results") or []
    if not isinstance(results, list):
        return []
    return results


def article_id(item: dict) -> str:
    return str(item.get("article_id") or item.get("link") or item.get("title") or "")


def to_article(item: dict) -> Article:
    return Article(
        title=item.get("title") or "(untitled)",
        link=item.get("link") or "",
        description=item.get("description") or "",
        source=item.get("source_id") or "newsdata.io",
        pub_date=item.get("pubDate") or "",
    )


def poll_once(args: argparse.Namespace, api_key: str, notifiers: list, seen: set[str]) -> int:
    params = build_params(args, api_key)
    results = fetch_latest(params)
    if not results:
        print("No articles returned this poll.")
        return 0

    # newsdata returns newest first; reverse so alerts arrive oldest-first.
    new_items = [it for it in reversed(results) if article_id(it) and article_id(it) not in seen]

    if not new_items:
        print(f"Polled {len(results)} articles, nothing new.")
        return 0

    limit = max(1, args.max_alerts)
    to_send = new_items[-limit:] if len(new_items) > limit else new_items
    if len(new_items) > limit:
        print(f"{len(new_items)} new articles; capping to the latest {limit}.")

    sent = 0
    for item in to_send:
        article = to_article(item)
        if args.dry_run:
            print(f"[dry-run] {article.title} — {article.link}")
        else:
            for notifier in notifiers:
                try:
                    notifier.send(article)
                except Exception as exc:  # noqa: BLE001 - never let one channel crash the loop
                    sys.stderr.write(f"WARNING: {notifier.name} failed: {exc}\n")
        sent += 1

    # Mark every fetched-and-new item as seen (even if capped) to avoid re-flooding.
    for item in new_items:
        seen.add(article_id(item))
    save_seen(seen)
    print(f"Sent {sent} alert(s).")
    return sent


def parse_args(argv: list[str]) -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Push breaking news alerts from newsdata.io.")
    parser.add_argument("--once", action="store_true", help="Poll a single time and exit.")
    parser.add_argument("--dry-run", action="store_true", help="Fetch but print instead of sending.")
    parser.add_argument("--query", help="Keyword filter (overrides NEWS_QUERY).")
    parser.add_argument("--country", help="Country codes, e.g. us,gb (overrides NEWS_COUNTRY).")
    parser.add_argument("--language", help="Language codes (overrides NEWS_LANGUAGE).")
    parser.add_argument("--category", help="Categories, e.g. top,business (overrides NEWS_CATEGORY).")
    parser.add_argument(
        "--interval",
        type=int,
        default=int(os.getenv("POLL_INTERVAL", "300")),
        help="Seconds between polls in loop mode (default 300).",
    )
    parser.add_argument(
        "--max-alerts",
        type=int,
        default=int(os.getenv("MAX_ALERTS_PER_POLL", "5")),
        help="Maximum alerts to send per poll (default 5).",
    )
    return parser.parse_args(argv)


def main(argv: list[str]) -> int:
    load_env_file()
    args = parse_args(argv)
    api_key = require_api_key()
    notifiers = build_notifiers()

    if not notifiers and not args.dry_run:
        print("No notifiers configured — alerts will be printed to the console.")
        print("Configure Telegram, Discord or email in .env to receive real alerts.\n")

    seen = load_seen()

    if args.once:
        poll_once(args, api_key, notifiers, seen)
        return 0

    interval = max(60, args.interval)  # never hammer the free tier faster than 60s
    print(f"Starting breaking-news loop (every {interval}s). Press Ctrl+C to stop.")

    running = {"go": True}

    def _stop(_signum, _frame):
        running["go"] = False
        print("\nShutting down...")

    signal.signal(signal.SIGINT, _stop)
    signal.signal(signal.SIGTERM, _stop)

    while running["go"]:
        try:
            poll_once(args, api_key, notifiers, seen)
        except Exception as exc:  # noqa: BLE001 - keep the loop alive on transient errors
            sys.stderr.write(f"WARNING: poll failed: {exc}\n")
        # Sleep in small slices so Ctrl+C is responsive.
        for _ in range(interval):
            if not running["go"]:
                break
            time.sleep(1)
    return 0


if __name__ == "__main__":
    raise SystemExit(main(sys.argv[1:]))
