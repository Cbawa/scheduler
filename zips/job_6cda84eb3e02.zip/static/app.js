// News Map Explorer - draws a world map with D3 and loads headlines from the
// Flask backend (which proxies newsdata.io) whenever a country is clicked.

const WORLD_URL = "https://cdn.jsdelivr.net/npm/world-atlas@2/countries-110m.json";

const svg = d3.select("#map");
const WIDTH = 960, HEIGHT = 500;
const projection = d3.geoNaturalEarth1().scale(175).translate([WIDTH / 2, HEIGHT / 2 + 8]);
const path = d3.geoPath(projection);

const articlesEl = document.getElementById("articles");
const titleEl = document.getElementById("panel-title");
const sentimentEl = document.getElementById("sentiment");
const moreBtn = document.getElementById("more");

let current = { country: "", name: "", q: "", nextPage: null };

// ---- Map ----
d3.json(WORLD_URL).then(world => {
  const countries = topojson.feature(world, world.objects.countries).features;
  const g = svg.append("g");
  g.selectAll("path")
    .data(countries)
    .join("path")
      .attr("class", "country")
      .attr("d", path)
      .on("click", (event, d) => selectCountry(d))
    .append("title")
      .text(d => d.properties.name);
}).catch(() => {
  articlesEl.innerHTML = "<p class='empty'>Could not load the map data.</p>";
});

function selectCountry(feature) {
  const alpha2 = ISO_NUMERIC_TO_ALPHA2[+feature.id];
  current = { country: alpha2 || "", name: feature.properties.name, q: current.q, nextPage: null };
  d3.selectAll(".country").classed("selected", d => d === feature);

  if (!alpha2) {
    titleEl.textContent = feature.properties.name;
    sentimentEl.innerHTML = "";
    moreBtn.hidden = true;
    articlesEl.innerHTML = "<p class='empty'>This country isn't covered by the news API.</p>";
    return;
  }
  load(false);
}

// ---- Search ----
document.getElementById("search-form").addEventListener("submit", evt => {
  evt.preventDefault();
  current.q = document.getElementById("search").value.trim();
  current.nextPage = null;
  load(false);
});

moreBtn.addEventListener("click", () => load(true));

// ---- Data loading ----
function load(append) {
  if (!append) articlesEl.innerHTML = "<p class='empty'>Loading\u2026</p>";

  const params = new URLSearchParams();
  if (current.country) params.set("country", current.country);
  if (current.q) params.set("q", current.q);
  if (append && current.nextPage) params.set("page", current.nextPage);

  titleEl.textContent = current.name ? ("Headlines \u00b7 " + current.name) : "Latest world headlines";

  fetch("/api/news?" + params.toString())
    .then(r => r.json())
    .then(data => render(data, append))
    .catch(() => { articlesEl.innerHTML = "<p class='empty'>Something went wrong.</p>"; });
}

function render(data, append) {
  if (data.error) {
    sentimentEl.innerHTML = "";
    moreBtn.hidden = true;
    articlesEl.innerHTML = "<p class='empty'>" + escapeHtml(data.error) + "</p>";
    return;
  }

  const articles = data.articles || [];
  if (!append) articlesEl.innerHTML = "";

  renderSentiment(data.sentiment);

  if (articles.length === 0 && !append) {
    articlesEl.innerHTML = "<p class='empty'>" +
      escapeHtml(data.note || "No headlines found.") + "</p>";
  }

  for (const a of articles) articlesEl.appendChild(card(a));

  current.nextPage = data.nextPage || null;
  moreBtn.hidden = !current.nextPage;
}

// ---- Sentiment breakdown (paid field; sampled + labelled when absent) ----
function renderSentiment(s) {
  let counts, sample = false;
  if (s && s.available) {
    counts = s.counts;
  } else {
    counts = { positive: 6, neutral: 3, negative: 1 };
    sample = true;
  }
  const total = counts.positive + counts.neutral + counts.negative || 1;
  const seg = (n, cls) =>
    `<span class="seg ${cls}" style="width:${(n / total * 100).toFixed(1)}%"></span>`;

  sentimentEl.innerHTML =
    `<div class="bar">${seg(counts.positive, "pos")}${seg(counts.neutral, "neu")}${seg(counts.negative, "neg")}</div>` +
    `<div class="legend">` +
      `<span class="pos">positive ${counts.positive}</span>` +
      `<span class="neu">neutral ${counts.neutral}</span>` +
      `<span class="neg">negative ${counts.negative}</span>` +
    `</div>` +
    (sample ? `<p class="caption">sample \u2014 live sentiment requires a paid newsdata.io plan</p>` : "");
}

// ---- Article card ----
function card(a) {
  const el = document.createElement("article");
  el.className = "card";
  let html = "";

  if (a.image) {
    html += `<img class="thumb" src="${escapeAttr(a.image)}" alt="" loading="lazy" onerror="this.remove()">`;
  }
  html += `<h3><a href="${escapeAttr(a.link || '#')}" target="_blank" rel="noopener">${escapeHtml(a.title)}</a></h3>`;

  const meta = [a.source, formatDate(a.pubDate)].filter(Boolean).join(" \u00b7 ");
  if (meta || a.sentiment) {
    html += `<p class="meta">${escapeHtml(meta)}`;
    if (a.sentiment) html += ` <span class="badge ${escapeAttr(a.sentiment)}">${escapeHtml(a.sentiment)}</span>`;
    html += `</p>`;
  }

  if (a.ai_summary) {
    html += `<p class="summary">${escapeHtml(a.ai_summary)}</p>`;
  } else if (a.description) {
    html += `<p class="desc">${escapeHtml(truncate(a.description, 180))}</p>`;
  }

  // Prefer AI tags (paid); fall back to free keywords so chips always show.
  const tags = (a.ai_tag.length ? a.ai_tag : a.keywords).slice(0, 6);
  if (tags.length) {
    html += `<p class="tags">` +
      tags.map(t => `<span class="chip">${escapeHtml(t)}</span>`).join("") + `</p>`;
  }

  el.innerHTML = html;
  return el;
}

// ---- Helpers ----
function truncate(str, n) {
  return str.length > n ? str.slice(0, n - 1).trim() + "\u2026" : str;
}

function formatDate(value) {
  if (!value) return "";
  const d = new Date(value.replace(" ", "T") + "Z");
  if (isNaN(d)) return "";
  return d.toLocaleDateString(undefined, { month: "short", day: "numeric", year: "numeric" });
}

function escapeHtml(s) {
  return String(s == null ? "" : s)
    .replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;").replace(/'/g, "&#39;");
}

function escapeAttr(s) {
  return escapeHtml(s);
}

// Initial view: latest world headlines.
load(false);
