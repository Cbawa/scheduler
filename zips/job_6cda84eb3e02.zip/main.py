#!/usr/bin/env python3
"""News Map Explorer.

A small Flask app: click a country on a world map and see its latest
headlines. Headlines come from the newsdata.io news API
(https://newsdata.io). The API key is read from the NEWSDATA_API_KEY
environment variable.
"""
import os
import sys

import requests
from flask import Flask, jsonify, render_template, request

LATEST_URL = "https://newsdata.io/api/1/latest"
REQUEST_TIMEOUT = 20

# Query parameters that only work on paid newsdata.io plans. Sending any of
# these with a free key fails the whole request, so we strip them and retry.
PAID_PARAMS = {
    "full_content", "sentiment", "timeframe", "from_date", "to_date",
    "tag", "region", "organization", "size",
}

app = Flask(__name__)


def get_api_key():
    key = os.environ.get("NEWSDATA_API_KEY")
    if not key:
        sys.stderr.write(
            "NEWSDATA_API_KEY is not set.\n"
            "Get a free key at https://newsdata.io and export it, e.g.\n"
            "    export NEWSDATA_API_KEY=pub_xxxxxxxx\n"
        )
        sys.exit(1)
    return key


API_KEY = get_api_key()
# Optional paid mode. Off by default so the app runs on a free key.
PAID_MODE = os.environ.get("ENABLE_FULL_CONTENT") == "1"


def _request(params):
    """Call the latest-news endpoint, retrying once without paid params."""
    resp = requests.get(LATEST_URL, params=params, timeout=REQUEST_TIMEOUT)
    if resp.status_code in (403, 422) and any(p in params for p in PAID_PARAMS):
        clean = {k: v for k, v in params.items() if k not in PAID_PARAMS}
        resp = requests.get(LATEST_URL, params=clean, timeout=REQUEST_TIMEOUT)
    return resp


def _as_list(value):
    if not value:
        return []
    if isinstance(value, list):
        return [v for v in value if v]
    return [value]


def _clean_article(item):
    return {
        "title": item.get("title") or "(untitled)",
        "link": item.get("link"),
        "description": item.get("description"),
        "source": item.get("source_id") or item.get("source_name"),
        "pubDate": item.get("pubDate"),
        "image": item.get("image_url"),
        "category": _as_list(item.get("category")),
        # Always present on the free tier - the backbone of the tag chips.
        "keywords": _as_list(item.get("keywords")),
        # Paid response fields. Simply absent/None on a free key; the UI
        # guards every one of these and falls back to a labelled placeholder.
        "sentiment": item.get("sentiment"),
        "ai_tag": _as_list(item.get("ai_tag")),
        "ai_summary": item.get("ai_summary"),
    }


def _sentiment_breakdown(articles):
    counts = {"positive": 0, "neutral": 0, "negative": 0}
    found = False
    for art in articles:
        sent = art.get("sentiment")
        if sent in counts:
            counts[sent] += 1
            found = True
    return counts, found


@app.route("/")
def index():
    return render_template("index.html")


@app.route("/api/news")
def api_news():
    params = {"apikey": API_KEY}

    country = (request.args.get("country") or "").strip().lower()
    if country:
        params["country"] = country

    query = (request.args.get("q") or "").strip()
    if query:
        params["q"] = query

    page = (request.args.get("page") or "").strip()
    if page:
        params["page"] = page

    if PAID_MODE:
        params["full_content"] = 1  # stripped + retried if the key is free

    try:
        resp = _request(params)
    except requests.RequestException as exc:
        return jsonify({"error": "Could not reach newsdata.io: %s" % exc,
                        "articles": []}), 502

    if resp.status_code == 401:
        return jsonify({"error": "Invalid newsdata.io API key (401). "
                                 "Check NEWSDATA_API_KEY.",
                        "articles": []}), 401
    if resp.status_code == 429:
        return jsonify({"error": "Rate limit reached (429). "
                                 "Wait a moment and try again.",
                        "articles": []}), 429

    try:
        payload = resp.json()
    except ValueError:
        payload = {}

    if resp.status_code != 200 or payload.get("status") == "error":
        # Unsupported country codes also land here; treat as "no headlines".
        message = ""
        if isinstance(payload.get("results"), dict):
            message = payload["results"].get("message", "")
        return jsonify({"articles": [], "nextPage": None,
                        "note": message or "No headlines available here."}), 200

    results = payload.get("results") or []
    articles = [_clean_article(item) for item in results]
    counts, found = _sentiment_breakdown(articles)

    return jsonify({
        "articles": articles,
        "nextPage": payload.get("nextPage"),
        "total": payload.get("totalResults"),
        "sentiment": {"counts": counts, "available": found},
    })


if __name__ == "__main__":
    port = int(os.environ.get("PORT", "5000"))
    app.run(host="127.0.0.1", port=port, debug=False)
