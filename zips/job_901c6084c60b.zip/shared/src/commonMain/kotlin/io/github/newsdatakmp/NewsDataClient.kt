package io.github.newsdatakmp

import io.ktor.client.HttpClient
import io.ktor.client.call.body
import io.ktor.client.engine.HttpClientEngineFactory
import io.ktor.client.plugins.HttpTimeout
import io.ktor.client.plugins.contentnegotiation.ContentNegotiation
import io.ktor.client.request.get
import io.ktor.serialization.kotlinx.json.json
import kotlinx.serialization.json.Json

/** Platform-supplied Ktor engine: CIO on the JVM/Android, Darwin on iOS. */
internal expect val httpEngineFactory: HttpClientEngineFactory<*>

/** Raised for API errors, with a message suitable for showing to a user. */
class NewsDataException(val statusCode: Int?, message: String) : Exception(message)

/** Internal signal that a paid-only query parameter was rejected. */
private class PaidParamRejected : Exception()

/**
 * Thin client over the newsdata.io `/latest` endpoint. The key is supplied by the caller and
 * sent as the `apikey` query parameter on every request.
 */
class NewsDataClient(
    private val apiKey: String,
    private val enablePaidParams: Boolean = false,
) {
    private val json = Json {
        ignoreUnknownKeys = true
        isLenient = true
    }

    private val client = HttpClient(httpEngineFactory) {
        expectSuccess = false
        install(ContentNegotiation) { json(json) }
        install(HttpTimeout) { requestTimeoutMillis = 30_000 }
    }

    /**
     * Fetch one page of the latest news. Only free-plan parameters are sent unless
     * [enablePaidParams] is set, in which case a rejected paid parameter is retried once
     * without it so a free key still returns results.
     */
    suspend fun latest(
        query: String? = null,
        language: String? = "en",
        country: String? = null,
        category: String? = null,
        page: String? = null,
    ): NewsPage {
        val params = buildMap {
            query?.takeIf { it.isNotBlank() }?.let { put("q", it) }
            language?.takeIf { it.isNotBlank() }?.let { put("language", it) }
            country?.takeIf { it.isNotBlank() }?.let { put("country", it) }
            category?.takeIf { it.isNotBlank() }?.let { put("category", it) }
            page?.let { put("page", it) }
        }
        val response = try {
            fetch(params, usePaidParams = enablePaidParams)
        } catch (e: PaidParamRejected) {
            fetch(params, usePaidParams = false)
        }
        return NewsPage(
            articles = response.results.map { it.toArticle() },
            nextPage = response.nextPage,
            totalResults = response.totalResults,
        )
    }

    /**
     * Walk the `nextPage` cursor up to [maxPages] times and return every article. Stops as soon
     * as the cursor is null.
     */
    suspend fun fetchAll(
        query: String? = null,
        language: String? = "en",
        maxPages: Int = 3,
    ): List<Article> {
        val all = mutableListOf<Article>()
        var cursor: String? = null
        var pages = 0
        do {
            val current = latest(query = query, language = language, page = cursor)
            all += current.articles
            cursor = current.nextPage
            pages++
        } while (cursor != null && pages < maxPages)
        return all
    }

    private suspend fun fetch(params: Map<String, String>, usePaidParams: Boolean): NewsResponse {
        val response = client.get("https://newsdata.io/api/1/latest") {
            url {
                parameters.append("apikey", apiKey)
                params.forEach { (key, value) -> parameters.append(key, value) }
                if (usePaidParams) {
                    parameters.append("full_content", "1")
                    parameters.append("size", "25")
                }
            }
        }
        return when (response.status.value) {
            200 -> response.body()
            401 -> throw NewsDataException(401, "Invalid API key (401). Check the NEWSDATA_API_KEY value.")
            429 -> throw NewsDataException(429, "Rate limit reached (429). Wait a moment before trying again.")
            403, 422 -> throw PaidParamRejected()
            else -> throw NewsDataException(
                response.status.value,
                "Unexpected response from newsdata.io: ${response.status}",
            )
        }
    }

    fun close() = client.close()
}

/** Builds a plain-text report from a page of news. Shared across platforms. */
object ConsoleReport {
    fun render(page: NewsPage, paidMode: Boolean): String {
        val sb = StringBuilder()
        sb.appendLine("newsdata.io — latest headlines")
        sb.appendLine("=".repeat(48))
        if (page.articles.isEmpty()) {
            sb.appendLine("No articles matched this request.")
            sb.appendLine("Try a different query, or check back later.")
            return sb.toString()
        }
        page.totalResults?.let { sb.appendLine("Approx. total results: $it") }
        sb.appendLine("Showing ${page.articles.size} article(s)")
        page.nextPage?.let { sb.appendLine("Next page cursor: $it") }
        sb.appendLine()

        page.articles.forEachIndexed { index, article ->
            sb.appendLine("${index + 1}. ${article.title}")
            val meta = listOfNotNull(article.source, article.pubDate).joinToString("  •  ")
            if (meta.isNotBlank()) sb.appendLine("   $meta")
            article.link?.let { sb.appendLine("   $it") }
            sb.appendLine("   sentiment: ${article.sentiment?.label ?: "n/a (paid plan)"}")
            if (article.keywords.isNotEmpty()) {
                sb.appendLine("   keywords: " + article.keywords.take(8).joinToString(" ") { "#$it" })
            }
            if (article.aiTags.isNotEmpty()) {
                sb.appendLine("   ai tags: " + article.aiTags.take(8).joinToString(", "))
            }
            article.aiSummary?.let { sb.appendLine("   ai summary: $it") }
            sb.appendLine()
        }

        sb.append(renderSentiment(SentimentBreakdown.from(page.articles)))
        if (!paidMode) {
            sb.appendLine()
            sb.appendLine(
                "Tip: set ENABLE_PAID_PARAMS=1 to request full content and larger pages " +
                    "(needs a paid newsdata.io plan).",
            )
        }
        return sb.toString()
    }

    private fun renderSentiment(b: SentimentBreakdown): String {
        val sb = StringBuilder()
        sb.appendLine("Sentiment breakdown")
        sb.appendLine("-".repeat(48))
        if (b.hasLiveData) {
            sb.appendLine(bar("positive", b.positive, b.total))
            sb.appendLine(bar("neutral ", b.neutral, b.total))
            sb.appendLine(bar("negative", b.negative, b.total))
            if (b.unknown > 0) sb.appendLine(bar("n/a     ", b.unknown, b.total))
        } else {
            sb.appendLine(bar("positive", 40, 100))
            sb.appendLine(bar("neutral ", 45, 100))
            sb.appendLine(bar("negative", 15, 100))
            sb.appendLine("(sample — live sentiment requires a paid newsdata.io plan)")
        }
        return sb.toString()
    }

    private fun bar(label: String, value: Int, total: Int): String {
        val ratio = if (total > 0) value.toDouble() / total else 0.0
        val filled = (ratio * 24).toInt()
        val pct = (ratio * 100).toInt()
        return "  $label | " + "#".repeat(filled).padEnd(24) + " $pct% ($value)"
    }
}
