package io.github.newsdatakmp

import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable
import kotlinx.serialization.json.JsonArray
import kotlinx.serialization.json.JsonElement
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.JsonPrimitive

/** Raw shape returned by newsdata.io. Unknown fields are ignored by the Json parser. */
@Serializable
data class NewsResponse(
    val status: String? = null,
    val totalResults: Int? = null,
    val results: List<RawArticle> = emptyList(),
    val nextPage: String? = null,
)

/**
 * A single result straight from the API. The paid-only fields are kept as [JsonElement]
 * because the free plan returns a sentinel string there while paid plans return objects or
 * arrays; normalization happens in [toArticle].
 */
@Serializable
data class RawArticle(
    @SerialName("article_id") val articleId: String? = null,
    val title: String? = null,
    val link: String? = null,
    val description: String? = null,
    @SerialName("pubDate") val pubDate: String? = null,
    @SerialName("source_id") val sourceId: String? = null,
    val keywords: List<String>? = null,
    val sentiment: JsonElement? = null,
    @SerialName("sentiment_stats") val sentimentStats: JsonElement? = null,
    @SerialName("ai_tag") val aiTag: JsonElement? = null,
    @SerialName("ai_region") val aiRegion: JsonElement? = null,
    @SerialName("ai_org") val aiOrg: JsonElement? = null,
    @SerialName("ai_summary") val aiSummary: JsonElement? = null,
)

/** A normalized result, safe to render on any platform. */
data class Article(
    val id: String,
    val title: String,
    val link: String?,
    val description: String?,
    val source: String?,
    val pubDate: String?,
    val keywords: List<String>,
    val sentiment: Sentiment?,
    val sentimentStats: SentimentStats?,
    val aiTags: List<String>,
    val aiSummary: String?,
)

data class NewsPage(
    val articles: List<Article>,
    val nextPage: String?,
    val totalResults: Int?,
)

enum class Sentiment {
    POSITIVE, NEUTRAL, NEGATIVE;

    val label: String get() = name.lowercase()

    companion object {
        fun fromApi(value: String?): Sentiment? = when (value?.lowercase()?.trim()) {
            "positive" -> POSITIVE
            "neutral" -> NEUTRAL
            "negative" -> NEGATIVE
            else -> null
        }
    }
}

data class SentimentStats(val positive: Double, val neutral: Double, val negative: Double)

data class SentimentBreakdown(
    val positive: Int,
    val neutral: Int,
    val negative: Int,
    val unknown: Int,
) {
    val total: Int get() = positive + neutral + negative + unknown
    val hasLiveData: Boolean get() = positive + neutral + negative > 0

    companion object {
        fun from(articles: List<Article>): SentimentBreakdown {
            var p = 0; var n = 0; var neg = 0; var u = 0
            for (a in articles) when (a.sentiment) {
                Sentiment.POSITIVE -> p++
                Sentiment.NEUTRAL -> n++
                Sentiment.NEGATIVE -> neg++
                null -> u++
            }
            return SentimentBreakdown(p, n, neg, u)
        }
    }
}

// --- Field normalization -----------------------------------------------------
// Paid-only fields arrive as a sentinel string on the free plan; treat those (and blanks)
// as "absent" so callers get clean nulls/empties instead of noise.

private const val PAID_SENTINEL = "ONLY AVAILABLE"

private fun JsonElement?.asCleanString(): String? {
    val primitive = this as? JsonPrimitive ?: return null
    if (!primitive.isString) return null
    val text = primitive.content.trim()
    if (text.isEmpty() || text.contains(PAID_SENTINEL, ignoreCase = true)) return null
    return text
}

private fun JsonElement?.asStringList(): List<String> = when (this) {
    is JsonArray -> mapNotNull { (it as? JsonPrimitive)?.content?.trim() }
        .filter { it.isNotEmpty() && !it.contains(PAID_SENTINEL, ignoreCase = true) }
    is JsonPrimitive -> asCleanString()?.let { listOf(it) } ?: emptyList()
    else -> emptyList()
}

private fun JsonElement?.asSentimentStats(): SentimentStats? {
    val obj = this as? JsonObject ?: return null
    fun value(key: String): Double = (obj[key] as? JsonPrimitive)?.content?.toDoubleOrNull() ?: 0.0
    val stats = SentimentStats(value("positive"), value("neutral"), value("negative"))
    val empty = stats.positive == 0.0 && stats.neutral == 0.0 && stats.negative == 0.0
    return if (empty) null else stats
}

fun RawArticle.toArticle(): Article = Article(
    id = articleId ?: link ?: title.orEmpty(),
    title = title?.takeIf { it.isNotBlank() } ?: "(untitled)",
    link = link,
    description = description,
    source = sourceId,
    pubDate = pubDate,
    keywords = keywords?.map { it.trim() }?.filter { it.isNotEmpty() } ?: emptyList(),
    sentiment = Sentiment.fromApi(sentiment.asCleanString()),
    sentimentStats = sentimentStats.asSentimentStats(),
    aiTags = (aiTag.asStringList() + aiRegion.asStringList() + aiOrg.asStringList()).distinct(),
    aiSummary = aiSummary.asCleanString(),
)
