package io.github.newsdatakmp

import io.ktor.client.engine.HttpClientEngineFactory
import io.ktor.client.engine.cio.CIO
import kotlinx.coroutines.runBlocking
import kotlin.system.exitProcess

/** JVM (and Android) engine. */
internal actual val httpEngineFactory: HttpClientEngineFactory<*> = CIO

fun main(args: Array<String>) {
    val apiKey = System.getenv("NEWSDATA_API_KEY")?.takeIf { it.isNotBlank() }
    if (apiKey == null) {
        System.err.println("NEWSDATA_API_KEY is not set.")
        System.err.println("Get a free key at https://newsdata.io and export it, e.g.:")
        System.err.println("  export NEWSDATA_API_KEY=pub_xxxxxxxxxxxxxxxx")
        exitProcess(1)
    }

    val paidMode = System.getenv("ENABLE_PAID_PARAMS") == "1" || args.contains("--paid")
    val query = args.filterNot { it.startsWith("--") }.joinToString(" ").ifBlank { null }

    val client = NewsDataClient(apiKey = apiKey, enablePaidParams = paidMode)
    try {
        runBlocking {
            val page = client.latest(query = query, language = "en")
            print(ConsoleReport.render(page, paidMode))
        }
    } catch (e: NewsDataException) {
        System.err.println("Request failed: ${e.message}")
        exitProcess(1)
    } catch (e: Exception) {
        System.err.println("Could not reach newsdata.io: ${e.message}")
        exitProcess(1)
    } finally {
        client.close()
    }
}
