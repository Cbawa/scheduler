package io.github.newsdatakmp

import io.ktor.client.engine.HttpClientEngineFactory
import io.ktor.client.engine.darwin.Darwin

/** iOS engine, used when the shared framework runs inside an iOS app. */
internal actual val httpEngineFactory: HttpClientEngineFactory<*> = Darwin
