# news-kotlin-multiplatform

A small Kotlin Multiplatform module that keeps the networking and JSON-parsing code for the
newsdata.io news API in one place, so an Android app and an iOS app can share it instead of
each writing its own client. Headlines come from the newsdata.io news API
(https://newsdata.io) — grab a free API key to run it.

The shared code makes the HTTP request (via Ktor), deserializes the response, normalizes the
fields that differ between the free and paid plans, and exposes a plain `NewsDataClient` that
hands back clean `Article` objects. A small JVM console demo is included so you can run the
shared code and see real headlines without opening Android Studio or Xcode.

## Layout

- `shared/` — the multiplatform module
  - `commonMain` — `NewsDataClient`, the data models, field normalization, and a text report
    renderer. This is the part Android and iOS share.
  - `jvmMain` — the Ktor CIO engine plus a `main()` that prints headlines to the terminal.
    Android consumes this same JVM artifact (the bytecode runs on the Android runtime).
  - `iosMain` — the Ktor Darwin engine, compiled into an iOS framework named `Shared`.

Each article carries its headline, source, publish date, link, and `keywords` (returned on the
free plan). It also surfaces the richer fields newsdata.io can return — per-article `sentiment`,
AI tags (`ai_tag` / `ai_region` / `ai_org`) and `ai_summary`. On a free key those fields come
back empty, so the report shows a clearly labelled placeholder instead of a blank space.

## Requirements

- JDK 11 or newer
- Gradle 8.2+ (or run `gradle wrapper` once to generate the wrapper scripts)
- A newsdata.io API key — the free plan is enough. Sign up at https://newsdata.io and copy your
  key.

The console demo builds only the JVM target, so you can run it on Linux or Windows. Building the
iOS framework requires macOS with Xcode, as usual for Kotlin/Native.

## Setup

The code reads the key from `NEWSDATA_API_KEY` and refuses to run without it:

    export NEWSDATA_API_KEY=pub_xxxxxxxxxxxxxxxxxxxxxxxx

## Run the console demo

    gradle :shared:jvmRun

Search for a topic by passing arguments:

    gradle :shared:jvmRun --args="bitcoin"

### Sample output

    newsdata.io — latest headlines
    ================================================
    Approx. total results: 1932
    Showing 10 article(s)
    Next page cursor: 1700000000000abcdef

    1. Central bank holds rates steady amid mixed signals
       reuters  •  2026-06-12 09:14:00
       https://example.com/article
       sentiment: n/a (paid plan)
       keywords: #economy #rates #inflation

    2. Regional grid operator reports record solar output
       example-news  •  2026-06-12 08:50:00
       https://example.com/solar
       sentiment: n/a (paid plan)
       keywords: #energy #solar #grid

    Sentiment breakdown
    ------------------------------------------------
      positive | ##########               40% (40)
      neutral  | ###########              45% (45)
      negative | ###                      15% (15)
    (sample — live sentiment requires a paid newsdata.io plan)

The keyword chips are real data from the free plan. The sentiment bars switch to live counts
automatically once your key returns the `sentiment` field.

## Using the shared module from Android

Add `shared` as a dependency and call it from a coroutine. The default Ktor engine on the JVM
artifact is CIO, which works on Android too:

    val client = NewsDataClient(apiKey = BuildConfig.NEWSDATA_API_KEY)
    lifecycleScope.launch {
        val page = client.latest(query = "technology", language = "en")
        page.articles.forEach { article ->
            println("${article.title} — ${article.keywords}")
        }
        client.close()
    }

## Using it from iOS

Link the generated `Shared` framework and call the same client. Suspend functions are exposed
to Swift as completion handlers:

    import Shared

    let client = NewsDataClient(apiKey: apiKey, enablePaidParams: false)
    client.latest(query: "technology", language: "en", country: nil, category: nil, page: nil) { page, error in
        page?.articles.forEach { print($0.title) }
        client.close()
    }

## Pagination

Results are paged with the `nextPage` cursor. Pass it back as `page` to fetch the next set and
stop when it is `null`:

    var cursor: String? = null
    do {
        val page = client.latest(query = "climate", page = cursor)
        // ... use page.articles ...
        cursor = page.nextPage
    } while (cursor != null)

`NewsDataClient.fetchAll(query = ..., maxPages = 3)` wraps this loop for you.

## Optional: paid-plan parameters

The free plan covers the core flow. If you have a paid newsdata.io plan, set:

    export ENABLE_PAID_PARAMS=1

This adds `full_content=1` and a larger page `size` to the request. Those are paid-only query
parameters; if the API rejects them, the client retries once without them, so a free key still
gets results. The `sentiment` and `ai_*` response fields fill in on their own when your plan
includes them — no code change needed.

## Notes

- Only the `/latest` endpoint and free query parameters are used on the default path.
- An invalid key (401) and rate limiting (429) surface as readable messages; an empty result
  set is reported as "no matches" rather than an error.
- Paid-only response fields arrive as a sentinel string on the free plan; the normalization
  layer treats those as absent so callers always get clean nulls and empty lists.
