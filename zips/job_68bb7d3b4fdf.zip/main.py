#!/usr/bin/env python3
"""bluesky-news-bot — post curated newsdata.io headlines to Bluesky."""
from __future__ import annotations

import argparse
import os
import sys
import time
from collections import Counter

try:
    from dotenv import load_dotenv
    load_dotenv()
except ImportError:
    pass

from newsdata import NewsDataClient, NewsDataError
from bluesky_client import BlueskyPoster, BlueskyError
from formatting import build_post, clean_tags, VALID_SENTIMENT
from state import PostedStore

DEFAULT_STATE = os.path.join("data", "posted.json")


def env(name, default=None):
    value = os.environ.get(name)
    return value if value not in (None, "") else default


def article_id(article):
    return (article.get("article_id") or article.get("link")
            or article.get("title") or "")


def sentiment_summary(articles):
    counts = Counter()
    for art in articles:
        sentiment = art.get("sentiment")
        if isinstance(sentiment, str) and sentiment.lower() in VALID_SENTIMENT:
            counts[sentiment.lower()] += 1
    return counts


def run_once(args):
    api_key = env("NEWSDATA_API_KEY")
    if not api_key:
        print("error: NEWSDATA_API_KEY is not set. Get a free key at "
              "https://newsdata.io", file=sys.stderr)
        return 2

    news = NewsDataClient(api_key)
    try:
        articles = news.fetch_latest(
            query=args.query,
            category=args.category,
            language=args.language,
            country=args.country,
            max_articles=args.max,
        )
    except NewsDataError as exc:
        print(f"error: {exc}", file=sys.stderr)
        return 1

    if not articles:
        print("No articles returned for the current filters.")
        return 0

    store = PostedStore(args.state)
    fresh = [a for a in articles if not store.seen(article_id(a))]

    print(f"Fetched {len(articles)} article(s); {len(fresh)} new.")

    # A visible look at the API's richer fields.
    counts = sentiment_summary(articles)
    if counts:
        breakdown = ", ".join(f"{k}: {v}" for k, v in counts.items())
        print(f"Sentiment in this batch -> {breakdown}")
    else:
        print("Sentiment not present on these results "
              "(requires a paid newsdata.io plan).")

    poster = None
    if not args.dry_run and fresh:
        try:
            poster = BlueskyPoster(env("BLUESKY_HANDLE"),
                                   env("BLUESKY_PASSWORD"))
            poster.login()
        except BlueskyError as exc:
            print(f"error: {exc}", file=sys.stderr)
            return 1

    posted = 0
    for art in fresh[:args.limit]:
        builder = build_post(art)
        preview = builder.build_text().replace("\n", " ").strip()
        tags = clean_tags(art.get("keywords"))
        tag_note = f"   tags: {', '.join(tags)}" if tags else ""
        if args.dry_run:
            print(f"[dry-run] {preview}{tag_note}")
            store.add(article_id(art))
            posted += 1
            continue
        try:
            poster.post(builder)
            print(f"[posted] {preview}{tag_note}")
            store.add(article_id(art))
            posted += 1
        except BlueskyError as exc:
            print(f"warning: {exc}", file=sys.stderr)
        time.sleep(args.delay)

    store.save()
    verb = "previewed" if args.dry_run else "sent"
    print(f"Done. {posted} post(s) {verb}.")
    return 0


def build_arg_parser():
    parser = argparse.ArgumentParser(
        description="Post curated newsdata.io headlines to Bluesky.")
    parser.add_argument("--category",
                        help="newsdata.io category, e.g. technology")
    parser.add_argument("--language", help="language code, e.g. en")
    parser.add_argument("--country", help="country code, e.g. us")
    parser.add_argument("--query", "-q", help="keyword search")
    parser.add_argument("--max", type=int, default=10,
                        help="max articles to fetch (default 10)")
    parser.add_argument("--limit", type=int, default=3,
                        help="max posts to publish per run (default 3)")
    parser.add_argument("--delay", type=float, default=2.0,
                        help="seconds between posts (default 2)")
    parser.add_argument("--state", default=DEFAULT_STATE,
                        help="path to the dedupe state file")
    parser.add_argument("--interval", type=float,
                        help="minutes between runs; omit to run once")
    parser.add_argument("--dry-run", action="store_true",
                        help="print posts instead of publishing")
    return parser


def main(argv=None):
    args = build_arg_parser().parse_args(argv)
    if args.interval:
        print(f"Running every {args.interval} minute(s). Ctrl-C to stop.")
        try:
            while True:
                code = run_once(args)
                if code == 2:
                    return code
                time.sleep(max(1.0, args.interval * 60))
        except KeyboardInterrupt:
            print("\nStopped.")
            return 0
    return run_once(args)


if __name__ == "__main__":
    sys.exit(main())
