"""Minimal client for the newsdata.io news API (https://newsdata.io).

Uses only the free-tier `/1/latest` endpoint and free query parameters
(q, category, language, country). Paid response fields such as `sentiment`
and `ai_summary` are read straight off each result when present and are
simply absent on a free key, so nothing here needs a paid plan to run.
"""
from __future__ import annotations

import time

import requests

LATEST_URL = "https://newsdata.io/api/1/latest"


class NewsDataError(Exception):
    """Raised when the news API returns an unrecoverable error."""


class NewsDataClient:
    def __init__(self, api_key, timeout=30, max_retries=3):
        if not api_key:
            raise NewsDataError("NEWSDATA_API_KEY is empty.")
        self.api_key = api_key
        self.timeout = timeout
        self.max_retries = max_retries
        self.session = requests.Session()

    def fetch_latest(self, *, query=None, category=None, language=None,
                     country=None, max_articles=10):
        """Fetch up to `max_articles` recent articles, following nextPage."""
        collected = []
        page = None
        while len(collected) < max_articles:
            params = {"apikey": self.api_key}
            if query:
                params["q"] = query
            if category:
                params["category"] = category
            if language:
                params["language"] = language
            if country:
                params["country"] = country
            if page:
                params["page"] = page

            payload = self._get(params)
            results = payload.get("results") or []
            collected.extend(results)

            page = payload.get("nextPage")
            if not page or not results:
                break
        return collected[:max_articles]

    def _get(self, params):
        last_error = None
        for attempt in range(self.max_retries):
            try:
                resp = self.session.get(LATEST_URL, params=params,
                                        timeout=self.timeout)
            except requests.RequestException as exc:
                last_error = str(exc)
                time.sleep(2 * (attempt + 1))
                continue

            if resp.status_code == 200:
                return resp.json()
            if resp.status_code == 401:
                raise NewsDataError(
                    "Invalid API key (401). Check NEWSDATA_API_KEY.")
            if resp.status_code == 429:
                # Rate limited — back off and retry.
                last_error = "rate limited (429)"
                time.sleep(5 * (attempt + 1))
                continue
            if resp.status_code in (403, 422):
                raise NewsDataError(
                    f"Request rejected ({resp.status_code}). This usually means "
                    "a parameter requires a paid plan. Details: "
                    f"{resp.text[:200]}")
            last_error = f"HTTP {resp.status_code}: {resp.text[:200]}"
            time.sleep(2 * (attempt + 1))

        raise NewsDataError(f"News API request failed: {last_error}")
