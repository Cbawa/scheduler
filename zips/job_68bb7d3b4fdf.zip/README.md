# bluesky-news-bot

A small command-line bot that posts recent news headlines to a Bluesky account. It
pulls articles from the newsdata.io news API (https://newsdata.io) and publishes a
few of them at a time over the AT Protocol, with category and language filters so you
can scope a feed to, say, English technology news.

Each post links back to the original article and adds a couple of keyword hashtags.
When the response includes them, posts also carry a short summary line and a sentiment
label.

## Features

- Pull latest headlines from newsdata.io with `--category`, `--language`, `--country`,
  and keyword (`-q`) filters.
- Post to Bluesky via the AT Protocol using an app password.
- Keeps a small JSON state file so the same article is never posted twice.
- `--dry-run` previews posts without publishing.
- Optional `--interval` keeps the bot running on a timer.
- Reads keyword tags (available on every plan) plus `sentiment` and `ai_summary`
  fields when they are present in the response.

## Requirements

- Python 3.9 or newer
- A newsdata.io API key. The free tier is enough to run everything here; grab one at
  https://newsdata.io.
- A Bluesky account and an app password (Settings → App Passwords).

## Setup

```
git clone <your-fork-url>
cd bluesky-news-bot
python -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt
cp .env.example .env      # then fill in the values
```

The bot reads three environment variables. A `.env` file in the project root is loaded
automatically if it exists.

| Variable | Purpose |
| --- | --- |
| `NEWSDATA_API_KEY` | Your newsdata.io API key |
| `BLUESKY_HANDLE` | e.g. `you.bsky.social` |
| `BLUESKY_PASSWORD` | A Bluesky app password (not your main password) |

## Usage

Preview English technology headlines without posting anything:

```
python main.py --category technology --language en --dry-run
```

Sample output (free key, no sentiment in the response):

```
Fetched 10 article(s); 4 new.
Sentiment not present on these results (requires a paid newsdata.io plan).
[dry-run] New observatory releases its first images   tags: Space, Astronomy
[dry-run] Markets steady ahead of the jobs report   tags: Markets, Economy
Done. 3 post(s) previewed.
```

Publish up to two posts:

```
python main.py --category technology --language en --limit 2
```

Keep it running, checking for new headlines every 30 minutes:

```
python main.py --category world --language en --interval 30
```

## Options

| Flag | Default | Description |
| --- | --- | --- |
| `--category` | — | newsdata.io category, e.g. `technology`, `business`, `sports` |
| `--language` | — | language code, e.g. `en`, `es`, `de` |
| `--country` | — | country code, e.g. `us`, `gb`, `in` |
| `--query`, `-q` | — | keyword search |
| `--max` | 10 | how many articles to fetch per run |
| `--limit` | 3 | how many posts to publish per run |
| `--delay` | 2.0 | seconds to wait between posts |
| `--interval` | — | minutes between runs; omit to run once and exit |
| `--state` | `data/posted.json` | path to the dedupe state file |
| `--dry-run` | off | print posts instead of publishing |

## Notes on optional data

`keywords` are returned on every plan and drive the hashtags. The `sentiment` and
`ai_summary` fields are part of newsdata.io's paid plans; on a free key they come back
empty and the bot simply leaves them out, noting it in the per-batch summary line. No
extra configuration is needed in either case — the same command works on a free or paid
key.

## License

MIT
