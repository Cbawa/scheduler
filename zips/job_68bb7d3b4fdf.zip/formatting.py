"""Turn a newsdata.io article dict into a Bluesky post."""
from __future__ import annotations

import re

from atproto import client_utils

POST_LIMIT = 300
VALID_SENTIMENT = {"positive", "negative", "neutral"}


def clean_tag(keyword):
    parts = re.findall(r"[A-Za-z0-9]+", keyword or "")
    if not parts:
        return None
    tag = "".join(p.capitalize() for p in parts)
    return tag[:30] or None


def clean_tags(keywords, limit=3):
    tags = []
    for keyword in keywords or []:
        tag = clean_tag(keyword)
        if tag and tag not in tags:
            tags.append(tag)
        if len(tags) >= limit:
            break
    return tags


def pick_summary(article):
    # ai_summary is a paid field; fall back to the always-present description.
    for key in ("ai_summary", "description"):
        value = article.get(key)
        if isinstance(value, str) and value.strip():
            return value.strip()
    return ""


def _truncate(text, limit):
    text = (text or "").strip()
    if len(text) <= limit:
        return text
    if limit <= 1:
        return ""
    return text[:limit - 1].rstrip() + "\u2026"


def build_post(article):
    """Return an atproto TextBuilder ready to hand to send_post()."""
    title = (article.get("title") or "Untitled").strip()
    link = (article.get("link") or "").strip()
    summary = pick_summary(article)
    sentiment = article.get("sentiment")
    tags = clean_tags(article.get("keywords"))

    title = _truncate(title, 150)

    sentiment_line = ""
    if isinstance(sentiment, str) and sentiment.lower() in VALID_SENTIMENT:
        sentiment_line = f"Sentiment: {sentiment.lower()}"

    tag_text = " ".join("#" + t for t in tags)

    used = len(title)
    if sentiment_line:
        used += len(sentiment_line) + 2
    if tag_text:
        used += len(tag_text) + 2
    available = POST_LIMIT - used - 2
    if summary and available > 25:
        summary = _truncate(summary, available)
    else:
        summary = ""

    builder = client_utils.TextBuilder()
    if link:
        builder.link(title, link)
    else:
        builder.text(title)

    if summary:
        builder.text("\n\n" + summary)
    if sentiment_line:
        builder.text("\n\n" + sentiment_line)
    if tags:
        builder.text("\n" if sentiment_line else "\n\n")
        for index, tag in enumerate(tags):
            if index:
                builder.text(" ")
            builder.tag("#" + tag, tag)
    return builder
