"""Thin wrapper around the atproto client for posting to Bluesky."""
from __future__ import annotations

from atproto import Client


class BlueskyError(Exception):
    pass


class BlueskyPoster:
    def __init__(self, handle, password):
        if not handle or not password:
            raise BlueskyError(
                "BLUESKY_HANDLE and BLUESKY_PASSWORD must both be set.")
        self.handle = handle
        self._password = password
        self.client = Client()
        self._profile = None

    def login(self):
        try:
            self._profile = self.client.login(self.handle, self._password)
        except Exception as exc:  # atproto raises a variety of errors
            raise BlueskyError(f"Bluesky login failed: {exc}") from exc
        return self._profile

    def post(self, text_builder):
        try:
            return self.client.send_post(text_builder)
        except Exception as exc:
            raise BlueskyError(f"Failed to send post: {exc}") from exc
