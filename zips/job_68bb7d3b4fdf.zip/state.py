"""Track which articles have already been posted (atomic JSON file)."""
from __future__ import annotations

import json
import os
import tempfile


class PostedStore:
    def __init__(self, path):
        self.path = path
        self._ids = set()
        self._load()

    def _load(self):
        try:
            with open(self.path, "r", encoding="utf-8") as fh:
                data = json.load(fh)
            self._ids = set(data.get("posted", []))
        except (FileNotFoundError, ValueError):
            self._ids = set()

    def seen(self, article_id):
        return article_id in self._ids

    def add(self, article_id):
        if article_id:
            self._ids.add(article_id)

    def save(self):
        directory = os.path.dirname(self.path) or "."
        os.makedirs(directory, exist_ok=True)
        fd, tmp = tempfile.mkstemp(dir=directory, suffix=".tmp")
        try:
            with os.fdopen(fd, "w", encoding="utf-8") as fh:
                json.dump({"posted": sorted(self._ids)}, fh, indent=2)
            os.replace(tmp, self.path)
        finally:
            if os.path.exists(tmp):
                os.remove(tmp)
