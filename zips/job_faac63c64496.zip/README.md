# 📰 Inshorts Clone (React Native)

A swipeable, card-based news reader inspired by **Inshorts**, built with **React Native + Expo**.
Each story is fetched live from the [newsdata.io](https://newsdata.io) news API and condensed into a
bite-sized **~60 word** summary. Swipe vertically to flip through the day's headlines.

> This project is a community showcase for the **newsdata.io** API and runs on its **FREE tier** out of the box.

## ✨ Features

- Vertical, full-screen swipeable news cards (FlatList paging — just like Inshorts)
- Live headlines from `newsdata.io` `/news`
- Infinite scroll via the `nextPage` pagination token
- Pull-to-refresh
- **Optional** AI summarization to exactly ~60 words via OpenAI — gracefully falls back to the
  article description when no OpenAI key is configured
- Tap a card to open the full article in your browser
- Robust error handling for invalid keys (401), rate limits (429) and empty result sets

## 🧰 Tech stack

- React Native (Expo SDK 51)
- newsdata.io REST API
- OpenAI Chat Completions API (optional)

## 🚀 Getting started

### 1. Prerequisites

- [Node.js](https://nodejs.org) 18+
- The Expo Go app on your phone, or an Android/iOS simulator

### 2. Install

```bash
git clone https://github.com/your-username/inshorts-clone-react-native.git
cd inshorts-clone-react-native
npm install
```

### 3. Configure your API key

Get a **free** API key from [newsdata.io](https://newsdata.io/register).

Expo only exposes environment variables prefixed with `EXPO_PUBLIC_` to the app at runtime.
Create a `.env` file in the project root:

```bash
# Required — your free newsdata.io key
EXPO_PUBLIC_NEWSDATA_API_KEY=your_newsdata_key_here

# Optional — enables AI 60-word summaries. Without it the app uses the
# article description instead, so everything still works.
EXPO_PUBLIC_OPENAI_API_KEY=your_openai_key_here
```

If `EXPO_PUBLIC_NEWSDATA_API_KEY` is missing, the app shows a clear configuration
message instead of crashing.

### 4. Run

```bash
npm start
```

Then scan the QR code with Expo Go, or press `a` (Android) / `i` (iOS) in the terminal.

## 🆓 Free tier vs. paid

This app is built strictly against **free-tier** newsdata.io functionality:

- It uses `/news` with the free params `language`, `category`, `q` and `page` (the `nextPage` token).

The following newsdata.io features are **paid-only** and are intentionally **not** relied upon:

- Sentiment analysis
- AI fields (`ai_tag`, `ai_region`, `ai_org`, `ai_summary`)
- The historical `/archive` endpoint and long date ranges
- Advanced full-text query operators

The 60-word summaries in this app are generated client-side via **OpenAI** (not the paid newsdata.io
AI fields), and that step is entirely optional.

> ⚠️ Note: calling OpenAI directly from a mobile client exposes the key in the app bundle. The
> OpenAI integration here is for demos/learning. For production, proxy summarization through your
> own backend.

## 📂 Project structure

```
App.js            # The entire app: API client, summarizer, swipeable card UI
app.json          # Expo config
babel.config.js   # Babel preset for Expo
package.json      # Dependencies & scripts
```

## 📄 License

MIT — built with ❤️ to showcase [newsdata.io](https://newsdata.io).
