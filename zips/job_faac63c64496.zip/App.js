import React, { useCallback, useEffect, useState } from 'react';
import {
  ActivityIndicator,
  Dimensions,
  FlatList,
  Linking,
  RefreshControl,
  SafeAreaView,
  StyleSheet,
  Text,
  TouchableOpacity,
  View,
} from 'react-native';
import { StatusBar } from 'expo-status-bar';

// ---------------------------------------------------------------------------
// Configuration
// Expo inlines env vars prefixed with EXPO_PUBLIC_ at build time.
// ---------------------------------------------------------------------------
const NEWSDATA_API_KEY =
  process.env.EXPO_PUBLIC_NEWSDATA_API_KEY || process.env.NEWSDATA_API_KEY || '';
const OPENAI_API_KEY =
  process.env.EXPO_PUBLIC_OPENAI_API_KEY || process.env.OPENAI_API_KEY || '';

const NEWSDATA_BASE = 'https://newsdata.io/api/1';
const { height: SCREEN_HEIGHT } = Dimensions.get('window');

// ---------------------------------------------------------------------------
// newsdata.io client (FREE tier only)
// ---------------------------------------------------------------------------
async function fetchNews({ page = null } = {}) {
  const params = new URLSearchParams({
    apikey: NEWSDATA_API_KEY,
    language: 'en',
    category: 'top',
  });
  if (page) params.set('page', page);

  const res = await fetch(`${NEWSDATA_BASE}/news?${params.toString()}`);

  if (res.status === 401) {
    throw new Error('Invalid newsdata.io API key (401). Check EXPO_PUBLIC_NEWSDATA_API_KEY.');
  }
  if (res.status === 429) {
    throw new Error('Rate limit reached (429). The free plan has limited requests — try again soon.');
  }

  let data;
  try {
    data = await res.json();
  } catch (e) {
    throw new Error('Could not parse the newsdata.io response.');
  }

  if (data.status === 'error') {
    const msg = (data.results && data.results.message) || data.message || 'newsdata.io returned an error.';
    throw new Error(msg);
  }

  const results = Array.isArray(data.results) ? data.results : [];
  return {
    articles: results.filter((a) => a && a.title),
    nextPage: data.nextPage || null,
  };
}

// ---------------------------------------------------------------------------
// Summarization
// Optional OpenAI 60-word summary. Degrades gracefully to the article
// description when no key is set or the request fails.
// ---------------------------------------------------------------------------
function fallbackSummary(article) {
  const text = (article.description || article.content || article.title || '').trim();
  if (!text) return 'No summary available for this story.';
  const words = text.split(/\s+/);
  if (words.length <= 60) return text;
  return words.slice(0, 60).join(' ') + '…';
}

async function summarize(article) {
  if (!OPENAI_API_KEY) return fallbackSummary(article);

  const source = (article.description || article.content || article.title || '').trim();
  if (!source) return fallbackSummary(article);

  try {
    const res = await fetch('https://api.openai.com/v1/chat/completions', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${OPENAI_API_KEY}`,
      },
      body: JSON.stringify({
        model: 'gpt-4o-mini',
        temperature: 0.4,
        messages: [
          {
            role: 'system',
            content:
              'You are a news editor. Summarize the article into a single neutral paragraph of about 60 words. Do not exceed 60 words.',
          },
          { role: 'user', content: `Title: ${article.title}\n\nContent: ${source}` },
        ],
      }),
    });

    if (!res.ok) return fallbackSummary(article);
    const data = await res.json();
    const out = data?.choices?.[0]?.message?.content?.trim();
    return out || fallbackSummary(article);
  } catch (e) {
    return fallbackSummary(article);
  }
}

// ---------------------------------------------------------------------------
// UI
// ---------------------------------------------------------------------------
function formatDate(pubDate) {
  if (!pubDate) return '';
  const d = new Date(pubDate.replace(' ', 'T') + 'Z');
  if (isNaN(d.getTime())) return pubDate;
  return d.toLocaleString(undefined, {
    month: 'short',
    day: 'numeric',
    hour: '2-digit',
    minute: '2-digit',
  });
}

function NewsCard({ article }) {
  const [summary, setSummary] = useState(null);

  useEffect(() => {
    let alive = true;
    setSummary(null);
    summarize(article).then((s) => {
      if (alive) setSummary(s);
    });
    return () => {
      alive = false;
    };
  }, [article]);

  return (
    <View style={styles.card}>
      <View style={styles.cardHeader}>
        <Text style={styles.source}>{(article.source_id || 'news').toUpperCase()}</Text>
        <Text style={styles.date}>{formatDate(article.pubDate)}</Text>
      </View>

      <Text style={styles.title}>{article.title}</Text>

      <View style={styles.summaryWrap}>
        {summary === null ? (
          <ActivityIndicator color="#e63946" />
        ) : (
          <Text style={styles.summary}>{summary}</Text>
        )}
      </View>

      {!!article.link && (
        <TouchableOpacity
          style={styles.readMore}
          onPress={() => Linking.openURL(article.link)}
        >
          <Text style={styles.readMoreText}>Read full article ↗</Text>
        </TouchableOpacity>
      )}
    </View>
  );
}

function Centered({ children }) {
  return <View style={styles.centered}>{children}</View>;
}

export default function App() {
  const [articles, setArticles] = useState([]);
  const [nextPage, setNextPage] = useState(null);
  const [loading, setLoading] = useState(true);
  const [loadingMore, setLoadingMore] = useState(false);
  const [refreshing, setRefreshing] = useState(false);
  const [error, setError] = useState(null);

  const load = useCallback(async ({ append = false } = {}) => {
    try {
      setError(null);
      const { articles: fresh, nextPage: np } = await fetchNews({
        page: append ? nextPage : null,
      });
      setNextPage(np);
      setArticles((prev) => {
        const combined = append ? [...prev, ...fresh] : fresh;
        const seen = new Set();
        return combined.filter((a) => {
          const k = a.link || a.article_id || a.title;
          if (seen.has(k)) return false;
          seen.add(k);
          return true;
        });
      });
    } catch (e) {
      setError(e.message || 'Something went wrong.');
    }
  }, [nextPage]);

  useEffect(() => {
    if (!NEWSDATA_API_KEY) {
      setLoading(false);
      return;
    }
    (async () => {
      setLoading(true);
      await load({ append: false });
      setLoading(false);
    })();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const onRefresh = useCallback(async () => {
    setRefreshing(true);
    setNextPage(null);
    await load({ append: false });
    setRefreshing(false);
  }, [load]);

  const onEndReached = useCallback(async () => {
    if (loadingMore || !nextPage) return;
    setLoadingMore(true);
    await load({ append: true });
    setLoadingMore(false);
  }, [loadingMore, nextPage, load]);

  // --- Render states --------------------------------------------------------
  if (!NEWSDATA_API_KEY) {
    return (
      <SafeAreaView style={styles.appBg}>
        <StatusBar style="light" />
        <Centered>
          <Text style={styles.emoji}>🔑</Text>
          <Text style={styles.errorTitle}>API key not configured</Text>
          <Text style={styles.errorBody}>
            Set EXPO_PUBLIC_NEWSDATA_API_KEY in a .env file with your free key from newsdata.io,
            then restart the dev server.
          </Text>
        </Centered>
      </SafeAreaView>
    );
  }

  if (loading) {
    return (
      <SafeAreaView style={styles.appBg}>
        <StatusBar style="light" />
        <Centered>
          <ActivityIndicator size="large" color="#e63946" />
          <Text style={styles.loadingText}>Loading headlines…</Text>
        </Centered>
      </SafeAreaView>
    );
  }

  if (error && articles.length === 0) {
    return (
      <SafeAreaView style={styles.appBg}>
        <StatusBar style="light" />
        <Centered>
          <Text style={styles.emoji}>⚠️</Text>
          <Text style={styles.errorTitle}>Couldn't load news</Text>
          <Text style={styles.errorBody}>{error}</Text>
          <TouchableOpacity style={styles.retry} onPress={onRefresh}>
            <Text style={styles.retryText}>Try again</Text>
          </TouchableOpacity>
        </Centered>
      </SafeAreaView>
    );
  }

  if (articles.length === 0) {
    return (
      <SafeAreaView style={styles.appBg}>
        <StatusBar style="light" />
        <Centered>
          <Text style={styles.emoji}>🗞️</Text>
          <Text style={styles.errorTitle}>No stories right now</Text>
          <Text style={styles.errorBody}>Pull to refresh to check again.</Text>
          <TouchableOpacity style={styles.retry} onPress={onRefresh}>
            <Text style={styles.retryText}>Refresh</Text>
          </TouchableOpacity>
        </Centered>
      </SafeAreaView>
    );
  }

  return (
    <SafeAreaView style={styles.appBg}>
      <StatusBar style="light" />
      <FlatList
        data={articles}
        keyExtractor={(item, i) => item.article_id || item.link || String(i)}
        renderItem={({ item }) => <NewsCard article={item} />}
        pagingEnabled
        showsVerticalScrollIndicator={false}
        snapToInterval={SCREEN_HEIGHT}
        snapToAlignment="start"
        decelerationRate="fast"
        onEndReached={onEndReached}
        onEndReachedThreshold={0.5}
        refreshControl={
          <RefreshControl refreshing={refreshing} onRefresh={onRefresh} tintColor="#fff" />
        }
        ListFooterComponent={
          loadingMore ? (
            <View style={styles.footer}>
              <ActivityIndicator color="#e63946" />
            </View>
          ) : null
        }
      />
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  appBg: { flex: 1, backgroundColor: '#111111' },
  card: {
    height: SCREEN_HEIGHT,
    paddingHorizontal: 24,
    paddingTop: 60,
    paddingBottom: 40,
    backgroundColor: '#fafafa',
    borderBottomWidth: 6,
    borderBottomColor: '#e63946',
    justifyContent: 'flex-start',
  },
  cardHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 16,
  },
  source: { color: '#e63946', fontWeight: '800', fontSize: 13, letterSpacing: 1 },
  date: { color: '#888', fontSize: 12 },
  title: { fontSize: 26, fontWeight: '800', color: '#111', lineHeight: 34, marginBottom: 20 },
  summaryWrap: { flex: 1, justifyContent: 'flex-start' },
  summary: { fontSize: 18, lineHeight: 28, color: '#333' },
  readMore: { marginTop: 20, alignSelf: 'flex-start' },
  readMoreText: { color: '#e63946', fontWeight: '700', fontSize: 15 },
  centered: { flex: 1, alignItems: 'center', justifyContent: 'center', padding: 32 },
  loadingText: { color: '#ddd', marginTop: 16, fontSize: 16 },
  emoji: { fontSize: 56, marginBottom: 16 },
  errorTitle: { color: '#fff', fontSize: 22, fontWeight: '800', marginBottom: 10, textAlign: 'center' },
  errorBody: { color: '#bbb', fontSize: 15, textAlign: 'center', lineHeight: 22 },
  retry: {
    marginTop: 24,
    backgroundColor: '#e63946',
    paddingHorizontal: 28,
    paddingVertical: 12,
    borderRadius: 30,
  },
  retryText: { color: '#fff', fontWeight: '700', fontSize: 15 },
  footer: { paddingVertical: 24 },
});
