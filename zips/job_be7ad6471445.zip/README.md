# Panorama

A small Flask app that puts Spanish-language headlines from Latin America and Spain on
one page, with filters for country, section and a free-text search. The headlines come
from the newsdata.io news API (https://newsdata.io) — a free API key is enough to run it.

I wrote it because following news from several countries at once meant keeping a dozen
tabs open. It stays deliberately small: one API client module, one Flask app, one
template. The interface is in Spanish; the code and this file are in English.

## What it does

- Latest articles in Spanish (`language=es`) from 21 countries — Argentina through
  Uruguay, plus Spain and Spanish-language media in the US.
- Filter by country and by section (política, economía, deportes, ciencia…), or search a
  term. Filters combine.
- Cursor pagination. The `nextPage` value returned by newsdata.io is passed back as
  `page`, and "más noticias" disappears once the cursor comes back null.
- Keyword chips on every card plus an aggregated *palabras clave* panel, both built from
  the `keywords` field. Clicking a keyword re-runs the search with it.
- A sentiment badge per article and a stacked bar showing the tone breakdown of the
  current page.
- Chips for `ai_tag`, and the `ai_summary` line in place of the description when it is
  present.
- `/api/articles` returns the same data as JSON if you only want the feed.
- Responses are cached in memory for five minutes, which matters: the free plan bills
  every request against a daily credit allowance.

Sentiment and the `ai_*` fields are only populated on paid newsdata.io plans. With a free
key the app still renders both widgets — the tone bar shows clearly-labelled sample
percentages and the badges read "sentimiento: sin dato" — so the layout does not collapse
into empty boxes. Nothing that is not real API output is presented as if it were.

## Setup

Python 3.9 or newer.

```
git clone https://github.com/<you>/panorama-noticias.git
cd panorama-noticias
python -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt
```

The API key is read from `NEWSDATA_API_KEY` and is never stored in the repo. Register at
https://newsdata.io, copy the key from the dashboard, then either export it:

```
export NEWSDATA_API_KEY=pub_xxxxxxxxxxxxxxxxxxxxxxxxxxxx
```

or copy `.env.example` to `.env` and fill it in. The app prints an explanatory message and
exits if the variable is missing.

## Run

```
python app.py
```

Open http://127.0.0.1:5000. Some URLs that work straight away:

- `/?country=mx&category=politics` — política mexicana
- `/?country=es&q=vivienda` — vivienda en medios españoles
- `/?q=sequ%C3%ADa` — every country, one topic

## JSON endpoint

`GET /api/articles` accepts the same `q`, `country`, `category` and `page` parameters, plus
`pages` (1–3) to walk that many cursor pages in one call.

```
$ curl -s 'http://127.0.0.1:5000/api/articles?country=mx&category=politics' \
    | python -m json.tool
```

Trimmed output from a free key (note the nulls — those are the paid-only fields):

```json
{
    "filters": {"q": "", "country": "mx", "category": "politics", "language": "es"},
    "count": 10,
    "total_results": 431,
    "next_page": "1757012400123456789",
    "sentiment": {
        "is_sample": true,
        "total": 0,
        "percent": {"positive": 26.0, "neutral": 55.0, "negative": 19.0},
        "note": "sample values; live sentiment requires a paid newsdata.io plan"
    },
    "articles": [
        {
            "article_id": "9c1f2b7e4a8d5c30b6e1f9a27d4c8b11",
            "title": "El Congreso aprueba en lo general la reforma al sistema de pensiones",
            "link": "https://diario-ejemplo.mx/politica/reforma-pensiones",
            "source": "Diario Ejemplo",
            "pub_date": "2026-09-03 11:20:00",
            "pub_date_human": "3 sep 2026, 11:20 UTC",
            "country": ["mexico"],
            "category": ["politics"],
            "keywords": ["pensiones", "congreso", "reforma"],
            "sentiment": null,
            "sentiment_stats": null,
            "ai_tag": [],
            "ai_summary": null
        }
    ],
    "source": "newsdata.io"
}
```

Errors come back as `{"error": "...", "code": "rate_limit"}` with a matching HTTP status
(429 for rate limits, 504 when newsdata.io is unreachable, 502 for anything else it
rejects).

## Configuration

All optional except the first one.

| Variable | Default | Meaning |
| --- | --- | --- |
| `NEWSDATA_API_KEY` | — | Required. Your newsdata.io key. |
| `DEFAULT_COUNTRY` | *(none)* | Two-letter code preselected on first load, e.g. `co`. |
| `PAGE_SIZE` | `10` | Articles per request. Clamped to 10 unless paid mode is on. |
| `CACHE_TTL` | `300` | Seconds to cache a response. `0` disables the cache. |
| `NEWSDATA_PAID_MODE` | `0` | Set to `1` to send query parameters that the free plan rejects. |
| `NEWSDATA_TIMEFRAME` | *(none)* | Hours to look back, e.g. `24`. Only sent in paid mode. |
| `PORT` | `5000` | Port for the dev server. |
| `FLASK_DEBUG` | `0` | Set to `1` for the reloader. |

## Notes on the free plan

The distinction that matters when working against this API is between response fields and
query parameters.

Paid *response fields* (`sentiment`, `sentiment_stats`, `ai_tag`, `ai_region`, `ai_org`,
`ai_summary`) are safe to ask for: on a free key they simply arrive empty, or as the
literal string `ONLY AVAILABLE IN PROFESSIONAL AND CORPORATE PLANS`. `newsdata.py` filters
that placeholder out in `_clean_text`, so the templates only ever see real values or
`None`.

Paid *query parameters* fail the whole request with a 4xx. On the default path the client
sends only `apikey`, `language`, `q`, `country`, `category`, `size` (≤10) and `page`.
`removeduplicate`, `timeframe`, `full_content`, `sentiment`, `tag`, `region` and friends
are added only when `NEWSDATA_PAID_MODE=1`, and if the API still answers 403 or 422 the
request is retried once with them stripped — so switching paid mode on by mistake
degrades to free results instead of an error page. The `/archive` and `/count` endpoints
are not used at all.

The free plan also allows a single value per filter, so the country selector is one
country at a time rather than a multi-select, and it caps out at 200 credits per day —
hence the cache. A 401 shows "la clave no es válida", a 429 shows a wait-a-few-minutes
notice, and an empty `results` array shows an empty-state line rather than a blank page.

## Files

```
app.py                 Flask routes, filter parsing, aggregation for the side panels
newsdata.py            API client: auth, caching, pagination, error handling, field cleanup
templates/index.html   the single page
static/style.css       styles
```

## License

MIT.
