"""Small client for the newsdata.io news API (https://newsdata.io).

Only the /1/latest endpoint is used; it is available on every plan, free one
included. Query parameters that the free plan refuses (timeframe,
removeduplicate, page sizes above 10, ...) are sent only when paid mode is
enabled, and if the API still rejects the call the request is retried once with
those parameters stripped.

Paid *response* fields behave differently: they are always requested, and on a
free key they come back empty or as a placeholder string, which _clean_text
turns into None so the UI can show a labelled empty state.
"""

from __future__ import annotations

import threading
import time
from typing import Any, Dict, List, Optional

import requests

BASE_URL = "https://newsdata.io/api/1"
LATEST_PATH = "/latest"

# The free plan caps a page at 10 articles.
FREE_MAX_PAGE_SIZE = 10
MAX_PAGE_SIZE = 50

# Query parameters that error the whole request on a free key.
PAID_QUERY_PARAMS = frozenset(
    {
        "timeframe",
        "from_date",
        "to_date",
        "full_content",
        "sentiment",
        "sentiment_score",
        "tag",
        "region",
        "organization",
        "creator",
        "datatype",
        "prioritydomain",
        "removeduplicate",
        "excludefield",
    }
)

# Free keys return this text instead of a value for paid-only response fields.
_PLACEHOLDER_MARKERS = ("only available in", "only available for")

_VALID_SENTIMENT = ("positive", "neutral", "negative")


class NewsDataError(RuntimeError):
    """Raised when newsdata.io answers with something we cannot use.

    ``code`` is one of: auth, rate_limit, network, api.
    """

    def __init__(self, message: str, status: Optional[int] = None, code: str = "api"):
        super().__init__(message)
        self.status = status
        self.code = code


def _clean_text(value: Any) -> Optional[str]:
    """Return a usable string, or None for empty / paid-placeholder values."""
    if not isinstance(value, str):
        return None
    text = value.strip()
    if not text:
        return None
    lowered = text.lower()
    for marker in _PLACEHOLDER_MARKERS:
        if marker in lowered:
            return None
    return text


def _clean_list(value: Any) -> List[str]:
    if isinstance(value, list):
        cleaned = [_clean_text(item) for item in value]
        return [item for item in cleaned if item]
    single = _clean_text(value)
    return [single] if single else []


def _clean_sentiment(value: Any) -> Optional[str]:
    text = _clean_text(value)
    if text and text.lower() in _VALID_SENTIMENT:
        return text.lower()
    return None


def _clean_sentiment_stats(value: Any) -> Optional[Dict[str, float]]:
    if not isinstance(value, dict):
        return None
    stats: Dict[str, float] = {}
    for key in _VALID_SENTIMENT:
        raw = value.get(key)
        if isinstance(raw, (int, float)):
            stats[key] = round(float(raw), 2)
    return stats or None


def normalize_article(raw: Dict[str, Any]) -> Dict[str, Any]:
    """Flatten one API result into the shape the templates expect."""
    return {
        "article_id": raw.get("article_id") or "",
        "title": _clean_text(raw.get("title")) or "(sin título)",
        "link": raw.get("link") or "",
        "description": _clean_text(raw.get("description")),
        "image_url": _clean_text(raw.get("image_url")),
        "pub_date": raw.get("pubDate") or "",
        "source": (
            _clean_text(raw.get("source_name"))
            or _clean_text(raw.get("source_id"))
            or "fuente desconocida"
        ),
        "source_url": _clean_text(raw.get("source_url")),
        "language": _clean_text(raw.get("language")),
        "country": _clean_list(raw.get("country")),
        "category": _clean_list(raw.get("category")),
        "creator": _clean_list(raw.get("creator")),
        # Free on every plan - the app leans on this one.
        "keywords": _clean_list(raw.get("keywords"))[:8],
        # Paid response fields: absent on a free key, hence the cleaning above.
        "sentiment": _clean_sentiment(raw.get("sentiment")),
        "sentiment_stats": _clean_sentiment_stats(raw.get("sentiment_stats")),
        "ai_tag": _clean_list(raw.get("ai_tag"))[:6],
        "ai_region": _clean_list(raw.get("ai_region"))[:4],
        "ai_org": _clean_list(raw.get("ai_org"))[:4],
        "ai_summary": _clean_text(raw.get("ai_summary")),
    }


def _drop_paid_params(params: Dict[str, Any]) -> Dict[str, Any]:
    downgraded = {k: v for k, v in params.items() if k not in PAID_QUERY_PARAMS}
    size = downgraded.get("size")
    try:
        if size is not None and int(size) > FREE_MAX_PAGE_SIZE:
            downgraded["size"] = FREE_MAX_PAGE_SIZE
    except (TypeError, ValueError):
        downgraded.pop("size", None)
    return downgraded


def _error_message(response: requests.Response) -> str:
    try:
        body = response.json()
    except ValueError:
        text = (response.text or "").strip()
        return text[:200] or "HTTP {}".format(response.status_code)
    if isinstance(body, dict):
        results = body.get("results")
        if isinstance(results, dict):
            message = results.get("message") or results.get("code")
            if message:
                return str(message)
        message = body.get("message")
        if message:
            return str(message)
    return "HTTP {}".format(response.status_code)


class NewsDataClient:
    """Fetches articles from newsdata.io with a small in-memory response cache."""

    def __init__(
        self,
        api_key: str,
        *,
        paid_mode: bool = False,
        timeframe: Optional[str] = None,
        timeout: float = 20.0,
        cache_ttl: int = 300,
        session: Optional[requests.Session] = None,
    ):
        if not api_key:
            raise NewsDataError("missing newsdata.io API key", code="auth")
        self._api_key = api_key
        self.paid_mode = bool(paid_mode)
        self.timeframe = timeframe
        self.timeout = timeout
        self.cache_ttl = max(0, int(cache_ttl))
        self._session = session or requests.Session()
        self._cache: Dict[Any, Any] = {}
        self._lock = threading.Lock()

    # -- cache -----------------------------------------------------------

    def _cache_lookup(self, key):
        if self.cache_ttl <= 0:
            return None
        with self._lock:
            entry = self._cache.get(key)
            if not entry:
                return None
            expires_at, payload = entry
            if expires_at < time.time():
                self._cache.pop(key, None)
                return None
            return payload

    def _cache_store(self, key, payload):
        if self.cache_ttl <= 0:
            return
        with self._lock:
            if len(self._cache) > 128:
                self._cache.clear()
            self._cache[key] = (time.time() + self.cache_ttl, payload)

    # -- transport -------------------------------------------------------

    def _get(self, path: str, params: Dict[str, Any], allow_downgrade: bool = True):
        query = {k: v for k, v in params.items() if v not in (None, "", [])}
        cache_key = (path, tuple(sorted((k, str(v)) for k, v in query.items())))
        cached = self._cache_lookup(cache_key)
        if cached is not None:
            return cached

        try:
            response = self._session.get(
                BASE_URL + path,
                params=query,
                headers={
                    "X-ACCESS-KEY": self._api_key,
                    "Accept": "application/json",
                    "User-Agent": "panorama-noticias/1.0",
                },
                timeout=self.timeout,
            )
        except requests.RequestException as exc:
            raise NewsDataError(
                "could not reach newsdata.io: {}".format(exc), code="network"
            ) from exc

        if response.status_code == 401:
            raise NewsDataError(
                "newsdata.io rejected the API key (401)", 401, "auth"
            )
        if response.status_code == 429:
            raise NewsDataError(
                "newsdata.io rate limit reached (429)", 429, "rate_limit"
            )
        if response.status_code in (403, 422) and allow_downgrade:
            downgraded = _drop_paid_params(query)
            if downgraded != query:
                # Most likely a paid-only parameter on a free plan: try again
                # without them so the user still gets articles.
                return self._get(path, downgraded, allow_downgrade=False)
        if response.status_code >= 400:
            raise NewsDataError(
                _error_message(response), response.status_code, "api"
            )

        try:
            payload = response.json()
        except ValueError as exc:
            raise NewsDataError(
                "newsdata.io returned a non-JSON body", response.status_code, "api"
            ) from exc

        if not isinstance(payload, dict):
            raise NewsDataError("unexpected response shape", code="api")
        if payload.get("status") not in (None, "success"):
            results = payload.get("results")
            message = (
                results.get("message")
                if isinstance(results, dict)
                else payload.get("message")
            )
            raise NewsDataError(str(message or "newsdata.io returned an error"), code="api")

        self._cache_store(cache_key, payload)
        return payload

    # -- public API ------------------------------------------------------

    def fetch_latest(
        self,
        *,
        q: Optional[str] = None,
        country: Optional[str] = None,
        category: Optional[str] = None,
        language: str = "es",
        size: Optional[int] = None,
        page: Optional[str] = None,
    ) -> Dict[str, Any]:
        """One call to /1/latest. Returns the raw payload."""
        requested = FREE_MAX_PAGE_SIZE if size is None else int(size)
        ceiling = MAX_PAGE_SIZE if self.paid_mode else FREE_MAX_PAGE_SIZE
        params: Dict[str, Any] = {
            "language": language,
            "q": q,
            "country": country,
            "category": category,
            "size": max(1, min(requested, ceiling)),
            "page": page,
        }
        if self.paid_mode:
            # Everything below needs a paid plan; a free key would 4xx on them.
            params["removeduplicate"] = 1
            if self.timeframe:
                params["timeframe"] = self.timeframe
        return self._get(LATEST_PATH, params)

    def fetch_many(
        self,
        *,
        q: Optional[str] = None,
        country: Optional[str] = None,
        category: Optional[str] = None,
        language: str = "es",
        size: Optional[int] = None,
        page: Optional[str] = None,
        max_pages: int = 1,
    ) -> Dict[str, Any]:
        """Walk up to ``max_pages`` cursor pages and normalize the articles.

        Pagination follows the documented cursor: the ``nextPage`` value of one
        response is sent back as ``page`` on the next one, and the loop stops as
        soon as it is null.
        """
        cursor = page
        articles: List[Dict[str, Any]] = []
        seen = set()
        total = 0

        for _ in range(max(1, int(max_pages))):
            payload = self.fetch_latest(
                q=q,
                country=country,
                category=category,
                language=language,
                size=size,
                page=cursor,
            )
            reported = payload.get("totalResults")
            if isinstance(reported, int):
                total = reported
            results = payload.get("results")
            if not isinstance(results, list):
                results = []
            for raw in results:
                if not isinstance(raw, dict):
                    continue
                article = normalize_article(raw)
                key = article["article_id"] or article["link"] or article["title"]
                if key in seen:
                    continue
                seen.add(key)
                articles.append(article)
            cursor = payload.get("nextPage") or None
            if not cursor:
                break

        return {"articles": articles, "next_page": cursor, "total": total}
