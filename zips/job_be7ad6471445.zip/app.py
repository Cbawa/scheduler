#!/usr/bin/env python3
"""Panorama - Spanish-language news aggregator on top of the newsdata.io API.

    python app.py

Needs NEWSDATA_API_KEY in the environment (or in a .env file next to this one).
"""

from __future__ import annotations

import os
import sys
from datetime import datetime
from typing import Any, Dict, List, Optional, Tuple

from dotenv import load_dotenv
from flask import Flask, jsonify, render_template, request, url_for

from newsdata import FREE_MAX_PAGE_SIZE, NewsDataClient, NewsDataError

load_dotenv()

# --- catalogues -----------------------------------------------------------

# The free plan accepts a single value per filter, so this is a one-at-a-time
# selector rather than a multi-select.
COUNTRIES: List[Tuple[str, str]] = [
    ("", "Todos los países"),
    ("ar", "Argentina"),
    ("bo", "Bolivia"),
    ("cl", "Chile"),
    ("co", "Colombia"),
    ("cr", "Costa Rica"),
    ("cu", "Cuba"),
    ("do", "República Dominicana"),
    ("ec", "Ecuador"),
    ("sv", "El Salvador"),
    ("es", "España"),
    ("us", "Estados Unidos"),
    ("gt", "Guatemala"),
    ("hn", "Honduras"),
    ("mx", "México"),
    ("ni", "Nicaragua"),
    ("pa", "Panamá"),
    ("py", "Paraguay"),
    ("pe", "Perú"),
    ("pr", "Puerto Rico"),
    ("uy", "Uruguay"),
    ("ve", "Venezuela"),
]

CATEGORIES: List[Tuple[str, str]] = [
    ("", "Todas las secciones"),
    ("top", "Portada"),
    ("politics", "Política"),
    ("business", "Economía"),
    ("world", "Internacional"),
    ("sports", "Deportes"),
    ("technology", "Tecnología"),
    ("science", "Ciencia"),
    ("health", "Salud"),
    ("environment", "Medioambiente"),
    ("entertainment", "Entretenimiento"),
    ("crime", "Sucesos"),
    ("education", "Educación"),
    ("food", "Gastronomía"),
    ("tourism", "Turismo"),
    ("lifestyle", "Estilo de vida"),
]

COUNTRY_CODES = {code for code, _ in COUNTRIES if code}
CATEGORY_CODES = {code for code, _ in CATEGORIES if code}
CATEGORY_NAMES = {code: name for code, name in CATEGORIES if code}

SENTIMENT_LABELS = {
    "positive": "positivo",
    "neutral": "neutral",
    "negative": "negativo",
}

# Shown only when the key returns no sentiment at all, and always labelled as a
# sample in the template so it cannot be mistaken for live data.
SAMPLE_SENTIMENT = {"positive": 26.0, "neutral": 55.0, "negative": 19.0}
SAMPLE_AI_TAGS = ["política", "economía", "deportes", "medioambiente", "tecnología"]

MESES = (
    "ene", "feb", "mar", "abr", "may", "jun",
    "jul", "ago", "sep", "oct", "nov", "dic",
)

HTTP_STATUS = {"auth": 500, "rate_limit": 429, "network": 504, "api": 502}


# --- configuration --------------------------------------------------------

def env_flag(name: str, default: bool = False) -> bool:
    raw = os.environ.get(name)
    if raw is None:
        return default
    return raw.strip().lower() in {"1", "true", "yes", "on"}


def env_int(name: str, default: int, minimum: int, maximum: int) -> int:
    raw = os.environ.get(name, "").strip()
    if not raw:
        return default
    try:
        return max(minimum, min(int(raw), maximum))
    except ValueError:
        return default


PAID_MODE = env_flag("NEWSDATA_PAID_MODE")
CACHE_TTL = env_int("CACHE_TTL", 300, 0, 86400)
PAGE_SIZE = env_int("PAGE_SIZE", FREE_MAX_PAGE_SIZE, 1, 50)
TIMEFRAME = os.environ.get("NEWSDATA_TIMEFRAME", "").strip() or None

DEFAULT_COUNTRY = os.environ.get("DEFAULT_COUNTRY", "").strip().lower()
if DEFAULT_COUNTRY not in COUNTRY_CODES:
    DEFAULT_COUNTRY = ""

API_KEY = os.environ.get("NEWSDATA_API_KEY", "").strip()
if not API_KEY:
    sys.stderr.write(
        "NEWSDATA_API_KEY is not set.\n\n"
        "Panorama reads its key from the environment. Get a free one at\n"
        "https://newsdata.io and then either export it:\n\n"
        "    export NEWSDATA_API_KEY=pub_xxxxxxxxxxxxxxxxxxxx\n\n"
        "or copy .env.example to .env and fill in the value.\n"
    )
    raise SystemExit(1)

client = NewsDataClient(
    API_KEY,
    paid_mode=PAID_MODE,
    timeframe=TIMEFRAME,
    cache_ttl=CACHE_TTL,
)

app = Flask(__name__)
try:  # keep accents readable in the JSON endpoint
    app.json.ensure_ascii = False
except AttributeError:  # Flask < 2.2
    app.config["JSON_AS_ASCII"] = False


# --- helpers --------------------------------------------------------------

def read_filters(args) -> Dict[str, str]:
    raw_country = args.get("country")
    country = (raw_country if raw_country is not None else DEFAULT_COUNTRY).strip().lower()
    if country not in COUNTRY_CODES:
        country = ""

    category = (args.get("category") or "").strip().lower()
    if category not in CATEGORY_CODES:
        category = ""

    return {
        "q": (args.get("q") or "").strip()[:120],
        "country": country,
        "category": category,
        "page": (args.get("page") or "").strip()[:200],
    }


def human_date(value: str) -> str:
    if not value:
        return ""
    stamp = value.replace("T", " ")[:19]
    try:
        parsed = datetime.strptime(stamp, "%Y-%m-%d %H:%M:%S")
    except ValueError:
        return value
    return "{} {} {}, {:%H:%M} UTC".format(
        parsed.day, MESES[parsed.month - 1], parsed.year, parsed
    )


def decorate(article: Dict[str, Any]) -> Dict[str, Any]:
    article["pub_date_human"] = human_date(article.get("pub_date", ""))
    return article


def sentiment_breakdown(articles: List[Dict[str, Any]]) -> Dict[str, Any]:
    """Tone split of the current page.

    A free key never fills `sentiment`, so instead of hiding the widget we keep
    it on screen with sample percentages and flag them as such.
    """
    counts = {"positive": 0, "neutral": 0, "negative": 0}
    for article in articles:
        label = article.get("sentiment")
        if label in counts:
            counts[label] += 1

    total = sum(counts.values())
    if total == 0:
        return {
            "is_sample": True,
            "total": 0,
            "counts": {"positive": 0, "neutral": 0, "negative": 0},
            "percent": dict(SAMPLE_SENTIMENT),
            "note": "sample values; live sentiment requires a paid newsdata.io plan",
        }

    return {
        "is_sample": False,
        "total": total,
        "counts": counts,
        "percent": {k: round(v * 100.0 / total, 1) for k, v in counts.items()},
        "note": "computed from the sentiment field of this page",
    }


def top_terms(articles: List[Dict[str, Any]], field: str, limit: int = 14):
    counts: Dict[str, int] = {}
    for article in articles:
        for term in article.get(field) or []:
            key = term.strip().lower()
            if len(key) < 2:
                continue
            counts[key] = counts.get(key, 0) + 1
    ranked = sorted(counts.items(), key=lambda item: (-item[1], item[0]))
    return ranked[:limit]


def friendly_error(exc: NewsDataError) -> str:
    if exc.code == "auth":
        return (
            "La clave de newsdata.io no es válida o ha caducado. "
            "Revisa la variable NEWSDATA_API_KEY."
        )
    if exc.code == "rate_limit":
        return (
            "Se alcanzó el límite de peticiones de newsdata.io. "
            "Espera unos minutos antes de recargar."
        )
    if exc.code == "network":
        return "No se pudo conectar con newsdata.io. Comprueba tu conexión."
    return "newsdata.io devolvió un error: {}".format(exc)


def build_url(filters: Dict[str, str], page: Optional[str] = None) -> str:
    params = {
        "q": filters["q"] or None,
        "country": filters["country"] or None,
        "category": filters["category"] or None,
        "page": page or None,
    }
    return url_for("index", **{k: v for k, v in params.items() if v})


# --- routes ---------------------------------------------------------------

@app.route("/")
def index():
    filters = read_filters(request.args)
    error = None
    data = {"articles": [], "next_page": None, "total": 0}

    try:
        data = client.fetch_many(
            q=filters["q"] or None,
            country=filters["country"] or None,
            category=filters["category"] or None,
            size=PAGE_SIZE,
            page=filters["page"] or None,
            max_pages=1,
        )
    except NewsDataError as exc:
        error = friendly_error(exc)

    articles = [decorate(a) for a in data["articles"]]

    return render_template(
        "index.html",
        page_title="Panorama — noticias en español",
        filters=filters,
        countries=COUNTRIES,
        categories=CATEGORIES,
        category_names=CATEGORY_NAMES,
        sentiment_labels=SENTIMENT_LABELS,
        articles=articles,
        total=data["total"],
        error=error,
        sentiment=sentiment_breakdown(articles),
        keywords=top_terms(articles, "keywords"),
        ai_tags=top_terms(articles, "ai_tag", limit=10),
        sample_ai_tags=SAMPLE_AI_TAGS,
        next_url=build_url(filters, data["next_page"]) if data["next_page"] else None,
        reset_url=url_for("index"),
        cache_ttl=CACHE_TTL,
        paid_mode=PAID_MODE,
    )


@app.route("/api/articles")
def api_articles():
    filters = read_filters(request.args)
    try:
        pages = max(1, min(int(request.args.get("pages", 1)), 3))
    except (TypeError, ValueError):
        pages = 1

    try:
        data = client.fetch_many(
            q=filters["q"] or None,
            country=filters["country"] or None,
            category=filters["category"] or None,
            size=PAGE_SIZE,
            page=filters["page"] or None,
            max_pages=pages,
        )
    except NewsDataError as exc:
        return (
            jsonify({"error": friendly_error(exc), "code": exc.code}),
            HTTP_STATUS.get(exc.code, 502),
        )

    articles = [decorate(a) for a in data["articles"]]
    return jsonify(
        {
            "filters": {
                "q": filters["q"],
                "country": filters["country"],
                "category": filters["category"],
                "language": "es",
            },
            "count": len(articles),
            "total_results": data["total"],
            "next_page": data["next_page"],
            "pages_fetched": pages,
            "sentiment": sentiment_breakdown(articles),
            "keywords": [{"term": t, "count": c} for t, c in top_terms(articles, "keywords")],
            "articles": articles,
            "source": "newsdata.io",
        }
    )


@app.errorhandler(404)
def not_found(_exc):
    return (
        jsonify({"error": "ruta no encontrada"})
        if request.path.startswith("/api/")
        else ("<p>Página no encontrada. <a href=\"/\">Volver a Panorama</a>.</p>", 404)
    )


if __name__ == "__main__":
    port = env_int("PORT", 5000, 1, 65535)
    app.run(host=os.environ.get("HOST", "127.0.0.1"), port=port, debug=env_flag("FLASK_DEBUG"))
