"""LangChain tool wrapping the newsdata.io news API (https://newsdata.io).

The core path uses only free-tier-safe parameters on the /1/latest endpoint. Paid-only
response fields (sentiment, ai_tag, ai_summary, ...) are read when present and quietly
skipped when absent, so this runs unchanged on a brand-new free key.
"""

import os

import requests
from langchain_core.tools import tool

API_URL = "https://newsdata.io/api/1/latest"
TIMEOUT = 20
MAX_ARTICLES = 8


def _request(params):
    return requests.get(API_URL, params=params, timeout=TIMEOUT)


def _format(results, query):
    lines = [f"Found {len(results)} recent article(s) for '{query}':", ""]
    saw_sentiment = False
    saw_ai = False

    for i, art in enumerate(results, 1):
        title = art.get("title") or "(untitled)"
        source = art.get("source_id") or art.get("source_name") or "unknown source"
        date = art.get("pubDate") or ""
        link = art.get("link") or ""

        lines.append(f"{i}. {title}")
        lines.append(f"   source: {source}  {date}".rstrip())
        if link:
            lines.append(f"   link: {link}")

        keywords = art.get("keywords")
        if isinstance(keywords, list) and keywords:
            lines.append("   keywords: " + ", ".join(str(k) for k in keywords[:6]))

        # Paid-plan response fields: present only on paid newsdata.io keys.
        sentiment = art.get("sentiment")
        if sentiment:
            saw_sentiment = True
            lines.append(f"   sentiment: {sentiment}")

        ai_tag = art.get("ai_tag")
        if isinstance(ai_tag, list) and ai_tag:
            saw_ai = True
            lines.append("   ai_tags: " + ", ".join(str(t) for t in ai_tag[:6]))
        elif isinstance(ai_tag, str) and ai_tag:
            saw_ai = True
            lines.append(f"   ai_tags: {ai_tag}")

        ai_summary = art.get("ai_summary")
        if isinstance(ai_summary, str) and ai_summary.strip():
            saw_ai = True
            lines.append(f"   ai_summary: {ai_summary.strip()}")

        lines.append("")

    if not saw_sentiment and not saw_ai:
        lines.append(
            "(No sentiment or AI tag/summary fields were returned for these articles "
            "\u2014 those come from a paid newsdata.io plan and are absent on a free key.)"
        )

    return "\n".join(lines).rstrip()


@tool
def search_news(query: str) -> str:
    """Search current news headlines for a topic, person, company, or place and return a
    list of recent articles with their source, publish date, link, and keywords. Use this
    whenever the user asks what is happening with something or wants recent news on it."""
    api_key = os.environ.get("NEWSDATA_API_KEY")
    if not api_key:
        return (
            "Error: NEWSDATA_API_KEY is not set. Get a free key at https://newsdata.io "
            "and export it before running."
        )

    language = os.environ.get("NEWS_LANGUAGE", "en")
    params = {"apikey": api_key, "q": query, "language": language}

    # Optional paid options. These query params error the whole request on a free key,
    # so they are only sent when explicitly enabled, and we retry without them on refusal.
    paid = os.environ.get("NEWSDATA_PAID") == "1"
    paid_keys = ["full_content"]
    if paid:
        params["full_content"] = 1

    try:
        resp = _request(params)
        if paid and resp.status_code in (403, 422):
            for key in paid_keys:
                params.pop(key, None)
            resp = _request(params)
    except requests.RequestException as e:
        return f"Error reaching newsdata.io: {e}"

    if resp.status_code == 401:
        return "Error: newsdata.io rejected the API key (401). Check NEWSDATA_API_KEY."
    if resp.status_code == 429:
        return "newsdata.io rate limit reached (429). Wait a moment and try again."
    if resp.status_code != 200:
        return f"newsdata.io returned HTTP {resp.status_code} for this query."

    try:
        data = resp.json()
    except ValueError:
        return "newsdata.io returned a response that could not be parsed as JSON."

    if data.get("status") == "error":
        message = (data.get("results") or {}).get("message", "unknown error")
        return f"newsdata.io error: {message}"

    results = data.get("results") or []
    if not results:
        return f"No recent articles found for '{query}'."

    return _format(results[:MAX_ARTICLES], query)
