"""Command-line entry point for the news LangChain agent.

Builds a tool-calling agent whose only tool is `search_news` (a wrapper around the
newsdata.io news API) and answers questions like "what's happening with X?".
"""

import os
import sys

try:
    from dotenv import load_dotenv
    load_dotenv()
except Exception:
    # python-dotenv is optional; real environment variables work fine without it.
    pass

from news_tool import search_news

SYSTEM_PROMPT = (
    "You are a news research assistant. When the user asks what is happening with a "
    "topic, person, company, or place, call the search_news tool to fetch current "
    "articles from the newsdata.io news API. Base your answer only on the articles you "
    "retrieve: summarize what is going on in a few sentences, then list the sources you "
    "used with their links. If the tool returns no articles, say so plainly instead of "
    "guessing."
)


def build_agent():
    """Construct the AgentExecutor. Imported lazily so missing keys fail with a clear
    message before any heavy imports run."""
    from langchain_anthropic import ChatAnthropic
    from langchain.agents import AgentExecutor, create_tool_calling_agent
    from langchain_core.prompts import ChatPromptTemplate

    model = os.environ.get("LLM_MODEL", "claude-sonnet-4-5")
    llm = ChatAnthropic(model=model, temperature=0)

    prompt = ChatPromptTemplate.from_messages(
        [
            ("system", SYSTEM_PROMPT),
            ("human", "{input}"),
            ("placeholder", "{agent_scratchpad}"),
        ]
    )
    tools = [search_news]
    agent = create_tool_calling_agent(llm, tools, prompt)
    return AgentExecutor(agent=agent, tools=tools, verbose=False)


def check_env():
    missing = []
    if not os.environ.get("NEWSDATA_API_KEY"):
        missing.append("NEWSDATA_API_KEY (free key from https://newsdata.io)")
    if not os.environ.get("ANTHROPIC_API_KEY"):
        missing.append("ANTHROPIC_API_KEY (the LLM that drives the agent)")
    if missing:
        print("Missing required environment variable(s):", file=sys.stderr)
        for m in missing:
            print(f"  - {m}", file=sys.stderr)
        sys.exit(1)


def ask(executor, question):
    try:
        result = executor.invoke({"input": question})
    except Exception as e:  # network, model, or auth errors from the LLM side
        print(f"Agent error: {e}", file=sys.stderr)
        return
    print("\n" + (result.get("output") or "(no answer)") + "\n")


def main():
    check_env()
    executor = build_agent()

    args = sys.argv[1:]
    if args:
        ask(executor, " ".join(args))
        return

    print("News agent ready. Ask about a topic, or press Enter / Ctrl-D to quit.")
    while True:
        try:
            question = input("\n> ").strip()
        except (EOFError, KeyboardInterrupt):
            print()
            break
        if not question:
            break
        ask(executor, question)


if __name__ == "__main__":
    main()
