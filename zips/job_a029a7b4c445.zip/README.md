# news-langchain-agent

Ask "what's happening with X?" and get a short, sourced answer built from current
headlines. It's a small [LangChain](https://python.langchain.com) agent with a single
tool: a wrapper around the newsdata.io news API (https://newsdata.io). The agent decides
when to search, reads back the articles, and writes a few sentences with links to the
sources it used.

Grab a free newsdata.io API key to run it.

## How it works

- `news_tool.py` exposes `search_news`, a LangChain tool that calls newsdata.io's
  `/1/latest` endpoint and returns recent articles (title, source, date, link, keywords).
- `main.py` builds a tool-calling agent around that tool and runs your question, either
  once from the command line or in a small interactive loop.

The agent is told to answer only from the articles it retrieved and to list the sources,
so replies stay grounded in what the news API actually returned.

## Setup

Requires Python 3.9+.

```bash
pip install -r requirements.txt
```

The agent needs two keys, both read from the environment:

```bash
export NEWSDATA_API_KEY=your_newsdata_key   # free key from https://newsdata.io
export ANTHROPIC_API_KEY=your_anthropic_key # the LLM that drives the agent
```

You can also put these in a `.env` file (see `.env.example`); it's loaded automatically.

## Run

One-shot:

```bash
python main.py "what's happening with the James Webb telescope?"
```

Interactive:

```bash
python main.py
```

### Sample output

```
$ python main.py "what's happening with renewable energy in Europe?"

There's been a run of recent coverage on Europe's renewable push: several countries
reported record solar output this summer, and there's ongoing debate about grid capacity
keeping up with new wind projects.

Sources:
- "Solar overtakes coal across the EU" — reuters (2026-06-11)
  https://example-news-source/solar-eu
- "Offshore wind permits face grid bottleneck" — bbc (2026-06-10)
  https://example-news-source/wind-grid
```

(Exact articles and sources depend on what newsdata.io returns at the time you run it.)

## Configuration

All optional, set as environment variables:

| Variable | Default | Notes |
| --- | --- | --- |
| `LLM_MODEL` | `claude-sonnet-4-5` | Any model id supported by `langchain-anthropic`. |
| `NEWS_LANGUAGE` | `en` | ISO language code passed to newsdata.io as `language`. |
| `NEWSDATA_PAID` | unset | Set to `1` to request paid-plan options (e.g. full content). On a free key these are rejected, so the tool automatically retries without them. |

## Notes on newsdata.io fields

Each article can carry extra fields like `sentiment`, `ai_tag`, and `ai_summary`. These
are part of newsdata.io's paid plans and are simply absent on a free key — the tool reads
them when present and otherwise just leaves them out, so the agent still works on the free
tier. When none of the returned articles include them, the tool appends a short note so
you can tell the difference between "neutral" and "not available on this plan".

## License

MIT
