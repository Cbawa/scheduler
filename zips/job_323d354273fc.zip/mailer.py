"""Send the rendered digest through the Mailgun HTTP API."""

from __future__ import annotations

import os
from typing import List

import requests


class MailerError(RuntimeError):
    """Raised when Mailgun configuration is missing or a send fails."""


def _require(name: str) -> str:
    value = os.environ.get(name, "").strip()
    if not value:
        raise MailerError(
            f"{name} is not set. Configure your Mailgun credentials (see .env.example)."
        )
    return value


def _recipients() -> List[str]:
    raw = _require("MAIL_TO")
    return [addr.strip() for addr in raw.split(",") if addr.strip()]


def send_email(subject: str, html_body: str) -> dict:
    """Send an HTML email via Mailgun. Returns the parsed Mailgun response."""
    api_key = _require("MAILGUN_API_KEY")
    domain = _require("MAILGUN_DOMAIN")
    sender = _require("MAIL_FROM")
    recipients = _recipients()

    base_url = os.environ.get("MAILGUN_BASE_URL", "https://api.mailgun.net").rstrip("/")
    endpoint = f"{base_url}/v3/{domain}/messages"

    try:
        resp = requests.post(
            endpoint,
            auth=("api", api_key),
            data={
                "from": sender,
                "to": recipients,
                "subject": subject,
                "html": html_body,
            },
            timeout=30,
        )
    except requests.RequestException as exc:
        raise MailerError(f"Network error contacting Mailgun: {exc}") from exc

    if resp.status_code == 401:
        raise MailerError("Mailgun rejected the credentials (401). Check MAILGUN_API_KEY.")
    if resp.status_code >= 400:
        raise MailerError(f"Mailgun returned HTTP {resp.status_code}: {resp.text[:300]}")

    return resp.json()
