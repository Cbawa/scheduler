# 📰 News Email Digest

Automated **daily email digest** of top headlines from the [newsdata.io](https://newsdata.io) news API — rendered as a responsive HTML email with [MJML](https://mjml.io) and delivered via [Mailgun](https://www.mailgun.com).

Perfect as a personal morning briefing or a lightweight newsletter for your team. Runs fine on the **newsdata.io free tier**.

```
┌─────────────┐    ┌──────────────┐    ┌─────────────┐    ┌──────────┐
│ newsdata.io │ →  │  build MJML  │ →  │ render HTML │ →  │ Mailgun  │
│   /news     │    │   template   │    │   (mrml)    │    │  send ✉  │
└─────────────┘    └──────────────┘    └─────────────┘    └──────────┘
```

## Features

- 🗞️ Pulls the latest headlines from newsdata.io with filters for **country**, **language** and **category**.
- 📄 **Pagination** support via the `nextPage` token so you can gather more than one page of stories.
- 🎨 Beautiful, mobile-friendly emails built with **MJML** and compiled in pure Python (no Node.js required, thanks to [`mrml`](https://pypi.org/project/mrml/)).
- 📬 One-call delivery through the **Mailgun** HTTP API.
- 🛟 **Free-tier safe**: gracefully handles invalid keys (401), rate limits (429), paid-only upgrade responses (403/422) and empty result sets — it never crashes.
- 🔍 `--dry-run` mode writes the rendered HTML to a file so you can preview without sending.

## Requirements

- Python 3.9+
- A free **newsdata.io** API key — get one at <https://newsdata.io/register>
- A **Mailgun** account (the free/sandbox domain works for testing)

## Installation

```bash
git clone https://github.com/your-username/news-email-digest.git
cd news-email-digest
python -m venv .venv && source .venv/bin/activate   # Windows: .venv\Scripts\activate
pip install -r requirements.txt
```

## Configuration

All configuration is via environment variables. Copy the example file and fill it in:

```bash
cp .env.example .env
```

| Variable             | Required | Description                                                        |
|----------------------|----------|--------------------------------------------------------------------|
| `NEWSDATA_API_KEY`   | ✅       | Your newsdata.io API key.                                          |
| `MAILGUN_API_KEY`    | ✅*      | Your Mailgun private API key (`key-...`). *Not needed for dry runs.|
| `MAILGUN_DOMAIN`     | ✅*      | Your Mailgun sending domain, e.g. `mg.example.com`.                |
| `MAIL_FROM`          | ✅*      | The `From` address, e.g. `Daily Digest <digest@mg.example.com>`.   |
| `MAIL_TO`            | ✅*      | Comma-separated list of recipient addresses.                       |
| `DIGEST_COUNTRY`     | ❌       | Country filter, e.g. `us` (default: none).                         |
| `DIGEST_LANGUAGE`    | ❌       | Language filter, e.g. `en` (default: `en`).                        |
| `DIGEST_CATEGORY`    | ❌       | Category filter, e.g. `top`, `technology`, `business`.             |
| `DIGEST_QUERY`       | ❌       | Free-text search term for the `q` parameter.                       |
| `DIGEST_MAX_ITEMS`   | ❌       | Max number of articles in the digest (default: `10`).              |
| `MAILGUN_BASE_URL`   | ❌       | Override for EU region: `https://api.eu.mailgun.net`.              |

The app reads `.env` automatically (via `python-dotenv`). Real environment variables take precedence, so cron/CI exports win.

## Usage

Preview without sending — writes `digest.html` you can open in a browser:

```bash
python digest.py --dry-run
```

Send the digest for real:

```bash
python digest.py
```

Useful flags (these override the matching env vars):

```bash
python digest.py --country us --category technology --max-items 8
python digest.py --query "climate" --language en
python digest.py --pages 2          # fetch up to 2 pages via nextPage
python digest.py --dry-run --out preview.html
```

## Schedule it daily (cron)

Send every morning at 07:00:

```cron
0 7 * * *  cd /path/to/news-email-digest && /path/to/.venv/bin/python digest.py >> digest.log 2>&1
```

## Free vs. paid plan

This project is built entirely around the newsdata.io **free tier** (`/news` endpoint with `q`, `country`, `language`, `category` and `page` pagination).

The following are **paid-only** features and are intentionally **not** part of the core flow:

- Sentiment analysis and AI fields (`ai_tag`, `ai_region`, `ai_org`, `ai_summary`).
- The historical `/archive` endpoint and long date ranges.
- Advanced full-text query operators.

If your key lacks access to an optional feature, newsdata.io returns a 403/422 "upgrade your plan" response; the client detects this, logs a friendly note, and continues without that feature so the digest still goes out.

## Project layout

```
news-email-digest/
├── digest.py            # CLI entry point — fetch, render, send
├── newsdata_client.py   # newsdata.io API wrapper (free-tier safe)
├── email_builder.py     # builds the MJML template & renders to HTML
├── requirements.txt
├── .env.example
└── .gitignore
```

## License

MIT — see the header of each file. Built to showcase the [newsdata.io](https://newsdata.io) news API.
