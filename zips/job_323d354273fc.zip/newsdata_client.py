"""Thin, free-tier-safe wrapper around the newsdata.io news API.

Reads the API key from the NEWSDATA_API_KEY environment variable and exposes a
single `fetch_latest` helper that returns a list of article dicts. All known
error conditions (invalid key, rate limit, paid-only upgrade prompts and empty
results) are handled gracefully so callers never see an unhandled exception.
"""

from __future__ import annotations

import os
import time
from typing import Any, Dict, List, Optional

import requests

BASE_URL = "https://newsdata.io/api/1"
NEWS_ENDPOINT = f"{BASE_URL}/news"


class NewsDataError(RuntimeError):
    """Raised for unrecoverable newsdata.io problems (e.g. invalid API key)."""


def get_api_key() -> str:
    """Return the API key or raise a clear error if it is missing."""
    key = os.environ.get("NEWSDATA_API_KEY", "").strip()
    if not key:
        raise NewsDataError(
            "NEWSDATA_API_KEY is not set. Get a free key at "
            "https://newsdata.io/register and export it, e.g.\n"
            "  export NEWSDATA_API_KEY=pub_xxxxxxxx"
        )
    return key


def _request(params: Dict[str, Any], *, max_retries: int = 3) -> Optional[Dict[str, Any]]:
    """Perform a single GET /news request with basic retry on rate limits.

    Returns the parsed JSON body, or None if the request should be skipped
    (e.g. a paid-only feature was rejected) so the caller can degrade.
    """
    for attempt in range(1, max_retries + 1):
        try:
            resp = requests.get(NEWS_ENDPOINT, params=params, timeout=30)
        except requests.RequestException as exc:
            if attempt == max_retries:
                raise NewsDataError(f"Network error contacting newsdata.io: {exc}") from exc
            time.sleep(2 * attempt)
            continue

        if resp.status_code == 200:
            return resp.json()

        if resp.status_code == 401:
            raise NewsDataError(
                "newsdata.io rejected the API key (401). Double-check NEWSDATA_API_KEY."
            )

        if resp.status_code == 429:
            # Rate limited — back off and retry a couple of times.
            if attempt == max_retries:
                print("[newsdata] Rate limited (429) and out of retries — returning what we have.")
                return None
            wait = 5 * attempt
            print(f"[newsdata] Rate limited (429); backing off {wait}s (attempt {attempt}).")
            time.sleep(wait)
            continue

        if resp.status_code in (403, 422):
            # Typically a paid-only feature / unsupported param on the free plan.
            message = _safe_message(resp)
            print(
                f"[newsdata] Request rejected ({resp.status_code}): {message}. "
                "This usually means a paid-only feature on the free plan — skipping it."
            )
            return None

        # Anything else: surface a concise error.
        raise NewsDataError(
            f"newsdata.io returned HTTP {resp.status_code}: {_safe_message(resp)}"
        )

    return None


def _safe_message(resp: requests.Response) -> str:
    try:
        body = resp.json()
    except ValueError:
        return resp.text[:200]
    if isinstance(body, dict):
        results = body.get("results")
        if isinstance(results, dict):
            return str(results.get("message") or results)
        return str(body.get("message") or body)
    return str(body)[:200]


def fetch_latest(
    *,
    query: Optional[str] = None,
    country: Optional[str] = None,
    language: Optional[str] = "en",
    category: Optional[str] = None,
    max_items: int = 10,
    max_pages: int = 1,
) -> List[Dict[str, Any]]:
    """Fetch the latest articles, following nextPage tokens as needed.

    Only free-tier parameters are used (q, country, language, category, page).
    Returns a (possibly empty) list of article dicts, trimmed to `max_items`.
    """
    api_key = get_api_key()

    base_params: Dict[str, Any] = {"apikey": api_key}
    if query:
        base_params["q"] = query
    if country:
        base_params["country"] = country
    if language:
        base_params["language"] = language
    if category:
        base_params["category"] = category

    articles: List[Dict[str, Any]] = []
    next_page: Optional[str] = None
    pages_fetched = 0

    while pages_fetched < max(1, max_pages) and len(articles) < max_items:
        params = dict(base_params)
        if next_page:
            params["page"] = next_page

        body = _request(params)
        pages_fetched += 1

        if not body:
            break

        results = body.get("results") or []
        if not isinstance(results, list):
            print("[newsdata] Unexpected 'results' shape — stopping pagination.")
            break

        articles.extend(results)

        next_page = body.get("nextPage")
        if not next_page:
            break

    if not articles:
        print("[newsdata] No articles returned for these filters.")

    return articles[:max_items]
