#!/usr/bin/env python3
"""News Email Digest — fetch top headlines from newsdata.io, render an MJML
email and deliver it via Mailgun.

Usage:
    python digest.py                 # build and send
    python digest.py --dry-run       # render to digest.html without sending
    python digest.py --country us --category technology --max-items 8

License: MIT.
"""

from __future__ import annotations

import argparse
import os
import sys
from datetime import datetime, timezone

from dotenv import load_dotenv

from email_builder import render_html
from mailer import MailerError, send_email
from newsdata_client import NewsDataError, fetch_latest


def _env(name: str, default=None):
    value = os.environ.get(name)
    return value if value not in (None, "") else default


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Daily news email digest powered by newsdata.io")
    parser.add_argument("--query", default=_env("DIGEST_QUERY"), help="Free-text search term (q)")
    parser.add_argument("--country", default=_env("DIGEST_COUNTRY"), help="Country filter, e.g. us")
    parser.add_argument("--language", default=_env("DIGEST_LANGUAGE", "en"), help="Language filter")
    parser.add_argument("--category", default=_env("DIGEST_CATEGORY"), help="Category filter")
    parser.add_argument(
        "--max-items", type=int, default=int(_env("DIGEST_MAX_ITEMS", 10)), help="Max articles"
    )
    parser.add_argument("--pages", type=int, default=1, help="Max pages to fetch (nextPage)")
    parser.add_argument("--subject", default=None, help="Override the email subject line")
    parser.add_argument("--dry-run", action="store_true", help="Render HTML to a file, do not send")
    parser.add_argument("--out", default="digest.html", help="Output file for --dry-run")
    return parser.parse_args()


def main() -> int:
    load_dotenv()
    args = parse_args()

    today = datetime.now(timezone.utc).strftime("%d %b %Y")
    subject = args.subject or f"\U0001F4F0 Your News Digest — {today}"

    try:
        articles = fetch_latest(
            query=args.query,
            country=args.country,
            language=args.language,
            category=args.category,
            max_items=args.max_items,
            max_pages=args.pages,
        )
    except NewsDataError as exc:
        print(f"Error: {exc}", file=sys.stderr)
        return 1

    print(f"Fetched {len(articles)} article(s).")

    html_body = render_html(articles, title="Your Daily News Digest")

    if args.dry_run:
        with open(args.out, "w", encoding="utf-8") as fh:
            fh.write(html_body)
        print(f"Dry run — wrote rendered email to {args.out!r}. Open it in a browser to preview.")
        return 0

    try:
        result = send_email(subject, html_body)
    except MailerError as exc:
        print(f"Error: {exc}", file=sys.stderr)
        return 1

    print(f"Sent! Mailgun id: {result.get('id', '<none>')}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
