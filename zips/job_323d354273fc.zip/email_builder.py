"""Build the digest email: turn articles into MJML and render to HTML.

Uses `mrml` (a pure-Python/Rust MJML engine) so no Node.js install is needed.
"""

from __future__ import annotations

import html
from datetime import datetime, timezone
from typing import Any, Dict, List

import mrml


def _esc(value: Any) -> str:
    """HTML-escape a value, tolerating None."""
    if value is None:
        return ""
    return html.escape(str(value))


def _truncate(text: str, limit: int = 220) -> str:
    text = (text or "").strip()
    if len(text) <= limit:
        return text
    return text[: limit - 1].rstrip() + "\u2026"


def _article_block(article: Dict[str, Any]) -> str:
    title = _esc(article.get("title") or "Untitled")
    link = _esc(article.get("link") or "#")
    description = _esc(_truncate(article.get("description") or ""))
    source = _esc(article.get("source_id") or "unknown source")
    pub_date = _esc(article.get("pubDate") or "")

    meta_parts = [p for p in (source, pub_date) if p]
    meta = " \u00b7 ".join(meta_parts)

    return f"""
    <mj-section padding=\"8px 0\">
      <mj-column>
        <mj-text font-size=\"18px\" font-weight=\"700\" line-height=\"24px\" color=\"#11181c\">
          <a href=\"{link}\" style=\"color:#11181c;text-decoration:none;\">{title}</a>
        </mj-text>
        <mj-text font-size=\"12px\" color=\"#687076\" padding-top=\"2px\">{meta}</mj-text>
        <mj-text font-size=\"14px\" color=\"#3c4043\" line-height=\"20px\" padding-top=\"6px\">{description}</mj-text>
        <mj-text padding-top=\"6px\">
          <a href=\"{link}\" style=\"color:#1971c2;font-size:13px;text-decoration:none;\">Read more &rarr;</a>
        </mj-text>
        <mj-divider border-width=\"1px\" border-color=\"#eceef0\" padding-top=\"12px\" />
      </mj-column>
    </mj-section>"""


def build_mjml(articles: List[Dict[str, Any]], *, title: str = "Your Daily News Digest") -> str:
    today = datetime.now(timezone.utc).strftime("%A, %d %B %Y")

    if articles:
        body_blocks = "\n".join(_article_block(a) for a in articles)
    else:
        body_blocks = """
        <mj-section>
          <mj-column>
            <mj-text font-size=\"15px\" color=\"#687076\" align=\"center\" padding=\"24px 0\">
              No fresh headlines matched your filters today. Check back tomorrow!
            </mj-text>
          </mj-column>
        </mj-section>"""

    return f"""<mjml>
  <mj-head>
    <mj-title>{html.escape(title)}</mj-title>
    <mj-attributes>
      <mj-all font-family=\"Helvetica, Arial, sans-serif\" />
    </mj-attributes>
    <mj-preview>Top headlines for {today}</mj-preview>
  </mj-head>
  <mj-body background-color=\"#f1f3f5\">
    <mj-section padding=\"24px 0 8px\">
      <mj-column>
        <mj-text font-size=\"24px\" font-weight=\"800\" color=\"#11181c\" align=\"center\">
          \U0001F4F0 {html.escape(title)}
        </mj-text>
        <mj-text font-size=\"13px\" color=\"#687076\" align=\"center\">{today}</mj-text>
      </mj-column>
    </mj-section>
    <mj-wrapper background-color=\"#ffffff\" border-radius=\"8px\" padding=\"8px 16px\">
      {body_blocks}
    </mj-wrapper>
    <mj-section padding=\"16px 0\">
      <mj-column>
        <mj-text font-size=\"11px\" color=\"#9aa0a6\" align=\"center\">
          Powered by <a href=\"https://newsdata.io\" style=\"color:#9aa0a6;\">newsdata.io</a>
          &middot; rendered with MJML &middot; delivered by Mailgun
        </mj-text>
      </mj-column>
    </mj-section>
  </mj-body>
</mjml>"""


def render_html(articles: List[Dict[str, Any]], *, title: str = "Your Daily News Digest") -> str:
    """Build the MJML for `articles` and compile it to responsive HTML."""
    mjml_source = build_mjml(articles, title=title)
    rendered = mrml.to_html(mjml_source)
    # mrml returns either a string or an object with `.content` depending on version.
    if isinstance(rendered, str):
        return rendered
    return getattr(rendered, "content", str(rendered))
