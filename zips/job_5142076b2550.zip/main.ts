import {
  Editor,
  MarkdownView,
  Notice,
  Plugin,
  PluginSettingTab,
  Setting,
  requestUrl,
} from "obsidian";

interface NewsPluginSettings {
  apiKey: string;
  language: string;
  resultCount: number;
  querySource: "title" | "selection" | "firstHeading";
  enablePaidFeatures: boolean;
  showSummary: boolean;
  showKeywords: boolean;
  showSentiment: boolean;
}

const DEFAULT_SETTINGS: NewsPluginSettings = {
  apiKey: "",
  language: "en",
  resultCount: 5,
  querySource: "title",
  enablePaidFeatures: false,
  showSummary: true,
  showKeywords: true,
  showSentiment: true,
};

const API_BASE = "https://newsdata.io/api/1/latest";

interface NewsArticle {
  article_id?: string;
  title?: string;
  link?: string;
  source_id?: string;
  source_name?: string;
  pubDate?: string;
  description?: string;
  keywords?: string[] | null;
  sentiment?: string | null;
  ai_tag?: string[] | string | null;
  ai_summary?: string | null;
}

interface NewsResponse {
  status?: string;
  totalResults?: number;
  results?: NewsArticle[];
  nextPage?: string | null;
  message?: string;
}

// Read the key from the environment only when the settings field is blank.
// process is unavailable on mobile / sandboxed builds, so guard the access.
function readEnvKey(): string | null {
  try {
    const proc = (globalThis as any).process;
    const value = proc?.env?.NEWSDATA_API_KEY;
    if (typeof value === "string" && value.trim()) return value.trim();
  } catch (error) {
    // ignore — fall through to null
  }
  return null;
}

function slug(value: string): string {
  return value
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/^-+|-+$/g, "")
    .slice(0, 40);
}

export default class NewsReferencePlugin extends Plugin {
  settings: NewsPluginSettings = DEFAULT_SETTINGS;

  async onload() {
    await this.loadSettings();

    this.addCommand({
      id: "append-related-news",
      name: "Append related news to current note",
      editorCallback: (editor: Editor, view: MarkdownView) =>
        this.appendNews(editor, view),
    });

    this.addRibbonIcon("newspaper", "Append related news", () => {
      const view = this.app.workspace.getActiveViewOfType(MarkdownView);
      if (view) {
        this.appendNews(view.editor, view);
      } else {
        new Notice("Open a note first.");
      }
    });

    this.addSettingTab(new NewsSettingTab(this.app, this));
  }

  async loadSettings() {
    this.settings = Object.assign({}, DEFAULT_SETTINGS, await this.loadData());
  }

  async saveSettings() {
    await this.saveData(this.settings);
  }

  resolveApiKey(): string {
    if (this.settings.apiKey.trim()) return this.settings.apiKey.trim();
    return readEnvKey() ?? "";
  }

  resolveQuery(editor: Editor, view: MarkdownView): string {
    const selection = editor.getSelection().trim();
    if (selection) return selection;
    if (this.settings.querySource === "firstHeading") {
      const match = editor.getValue().match(/^#{1,6}\s+(.+)$/m);
      if (match) return match[1].trim();
    }
    return view.file ? view.file.basename : "";
  }

  async appendNews(editor: Editor, view: MarkdownView) {
    const query = this.resolveQuery(editor, view);
    if (!query) {
      new Notice("Could not work out a search query for this note.");
      return;
    }
    new Notice(`Searching newsdata.io for "${query}"...`);
    try {
      const articles = await this.fetchNews(query);
      if (!articles.length) {
        new Notice(`No related news found for "${query}".`);
        return;
      }
      const markdown = this.buildMarkdown(query, articles);
      const lastLine = editor.lastLine();
      const lastCh = editor.getLine(lastLine).length;
      editor.replaceRange("\n" + markdown, { line: lastLine, ch: lastCh });
      new Notice(`Added ${articles.length} related article(s).`);
    } catch (error: any) {
      new Notice(error?.message ?? String(error));
    }
  }

  async fetchNews(query: string): Promise<NewsArticle[]> {
    const apiKey = this.resolveApiKey();
    if (!apiKey) {
      throw new Error(
        "No newsdata.io API key. Add one in the plugin settings or set NEWSDATA_API_KEY."
      );
    }

    const usePaid = this.settings.enablePaidFeatures;
    let response = await this.request(apiKey, query, usePaid);

    // Paid query params error the whole request on a free key — retry free.
    if (usePaid && (response.status === 403 || response.status === 422)) {
      response = await this.request(apiKey, query, false);
    }

    if (response.status === 401) {
      throw new Error("newsdata.io rejected the API key (401). Check it in settings.");
    }
    if (response.status === 429) {
      throw new Error("newsdata.io rate limit reached (429). Try again shortly.");
    }

    const body = (response.json ?? {}) as NewsResponse;
    if (response.status >= 400 || body.status === "error") {
      throw new Error(
        `newsdata.io error: ${body.message ?? `HTTP ${response.status}`}`
      );
    }

    const wanted = Math.min(Math.max(this.settings.resultCount, 1), 50);
    return (body.results ?? []).slice(0, wanted);
  }

  private async request(apiKey: string, query: string, usePaid: boolean) {
    const params = new URLSearchParams();
    params.set("apikey", apiKey);
    params.set("q", query);
    if (this.settings.language) params.set("language", this.settings.language);

    if (usePaid) {
      // size > 10 and full_content require a paid plan; only sent in paid mode.
      params.set("size", String(Math.min(Math.max(this.settings.resultCount, 1), 50)));
      params.set("full_content", "1");
    }

    return requestUrl({
      url: `${API_BASE}?${params.toString()}`,
      method: "GET",
      throw: false,
    });
  }

  buildMarkdown(query: string, articles: NewsArticle[]): string {
    const stamp = new Date().toISOString().slice(0, 10);
    const lines: string[] = [];
    lines.push("");
    lines.push(`## Related news — ${query} (${stamp})`);
    lines.push("");
    lines.push("_Headlines from the [newsdata.io](https://newsdata.io) news API._");
    lines.push("");

    if (this.settings.showSentiment) {
      lines.push(this.sentimentBreakdown(articles));
      lines.push("");
    }

    for (const article of articles) {
      lines.push(...this.renderArticle(article));
    }
    lines.push("");
    return lines.join("\n");
  }

  private renderArticle(a: NewsArticle): string[] {
    const out: string[] = [];
    const title = (a.title ?? "Untitled").replace(/\s+/g, " ").trim();
    const source = a.source_name ?? a.source_id ?? "unknown source";
    const date = a.pubDate ? a.pubDate.slice(0, 10) : "";

    let head = a.link ? `- [${title}](${a.link})` : `- ${title}`;
    head += ` — ${source}`;
    if (date) head += ` · ${date}`;
    // sentiment is a paid response field; only shown when present.
    if (this.settings.showSentiment && a.sentiment) {
      head += ` · sentiment: ${a.sentiment}`;
    }
    out.push(head);

    if (this.settings.showSummary) {
      // ai_summary is paid; fall back to the free description field.
      const summary = (a.ai_summary ?? a.description ?? "").replace(/\s+/g, " ").trim();
      if (summary) out.push(`    - ${summary}`);
    }

    if (this.settings.showKeywords) {
      const tags = this.collectTags(a);
      if (tags.length) {
        out.push(`    - tags: ${tags.map((t) => `#news/${slug(t)}`).join(" ")}`);
      }
    }
    return out;
  }

  private collectTags(a: NewsArticle): string[] {
    const set = new Set<string>();
    // keywords is returned on the free plan.
    if (Array.isArray(a.keywords)) {
      for (const k of a.keywords) if (k) set.add(k);
    }
    // ai_tag is a paid field; may be a string or an array, or absent.
    if (Array.isArray(a.ai_tag)) {
      for (const k of a.ai_tag) if (k) set.add(k);
    } else if (typeof a.ai_tag === "string" && a.ai_tag) {
      set.add(a.ai_tag);
    }
    return Array.from(set)
      .filter((t) => slug(t).length > 0)
      .slice(0, 6);
  }

  private sentimentBreakdown(articles: NewsArticle[]): string {
    const counts: Record<string, number> = { positive: 0, neutral: 0, negative: 0 };
    let have = false;
    for (const a of articles) {
      if (a.sentiment && a.sentiment in counts) {
        counts[a.sentiment] += 1;
        have = true;
      }
    }
    if (have) {
      return `> Sentiment: ${counts.positive} positive · ${counts.neutral} neutral · ${counts.negative} negative`;
    }
    // Free keys return no sentiment — show a clearly labelled sample.
    return "> Sentiment breakdown (sample — live sentiment needs a paid newsdata.io plan): e.g. 3 positive · 1 neutral · 1 negative";
  }
}

class NewsSettingTab extends PluginSettingTab {
  plugin: NewsReferencePlugin;

  constructor(app: any, plugin: NewsReferencePlugin) {
    super(app, plugin);
    this.plugin = plugin;
  }

  display(): void {
    const { containerEl } = this;
    containerEl.empty();

    new Setting(containerEl)
      .setName("API key")
      .setDesc(
        "newsdata.io API key. Leave blank to use the NEWSDATA_API_KEY environment variable (desktop only)."
      )
      .addText((text) =>
        text
          .setPlaceholder("pub_...")
          .setValue(this.plugin.settings.apiKey)
          .onChange(async (value) => {
            this.plugin.settings.apiKey = value.trim();
            await this.plugin.saveSettings();
          })
      );

    new Setting(containerEl)
      .setName("Language")
      .setDesc("Two-letter language code passed to the API (for example en, es, de).")
      .addText((text) =>
        text.setValue(this.plugin.settings.language).onChange(async (value) => {
          this.plugin.settings.language = value.trim();
          await this.plugin.saveSettings();
        })
      );

    new Setting(containerEl)
      .setName("Number of articles")
      .setDesc("How many articles to append (1 to 10 on the free plan).")
      .addSlider((slider) =>
        slider
          .setLimits(1, 10, 1)
          .setValue(Math.min(this.plugin.settings.resultCount, 10))
          .setDynamicTooltip()
          .onChange(async (value) => {
            this.plugin.settings.resultCount = value;
            await this.plugin.saveSettings();
          })
      );

    new Setting(containerEl)
      .setName("Search query source")
      .setDesc("What to search for when no text is selected.")
      .addDropdown((drop) =>
        drop
          .addOption("title", "Note title")
          .addOption("firstHeading", "First heading")
          .setValue(
            this.plugin.settings.querySource === "selection"
              ? "title"
              : this.plugin.settings.querySource
          )
          .onChange(async (value) => {
            this.plugin.settings.querySource = value as NewsPluginSettings["querySource"];
            await this.plugin.saveSettings();
          })
      );

    new Setting(containerEl).setName("Show AI summary").addToggle((toggle) =>
      toggle.setValue(this.plugin.settings.showSummary).onChange(async (value) => {
        this.plugin.settings.showSummary = value;
        await this.plugin.saveSettings();
      })
    );

    new Setting(containerEl).setName("Show keyword tags").addToggle((toggle) =>
      toggle.setValue(this.plugin.settings.showKeywords).onChange(async (value) => {
        this.plugin.settings.showKeywords = value;
        await this.plugin.saveSettings();
      })
    );

    new Setting(containerEl).setName("Show sentiment").addToggle((toggle) =>
      toggle.setValue(this.plugin.settings.showSentiment).onChange(async (value) => {
        this.plugin.settings.showSentiment = value;
        await this.plugin.saveSettings();
      })
    );

    new Setting(containerEl)
      .setName("Paid plan features")
      .setDesc(
        "Request full_content and more than 10 results. Requires a paid newsdata.io plan; rejected requests fall back to the free path automatically."
      )
      .addToggle((toggle) =>
        toggle
          .setValue(this.plugin.settings.enablePaidFeatures)
          .onChange(async (value) => {
            this.plugin.settings.enablePaidFeatures = value;
            await this.plugin.saveSettings();
          })
      );
  }
}
