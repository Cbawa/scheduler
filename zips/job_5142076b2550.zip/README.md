# News Reference Links

An Obsidian plugin that searches for news related to the note you're editing and appends the results to the bottom of the note as a list of reference links. It pulls live headlines from the newsdata.io news API (https://newsdata.io) — grab a free API key to run it.

The search term comes from the current text selection, the note title, or the first heading. Each appended entry is a markdown link to the article with its source and date and — when your plan returns them — a short summary, keyword tags, and a sentiment label.

## Features

- Command and ribbon button: "Append related news to current note".
- Query taken from a text selection, the note title, or the first heading.
- Results written as plain markdown links you can keep, edit, or delete.
- Optional per-article AI summary, keyword/AI tags (rendered as `#news/...` tags), and sentiment label.
- A sentiment breakdown line above the results.
- Runs on a free newsdata.io key; paid-only fields degrade to a labelled placeholder instead of breaking the layout.

## Requirements

- Obsidian 1.4.0 or newer.
- A newsdata.io API key. You can create a free key at https://newsdata.io.

## Install from source

1. Create a plugin folder in your vault:
   `<vault>/.obsidian/plugins/news-reference-links/`
2. From this repo run `npm install`.
3. Run `npm run build` to produce `main.js`.
4. Copy `main.js` and `manifest.json` into the plugin folder.
5. In Obsidian go to Settings -> Community plugins and enable "News Reference Links".

## Configuration

Open Settings -> News Reference Links:

- **API key** — your newsdata.io key. If left blank, the plugin falls back to the `NEWSDATA_API_KEY` environment variable (desktop only).
- **Language** — two-letter language code passed to the API (default `en`).
- **Number of articles** — 1 to 10 on the free plan.
- **Search query source** — note title or first heading. A text selection always takes priority.
- **Show AI summary / keyword tags / sentiment** — toggles for the per-article extras.
- **Paid plan features** — off by default. See the note below.

### Using the environment variable

Instead of storing the key in settings you can export it before launching Obsidian:

```
export NEWSDATA_API_KEY=pub_xxxxxxxxxxxxxxxxxxxx
```

### Optional paid fields

Some response fields — `sentiment`, `ai_summary`, `ai_tag` — are only populated on paid newsdata.io plans. On a free key they come back empty: the plugin omits the summary/tags and shows a clearly labelled sample for the sentiment line so the feature stays visible. The `keywords` field is returned on the free plan and is used for tags.

Turning on "Paid plan features" makes the plugin request `full_content` and more than 10 results. Those query parameters are rejected on a free key, so if the request comes back as an error the plugin retries once on the free path and you still get results.

## Usage

1. Open a note, for example one titled `Renewable energy`.
2. Run the command "Append related news to current note" from the command palette, or click the newspaper icon in the ribbon.
3. The plugin appends a news section to the end of the note.

Example of what gets appended:

```
## Related news — Renewable energy (2026-06-11)

_Headlines from the [newsdata.io](https://newsdata.io) news API._

> Sentiment breakdown (sample — live sentiment needs a paid newsdata.io plan): e.g. 3 positive · 1 neutral · 1 negative

- [Solar capacity passes new milestone](https://example.com/a) — Example News · 2026-06-10
    - Installed solar capacity grew faster than forecast this quarter as panel prices fell.
    - tags: #news/solar #news/energy
- [Grid operators plan storage expansion](https://example.com/b) — Example Wire · 2026-06-09
    - tags: #news/grid #news/storage
```

If no related headlines are found you get a notice and the note is left unchanged.

## Development

- `npm run dev` — rebuild on file change.
- `npm run build` — type-check and produce a production `main.js`.

The source lives in `main.ts`; the build is configured in `esbuild.config.mjs` and the plugin metadata in `manifest.json`.

## License

MIT
