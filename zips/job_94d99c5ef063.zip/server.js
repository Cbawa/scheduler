'use strict';

// Tiny dependency-free proxy + static server for the newsfeed widget.
// It reads the newsdata.io API key from the environment so the key never
// reaches the browser, and forwards a small whitelist of query parameters
// to the newsdata.io news API (https://newsdata.io).

const http = require('http');
const https = require('https');
const fs = require('fs');
const path = require('path');

const API_KEY = process.env.NEWSDATA_API_KEY;
if (!API_KEY) {
  console.error('Error: NEWSDATA_API_KEY is not set.');
  console.error('Get a free key at https://newsdata.io and run:');
  console.error('  export NEWSDATA_API_KEY=your_key_here');
  process.exit(1);
}

const PORT = Number(process.env.PORT) || 3000;
const PAID = process.env.ENABLE_PAID === '1';
const UPSTREAM = 'https://newsdata.io/api/1/latest';

// Safe on a free key.
const FREE_PARAMS = ['q', 'qInTitle', 'country', 'language', 'category', 'domain', 'image', 'video', 'page'];
// Rejected on a free key; only forwarded when ENABLE_PAID=1.
const PAID_PARAMS = ['sentiment', 'tag', 'region', 'timeframe', 'full_content'];

const MIME = {
  '.html': 'text/html; charset=utf-8',
  '.js': 'text/javascript; charset=utf-8',
  '.css': 'text/css; charset=utf-8',
  '.json': 'application/json; charset=utf-8',
  '.svg': 'image/svg+xml',
  '.ico': 'image/x-icon'
};

function requestUpstream(params) {
  const url = new URL(UPSTREAM);
  url.searchParams.set('apikey', API_KEY);
  for (const key of Object.keys(params)) {
    const v = params[key];
    if (v !== undefined && v !== null && v !== '') url.searchParams.set(key, v);
  }
  return new Promise((resolve, reject) => {
    https.get(url.toString(), (res) => {
      let data = '';
      res.on('data', (c) => { data += c; });
      res.on('end', () => {
        let json = null;
        try { json = JSON.parse(data); } catch (e) { json = null; }
        resolve({ statusCode: res.statusCode, json: json });
      });
    }).on('error', reject);
  });
}

async function getNews(query) {
  const params = {};
  for (const p of FREE_PARAMS) if (query[p]) params[p] = query[p];

  let usedPaid = false;
  if (PAID) {
    for (const p of PAID_PARAMS) {
      if (query[p]) { params[p] = query[p]; usedPaid = true; }
    }
  }

  let resp = await requestUpstream(params);

  // A paid parameter on a free key fails the whole request; retry without them.
  if (usedPaid && (resp.statusCode === 403 || resp.statusCode === 422)) {
    for (const p of PAID_PARAMS) delete params[p];
    resp = await requestUpstream(params);
  }
  return resp;
}

function sendJson(res, status, obj) {
  const body = JSON.stringify(obj);
  res.writeHead(status, {
    'Content-Type': 'application/json; charset=utf-8',
    'Cache-Control': 'no-store'
  });
  res.end(body);
}

function serveStatic(req, res) {
  let pathname;
  try {
    pathname = decodeURIComponent(new URL(req.url, 'http://localhost').pathname);
  } catch (e) {
    res.writeHead(400); res.end('Bad request'); return;
  }
  if (pathname === '/') pathname = '/index.html';
  const filePath = path.join(__dirname, pathname);
  // Block path traversal outside the project directory.
  if (path.relative(__dirname, filePath).startsWith('..')) {
    res.writeHead(403); res.end('Forbidden'); return;
  }
  fs.readFile(filePath, (err, content) => {
    if (err) {
      res.writeHead(404, { 'Content-Type': 'text/plain; charset=utf-8' });
      res.end('Not found');
      return;
    }
    const ext = path.extname(filePath).toLowerCase();
    res.writeHead(200, { 'Content-Type': MIME[ext] || 'application/octet-stream' });
    res.end(content);
  });
}

const server = http.createServer(async (req, res) => {
  const u = new URL(req.url, 'http://localhost');

  if (u.pathname === '/api/news') {
    const query = {};
    u.searchParams.forEach((value, key) => { query[key] = value; });
    try {
      const resp = await getNews(query);
      if (resp.statusCode === 401) {
        sendJson(res, 401, { error: 'Invalid newsdata.io API key (401). Check NEWSDATA_API_KEY.' });
        return;
      }
      if (resp.statusCode === 429) {
        sendJson(res, 429, { error: 'Rate limit reached (429). Wait a moment and try again.' });
        return;
      }
      if (!resp.json) {
        sendJson(res, 502, { error: 'Unexpected response from newsdata.io.' });
        return;
      }
      if (resp.json.status === 'error') {
        const r = resp.json.results;
        const msg = (r && r.message) ? r.message : 'newsdata.io returned an error.';
        sendJson(res, resp.statusCode || 400, { error: msg });
        return;
      }
      sendJson(res, 200, {
        results: Array.isArray(resp.json.results) ? resp.json.results : [],
        nextPage: resp.json.nextPage || null,
        totalResults: resp.json.totalResults || 0
      });
    } catch (e) {
      sendJson(res, 502, { error: 'Could not reach newsdata.io: ' + e.message });
    }
    return;
  }

  serveStatic(req, res);
});

server.listen(PORT, () => {
  console.log('newsfeed-widget running at http://localhost:' + PORT);
  console.log('Paid query params: ' + (PAID ? 'enabled' : 'disabled (free tier)'));
});
