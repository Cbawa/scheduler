(function (global) {
  'use strict';

  var DEFAULTS = {
    target: '#newsfeed',
    endpoint: '/api/news',
    query: '',
    country: '',
    language: 'en',
    category: '',
    title: 'Latest headlines',
    showChart: true
  };

  function el(tag, cls, html) {
    var e = document.createElement(tag);
    if (cls) e.className = cls;
    if (html != null) e.innerHTML = html;
    return e;
  }

  function esc(s) {
    return String(s == null ? '' : s)
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;');
  }

  function timeAgo(str) {
    if (!str) return '';
    var d = new Date(String(str).replace(' ', 'T') + 'Z');
    if (isNaN(d.getTime())) return esc(str);
    var s = Math.floor((Date.now() - d.getTime()) / 1000);
    if (s < 60) return s + 's ago';
    var m = Math.floor(s / 60);
    if (m < 60) return m + 'm ago';
    var h = Math.floor(m / 60);
    if (h < 24) return h + 'h ago';
    return Math.floor(h / 24) + 'd ago';
  }

  function asArray(v) {
    if (!v) return [];
    return Array.isArray(v) ? v : [v];
  }

  function Widget(opts) {
    this.o = {};
    for (var k in DEFAULTS) this.o[k] = DEFAULTS[k];
    if (opts) for (var j in opts) this.o[j] = opts[j];
    this.root = typeof this.o.target === 'string'
      ? document.querySelector(this.o.target)
      : this.o.target;
    if (!this.root) throw new Error('Newsfeed: target not found (' + this.o.target + ')');
    this.articles = [];
    this.nextPage = null;
    this.loading = false;
    this._build();
    this.load();
  }

  Widget.prototype._build = function () {
    this.root.classList.add('nf');
    this.root.innerHTML = '';
    this.header = el('div', 'nf-header');
    this.header.appendChild(el('h2', 'nf-title', esc(this.o.title)));
    this.chart = el('div', 'nf-chart');
    if (this.o.showChart) this.header.appendChild(this.chart);
    this.list = el('div', 'nf-list');
    this.status = el('div', 'nf-status');
    this.more = el('button', 'nf-more', 'Load more');
    this.more.type = 'button';
    var self = this;
    this.more.addEventListener('click', function () { self.load(); });
    this.root.appendChild(this.header);
    this.root.appendChild(this.list);
    this.root.appendChild(this.status);
    this.root.appendChild(this.more);
    this.more.style.display = 'none';
  };

  Widget.prototype._url = function () {
    var pairs = [];
    var map = {
      q: this.o.query,
      country: this.o.country,
      language: this.o.language,
      category: this.o.category
    };
    for (var k in map) {
      if (map[k]) pairs.push(encodeURIComponent(k) + '=' + encodeURIComponent(map[k]));
    }
    if (this.nextPage) pairs.push('page=' + encodeURIComponent(this.nextPage));
    return this.o.endpoint + (pairs.length ? '?' + pairs.join('&') : '');
  };

  Widget.prototype.load = function () {
    if (this.loading) return;
    this.loading = true;
    this.more.disabled = true;
    this.status.textContent = this.articles.length ? 'Loading more\u2026' : 'Loading headlines\u2026';
    var self = this;
    fetch(this._url(), { headers: { 'Accept': 'application/json' } })
      .then(function (r) {
        return r.json()
          .catch(function () { return {}; })
          .then(function (body) { return { ok: r.ok, body: body }; });
      })
      .then(function (res) {
        self.loading = false;
        self.more.disabled = false;
        if (!res.ok || (res.body && res.body.error)) {
          self.status.textContent = (res.body && res.body.error) ? res.body.error : 'Could not load headlines.';
          return;
        }
        var items = (res.body && res.body.results) || [];
        if (!items.length && !self.articles.length) {
          self.status.textContent = 'No articles found for this query.';
          self._chart();
          return;
        }
        self.articles = self.articles.concat(items);
        self.nextPage = res.body.nextPage || null;
        for (var i = 0; i < items.length; i++) self.list.appendChild(self._card(items[i]));
        self._chart();
        var n = self.articles.length;
        self.status.textContent = n + ' article' + (n === 1 ? '' : 's') + ' shown';
        self.more.style.display = self.nextPage ? '' : 'none';
      })
      .catch(function (e) {
        self.loading = false;
        self.more.disabled = false;
        self.status.textContent = 'Network error: ' + e.message;
      });
  };

  Widget.prototype._card = function (a) {
    var card = el('article', 'nf-card');

    if (a.image_url) {
      var img = el('img', 'nf-img');
      img.loading = 'lazy';
      img.alt = '';
      img.src = a.image_url;
      img.addEventListener('error', function () { img.style.display = 'none'; });
      card.appendChild(img);
    }

    var body = el('div', 'nf-body');

    // sentiment badge: a paid field, simply absent on the free plan
    if (a.sentiment) {
      body.appendChild(el('span', 'nf-badge nf-sent-' + esc(a.sentiment), esc(a.sentiment)));
    }

    var h = el('h3', 'nf-card-title');
    var link = el('a');
    link.href = a.link || '#';
    link.target = '_blank';
    link.rel = 'noopener';
    link.textContent = a.title || '(untitled)';
    h.appendChild(link);
    body.appendChild(h);

    var meta = el('div', 'nf-meta');
    var src = a.source_name || a.source_id || 'unknown source';
    meta.textContent = src + (a.pubDate ? ' \u00b7 ' + timeAgo(a.pubDate) : '');
    body.appendChild(meta);

    var summary = a.ai_summary || a.description;
    if (summary) {
      var s = el('p', a.ai_summary ? 'nf-summary nf-ai' : 'nf-summary', esc(summary));
      if (a.ai_summary) s.title = 'AI summary (newsdata.io)';
      body.appendChild(s);
    }

    // chips: ai_tag (paid field) followed by keywords (free field)
    var tags = el('div', 'nf-tags');
    asArray(a.ai_tag).slice(0, 4).forEach(function (t) {
      if (t) tags.appendChild(el('span', 'nf-chip nf-chip-ai', esc(t)));
    });
    asArray(a.keywords).slice(0, 5).forEach(function (t) {
      if (t) tags.appendChild(el('span', 'nf-chip', '#' + esc(t)));
    });
    if (tags.childNodes.length) body.appendChild(tags);

    card.appendChild(body);
    return card;
  };

  Widget.prototype._chart = function () {
    if (!this.o.showChart) return;
    var counts = { positive: 0, neutral: 0, negative: 0 };
    var total = 0;
    this.articles.forEach(function (a) {
      if (a.sentiment && counts.hasOwnProperty(a.sentiment)) {
        counts[a.sentiment]++;
        total++;
      }
    });

    var sample = total === 0;
    var data = sample ? { positive: 40, neutral: 38, negative: 22 } : counts;
    var sum = sample ? 100 : total;
    var order = ['positive', 'neutral', 'negative'];

    var html = '<div class="nf-chart-bar">';
    order.forEach(function (k) {
      var pct = sum ? Math.round((data[k] / sum) * 100) : 0;
      html += '<span class="nf-seg nf-sent-' + k + '" style="width:' + pct + '%" title="' + k + ' ' + pct + '%"></span>';
    });
    html += '</div><div class="nf-chart-legend">';
    order.forEach(function (k) {
      var val = sample ? (data[k] + '%') : data[k];
      html += '<span class="nf-leg"><i class="nf-dot nf-sent-' + k + '"></i>' + k + ' ' + val + '</span>';
    });
    html += '</div>';
    if (sample) {
      html += '<div class="nf-note">sample \u2014 live sentiment requires a paid newsdata.io plan</div>';
    }
    this.chart.innerHTML = html;
  };

  var Newsfeed = {
    init: function (opts) { return new Widget(opts); }
  };

  if (typeof module !== 'undefined' && module.exports) module.exports = Newsfeed;
  global.Newsfeed = Newsfeed;
})(typeof window !== 'undefined' ? window : this);
