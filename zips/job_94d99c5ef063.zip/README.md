# newsfeed-widget

An embeddable newsfeed widget written in plain JavaScript. Drop it into any page to show a
live list of news headlines as article cards, with keyword tags and a sentiment breakdown.
It pulls headlines from the newsdata.io news API (https://newsdata.io) — grab a free API key
to run it.

The widget itself has no build step and no dependencies: one CSS file and one JS file. A small
Node.js server (also dependency-free — it only uses the standard library) keeps your API key
on the server side and proxies requests to newsdata.io, so the key is never exposed in the
browser.

## Features

- Plain vanilla JS — no framework, no bundler, no install for the widget.
- Configurable search query, country, language, and category.
- Cursor-based pagination with a "Load more" button (uses the API's `nextPage` cursor).
- Article cards with source, relative time, image, and an AI summary line when present.
- Keyword tag chips (returned on the free plan).
- Per-article sentiment badges and an aggregate sentiment bar.
- Handles invalid keys, rate limits, and empty results without breaking the layout.

## Requirements

- Node.js 14 or newer.
- A newsdata.io API key. The free plan covers the default setup. Get one at https://newsdata.io.

## Setup

1. Set your key (the server reads it from the environment and never sends it to the browser):

   ```
   export NEWSDATA_API_KEY=your_key_here
   ```

2. Start the server:

   ```
   node server.js
   ```

3. Open http://localhost:3000 to see the demo page.

If `NEWSDATA_API_KEY` is missing, the server prints a short message and exits.

## Embedding in your own page

Copy `newsfeed-widget.css` and `newsfeed-widget.js` into your project, add a container, and
call `Newsfeed.init`:

```html
<link rel="stylesheet" href="newsfeed-widget.css">
<div id="newsfeed"></div>
<script src="newsfeed-widget.js"></script>
<script>
  Newsfeed.init({
    target: '#newsfeed',
    endpoint: '/api/news',   // a route backed by the proxy below (or your own)
    query: 'climate',
    language: 'en',
    category: 'science'
  });
</script>
```

Point `endpoint` at a route served by the included `server.js` (or your own proxy) so the
API key stays server-side. Options:

| option     | default        | description                                            |
| ---------- | -------------- | ------------------------------------------------------ |
| `target`   | `#newsfeed`    | CSS selector or element to render into                 |
| `endpoint` | `/api/news`    | proxy route the widget fetches from                    |
| `query`    | `''`           | search term (maps to the API `q` parameter)            |
| `country`  | `''`           | two-letter country code, e.g. `us`                     |
| `language` | `en`           | language code                                          |
| `category` | `''`           | one category, e.g. `technology`, `business`, `sports`  |
| `title`    | `Latest headlines` | heading shown above the list                       |
| `showChart`| `true`         | show the aggregate sentiment bar                       |

## Example

Request:

```
curl 'http://localhost:3000/api/news?q=technology&language=en'
```

Response (trimmed):

```json
{
  "results": [
    {
      "title": "...",
      "link": "https://...",
      "source_name": "...",
      "pubDate": "2026-06-11 09:12:00",
      "keywords": ["technology", "startups"],
      "sentiment": null,
      "ai_summary": null
    }
  ],
  "nextPage": "1718...",
  "totalResults": 1234
}
```

## Notes on paid fields

Some response fields — `sentiment`, `ai_tag`, `ai_summary`, `ai_region`, `ai_org` — are only
populated on paid newsdata.io plans. On the free plan they come back empty, and the widget
degrades cleanly: sentiment badges are simply omitted, and the aggregate sentiment bar shows
sample values with a caption noting that live sentiment requires a paid plan. Keyword tags
are available on the free plan and are always shown when present.

To forward paid query parameters (for example `sentiment`) when you do have a paid plan, set
`ENABLE_PAID=1` before starting the server. If newsdata.io rejects a paid parameter, the
server retries the request once without it so you still get results.

## Files

- `server.js` — dependency-free Node proxy and static file server
- `newsfeed-widget.js` — the widget
- `newsfeed-widget.css` — widget styles
- `index.html` — demo page

## License

MIT
