# 🗳️ Politics News Bias Detector

Analyze how political news is *framed* across different countries and sources.

This project pulls live political headlines from the [newsdata.io](https://newsdata.io)
news API, asks an LLM (OpenAI **GPT-4o-mini**) to rate the framing of each article
(`positive` / `negative` / `neutral`) with a one-sentence reason, then aggregates the
scores by **country** and **source_id** to surface potentially biased outlets.

## How it works (pipeline)

1. **Fetch** — for each selected country (e.g. `us, gb, in, au, za`), call newsdata.io
   `/news` with `q="politics"` and follow the `nextPage` pagination token.
2. **Classify** — send each article `title + description` to GPT-4o-mini with the prompt:
   *"Rate framing of this article: positive/negative/neutral toward subject, 1 sentence reason."*
3. **Aggregate** — group sentiment counts by country and by `source_id`.
4. **Flag** — heuristic: if **> 60%** of a source's articles share the same sentiment,
   the source is flagged as *potentially biased*.
5. **Report** — render a **seaborn heatmap** and export a **CSV report**.

A **Streamlit UI** lets you pick up to 5 countries from a dropdown and compare sources
interactively. A command-line mode is also available.

## Quick start

```bash
git clone https://github.com/your-org/politics-news-bias-detector.git
cd politics-news-bias-detector
python -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt
```

### Set your API keys

```bash
# Required: free key from https://newsdata.io
export NEWSDATA_API_KEY="your_newsdata_key"

# Optional: enables GPT-4o-mini framing analysis (https://platform.openai.com)
export OPENAI_API_KEY="your_openai_key"
# Optional model override (defaults to gpt-4o-mini)
export OPENAI_MODEL="gpt-4o-mini"
```

> **No OpenAI key?** No problem — the app **degrades gracefully** to a lightweight
> keyword heuristic so you can still run the full pipeline. The UI tells you which
> mode is active.

### Run the Streamlit app

```bash
streamlit run app.py
```

### Or run from the command line

```bash
python bias_detector.py --countries us gb in --query politics --max-pages 2
# -> writes bias_report.csv and bias_heatmap.png
```

## Free-tier friendly ✅

This project is built to work on the **newsdata.io FREE plan**:

- Uses only the free `/news` endpoint with free params (`q`, `country`, `language`, `page`).
- **Does NOT** depend on paid-only features (built-in `sentiment`, `ai_tag`/`ai_summary`
  and other `ai_*` fields, the `/archive` endpoint, or advanced query operators).
  All sentiment scoring is done by *your own* OpenAI call (or the local heuristic).
- Handles `401` (invalid key), `429` (rate limit), `403/422` (upgrade-required), and
  empty `results` without crashing.

| Feature | Plan required |
|---|---|
| Fetching political news (`/news`) | Free |
| Pagination via `nextPage` | Free |
| GPT-4o-mini framing analysis | Your OpenAI account (separate from newsdata.io) |
| newsdata.io built-in `sentiment` / `ai_*` fields | Paid (NOT used here) |

## Output

- `bias_report.csv` — one row per article: country, source_id, sentiment, reason, link.
- `bias_heatmap.png` — normalized sentiment share per source.
- Interactive tables + heatmap in the Streamlit UI, including the flagged-source list.

## License

MIT
