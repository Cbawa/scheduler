"""Streamlit UI for the Politics News Bias Detector (newsdata.io + GPT-4o-mini)."""
import pandas as pd
import streamlit as st

import bias_detector as bd
from newsdata_client import NewsDataError

# Country dropdown -> newsdata.io country codes.
COUNTRIES = {
    "United States": "us",
    "United Kingdom": "gb",
    "India": "in",
    "Australia": "au",
    "South Africa": "za",
    "Canada": "ca",
    "Germany": "de",
    "France": "fr",
    "Brazil": "br",
    "Japan": "jp",
    "Nigeria": "ng",
    "Singapore": "sg",
}

st.set_page_config(page_title="Politics News Bias Detector", layout="wide")
st.title("\U0001F5F3\uFE0F Politics News Bias Detector")
st.caption("Powered by the newsdata.io news API + OpenAI GPT-4o-mini")

with st.sidebar:
    st.header("Settings")
    selected = st.multiselect(
        "Countries (pick up to 5)",
        options=list(COUNTRIES.keys()),
        default=["United States", "United Kingdom", "India", "Australia", "South Africa"],
    )
    query = st.text_input("Search query", value="politics")
    language = st.text_input("Language code", value="en")
    max_pages = st.slider("Pages per country", 1, 5, 2,
                          help="Each page is one free-tier /news request.")
    run = st.button("Run analysis", type="primary")

if len(selected) > 5:
    st.warning("Please select at most 5 countries. Using the first 5.")
    selected = selected[:5]

_, mode = bd.get_classifier()
if mode == "openai":
    st.info("Framing analysis: OpenAI GPT-4o-mini.")
else:
    st.warning(
        "OPENAI_API_KEY not set \u2014 using the built-in keyword heuristic. "
        "Set OPENAI_API_KEY for GPT-4o-mini analysis."
    )

if run:
    if not selected:
        st.error("Select at least one country.")
        st.stop()

    codes = [COUNTRIES[name] for name in selected]
    bar = st.progress(0.0, text="Fetching & classifying articles...")

    def _progress(done, total):
        if total:
            bar.progress(min(done / total, 1.0), text=f"Classified {done}/{total} articles")

    try:
        df, mode = bd.run_pipeline(
            codes, query=query or "politics", language=language or "en",
            max_pages=max_pages, progress=_progress,
        )
    except NewsDataError as exc:
        bar.empty()
        st.error(f"newsdata.io error: {exc}")
        st.stop()

    bar.empty()

    if df.empty:
        st.warning("No articles found for the selected countries/query. Try different options.")
        st.stop()

    code_to_name = {v: k for k, v in COUNTRIES.items()}
    df["country_name"] = df["country"].map(code_to_name).fillna(df["country"])

    st.success(f"Analyzed {len(df)} articles across {df['country'].nunique()} countries.")

    col1, col2 = st.columns(2)
    with col1:
        st.subheader("Sentiment by country")
        st.dataframe(bd.aggregate_by_country(df), use_container_width=True)
    with col2:
        st.subheader("Potentially biased sources")
        flagged = bd.flag_biased_sources(df)
        if flagged.empty:
            st.write("Not enough articles per source to assess bias yet.")
        else:
            st.dataframe(flagged, use_container_width=True)
            biased = flagged[flagged["biased"]]
            if not biased.empty:
                st.error(
                    "Flagged (>60% one sentiment): "
                    + ", ".join(biased["source_id"].tolist())
                )

    st.subheader("Bias heatmap (normalized share per source)")
    heatmap_path = bd.build_heatmap(df)
    if heatmap_path:
        st.image(heatmap_path, use_container_width=True)
    else:
        st.write("Heatmap unavailable (plotting libraries missing).")

    st.subheader("Article-level results")
    st.dataframe(
        df[["country_name", "source_id", "sentiment", "reason", "title", "link"]],
        use_container_width=True,
    )

    st.download_button(
        "Download CSV report",
        data=df.to_csv(index=False).encode("utf-8"),
        file_name="bias_report.csv",
        mime="text/csv",
    )
else:
    st.write("Pick countries in the sidebar and click **Run analysis** to begin.")
