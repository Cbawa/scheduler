"""Core pipeline: fetch -> classify framing -> aggregate -> report.

Classification uses OpenAI GPT-4o-mini when OPENAI_API_KEY is available, and
falls back to a lightweight keyword heuristic otherwise so the project always
runs. newsdata.io paid-only sentiment/ai_* fields are never used.
"""
import argparse
import os

import pandas as pd

from newsdata_client import NewsDataError, fetch_news

try:
    import matplotlib

    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    import seaborn as sns

    _HAS_PLOT = True
except Exception:  # pragma: no cover - plotting is optional
    _HAS_PLOT = False

SENTIMENTS = ["positive", "negative", "neutral"]
BIAS_THRESHOLD = 0.60  # > 60% of a source's articles sharing a sentiment => flagged

POSITIVE_WORDS = [
    "win", "wins", "growth", "success", "praise", "boost", "agreement",
    "progress", "hope", "support", "reform", "deal", "breakthrough",
]
NEGATIVE_WORDS = [
    "crisis", "scandal", "attack", "fail", "failure", "corruption", "war",
    "conflict", "death", "controversy", "slam", "protest", "ban", "threat",
]


def _heuristic_sentiment(text):
    low = (text or "").lower()
    pos = sum(1 for w in POSITIVE_WORDS if w in low)
    neg = sum(1 for w in NEGATIVE_WORDS if w in low)
    if pos > neg:
        return "positive", "Heuristic: more positive keywords than negative."
    if neg > pos:
        return "negative", "Heuristic: more negative keywords than positive."
    return "neutral", "Heuristic: balanced or no strong keywords."


def _openai_sentiment(client, model, text):
    prompt = (
        "Rate framing of this article: positive/negative/neutral toward subject, "
        "1 sentence reason.\n\nArticle: " + text + "\n\n"
        "Respond exactly in the format: <sentiment> | <one sentence reason>"
    )
    resp = client.chat.completions.create(
        model=model,
        messages=[{"role": "user", "content": prompt}],
        temperature=0,
        max_tokens=60,
    )
    content = (resp.choices[0].message.content or "").strip()
    sentiment, _, reason = content.partition("|")
    sentiment = sentiment.strip().lower()
    for s in SENTIMENTS:
        if s in sentiment:
            return s, reason.strip() or "(no reason given)"
    return "neutral", reason.strip() or "(could not parse sentiment)"


def get_classifier():
    """Return ``(classify_fn, mode)`` where mode is 'openai' or 'heuristic'."""
    api_key = os.environ.get("OPENAI_API_KEY")
    model = os.environ.get("OPENAI_MODEL", "gpt-4o-mini")
    if api_key:
        try:
            from openai import OpenAI

            client = OpenAI(api_key=api_key)

            def classify(text):
                try:
                    return _openai_sentiment(client, model, text)
                except Exception:
                    # Any OpenAI hiccup -> fall back per-article, never crash.
                    return _heuristic_sentiment(text)

            return classify, "openai"
        except Exception:
            pass
    return (lambda text: _heuristic_sentiment(text)), "heuristic"


def analyze(articles_by_country, classify_fn, progress=None):
    """Classify every article and return a tidy DataFrame."""
    rows = []
    total = sum(len(v) for v in articles_by_country.values())
    done = 0
    for country, articles in articles_by_country.items():
        for art in articles:
            title = art.get("title") or ""
            desc = art.get("description") or ""
            text = (title + ". " + desc).strip(". ").strip()
            if not text:
                continue
            sentiment, reason = classify_fn(text)
            rows.append(
                {
                    "country": country,
                    "source_id": art.get("source_id") or "unknown",
                    "title": title,
                    "sentiment": sentiment,
                    "reason": reason,
                    "link": art.get("link") or "",
                    "pubDate": art.get("pubDate") or "",
                }
            )
            done += 1
            if progress:
                progress(done, total)
    return pd.DataFrame(rows)


def aggregate_by_country(df):
    if df.empty:
        return pd.DataFrame()
    pivot = df.pivot_table(
        index="country", columns="sentiment", values="title",
        aggfunc="count", fill_value=0,
    )
    for s in SENTIMENTS:
        if s not in pivot.columns:
            pivot[s] = 0
    return pivot[SENTIMENTS]


def flag_biased_sources(df, threshold=BIAS_THRESHOLD, min_articles=3):
    """Flag sources where one sentiment dominates more than ``threshold``."""
    if df.empty:
        return pd.DataFrame()
    out = []
    for source, g in df.groupby("source_id"):
        n = len(g)
        if n < min_articles:
            continue
        shares = g["sentiment"].value_counts(normalize=True)
        out.append(
            {
                "source_id": source,
                "articles": n,
                "dominant_sentiment": shares.idxmax(),
                "dominant_share": round(float(shares.max()), 2),
                "biased": bool(shares.max() > threshold),
            }
        )
    if not out:
        return pd.DataFrame()
    return pd.DataFrame(out).sort_values("dominant_share", ascending=False)


def build_heatmap(df, path="bias_heatmap.png"):
    """Render a normalized per-source sentiment heatmap. Returns path or None."""
    if not _HAS_PLOT or df.empty:
        return None
    pivot = df.pivot_table(
        index="source_id", columns="sentiment", values="title",
        aggfunc="count", fill_value=0,
    )
    for s in SENTIMENTS:
        if s not in pivot.columns:
            pivot[s] = 0
    pivot = pivot[SENTIMENTS]
    norm = pivot.div(pivot.sum(axis=1).replace(0, 1), axis=0)
    plt.figure(figsize=(8, max(4, 0.45 * len(norm))))
    sns.heatmap(
        norm, annot=True, fmt=".2f", cmap="RdYlGn_r",
        cbar_kws={"label": "share of articles"},
    )
    plt.title("Political News Framing Bias Heatmap (by source)")
    plt.ylabel("source_id")
    plt.tight_layout()
    plt.savefig(path, dpi=120)
    plt.close()
    return path


def save_csv(df, path="bias_report.csv"):
    df.to_csv(path, index=False)
    return path


def run_pipeline(countries, query="politics", language="en", max_pages=2, progress=None):
    classify_fn, mode = get_classifier()
    articles_by_country = {}
    for c in countries:
        articles_by_country[c] = fetch_news(
            c, query=query, language=language, max_pages=max_pages
        )
    df = analyze(articles_by_country, classify_fn, progress=progress)
    return df, mode


def main():
    parser = argparse.ArgumentParser(description="Politics News Bias Detector (newsdata.io)")
    parser.add_argument("--countries", nargs="+", default=["us", "gb", "in", "au", "za"],
                        help="Up to 5 country codes (e.g. us gb in au za)")
    parser.add_argument("--query", default="politics")
    parser.add_argument("--language", default="en")
    parser.add_argument("--max-pages", type=int, default=2)
    parser.add_argument("--csv", default="bias_report.csv")
    parser.add_argument("--heatmap", default="bias_heatmap.png")
    args = parser.parse_args()

    countries = args.countries[:5]
    try:
        df, mode = run_pipeline(countries, args.query, args.language, args.max_pages)
    except NewsDataError as exc:
        raise SystemExit(f"newsdata.io: {exc}")

    print(f"Classification mode: {mode}")
    if df.empty:
        print("No articles found for the selected countries/query.")
        return

    print(f"Analyzed {len(df)} articles across {df['country'].nunique()} countries.")
    print("\nSentiment by country:")
    print(aggregate_by_country(df))

    flagged = flag_biased_sources(df)
    if not flagged.empty:
        print("\nPotentially biased sources (>60% one sentiment):")
        print(flagged[flagged["biased"]].to_string(index=False))

    save_csv(df, args.csv)
    print(f"\nWrote {args.csv}")
    hm = build_heatmap(df, args.heatmap)
    if hm:
        print(f"Wrote {hm}")


if __name__ == "__main__":
    main()
