"""Thin, free-tier-safe client for the newsdata.io REST API."""
import os
import time

import requests

BASE_URL = "https://newsdata.io/api/1"


class NewsDataError(Exception):
    """Raised for unrecoverable newsdata.io API problems."""


def _get_api_key():
    key = os.environ.get("NEWSDATA_API_KEY")
    if not key:
        raise NewsDataError(
            "NEWSDATA_API_KEY is not set. Get a free key at https://newsdata.io "
            "and export it, e.g.  export NEWSDATA_API_KEY=your_key"
        )
    return key


def fetch_news(country, query="politics", language="en", max_pages=2, timeout=20):
    """Fetch latest news for a country from the free /news endpoint.

    Returns a list of article dicts. Follows the ``nextPage`` token for
    pagination and degrades gracefully on rate limits / paid-only responses.
    Only free-tier params are sent (q, country, language, page).
    """
    api_key = _get_api_key()
    articles = []
    next_page = None
    pages_fetched = 0

    while pages_fetched < max_pages:
        params = {
            "apikey": api_key,
            "q": query,
            "country": country,
            "language": language,
        }
        if next_page:
            params["page"] = next_page

        try:
            resp = requests.get(BASE_URL + "/news", params=params, timeout=timeout)
        except requests.RequestException as exc:
            raise NewsDataError(f"Network error contacting newsdata.io: {exc}")

        if resp.status_code == 401:
            raise NewsDataError("Invalid API key (401). Check NEWSDATA_API_KEY.")
        if resp.status_code == 429:
            # Rate limited on the free tier: back off briefly, then stop paging.
            time.sleep(2)
            break
        if resp.status_code in (403, 422):
            # A paid-only param/feature was rejected: stop gracefully.
            break
        if resp.status_code != 200:
            raise NewsDataError(
                f"newsdata.io error {resp.status_code}: {resp.text[:200]}"
            )

        try:
            data = resp.json()
        except ValueError:
            raise NewsDataError("newsdata.io returned a non-JSON response.")

        if data.get("status") != "success":
            break

        results = data.get("results") or []
        articles.extend(results)

        next_page = data.get("nextPage")
        pages_fetched += 1
        if not next_page:
            break

    return articles
