"""CLI for the CrewAI news digest.

Two modes:
  --fetch-only : just call newsdata.io and print a digest (no LLM key needed).
  default      : run the full three-agent CrewAI crew (needs an LLM key).
"""

import os
import sys
import argparse

try:
    from dotenv import load_dotenv
    load_dotenv()
except ImportError:
    pass

from news_tool import (
    fetch_latest,
    get_api_key,
    NewsDataError,
    NewsDataAuthError,
    NewsDataRateLimit,
)
from emailer import render_digest, send_email


def _bool_env(name):
    return os.environ.get(name, "").strip().lower() in ("1", "true", "yes", "on")


def parse_args(argv):
    p = argparse.ArgumentParser(
        description="CrewAI news digest powered by the newsdata.io API."
    )
    p.add_argument("--topic", "--query", dest="topic", default=None,
                   help="Topic / search keywords.")
    p.add_argument("--country", default=None, help="2-letter country code, e.g. us.")
    p.add_argument("--language", default="en", help="2-letter language code (default en).")
    p.add_argument("--category", default=None, help="newsdata.io category, e.g. technology.")
    p.add_argument("--max-articles", type=int, default=8,
                   help="Articles to fetch (<=10 on the free tier).")
    p.add_argument("--fetch-only", action="store_true",
                   help="Skip the agents; fetch and print a digest (no LLM key needed).")
    p.add_argument("--send", action="store_true", help="Email the digest via SMTP.")
    p.add_argument("--paid", action="store_true",
                   help="Send paid-tier query params (requires a paid plan).")
    return p.parse_args(argv)


def main(argv=None):
    args = parse_args(argv if argv is not None else sys.argv[1:])
    enable_paid = args.paid or _bool_env("ENABLE_PAID")

    try:
        get_api_key()
    except NewsDataError as exc:
        print("Error: %s" % exc, file=sys.stderr)
        return 2

    title = "%s news digest" % (args.topic or "Top")

    try:
        if args.fetch_only:
            articles = fetch_latest(
                query=args.topic,
                country=args.country,
                language=args.language,
                category=args.category,
                max_articles=args.max_articles,
                enable_paid=enable_paid,
            )
            body = render_digest(articles, title=title)
        else:
            from news_crew import run_crew
            body = run_crew(
                topic=args.topic,
                country=args.country,
                language=args.language,
                category=args.category,
                max_articles=args.max_articles,
                enable_paid=enable_paid,
            )
    except NewsDataAuthError as exc:
        print("Auth error: %s" % exc, file=sys.stderr)
        return 2
    except NewsDataRateLimit as exc:
        print("Rate limited: %s" % exc, file=sys.stderr)
        return 3
    except NewsDataError as exc:
        print("News API error: %s" % exc, file=sys.stderr)
        return 1

    print(body)

    if args.send:
        try:
            send_email(title, body)
            print("\n[sent] Email delivered.")
        except Exception as exc:
            print("\n[email skipped] %s" % exc, file=sys.stderr)

    return 0


if __name__ == "__main__":
    raise SystemExit(main())
