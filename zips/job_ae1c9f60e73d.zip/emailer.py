"""Render a news digest and optionally send it over SMTP.

Paid fields (sentiment, ai_summary, ai_tag) are shown when present. When they
are missing on a free key, the layout still renders with a clearly labeled
placeholder or sample so the capability stays visible.
"""

import os
import smtplib
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart

from news_tool import summarize_sentiment

SAMPLE_NOTE = "sample - live sentiment requires a paid newsdata.io plan"


def _bar(count, total, width=20):
    if total <= 0:
        filled = 0
    else:
        filled = int(round(width * count / float(total)))
    filled = max(0, min(width, filled))
    return "#" * filled + "-" * (width - filled)


def render_sentiment_chart(articles):
    counts, have = summarize_sentiment(articles)
    lines = ["Sentiment breakdown:"]
    if have:
        total = sum(counts.values()) or 1
        for label in ("positive", "neutral", "negative"):
            c = counts[label]
            lines.append("  %-8s %s %d" % (label, _bar(c, total), c))
    else:
        # Free key: no live sentiment. Show a plainly labeled sample.
        sample = {"positive": 5, "neutral": 3, "negative": 2}
        total = sum(sample.values())
        for label in ("positive", "neutral", "negative"):
            c = sample[label]
            lines.append("  %-8s %s %d" % (label, _bar(c, total), c))
        lines.append("  (%s)" % SAMPLE_NOTE)
    return "\n".join(lines)


def render_article(index, a):
    lines = ["%d. %s" % (index, a.get("title"))]
    if a.get("source") or a.get("pub_date"):
        lines.append("   %s | %s" % (a.get("source") or "unknown", a.get("pub_date") or ""))
    if a.get("link"):
        lines.append("   %s" % a["link"])

    summary = a.get("ai_summary") or a.get("description")
    if a.get("ai_summary"):
        lines.append("   AI summary: %s" % a["ai_summary"].strip())
    elif summary:
        lines.append("   %s" % summary.strip())
        lines.append("   AI summary: (not on free tier - add a paid newsdata.io plan)")
    else:
        lines.append("   AI summary: (not on free tier - add a paid newsdata.io plan)")

    kws = a.get("keywords") or []
    if kws:
        lines.append("   keywords: %s" % ", ".join([str(k) for k in kws[:8]]))

    tags = a.get("ai_tag")
    if tags:
        if isinstance(tags, list):
            tags = ", ".join([str(t) for t in tags[:6]])
        lines.append("   ai_tag: %s" % tags)

    sentiment = a.get("sentiment")
    if sentiment:
        lines.append("   sentiment: [%s]" % sentiment)

    return "\n".join(lines)


def render_digest(articles, title="News digest"):
    if not articles:
        return title + "\n\nNo articles found for this query. Try a broader topic."
    parts = [title, "=" * len(title), ""]
    parts.append(render_sentiment_chart(articles))
    parts.append("")
    for i, a in enumerate(articles, 1):
        parts.append(render_article(i, a))
        parts.append("")
    parts.append("Source: newsdata.io")
    return "\n".join(parts)


def send_email(subject, body):
    host = os.environ.get("SMTP_HOST")
    if not host:
        raise RuntimeError(
            "SMTP is not configured. Set SMTP_HOST, SMTP_PORT, SMTP_USER, "
            "SMTP_PASSWORD, EMAIL_FROM and EMAIL_TO to enable sending."
        )
    port = int(os.environ.get("SMTP_PORT", "587"))
    user = os.environ.get("SMTP_USER")
    password = os.environ.get("SMTP_PASSWORD")
    sender = os.environ.get("EMAIL_FROM", user)
    recipient = os.environ.get("EMAIL_TO")
    if not recipient:
        raise RuntimeError("EMAIL_TO is not set.")

    msg = MIMEMultipart()
    msg["From"] = sender or ""
    msg["To"] = recipient
    msg["Subject"] = subject
    msg.attach(MIMEText(body, "plain", "utf-8"))

    recipients = [r.strip() for r in recipient.split(",") if r.strip()]
    with smtplib.SMTP(host, port) as server:
        server.starttls()
        if user and password:
            server.login(user, password)
        server.sendmail(sender or user, recipients, msg.as_string())
