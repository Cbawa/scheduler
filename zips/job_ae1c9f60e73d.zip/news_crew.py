"""CrewAI agents, tasks and the newsdata.io fetch tool.

The crew runs three agents in sequence: a researcher that calls the fetch tool,
a summarizer, and an editor that formats the email body.
"""

import os
import json
from typing import Optional, Type

from pydantic import BaseModel, Field

from crewai import Agent, Task, Crew, Process
from crewai.tools import BaseTool

from news_tool import fetch_latest


def _make_llm():
    """Build a CrewAI LLM from OPENAI_MODEL, or None to use CrewAI defaults."""
    try:
        from crewai import LLM
    except ImportError:
        return None
    model = os.environ.get("OPENAI_MODEL", "gpt-4o-mini")
    return LLM(model=model)


class FetchNewsInput(BaseModel):
    query: Optional[str] = Field(None, description="Keywords to search for.")
    country: Optional[str] = Field(None, description="2-letter country code, e.g. us.")
    language: str = Field("en", description="2-letter language code.")
    category: Optional[str] = Field(None, description="A newsdata.io category, e.g. technology.")
    max_articles: int = Field(8, description="How many articles to fetch (<=10 on the free tier).")


class FetchNewsTool(BaseTool):
    name: str = "fetch_news"
    description: str = (
        "Fetch the latest news articles from the newsdata.io API. Returns a JSON "
        "list of articles with title, link, description, keywords and, when the "
        "plan provides them, sentiment and AI fields."
    )
    args_schema: Type[BaseModel] = FetchNewsInput
    enable_paid: bool = False

    def _run(self, query=None, country=None, language="en", category=None, max_articles=8):
        articles = fetch_latest(
            query=query,
            country=country,
            language=language,
            category=category,
            max_articles=max_articles,
            enable_paid=self.enable_paid,
        )
        return json.dumps(articles, ensure_ascii=False)


def build_crew(enable_paid=False):
    llm = _make_llm()
    tool = FetchNewsTool(enable_paid=enable_paid)

    researcher = Agent(
        role="News Researcher",
        goal="Fetch relevant, recent news stories for the requested topic.",
        backstory="You query the newsdata.io news API and hand raw stories to the team.",
        tools=[tool],
        llm=llm,
        verbose=True,
        allow_delegation=False,
    )
    summarizer = Agent(
        role="News Summarizer",
        goal="Turn raw articles into tight, factual summaries.",
        backstory="You distill each story to two or three plain sentences without hype.",
        llm=llm,
        verbose=True,
        allow_delegation=False,
    )
    editor = Agent(
        role="Email Editor",
        goal="Assemble the summaries into a clean plain-text email digest.",
        backstory="You format a scannable digest with titles, links and short blurbs.",
        llm=llm,
        verbose=True,
        allow_delegation=False,
    )

    fetch_task = Task(
        description=(
            "Use the fetch_news tool to get up to {max_articles} articles. Pass "
            "query={topic!r}, country={country!r}, language={language!r}, "
            "category={category!r}. Return the tool's JSON output unchanged."
        ),
        expected_output="A JSON array of article objects from newsdata.io.",
        agent=researcher,
    )
    summarize_task = Task(
        description=(
            "For each article in the fetched JSON, write a 2-3 sentence factual "
            "summary. Keep any keywords and sentiment that are present. Do not "
            "invent facts or sources."
        ),
        expected_output="A list of summarized stories, each with title, link and summary.",
        agent=summarizer,
        context=[fetch_task],
    )
    format_task = Task(
        description=(
            "Format the summaries into a plain-text email digest titled "
            "'{topic} news digest'. Number each story, include its link, and end "
            "with a one-line note naming the data source (newsdata.io)."
        ),
        expected_output="A ready-to-send plain-text email body.",
        agent=editor,
        context=[summarize_task],
    )

    return Crew(
        agents=[researcher, summarizer, editor],
        tasks=[fetch_task, summarize_task, format_task],
        process=Process.sequential,
        verbose=True,
    )


def run_crew(topic=None, country=None, language="en", category=None,
             max_articles=8, enable_paid=False):
    crew = build_crew(enable_paid=enable_paid)
    result = crew.kickoff(inputs={
        "topic": topic or "top",
        "country": country,
        "language": language,
        "category": category,
        "max_articles": max_articles,
    })
    return str(result)
