"""Client for the newsdata.io latest-news endpoint.

Keeps the core path free-tier safe: it only sends paid query params when the
caller explicitly opts in, and retries once without them if the API rejects
them. Paid response fields (sentiment, ai_*) are simply read when present.
"""

import os
import time
import json

import requests

LATEST_URL = "https://newsdata.io/api/1/latest"
FREE_PAGE_CAP = 10


class NewsDataError(Exception):
    """Base error for newsdata.io problems."""


class NewsDataAuthError(NewsDataError):
    """Invalid or missing API key (HTTP 401)."""


class NewsDataRateLimit(NewsDataError):
    """Rate limit reached (HTTP 429)."""


def get_api_key():
    key = os.environ.get("NEWSDATA_API_KEY", "").strip()
    if not key:
        raise NewsDataError(
            "NEWSDATA_API_KEY is not set. Get a free key at "
            "https://newsdata.io and run: export NEWSDATA_API_KEY=your_key"
        )
    return key


def _normalize(article):
    return {
        "title": article.get("title") or "(untitled)",
        "link": article.get("link"),
        "description": article.get("description"),
        "content": article.get("content"),
        "pub_date": article.get("pubDate"),
        "source": article.get("source_name") or article.get("source_id"),
        "image_url": article.get("image_url"),
        "keywords": article.get("keywords") or [],
        "sentiment": article.get("sentiment"),
        "sentiment_stats": article.get("sentiment_stats"),
        "ai_tag": article.get("ai_tag"),
        "ai_region": article.get("ai_region"),
        "ai_org": article.get("ai_org"),
        "ai_summary": article.get("ai_summary"),
    }


def _error_message(resp):
    try:
        body = resp.json()
    except ValueError:
        return resp.text[:200]
    if isinstance(body, dict):
        res = body.get("results")
        if isinstance(res, dict):
            return res.get("message") or json.dumps(res)[:200]
        return body.get("message") or json.dumps(body)[:200]
    return str(body)[:200]


def _check_status(resp):
    if resp.status_code == 401:
        raise NewsDataAuthError("Invalid API key (HTTP 401). Check NEWSDATA_API_KEY.")
    if resp.status_code == 429:
        raise NewsDataRateLimit(
            "Rate limit reached (HTTP 429). Wait a moment and retry."
        )


def fetch_latest(query=None, country=None, language="en", category=None,
                 max_articles=8, enable_paid=False, timeout=30, session=None):
    """Fetch up to max_articles latest articles, paginating via nextPage."""
    key = get_api_key()
    sess = session or requests.Session()

    base = {"apikey": key, "language": language}
    if query:
        base["q"] = query
    if country:
        base["country"] = country
    if category:
        base["category"] = category

    collected = []
    page = None
    paid = bool(enable_paid)
    guard = 0
    while len(collected) < max_articles and guard < 12:
        guard += 1
        params = dict(base)
        if page:
            params["page"] = page
        if paid:
            # Paid-only query params; rejected on the free tier.
            params["size"] = min(max(max_articles, 1), 50)
            params["full_content"] = 1

        resp = sess.get(LATEST_URL, params=params, timeout=timeout)

        if resp.status_code in (403, 422) and paid:
            # Free key cannot use paid params; retry this page without them.
            paid = False
            continue

        _check_status(resp)
        if resp.status_code != 200:
            raise NewsDataError(
                "newsdata.io request failed (HTTP %s): %s"
                % (resp.status_code, _error_message(resp))
            )

        data = resp.json()
        if data.get("status") != "success":
            raise NewsDataError("newsdata.io returned: %s" % _error_message(resp))

        for art in (data.get("results") or []):
            collected.append(_normalize(art))
            if len(collected) >= max_articles:
                break

        page = data.get("nextPage")
        if not page:
            break
        time.sleep(0.4)

    return collected[:max_articles]


def summarize_sentiment(articles):
    """Count sentiment labels present across articles.

    Returns (counts, have_data). have_data is False on a free key where the
    sentiment field is absent.
    """
    counts = {"positive": 0, "negative": 0, "neutral": 0}
    have = False
    for a in articles:
        s = (a.get("sentiment") or "").lower()
        if s in counts:
            counts[s] += 1
            have = True
    return counts, have
