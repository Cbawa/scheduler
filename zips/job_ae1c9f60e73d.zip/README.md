# news-crewai-agent

A small CrewAI pipeline that builds a news email digest. Three agents work in
sequence: one fetches stories from the newsdata.io news API
(https://newsdata.io), one summarizes them, and one formats the result as a
plain-text email you can print or send over SMTP.

The news data comes from the newsdata.io REST API; grab a free API key to run
it. The fetching step works on the free tier on its own, so you can try the
news side without wiring up an LLM (use `--fetch-only`).

## What it does

- Pulls latest headlines for a topic, country, language or category.
- Runs a three-agent CrewAI crew: researcher -> summarizer -> email editor.
- Surfaces the richer fields newsdata.io can return: per-article keywords, an
  AI summary line, AI tags and a sentiment badge, plus a small sentiment
  breakdown chart.
- Optional SMTP delivery of the finished digest.

## Requirements

- Python 3.10+
- A newsdata.io API key (free) in `NEWSDATA_API_KEY`
- For the full agent run: an LLM key for CrewAI (OpenAI by default)

## Setup

```
python -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt

export NEWSDATA_API_KEY=your_newsdata_key
# only needed for the full crew (not for --fetch-only):
export OPENAI_API_KEY=your_openai_key
```

You can also copy `.env.example` to `.env`; values there are loaded at startup.

## Usage

Fetch and print a digest without any LLM (the free-tier path):

```
python main.py --fetch-only --topic "climate" --country us --max-articles 8
```

Run the full CrewAI pipeline (needs an LLM key):

```
python main.py --topic technology --language en
```

Email the digest (configure the `SMTP_*` vars first):

```
python main.py --fetch-only --topic markets --send
```

### Sample output (`--fetch-only`)

```
Climate news digest
===================

Sentiment breakdown:
  positive ########------------ 5
  neutral  #####--------------- 3
  negative ####---------------- 2
  (sample - live sentiment requires a paid newsdata.io plan)

1. Coastal cities adapt to rising seas
   Reuters | 2026-06-12 09:00:00
   https://example.com/article
   A short description of the story.
   keywords: climate, sea level, cities
   AI summary: (not on free tier - add a paid newsdata.io plan)
```

## Configuration

All settings are environment variables (or lines in `.env`):

| Variable | Purpose |
| --- | --- |
| `NEWSDATA_API_KEY` | newsdata.io API key (required) |
| `OPENAI_API_KEY` | LLM key for the CrewAI agents |
| `OPENAI_MODEL` | model id for CrewAI (default `gpt-4o-mini`) |
| `ENABLE_PAID` | set to `1` to send paid-tier query params; requires a paid newsdata.io plan |
| `SMTP_HOST` / `SMTP_PORT` / `SMTP_USER` / `SMTP_PASSWORD` | SMTP server for `--send` |
| `EMAIL_FROM` / `EMAIL_TO` | sender and recipient(s) for `--send` |

Notes on the free tier: the free newsdata.io plan returns up to 10 articles per
request and omits fields like `sentiment` and the `ai_*` summaries. The app
reads those fields when present and shows a clearly labeled placeholder when
they are not, so nothing breaks on a free key. Setting `ENABLE_PAID=1` turns on
paid query parameters (larger pages, full content); if the API rejects them the
request is retried once without them.

## Project layout

- `main.py` — CLI entry point
- `news_crew.py` — CrewAI agents, tasks and the fetch tool
- `news_tool.py` — newsdata.io client (pagination, error handling)
- `emailer.py` — digest formatting and optional SMTP send

## License

MIT
