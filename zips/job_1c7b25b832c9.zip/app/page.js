'use client';

import { useState } from 'react';

const COUNTRIES = [
  { code: 'us', name: 'United States' },
  { code: 'gb', name: 'United Kingdom' },
  { code: 'in', name: 'India' },
  { code: 'au', name: 'Australia' },
  { code: 'ca', name: 'Canada' },
  { code: 'de', name: 'Germany' },
  { code: 'fr', name: 'France' },
  { code: 'jp', name: 'Japan' },
  { code: 'br', name: 'Brazil' },
  { code: 'za', name: 'South Africa' },
  { code: 'sg', name: 'Singapore' },
  { code: 'ae', name: 'United Arab Emirates' },
  { code: 'ng', name: 'Nigeria' },
  { code: 'mx', name: 'Mexico' },
];

const DEFAULT_SELECTED = ['us', 'gb', 'in'];
const SAMPLE_STATS = { positive: 4, neutral: 5, negative: 3 };

function nameFor(code) {
  const match = COUNTRIES.find((c) => c.code === code);
  return match ? match.name : code.toUpperCase();
}

function sentimentStats(articles) {
  const counts = { positive: 0, neutral: 0, negative: 0 };
  let total = 0;
  for (const a of articles) {
    const s = (a.sentiment || '').toLowerCase();
    if (s === 'positive' || s === 'neutral' || s === 'negative') {
      counts[s] += 1;
      total += 1;
    }
  }
  return { counts, total };
}

function SentimentBar({ counts, total }) {
  const sample = total === 0;
  const data = sample ? SAMPLE_STATS : counts;
  const sum = sample ? SAMPLE_STATS.positive + SAMPLE_STATS.neutral + SAMPLE_STATS.negative : total;
  const pct = (n) => (sum ? Math.round((n / sum) * 100) : 0);

  return (
    <div className={'sentiment' + (sample ? ' is-sample' : '')}>
      <div className="sentiment-bars">
        <span className="seg pos" style={{ width: pct(data.positive) + '%' }} />
        <span className="seg neu" style={{ width: pct(data.neutral) + '%' }} />
        <span className="seg neg" style={{ width: pct(data.negative) + '%' }} />
      </div>
      <div className="sentiment-legend">
        <span><i className="dot pos" />{data.positive} pos</span>
        <span><i className="dot neu" />{data.neutral} neu</span>
        <span><i className="dot neg" />{data.negative} neg</span>
      </div>
      {sample && (
        <p className="sample-note">sample — live sentiment requires a paid newsdata.io plan</p>
      )}
    </div>
  );
}

function ArticleCard({ a }) {
  return (
    <article className="card">
      {a.image && (
        <img
          className="thumb"
          src={a.image}
          alt=""
          loading="lazy"
          onError={(e) => {
            e.currentTarget.style.display = 'none';
          }}
        />
      )}
      <h3 className="card-title">
        {a.link ? (
          <a href={a.link} target="_blank" rel="noreferrer">
            {a.title}
          </a>
        ) : (
          a.title
        )}
      </h3>
      <div className="meta">
        {a.source && <span>{a.source}</span>}
        {a.pubDate && <span>{a.pubDate}</span>}
        {a.sentiment && (
          <span className={'badge ' + a.sentiment.toLowerCase()}>{a.sentiment}</span>
        )}
      </div>
      {a.aiSummary ? (
        <p className="summary ai">{a.aiSummary}</p>
      ) : (
        a.description && <p className="summary">{a.description}</p>
      )}
      {a.aiTag.length > 0 && (
        <div className="chips ai-chips">
          {a.aiTag.map((t, i) => (
            <span key={i} className="chip ai">{t}</span>
          ))}
        </div>
      )}
      {a.keywords.length > 0 && (
        <div className="chips">
          {a.keywords.map((k, i) => (
            <span key={i} className="chip">{k}</span>
          ))}
        </div>
      )}
    </article>
  );
}

function Column({ column }) {
  const { counts, total } = sentimentStats(column.articles);
  return (
    <section className="column">
      <header className="column-head">
        <h2>{nameFor(column.country)}</h2>
        <span className="count">
          {column.error ? '—' : column.articles.length + ' articles'}
        </span>
      </header>
      <SentimentBar counts={counts} total={total} />
      {column.error ? (
        <p className="col-error">{column.error}</p>
      ) : column.articles.length === 0 ? (
        <p className="empty">No articles found for this term.</p>
      ) : (
        column.articles.map((a) => <ArticleCard key={a.id} a={a} />)
      )}
    </section>
  );
}

export default function Home() {
  const [query, setQuery] = useState('elections');
  const [selected, setSelected] = useState(DEFAULT_SELECTED);
  const [columns, setColumns] = useState([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [lastQuery, setLastQuery] = useState('');

  function toggleCountry(code) {
    setSelected((prev) =>
      prev.includes(code) ? prev.filter((c) => c !== code) : [...prev, code]
    );
  }

  async function compare(e) {
    e.preventDefault();
    setError('');

    const q = query.trim();
    if (!q) {
      setError('Enter a search term first.');
      return;
    }
    if (selected.length === 0) {
      setError('Pick at least one country.');
      return;
    }

    setLoading(true);
    try {
      const url =
        '/api/compare?q=' +
        encodeURIComponent(q) +
        '&countries=' +
        encodeURIComponent(selected.join(','));
      const res = await fetch(url);
      const data = await res.json();
      if (!res.ok) {
        throw new Error(data.error || 'Request failed.');
      }
      setColumns(data.columns || []);
      setLastQuery(q);
    } catch (err) {
      setError(err.message);
      setColumns([]);
    } finally {
      setLoading(false);
    }
  }

  return (
    <main className="page">
      <header className="page-head">
        <h1>Country News Comparison</h1>
        <p>
          See how the same story is covered in different countries. Headlines
          come from the{' '}
          <a href="https://newsdata.io" target="_blank" rel="noreferrer">
            newsdata.io
          </a>{' '}
          news API.
        </p>
      </header>

      <form className="controls" onSubmit={compare}>
        <input
          className="search"
          type="text"
          value={query}
          placeholder="Search a topic or event, e.g. inflation"
          onChange={(e) => setQuery(e.target.value)}
        />
        <button className="go" type="submit" disabled={loading}>
          {loading ? 'Comparing…' : 'Compare'}
        </button>
      </form>

      <div className="country-picker">
        {COUNTRIES.map((c) => (
          <label
            key={c.code}
            className={'country-chip' + (selected.includes(c.code) ? ' on' : '')}
          >
            <input
              type="checkbox"
              checked={selected.includes(c.code)}
              onChange={() => toggleCountry(c.code)}
            />
            {c.name}
          </label>
        ))}
      </div>

      {error && <p className="error">{error}</p>}

      {lastQuery && !error && (
        <p className="result-note">
          Showing coverage for <strong>{lastQuery}</strong> across{' '}
          {columns.length} {columns.length === 1 ? 'country' : 'countries'}.
        </p>
      )}

      <div className="grid">
        {columns.map((col) => (
          <Column key={col.country} column={col} />
        ))}
      </div>

      {!loading && columns.length === 0 && !error && (
        <p className="hint">
          Choose your countries above, enter a term, and hit Compare.
        </p>
      )}
    </main>
  );
}
