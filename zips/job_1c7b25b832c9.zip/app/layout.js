import './globals.css';

export const metadata = {
  title: 'Country News Comparison',
  description:
    'Compare how outlets in different countries cover the same news event, using the newsdata.io news API.',
};

export default function RootLayout({ children }) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  );
}
