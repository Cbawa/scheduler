const BASE = 'https://newsdata.io/api/1/latest';

export async function GET(request) {
  const apiKey = process.env.NEWSDATA_API_KEY;
  if (!apiKey) {
    return json(
      {
        error:
          'NEWSDATA_API_KEY is not set. Get a free key at https://newsdata.io and add it to .env.local.',
      },
      500
    );
  }

  const { searchParams } = new URL(request.url);
  const q = (searchParams.get('q') || '').trim();
  const language = (searchParams.get('language') || '').trim();
  const countries = (searchParams.get('countries') || '')
    .split(',')
    .map((c) => c.trim().toLowerCase())
    .filter(Boolean)
    .slice(0, 6);

  if (!q) return json({ error: 'Please enter a search term.' }, 400);
  if (countries.length === 0)
    return json({ error: 'Please select at least one country.' }, 400);

  const paid = process.env.ENABLE_PAID_PARAMS === '1';

  const columns = await Promise.all(
    countries.map((country) => fetchCountry({ apiKey, q, country, language, paid }))
  );

  return json({ q, columns });
}

function buildUrl({ apiKey, q, country, language, paid, page }) {
  const params = new URLSearchParams();
  params.set('apikey', apiKey);
  params.set('q', q);
  params.set('country', country);
  if (language) params.set('language', language);
  // full_content is a paid-only query param; only sent in paid mode and
  // dropped on retry if the request is rejected.
  if (paid) params.set('full_content', '1');
  if (page) params.set('page', page);
  return BASE + '?' + params.toString();
}

async function requestNews(url) {
  const res = await fetch(url, {
    headers: { Accept: 'application/json' },
    cache: 'no-store',
  });

  let body = null;
  try {
    body = await res.json();
  } catch (_) {
    body = null;
  }

  if (res.status === 401) {
    throw fail('Invalid API key (401). Check NEWSDATA_API_KEY.');
  }
  if (res.status === 429) {
    throw fail('Rate limit reached (429). Wait a moment and try again.');
  }
  if (res.status === 403 || res.status === 422) {
    const msg =
      (body && (body.results?.message || body.message)) ||
      'Request rejected (' + res.status + ').';
    throw fail(msg, res.status);
  }
  if (!res.ok) {
    throw fail('Request failed (' + res.status + ').');
  }
  return body;
}

async function fetchCountry({ apiKey, q, country, language, paid }) {
  const attempt = (usePaid) =>
    requestNews(buildUrl({ apiKey, q, country, language, paid: usePaid }));

  try {
    let body;
    try {
      body = await attempt(paid);
    } catch (err) {
      // Paid params can error the whole request on a free key — retry once
      // without them so the user still gets free results.
      if (paid && (err.code === 403 || err.code === 422)) {
        body = await attempt(false);
      } else {
        throw err;
      }
    }

    const results = Array.isArray(body?.results) ? body.results : [];
    return { country, articles: results.map(normalize) };
  } catch (err) {
    return { country, articles: [], error: err.message };
  }
}

function normalize(a) {
  return {
    id: a.article_id || a.link || a.title || Math.random().toString(36).slice(2),
    title: a.title || 'Untitled',
    link: a.link || null,
    description: a.description || null,
    pubDate: a.pubDate || null,
    source: a.source_id || a.source_name || null,
    image: a.image_url || null,
    keywords: Array.isArray(a.keywords) ? a.keywords.slice(0, 6) : [],
    sentiment: cleanString(a.sentiment),
    aiTag: toList(a.ai_tag),
    aiSummary: cleanString(a.ai_summary),
  };
}

function toList(v) {
  if (!v) return [];
  if (Array.isArray(v)) {
    return v.filter((x) => typeof x === 'string' && !isNa(x)).slice(0, 6);
  }
  if (typeof v === 'string' && !isNa(v)) return [v];
  return [];
}

function cleanString(v) {
  if (typeof v !== 'string') return null;
  if (isNa(v)) return null;
  return v;
}

function isNa(v) {
  return typeof v === 'string' && v.trim().toLowerCase() === 'not available';
}

function fail(message, code) {
  const e = new Error(message);
  if (code) e.code = code;
  return e;
}

function json(data, status = 200) {
  return new Response(JSON.stringify(data), {
    status,
    headers: { 'Content-Type': 'application/json' },
  });
}
