# Country News Comparison

Type in an event or topic, pick a few countries, and see how each country's
outlets are covering it — laid out in side-by-side columns so the differences
are easy to scan.

Headlines come from the [newsdata.io](https://newsdata.io) news API. You'll need
a free API key to run it; one request goes out per selected country, each scoped
to that country's sources for the same search term.

## What it does

- Search any term and compare coverage across up to six countries at once.
- Each column shows the latest matching articles for that country: title,
  source, publish date, and a short description.
- Keyword tags (returned by the API) are shown as chips on every article.
- A per-column sentiment breakdown bar, per-article sentiment badges, AI topic
  tags, and an AI summary line surface the richer fields the API can return.
  These are read straight from the response, so on a free key they fall back to
  a clearly labelled placeholder instead of disappearing.

## Requirements

- Node.js 18.17 or newer
- A newsdata.io API key (the free tier is enough — get one at
  <https://newsdata.io>)

## Setup

```bash
git clone https://github.com/your-name/country-news-comparison.git
cd country-news-comparison
npm install
```

Copy the example environment file and drop your key in:

```bash
cp .env.example .env.local
```

```
# .env.local
NEWSDATA_API_KEY=pub_xxxxxxxxxxxxxxxxxxxxxxxx
```

The key is read on the server only (from `NEWSDATA_API_KEY`) and is never sent
to the browser. If it's missing, the API route returns a clear error instead of
failing silently.

## Running it

```bash
npm run dev
```

Then open <http://localhost:3000>, enter a search term such as `elections` or
`inflation`, tick a few countries, and hit Compare.

For a production build:

```bash
npm run build
npm start
```

## Example

Query `climate` across the United States, the United Kingdom, and India returns
three columns, each filled from that country's sources. A single article looks
roughly like this in the response, which is what the cards render from:

```json
{
  "title": "Government unveils new climate targets",
  "link": "https://example.com/article",
  "source_id": "example_news",
  "pubDate": "2026-06-10 09:14:00",
  "country": ["united kingdom"],
  "keywords": ["climate", "emissions", "policy"]
}
```

`keywords` is present on the free tier and drives the chips. The `sentiment`,
`ai_tag`, and `ai_summary` fields are part of the same response shape but only
carry values on a paid newsdata.io plan; the UI shows labelled sample states for
them otherwise.

## Configuration

| Variable | Required | Notes |
| --- | --- | --- |
| `NEWSDATA_API_KEY` | yes | Your newsdata.io key. |
| `ENABLE_PAID_PARAMS` | no | Set to `1` to send paid-only query params (e.g. full content). Requires a paid newsdata.io plan; if such a request is rejected, the app retries once without them so you still get free results. Leave unset on the free tier. |

## How it talks to the API

The server route calls `GET https://newsdata.io/api/1/latest` once per country
with `q` and `country` set, reads the `results` array, and normalises each
article. It handles invalid keys (401), rate limits (429), and empty result
sets without crashing. Pagination uses the `nextPage` cursor when more pages are
needed.

## Project layout

```
app/
  api/compare/route.js   server route that fans out one request per country
  page.js                the comparison UI (client component)
  layout.js
  globals.css
```

## License

MIT
