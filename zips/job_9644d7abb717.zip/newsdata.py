"""Thin client for the newsdata.io news API (https://newsdata.io).

Only the free-tier /latest endpoint is used by default. Paid query params are
sent only when paid=True, and the client falls back to a free request if the
server rejects them.
"""
import requests

BASE_URL = "https://newsdata.io/api/1"
USER_AGENT = "news-image-collager"


class NewsdataError(Exception):
    """Base error for any problem talking to newsdata.io."""


class AuthError(NewsdataError):
    """The API key was rejected (HTTP 401)."""


class RateLimitError(NewsdataError):
    """Too many requests (HTTP 429)."""


class PaidParamError(NewsdataError):
    """A paid-only query param was sent on a free key (HTTP 403/422)."""


def _message(body):
    if isinstance(body, dict):
        results = body.get("results")
        if isinstance(results, dict):
            return results.get("message") or results.get("code")
        return body.get("message")
    return None


def _get(params):
    try:
        resp = requests.get(
            BASE_URL + "/latest",
            params=params,
            timeout=30,
            headers={"User-Agent": USER_AGENT},
        )
    except requests.RequestException as exc:
        raise NewsdataError(str(exc)) from exc

    try:
        body = resp.json()
    except ValueError:
        body = {}

    if resp.status_code == 401:
        raise AuthError(_message(body) or "invalid API key")
    if resp.status_code == 429:
        raise RateLimitError(_message(body) or "rate limited")
    if resp.status_code in (403, 422):
        raise PaidParamError(_message(body) or "HTTP %s" % resp.status_code)
    if resp.status_code >= 400 or body.get("status") == "error":
        raise NewsdataError(_message(body) or "HTTP %s" % resp.status_code)
    return body


def fetch_latest(api_key, query=None, language="en", category=None,
                 country=None, max_articles=16, paid=False):
    """Fetch up to max_articles latest articles, following the nextPage cursor.

    Returns a list of article dicts (possibly empty). Raises AuthError,
    RateLimitError, or NewsdataError on failure.
    """
    base = {"apikey": api_key}
    if language:
        base["language"] = language
    if query:
        base["q"] = query
    if category:
        base["category"] = category
    if country:
        base["country"] = country
    if paid:
        # full_content is a paid-only param; included only in paid mode.
        base["full_content"] = 1

    articles = []
    page = None
    used_free_fallback = False

    while len(articles) < max_articles:
        params = dict(base)
        if page:
            params["page"] = page
        try:
            data = _get(params)
        except PaidParamError:
            if paid and not used_free_fallback:
                # Paid params rejected on a free key: retry on the free path.
                base.pop("full_content", None)
                used_free_fallback = True
                page = None
                articles = []
                continue
            raise

        results = data.get("results") or []
        articles.extend(results)
        page = data.get("nextPage")
        if not page:
            break

    return articles[:max_articles]
