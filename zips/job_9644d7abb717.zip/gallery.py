"""Render a standalone HTML gallery from newsdata.io articles.

Free-tier keys return keywords on every article; richer fields (sentiment,
ai_tag, ai_summary) are absent on free keys, so each is guarded and shown with
a clearly labeled placeholder when missing.
"""
import html
from collections import Counter

SENT_COLORS = {"positive": "#1a7f37", "neutral": "#57606a", "negative": "#cf222e"}
PAID_PLACEHOLDER = "ONLY AVAILABLE IN"


def _esc(value):
    return html.escape(str(value)) if value is not None else ""


def _paid(value):
    """Return a real paid-field value, or None if absent/placeholder."""
    if value is None:
        return None
    if isinstance(value, str):
        return None if PAID_PLACEHOLDER in value.upper() else value
    if isinstance(value, list):
        cleaned = [v for v in value
                   if not (isinstance(v, str) and PAID_PLACEHOLDER in v.upper())]
        return cleaned or None
    return value


def _as_list(value):
    if value is None:
        return []
    if isinstance(value, list):
        return [str(v) for v in value if v]
    return [str(value)]


def _chips(values, cls):
    return "".join("<span class='chip %s'>%s</span>" % (cls, _esc(v)) for v in values)


def _sentiment_counts(articles):
    counts = Counter()
    for art in articles:
        sentiment = _paid(art.get("sentiment"))
        if sentiment in SENT_COLORS:
            counts[sentiment] += 1
    return counts


def _bar_chart(counts, sample=False):
    order = ["positive", "neutral", "negative"]
    total = sum(counts.get(k, 0) for k in order) or 1
    rows = []
    for key in order:
        n = counts.get(key, 0)
        pct = round(100 * n / total)
        rows.append(
            "<div class='bar-row'>"
            "<span class='bar-label'>%s</span>"
            "<span class='bar-track'><span class='bar-fill' "
            "style='width:%d%%;background:%s'></span></span>"
            "<span class='bar-val'>%d</span></div>" % (key, pct, SENT_COLORS[key], n)
        )
    note = ""
    if sample:
        note = ("<p class='sample-note'>sample - live sentiment requires a paid "
                "newsdata.io plan</p>")
    return "<div class='chart'>" + "".join(rows) + note + "</div>"


def _card(art):
    title = _esc(art.get("title") or "(untitled)")
    link = _esc(art.get("link") or "#")
    source = _esc(art.get("source_id") or art.get("source_name") or "unknown source")

    img_src = art.get("_local_image") or art.get("image_url")
    if img_src:
        thumb = "<img class='thumb' src='%s' alt='' loading='lazy'>" % _esc(img_src)
    else:
        thumb = "<div class='thumb no-img'>no image</div>"

    keywords = _as_list(_paid(art.get("keywords")))[:6]
    if keywords:
        kw_html = _chips(keywords, "kw")
    else:
        kw_html = "<span class='muted'>no keywords</span>"

    ai_tags = _as_list(_paid(art.get("ai_tag")))[:5]
    if ai_tags:
        tag_html = _chips(ai_tags, "ai")
    else:
        tag_html = "<span class='muted sample'>AI tags - paid newsdata.io plan</span>"

    sentiment = _paid(art.get("sentiment"))
    if sentiment in SENT_COLORS:
        badge = "<span class='badge' style='background:%s'>%s</span>" % (
            SENT_COLORS[sentiment], sentiment)
    else:
        badge = "<span class='badge sample-badge'>sentiment n/a</span>"

    summary = _paid(art.get("ai_summary"))
    summary_html = "<p class='summary'>%s</p>" % _esc(summary) if summary else ""

    return (
        "<article class='card'>"
        "<a class='thumb-link' href='%s' target='_blank' rel='noopener'>%s</a>"
        "<div class='body'>"
        "<div class='meta'><span class='source'>%s</span>%s</div>"
        "<h2 class='title'><a href='%s' target='_blank' rel='noopener'>%s</a></h2>"
        "%s"
        "<div class='chips'>%s</div>"
        "<div class='chips'>%s</div>"
        "</div></article>"
    ) % (link, thumb, source, badge, link, title, summary_html, kw_html, tag_html)


def write_gallery(path, articles, used, paid=False):
    """Write a standalone HTML gallery to path."""
    counts = _sentiment_counts(articles)
    if sum(counts.values()) > 0:
        chart = _bar_chart(counts)
    else:
        sample = Counter({"positive": 5, "neutral": 8, "negative": 3})
        chart = _bar_chart(sample, sample=True)

    cards = "".join(_card(a) for a in articles)
    collage_block = ""
    if used:
        collage_block = (
            "<section class='collage'><h2>Today's collage</h2>"
            "<img src='collage.png' alt='news image collage'></section>"
        )

    doc = PAGE % {
        "count": len(articles),
        "with_images": len(used),
        "chart": chart,
        "collage": collage_block,
        "cards": cards,
    }
    with open(path, "w", encoding="utf-8") as fh:
        fh.write(doc)


PAGE = """<!doctype html>
<html lang='en'>
<head>
<meta charset='utf-8'>
<meta name='viewport' content='width=device-width, initial-scale=1'>
<title>News image collage</title>
<style>
:root { color-scheme: light dark; }
body { font-family: system-ui, sans-serif; margin: 0; background: #0f1117; color: #e6e6e6; }
header { padding: 24px; border-bottom: 1px solid #262a33; }
header h1 { margin: 0 0 4px; font-size: 20px; }
header p { margin: 0; color: #9aa0aa; font-size: 14px; }
main { max-width: 1100px; margin: 0 auto; padding: 24px; }
section { margin-bottom: 32px; }
section h2 { font-size: 16px; margin: 0 0 12px; }
.collage img { width: 100%%; border-radius: 10px; display: block; }
.chart { max-width: 460px; }
.bar-row { display: flex; align-items: center; gap: 10px; margin: 6px 0; font-size: 13px; }
.bar-label { width: 64px; color: #c7ccd4; }
.bar-track { flex: 1; height: 12px; background: #1b1f27; border-radius: 6px; overflow: hidden; }
.bar-fill { display: block; height: 100%%; }
.bar-val { width: 28px; text-align: right; color: #9aa0aa; }
.sample-note { color: #8a8f99; font-size: 12px; font-style: italic; margin: 6px 0 0; }
.grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(260px, 1fr)); gap: 16px; }
.card { background: #161922; border: 1px solid #262a33; border-radius: 10px; overflow: hidden; display: flex; flex-direction: column; }
.thumb-link { display: block; }
.thumb { width: 100%%; height: 160px; object-fit: cover; display: block; }
.no-img { display: flex; align-items: center; justify-content: center; color: #6b7280; background: #1b1f27; height: 160px; }
.body { padding: 12px; display: flex; flex-direction: column; gap: 8px; }
.meta { display: flex; align-items: center; gap: 8px; font-size: 12px; color: #9aa0aa; }
.source { text-transform: uppercase; letter-spacing: .04em; }
.title { font-size: 15px; margin: 0; line-height: 1.3; }
.title a { color: #e6e6e6; text-decoration: none; }
.title a:hover { text-decoration: underline; }
.summary { font-size: 13px; color: #c7ccd4; margin: 0; }
.chips { display: flex; flex-wrap: wrap; gap: 6px; }
.chip { font-size: 11px; padding: 2px 8px; border-radius: 999px; background: #1f2530; color: #cdd3dc; }
.chip.ai { background: #1d2b22; color: #8fd1a6; }
.badge { font-size: 11px; padding: 2px 8px; border-radius: 6px; color: #fff; }
.sample-badge { background: #2a2f3a; color: #9aa0aa; }
.muted { font-size: 11px; color: #6b7280; }
.muted.sample { font-style: italic; }
footer { padding: 24px; text-align: center; color: #6b7280; font-size: 12px; }
footer a { color: #8a93a3; }
</style>
</head>
<body>
<header>
<h1>News image collage</h1>
<p>%(count)s articles, %(with_images)s with images. Data from the newsdata.io news API.</p>
</header>
<main>
%(collage)s
<section><h2>Sentiment breakdown</h2>%(chart)s</section>
<section><h2>Articles</h2><div class='grid'>%(cards)s</div></section>
</main>
<footer>Built with the <a href='https://newsdata.io' target='_blank' rel='noopener'>newsdata.io</a> news API.</footer>
</body>
</html>
"""
