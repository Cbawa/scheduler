"""Image download + collage assembly with Pillow."""
import io
import math
import os

import requests
from PIL import Image, ImageOps

USER_AGENT = "news-image-collager"


def download_image(url, timeout=20):
    """Download an image URL and return an RGB PIL image."""
    resp = requests.get(url, timeout=timeout, headers={"User-Agent": USER_AGENT})
    resp.raise_for_status()
    img = Image.open(io.BytesIO(resp.content))
    return img.convert("RGB")


def gather_images(articles, img_dir, cell=320):
    """Download each article's image_url (when present) into img_dir.

    Saves a square thumbnail per article and records its relative path on the
    article dict under "_local_image". Returns the list of articles that got a
    usable image, each as {"index", "article", "image"}.
    """
    os.makedirs(img_dir, exist_ok=True)
    used = []
    for i, art in enumerate(articles):
        url = art.get("image_url")
        if not url:
            continue
        try:
            img = download_image(url)
        except Exception:
            # Broken link, timeout, or non-image payload - skip it quietly.
            continue
        thumb = ImageOps.fit(img, (cell, cell), Image.LANCZOS)
        fname = "img_%02d.jpg" % i
        thumb.save(os.path.join(img_dir, fname), "JPEG", quality=88)
        art["_local_image"] = os.path.join("images", fname)
        used.append({"index": i, "article": art, "image": thumb})
    return used


def build_collage(images, cols=None, cell=320, padding=8, bg=(18, 18, 22)):
    """Arrange square thumbnails into a padded grid and return a PIL image."""
    if not images:
        raise ValueError("no images to assemble")
    n = len(images)
    if not cols or cols < 1:
        cols = max(1, round(math.sqrt(n)))
    rows = math.ceil(n / cols)

    width = cols * cell + (cols + 1) * padding
    height = rows * cell + (rows + 1) * padding
    canvas = Image.new("RGB", (width, height), bg)

    for idx, img in enumerate(images):
        if img.size != (cell, cell):
            img = ImageOps.fit(img, (cell, cell), Image.LANCZOS)
        r, c = divmod(idx, cols)
        x = padding + c * (cell + padding)
        y = padding + r * (cell + padding)
        canvas.paste(img, (x, y))
    return canvas
