# news-image-collager

A small command-line tool that grabs recent news headlines, downloads their
article images, and stitches them into a single collage PNG plus a browsable
HTML gallery. It pulls live headlines from the newsdata.io news API
(https://newsdata.io) - grab a free API key to run it.

I built this to get a quick visual snapshot of "what the news looks like" on a
given day or topic. Point it at a category or a search term and you get one
image per article laid out in a grid, plus a card view that also surfaces the
keywords newsdata.io returns for each story.

## What it does

- Fetches the latest articles from newsdata.io, following the `nextPage` cursor
  to gather more than one page.
- Downloads each article's image and assembles a padded grid collage saved as
  `collage.png`.
- Writes a self-contained `gallery.html` with one card per article: image,
  source, title, keyword tags, an AI-tag row, and a sentiment breakdown chart.
- Skips broken, missing, or non-image links instead of crashing.

## Requirements

- Python 3.9 or newer
- A newsdata.io API key. The free tier is enough for the core flow. Create one
  at https://newsdata.io and export it:

```
export NEWSDATA_API_KEY=your_key_here
```

## Install

```
git clone <your-fork-url>
cd news-image-collager
pip install -r requirements.txt
```

## Usage

Latest English-language headlines:

```
python main.py
```

Search a topic and cap the count:

```
python main.py --query "space launch" --max 12
```

By category and country, with a fixed column count:

```
python main.py --category technology --country us --cols 4
```

### Options

| Flag | Description | Default |
| ---- | ----------- | ------- |
| `-q, --query` | Search term | none |
| `-l, --language` | Language code | `en` |
| `-c, --category` | Category (technology, sports, ...) | none |
| `--country` | Country code (us, gb, in, ...) | none |
| `-n, --max` | Max articles to fetch | `16` |
| `--cols` | Collage columns | auto |
| `--cell` | Cell size in pixels | `320` |
| `-o, --out` | Output directory | `output` |
| `--paid` | Send paid query params (see notes) | off |

### Example

```
$ export NEWSDATA_API_KEY=pub_xxx
$ python main.py --category science --max 9 --cols 3
Fetching headlines from newsdata.io ...
Got 9 articles. Downloading images ...
Wrote collage: output/collage.png  (984x984)
Wrote gallery: output/gallery.html
Open it in a browser to see the cards, keywords and sentiment breakdown.
```

Then open `output/gallery.html` in a browser.

## Output

Everything lands in the output directory (default `output/`):

- `collage.png` - the grid of article images
- `gallery.html` - the card gallery (open this one)
- `images/` - the individual downloaded thumbnails

## Notes on newsdata.io fields

The free tier returns `keywords` for most articles, which power the tag chips on
each card. A few fields only appear on paid plans: `sentiment` (used for the
per-article badge and the breakdown chart), `ai_tag`, and `ai_summary`. When
those are absent the gallery still renders the widgets, but with a small
"sample" or "n/a" label so it is clear the data needs a paid plan rather than
looking broken.

Passing `--paid` (or setting `NEWSDATA_PAID=1`) sends paid-only query params such
as `full_content`. On a free key that request would be rejected, so the tool
retries once without them and continues with free results.

## License

MIT
