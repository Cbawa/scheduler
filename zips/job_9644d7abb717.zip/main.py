#!/usr/bin/env python3
"""news-image-collager: build a collage + HTML gallery from newsdata.io images."""
import argparse
import os
import sys

from newsdata import fetch_latest, NewsdataError, AuthError, RateLimitError
from collage import build_collage, gather_images
from gallery import write_gallery


def parse_args(argv=None):
    parser = argparse.ArgumentParser(
        prog="news-image-collager",
        description="Download news images from newsdata.io and build a collage + gallery.",
    )
    parser.add_argument("-q", "--query", help="search term (optional)")
    parser.add_argument("-l", "--language", default="en", help="language code (default: en)")
    parser.add_argument("-c", "--category", help="category, e.g. technology, sports")
    parser.add_argument("--country", help="country code, e.g. us, gb, in")
    parser.add_argument("-n", "--max", type=int, default=16, help="max articles (default: 16)")
    parser.add_argument("--cols", type=int, help="collage columns (default: auto)")
    parser.add_argument("--cell", type=int, default=320, help="cell size in px (default: 320)")
    parser.add_argument("-o", "--out", default="output", help="output directory (default: output)")
    parser.add_argument(
        "--paid",
        action="store_true",
        help="send paid query params (needs a paid newsdata.io plan); "
             "falls back to free mode if rejected",
    )
    return parser.parse_args(argv)


def main(argv=None):
    args = parse_args(argv)

    api_key = os.environ.get("NEWSDATA_API_KEY")
    if not api_key:
        print("Error: NEWSDATA_API_KEY is not set.", file=sys.stderr)
        print("Get a free key at https://newsdata.io, then run:", file=sys.stderr)
        print("  export NEWSDATA_API_KEY=your_key_here", file=sys.stderr)
        return 2

    paid = args.paid or os.environ.get("NEWSDATA_PAID") == "1"

    try:
        print("Fetching headlines from newsdata.io ...")
        articles = fetch_latest(
            api_key,
            query=args.query,
            language=args.language,
            category=args.category,
            country=args.country,
            max_articles=args.max,
            paid=paid,
        )
    except AuthError:
        print("Error: newsdata.io rejected the API key (401). Check NEWSDATA_API_KEY.", file=sys.stderr)
        return 1
    except RateLimitError:
        print("Error: rate limit reached (429). Wait a minute and try again.", file=sys.stderr)
        return 1
    except NewsdataError as exc:
        print("Error talking to newsdata.io: %s" % exc, file=sys.stderr)
        return 1

    if not articles:
        print("No articles came back. Try a broader query or a different category.")
        return 0

    print("Got %d articles. Downloading images ..." % len(articles))
    os.makedirs(args.out, exist_ok=True)
    img_dir = os.path.join(args.out, "images")
    used = gather_images(articles, img_dir, cell=args.cell)

    if used:
        collage = build_collage([u["image"] for u in used], cols=args.cols, cell=args.cell)
        collage_path = os.path.join(args.out, "collage.png")
        collage.save(collage_path)
        print("Wrote collage: %s  (%dx%d)" % (collage_path, collage.width, collage.height))
    else:
        print("None of the articles had a usable image; writing the gallery without a collage.")

    gallery_path = os.path.join(args.out, "gallery.html")
    write_gallery(gallery_path, articles, used, paid=paid)
    print("Wrote gallery: %s" % gallery_path)
    print("Open it in a browser to see the cards, keywords and sentiment breakdown.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
