"""Helpers for turning newsdata.io article results into PR metrics.

These stay framework-free so they can be unit-tested or reused outside Streamlit.
"""
from collections import Counter
from datetime import datetime

PLACEHOLDER_HINT = 'ONLY AVAILABLE'


def clean_field(value):
    """Return a usable value, or None when the field is absent or carries a
    free-plan placeholder like 'ONLY AVAILABLE IN PAID PLANS'."""
    if value is None:
        return None
    if isinstance(value, str) and PLACEHOLDER_HINT in value.upper():
        return None
    return value


def as_list(value):
    value = clean_field(value)
    if value is None:
        return []
    if isinstance(value, list):
        return value
    return [value]


def article_sentiment(article):
    val = clean_field(article.get('sentiment'))
    if isinstance(val, str):
        v = val.strip().lower()
        if v in ('positive', 'negative', 'neutral'):
            return v
    return None


def parse_date(value):
    if not value or not isinstance(value, str):
        return None
    head = value.strip()[:19]
    for fmt in ('%Y-%m-%d %H:%M:%S', '%Y-%m-%dT%H:%M:%S'):
        try:
            return datetime.strptime(head, fmt)
        except ValueError:
            continue
    try:
        return datetime.strptime(value.strip()[:10], '%Y-%m-%d')
    except ValueError:
        return None


def coverage_score(articles, target_mentions=40, target_sources=12):
    """Relative 0-100 gauge: 60% mention volume + 40% source diversity."""
    count = len(articles)
    source_ids = {
        (a.get('source_id') or a.get('source_name'))
        for a in articles
        if (a.get('source_id') or a.get('source_name'))
    }
    sources = len(source_ids)
    volume = min(count / target_mentions, 1.0) * 60
    reach = min(sources / target_sources, 1.0) * 40
    return round(volume + reach), count, sources


def sentiment_breakdown(articles):
    counts = Counter()
    have = False
    for a in articles:
        s = article_sentiment(a)
        if s:
            have = True
            counts[s] += 1
    return dict(counts), have


def top_keywords(articles, limit=20):
    counter = Counter()
    for a in articles:
        for kw in as_list(a.get('keywords')):
            if isinstance(kw, str) and kw.strip():
                counter[kw.strip().lower()] += 1
    return counter.most_common(limit)
