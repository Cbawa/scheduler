"""Minimal client for the newsdata.io news API (https://newsdata.io).

Only the free-tier-safe /latest endpoint is used on the default path. Paid query
parameters are sent only when paid_mode is enabled, and the client retries once
without them if the API rejects the request.
"""
import os

import requests

BASE_URL = 'https://newsdata.io/api/1'


class NewsDataError(Exception):
    pass


def _error_message(data, status):
    msg = None
    if isinstance(data, dict):
        results = data.get('results')
        if isinstance(results, dict):
            msg = results.get('message')
        if not msg:
            msg = data.get('message')
    if msg:
        return f'newsdata.io error (HTTP {status}): {msg}'
    return f'newsdata.io request failed (HTTP {status}).'


class NewsDataClient:
    def __init__(self, api_key=None, paid_mode=False, timeout=20):
        self.api_key = api_key or os.environ.get('NEWSDATA_API_KEY')
        if not self.api_key:
            raise NewsDataError('NEWSDATA_API_KEY is not set.')
        self.paid_mode = paid_mode
        self.timeout = timeout
        self.session = requests.Session()

    def _get(self, endpoint, params):
        clean = {k: v for k, v in params.items() if v not in (None, '')}
        clean['apikey'] = self.api_key
        try:
            resp = self.session.get(f'{BASE_URL}/{endpoint}', params=clean, timeout=self.timeout)
        except requests.RequestException as exc:
            raise NewsDataError(f'Could not reach newsdata.io: {exc}')
        try:
            data = resp.json()
        except ValueError:
            data = None
        return data, resp.status_code

    def fetch_latest(self, query, language=None, country=None, max_pages=2):
        """Fetch up to max_pages of latest-news results for a query, following the
        nextPage cursor. Returns a list of article dicts."""
        collected = []
        page = None
        use_paid = self.paid_mode

        for _ in range(max(1, max_pages)):
            params = {'q': query, 'language': language, 'country': country}
            if page:
                params['page'] = page
            if use_paid:
                # size > 10 is a paid-only capability; pull more articles per page.
                params['size'] = 50

            data, status = self._get('latest', params)

            if status == 401:
                raise NewsDataError('newsdata.io rejected the API key (HTTP 401). Check NEWSDATA_API_KEY.')
            if status == 429:
                if collected:
                    break
                raise NewsDataError('newsdata.io rate limit reached (HTTP 429). Wait a moment and try again.')
            if status in (403, 422) and use_paid:
                # A paid parameter was refused on this key: drop it and retry the same page.
                use_paid = False
                continue
            if status != 200 or not isinstance(data, dict):
                raise NewsDataError(_error_message(data, status))

            results = data.get('results') or []
            collected.extend(results)

            page = data.get('nextPage')
            if not page:
                break

        return collected
