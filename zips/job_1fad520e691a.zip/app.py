import os
from collections import Counter

import pandas as pd
import streamlit as st

import analysis as an
from newsdata_client import NewsDataClient, NewsDataError

st.set_page_config(page_title='News PR Monitor', layout='wide')

SENT_COLORS = {'positive': '#2e7d32', 'negative': '#c62828', 'neutral': '#6b6b6b'}


@st.cache_data(ttl=600, show_spinner=False)
def load_mentions(query, language, country, paid_mode, max_pages):
    client = NewsDataClient(paid_mode=paid_mode)
    return client.fetch_latest(
        query=query,
        language=language or None,
        country=country or None,
        max_pages=max_pages,
    )


def badge(label):
    color = SENT_COLORS.get(label, '#9e9e9e')
    text = label.capitalize() if label else 'Unrated'
    return f'<span style="background:{color};color:#fff;padding:2px 9px;border-radius:11px;font-size:0.75rem">{text}</span>'


def chip(text):
    return f'<span style="background:#eef1f6;color:#2c3e50;padding:2px 9px;border-radius:11px;font-size:0.78rem;margin-right:4px;display:inline-block;margin-bottom:4px">{text}</span>'


def main():
    st.title('News PR Monitor')
    st.caption('Track brand and product mentions in global news, with a coverage score and a sentiment trend. Headlines come from the newsdata.io news API (https://newsdata.io).')

    api_key = os.environ.get('NEWSDATA_API_KEY')
    paid_mode = os.environ.get('ENABLE_PAID_PARAMS', '').strip().lower() in ('1', 'true', 'yes', 'on')

    with st.sidebar:
        st.header('Search')
        query = st.text_input('Brand or product', value='', placeholder='e.g. Figma')
        language = st.text_input('Language code', value='en', help='ISO code such as en, es, de. Leave blank for any.')
        country = st.text_input('Country code', value='', help='ISO code such as us, gb, in. Leave blank for global.')
        max_pages = st.slider('Pages to fetch', 1, 5, 2, help='Each page returns up to 10 articles on the free plan.')
        st.divider()
        st.caption('Paid mode: on' if paid_mode else 'Paid mode: off')

    if not api_key:
        st.error('NEWSDATA_API_KEY is not set. Export your key and reload. A free key is available at https://newsdata.io.')
        st.stop()

    if not query.strip():
        st.info('Enter a brand or product name in the sidebar to start monitoring.')
        st.stop()

    try:
        with st.spinner('Querying newsdata.io...'):
            articles = load_mentions(query.strip(), language.strip(), country.strip(), paid_mode, max_pages)
    except NewsDataError as exc:
        st.error(str(exc))
        st.stop()

    if not articles:
        st.warning(f'No recent mentions found for {query!r}. Try a broader term, another language, or remove the country filter.')
        st.stop()

    render_dashboard(query, articles, paid_mode)


def render_dashboard(query, articles, paid_mode):
    score, count, sources = an.coverage_score(articles)
    dates = [d for d in (an.parse_date(a.get('pubDate')) for a in articles) if d]
    span = f'{min(dates):%b %d} - {max(dates):%b %d}' if dates else 'n/a'

    c1, c2, c3, c4 = st.columns(4)
    c1.metric('Coverage score', f'{score}/100')
    c2.metric('Mentions', count)
    c3.metric('Distinct sources', sources)
    c4.metric('Date range', span)
    st.caption('Coverage score blends mention volume (60%) and source diversity (40%) into a 0-100 gauge. It is a relative indicator for comparing periods or brands, not an absolute reach figure.')

    st.divider()
    left, right = st.columns(2)

    with left:
        st.subheader('Sentiment breakdown')
        counts, have_sentiment = an.sentiment_breakdown(articles)
        if have_sentiment:
            frame = pd.DataFrame({'articles': counts}).reindex(['positive', 'neutral', 'negative']).dropna()
            st.bar_chart(frame)
        else:
            sample = pd.DataFrame({'articles': [6, 11, 3]}, index=['positive', 'neutral', 'negative'])
            st.bar_chart(sample)
            st.caption('Sample values shown — live sentiment requires a paid newsdata.io plan. Everything else on this page is live.')

    with right:
        st.subheader('Volume and sentiment trend')
        vol_frame, sent_frame = build_trend(articles)
        if sent_frame is not None:
            st.line_chart(sent_frame)
        elif not vol_frame.empty:
            st.line_chart(vol_frame)
            st.caption('Daily mention volume is live. The per-day positive/negative split requires a paid newsdata.io plan.')
        else:
            st.write('Not enough dated articles to plot a trend.')

    st.divider()
    st.subheader('Top keywords')
    keywords = an.top_keywords(articles, 24)
    if keywords:
        st.markdown(''.join(chip(f'{k} ({n})') for k, n in keywords), unsafe_allow_html=True)
    else:
        st.write('No keywords were returned for these results.')

    st.divider()
    st.subheader(f'Mentions ({len(articles)})')
    for a in articles:
        render_article(a)


def build_trend(articles):
    by_day = {}
    by_day_sent = {}
    for a in articles:
        d = an.parse_date(a.get('pubDate'))
        if not d:
            continue
        day = d.date()
        by_day[day] = by_day.get(day, 0) + 1
        s = an.article_sentiment(a)
        if s:
            by_day_sent.setdefault(day, Counter())[s] += 1

    if not by_day:
        return pd.DataFrame(), None

    vol_frame = pd.DataFrame({'mentions': by_day}).sort_index()
    if by_day_sent:
        rows = {}
        for day in sorted(by_day):
            c = by_day_sent.get(day, Counter())
            rows[day] = {
                'positive': c.get('positive', 0),
                'neutral': c.get('neutral', 0),
                'negative': c.get('negative', 0),
            }
        sent_frame = pd.DataFrame(rows).T.sort_index()
        return vol_frame, sent_frame
    return vol_frame, None


def render_article(a):
    with st.container(border=True):
        title = a.get('title') or '(untitled)'
        link = a.get('link')
        head = f'[{title}]({link})' if link else title
        st.markdown(f'**{head}**')

        source = a.get('source_id') or a.get('source_name') or 'unknown source'
        d = an.parse_date(a.get('pubDate'))
        when = f'{d:%Y-%m-%d %H:%M}' if d else (a.get('pubDate') or '')
        sentiment = an.article_sentiment(a)
        meta = f'{source} · {when}' if when else source
        st.markdown(f'{meta} &nbsp; {badge(sentiment)}', unsafe_allow_html=True)

        summary = an.clean_field(a.get('ai_summary')) or a.get('description')
        if summary:
            st.write(summary)

        tags = []
        tags.extend(t for t in an.as_list(an.clean_field(a.get('ai_tag'))) if t)
        tags.extend(k for k in an.as_list(a.get('keywords')) if k)
        seen = []
        for t in tags:
            label = str(t).strip()
            if label and label.lower() not in [s.lower() for s in seen]:
                seen.append(label)
        if seen:
            st.markdown(''.join(chip(t) for t in seen[:12]), unsafe_allow_html=True)


if __name__ == '__main__':
    main()
