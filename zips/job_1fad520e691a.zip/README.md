# News PR Monitor

A small Streamlit dashboard for PR and comms teams to keep an eye on how a brand
or product is showing up in the news. You type a name, it pulls recent global
headlines, and it shows a coverage score, the outlets covering you, a sentiment
breakdown, and a day-by-day volume and sentiment trend.

Headlines come from the newsdata.io news API (https://newsdata.io) — grab a free
API key to run it.

## What it shows

- Coverage score (0-100) combining how many mentions appeared and how many
  distinct outlets carried them.
- Total mentions, distinct sources, and the date range of the results.
- Sentiment breakdown across the matched articles.
- A volume-and-sentiment trend by day.
- Top keywords pulled from the articles, shown as chips.
- A list of mentions with source, time, sentiment, an AI summary line when
  available, and tag/keyword chips.

## Requirements

- Python 3.9+
- A newsdata.io API key (the free plan is enough for the core features)

## Setup

```
git clone <your-fork-url>
cd news-pr-monitor
python -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt
```

Set your key as an environment variable. The app reads it from
`NEWSDATA_API_KEY` and will refuse to start without it:

```
export NEWSDATA_API_KEY=your_key_here
```

On Windows PowerShell:

```
setx NEWSDATA_API_KEY your_key_here
```

## Run

```
streamlit run app.py
```

Streamlit opens a browser tab. Enter a brand or product in the sidebar, optionally
set a language or country code, and the dashboard fills in.

## Example

Searching for `Figma` with language `en` might produce:

```
Coverage score    72/100
Mentions          24
Distinct sources  15
Date range        Jun 04 - Jun 12

Top keywords: design (9)  software (6)  ai (5)  startups (4) ...
```

Each mention row links out to the original article and shows its source and
publication time.

## Free plan vs paid fields

The default search path uses only the free `/latest` endpoint and free query
parameters, so a brand-new free key works out of the box.

Some response fields — per-article sentiment, the `ai_*` fields, and the
sentiment trend split — are only populated on paid newsdata.io plans. On a free
key the app still renders those panels: sentiment is shown with clearly labeled
sample values, and AI fields fall back to the article description. Nothing breaks;
the panels just note where live data needs a paid plan.

### Optional paid mode

If you have a paid plan and want larger result pages, set:

```
export ENABLE_PAID_PARAMS=1
```

This lets the client request more than 10 articles per page. If the API rejects a
paid parameter (for example on a free key), the client retries the same request
without it, so enabling this can never lock you out of results.

## How the coverage score works

The score is a relative gauge, not an official metric. It is 60% mention volume
(scaled against a target of 40 articles) plus 40% source diversity (scaled against
a target of 12 distinct outlets), capped at 100. Use it to compare two brands or
two time windows, not as an absolute audience number. The targets live near the
top of `analysis.py` if you want to tune them.

## Project layout

- `app.py` — Streamlit UI and dashboard layout
- `newsdata_client.py` — thin wrapper over the newsdata.io REST API
- `analysis.py` — coverage score, sentiment, keyword, and date helpers

## Notes

- Results are cached for ten minutes to stay within free-plan request limits.
- The free plan returns the most recent articles; it is not a full historical
  archive.
- Sentiment and AI fields depend on your newsdata.io plan, as noted above.
