"""Thin client for the newsdata.io news API.

Reads the API key from NEWSDATA_API_KEY and only sends free-tier-safe query
parameters by default. Paid-only parameters are sent solely when paid mode is
on, and the request retries once without them if the API rejects them, so a
free key always gets results.
"""
from __future__ import annotations

import os
import time

import requests

BASE_URL = "https://newsdata.io/api/1"

# Query parameters that only work on a paid newsdata.io plan. Sending any of
# these on a free key fails the whole request, so they are opt-in.
PAID_QUERY_PARAMS = {
    "sentiment", "tag", "region", "organization",
    "timeframe", "from_date", "to_date", "full_content",
}


class NewsDataError(Exception):
    """Base error for newsdata.io requests."""


class AuthError(NewsDataError):
    pass


class RateLimitError(NewsDataError):
    pass


def get_api_key():
    key = os.environ.get("NEWSDATA_API_KEY")
    if not key:
        raise SystemExit(
            "NEWSDATA_API_KEY is not set.\n"
            "Get a free key at https://newsdata.io and export it, e.g.:\n"
            "    export NEWSDATA_API_KEY=pub_xxxxxxxx"
        )
    return key


class NewsDataClient:
    def __init__(self, api_key=None, endpoint="latest", paid_mode=False, session=None):
        self.api_key = api_key or get_api_key()
        self.endpoint = endpoint
        self.paid_mode = paid_mode
        self.session = session or requests.Session()

    def _get(self, params, allow_retry=True):
        clean = {k: v for k, v in params.items() if v is not None}
        payload = dict(clean)
        payload["apikey"] = self.api_key
        url = "{0}/{1}".format(BASE_URL, self.endpoint)
        try:
            resp = self.session.get(url, params=payload, timeout=30)
        except requests.RequestException as exc:
            raise NewsDataError("Network error contacting newsdata.io: {0}".format(exc))

        if resp.status_code == 401:
            raise AuthError("newsdata.io rejected the key (401). Check NEWSDATA_API_KEY.")
        if resp.status_code == 429:
            raise RateLimitError("newsdata.io rate limit reached (429). Wait and retry.")

        if resp.status_code in (403, 422):
            paid_used = PAID_QUERY_PARAMS.intersection(clean)
            if allow_retry and paid_used:
                # Drop the paid-only params and try again so free keys still work.
                stripped = {k: v for k, v in clean.items() if k not in paid_used}
                return self._get(stripped, allow_retry=False)
            raise NewsDataError(
                "newsdata.io request failed ({0}): {1}".format(resp.status_code, _detail(resp))
            )

        if resp.status_code >= 400:
            raise NewsDataError(
                "newsdata.io request failed ({0}): {1}".format(resp.status_code, _detail(resp))
            )

        data = resp.json()
        if isinstance(data, dict) and data.get("status") == "error":
            raise NewsDataError("newsdata.io error: {0}".format(data.get("results")))
        return data

    def fetch(self, q=None, country=None, language=None, category=None,
              max_pages=1, extra_paid=None):
        """Yield articles, following the nextPage cursor across pages."""
        params = {
            "q": q, "country": country,
            "language": language, "category": category,
        }
        if self.paid_mode and extra_paid:
            params.update(extra_paid)

        page = None
        fetched_pages = 0
        while fetched_pages < max_pages:
            call = dict(params)
            if page:
                call["page"] = page
            data = self._get(call)
            for article in data.get("results") or []:
                yield article
            fetched_pages += 1
            page = data.get("nextPage")
            if not page:
                break
            time.sleep(0.4)


def _detail(resp):
    try:
        body = resp.json()
    except ValueError:
        return resp.text[:200]
    if isinstance(body, dict):
        return body.get("results") or body.get("message") or str(body)[:200]
    return str(body)[:200]
