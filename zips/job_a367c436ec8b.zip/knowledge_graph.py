"""Build a co-occurrence knowledge graph from newsdata.io articles.

Entities come from each article's free `keywords` plus, when present on a paid
plan, the `ai_tag`, `ai_org`, and `ai_region` fields. Two entities are linked
when they appear in the same article; edge weight is the number of shared
articles. This lightweight, GraphRAG-style index is what makes multi-hop
question answering possible.
"""
from __future__ import annotations

import json
import re

import networkx as nx

_WORD_RE = re.compile(r"[a-z0-9]+")

# (article field, entity type) pairs used to populate the graph.
ENTITY_SOURCES = [
    ("keywords", "keyword"),
    ("ai_tag", "topic"),
    ("ai_org", "organization"),
    ("ai_region", "region"),
    ("category", "category"),
]

KEEP_FIELDS = [
    "title", "link", "description", "pubDate", "source_id",
    "keywords", "category", "country", "language",
    "sentiment", "ai_tag", "ai_org", "ai_region", "ai_summary",
]


def normalize(text):
    return " ".join(_WORD_RE.findall(text.lower())) if text else ""


def as_list(value):
    if value is None:
        return []
    if isinstance(value, list):
        return [v for v in value if v]
    return [value]


class KnowledgeGraph:
    def __init__(self):
        self.g = nx.Graph()
        self.articles = {}

    # -- construction ----------------------------------------------------
    def _entities(self, article):
        seen = {}
        for field, etype in ENTITY_SOURCES:
            for raw in as_list(article.get(field)):
                if not isinstance(raw, str):
                    continue
                key = normalize(raw)
                if key and key not in seen:
                    seen[key] = (raw.strip(), etype)
        return seen

    def add_article(self, article):
        aid = article.get("article_id") or article.get("link")
        if not aid or aid in self.articles:
            return False
        self.articles[aid] = {f: article.get(f) for f in KEEP_FIELDS}

        entities = self._entities(article)
        keys = list(entities)
        for key, label_type in entities.items():
            label, etype = label_type
            if self.g.has_node(key):
                node = self.g.nodes[key]
                node["count"] += 1
                node["types"].add(etype)
                node["articles"].add(aid)
            else:
                self.g.add_node(key, label=label, types={etype},
                                count=1, articles={aid})
        for i in range(len(keys)):
            for j in range(i + 1, len(keys)):
                a, b = keys[i], keys[j]
                if self.g.has_edge(a, b):
                    self.g[a][b]["weight"] += 1
                else:
                    self.g.add_edge(a, b, weight=1)
        return True

    # -- stats -----------------------------------------------------------
    def top_entities(self, limit=10, etype=None):
        nodes = [
            (d["label"], d["count"], sorted(d["types"]))
            for _, d in self.g.nodes(data=True)
            if etype is None or etype in d["types"]
        ]
        nodes.sort(key=lambda x: x[1], reverse=True)
        return nodes[:limit]

    def sentiment_breakdown(self):
        counts = {"positive": 0, "neutral": 0, "negative": 0}
        labelled = 0
        for rec in self.articles.values():
            s = rec.get("sentiment")
            if s in counts:
                counts[s] += 1
                labelled += 1
        return counts, labelled

    # -- persistence -----------------------------------------------------
    def to_dict(self):
        nodes = [
            {
                "id": n, "label": d["label"], "types": sorted(d["types"]),
                "count": d["count"], "articles": sorted(d["articles"]),
            }
            for n, d in self.g.nodes(data=True)
        ]
        edges = [
            {"source": u, "target": v, "weight": d["weight"]}
            for u, v, d in self.g.edges(data=True)
        ]
        return {"nodes": nodes, "edges": edges, "articles": self.articles}

    @classmethod
    def from_dict(cls, data):
        kg = cls()
        kg.articles = data.get("articles", {})
        for n in data.get("nodes", []):
            kg.g.add_node(
                n["id"], label=n["label"], types=set(n["types"]),
                count=n["count"], articles=set(n["articles"]),
            )
        for e in data.get("edges", []):
            kg.g.add_edge(e["source"], e["target"], weight=e["weight"])
        return kg

    def save(self, path):
        with open(path, "w", encoding="utf-8") as fh:
            json.dump(self.to_dict(), fh, ensure_ascii=False, indent=2)

    @classmethod
    def load(cls, path):
        with open(path, encoding="utf-8") as fh:
            return cls.from_dict(json.load(fh))
