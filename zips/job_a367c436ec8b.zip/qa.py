"""Multi-hop question answering over the news knowledge graph.

The graph turns a question into an answer in three steps:
  1. match question words to entity nodes (the "seeds"),
  2. walk short paths between seeds to find bridge entities that connect them
     across articles (the multi-hop part),
  3. rank articles by how many seed/bridge entities they mention.
"""
from __future__ import annotations

import itertools
import re
from collections import Counter

import networkx as nx

_WORD_RE = re.compile(r"[a-z0-9]+")

STOPWORDS = {
    "the", "a", "an", "and", "or", "of", "to", "in", "on", "for", "is",
    "are", "was", "were", "what", "which", "who", "whom", "how", "why",
    "when", "where", "did", "do", "does", "between", "with", "about",
    "that", "this", "these", "those", "from", "by", "at", "as", "it",
    "be", "has", "have", "had", "will", "would", "can", "could", "than",
}


def tokenize(text):
    return {t for t in _WORD_RE.findall(text.lower())
            if t not in STOPWORDS and len(t) > 2}


def find_seeds(kg, question, limit=8):
    q_tokens = tokenize(question)
    if not q_tokens:
        return []
    scored = []
    for node in kg.g.nodes():
        node_tokens = set(node.split())
        overlap = node_tokens & q_tokens
        if not overlap:
            continue
        coverage = len(overlap) / len(node_tokens)
        score = len(overlap) + coverage
        scored.append((score, node))
    scored.sort(reverse=True)
    return [node for _, node in scored[:limit]]


def find_bridges(kg, seeds, max_hops):
    bridges = Counter()
    for a, b in itertools.combinations(seeds, 2):
        if a not in kg.g or b not in kg.g:
            continue
        try:
            length = nx.shortest_path_length(kg.g, a, b)
        except (nx.NetworkXNoPath, nx.NodeNotFound):
            continue
        if length > max_hops:
            continue
        for path in itertools.islice(nx.all_shortest_paths(kg.g, a, b), 25):
            for node in path[1:-1]:
                if node not in seeds:
                    bridges[node] += 1
    return bridges


def answer(kg, question, max_hops=3, top_k=5):
    seeds = find_seeds(kg, question)
    if not seeds:
        return {
            "seeds": [], "bridges": [], "articles": [],
            "message": "No entities in the graph matched that question. "
                       "Try building from more articles or rephrasing.",
        }

    bridges = find_bridges(kg, seeds, max_hops)

    focus = {}
    for s in seeds:
        focus[s] = focus.get(s, 0) + 2.0
    for node, hits in bridges.items():
        focus[node] = focus.get(node, 0) + float(hits)

    art_scores = Counter()
    for node, weight in focus.items():
        if node not in kg.g:
            continue
        for aid in kg.g.nodes[node]["articles"]:
            art_scores[aid] += weight

    ranked = []
    for aid, score in art_scores.most_common(top_k):
        rec = dict(kg.articles.get(aid, {}))
        rec["_score"] = round(score, 2)
        ranked.append(rec)

    return {
        "seeds": [kg.g.nodes[s]["label"] for s in seeds],
        "bridges": [kg.g.nodes[b]["label"] for b, _ in bridges.most_common(8)],
        "articles": ranked,
        "message": None,
    }
