#!/usr/bin/env python3
"""news-graphrag-explorer

Build a knowledge graph from newsdata.io headlines and ask multi-hop
questions against it.
"""
from __future__ import annotations

import argparse
import os
import sys
import textwrap

from newsdata_client import NewsDataClient, NewsDataError
from knowledge_graph import KnowledgeGraph, normalize
import qa

DATA_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")
GRAPH_PATH = os.path.join(DATA_DIR, "graph.json")


def _paid_mode():
    return os.environ.get("ENABLE_PAID_PARAMS") == "1"


# ---- display helpers ---------------------------------------------------
SENTIMENT_BADGE = {
    "positive": "[+ positive]",
    "negative": "[- negative]",
    "neutral": "[= neutral]",
}


def sentiment_badge(value):
    return SENTIMENT_BADGE.get(value, "")


def keyword_chips(keywords, limit=6):
    items = [k for k in (keywords or []) if isinstance(k, str)][:limit]
    return "  ".join("#" + k.replace(" ", "_") for k in items)


def print_article(rec, index=None):
    title = rec.get("title") or "(untitled)"
    prefix = "{0}. ".format(index) if index is not None else ""
    print(prefix + title)
    meta = []
    if rec.get("source_id"):
        meta.append(rec["source_id"])
    if rec.get("pubDate"):
        meta.append(rec["pubDate"])
    badge = sentiment_badge(rec.get("sentiment"))
    if badge:
        meta.append(badge)
    if meta:
        print("   " + "  ".join(meta))
    summary = rec.get("ai_summary") or rec.get("description")
    if summary:
        print(textwrap.fill(summary.strip(), width=88,
                            initial_indent="   ", subsequent_indent="   "))
    chips = keyword_chips(rec.get("keywords"))
    if chips:
        print("   " + chips)
    ai_tags = [t for t in (rec.get("ai_tag") or []) if isinstance(t, str)]
    if ai_tags:
        print("   ai-tags: " + ", ".join(ai_tags[:6]))
    if rec.get("link"):
        print("   " + rec["link"])
    print()


def _print_sentiment(counts):
    total = sum(counts.values()) or 1
    for label in ("positive", "neutral", "negative"):
        n = counts[label]
        bar = "#" * int(round(30 * n / total))
        print("  {0:>8}: {1:>3}  {2}".format(label, n, bar))


# ---- commands ----------------------------------------------------------
def cmd_build(args):
    os.makedirs(DATA_DIR, exist_ok=True)
    client = NewsDataClient(endpoint=args.endpoint, paid_mode=_paid_mode())

    if args.append and os.path.exists(GRAPH_PATH):
        kg = KnowledgeGraph.load(GRAPH_PATH)
    else:
        kg = KnowledgeGraph()

    extra_paid = None
    if args.sentiment:
        if _paid_mode():
            extra_paid = {"sentiment": args.sentiment}
        else:
            print("note: --sentiment needs a paid plan; set ENABLE_PAID_PARAMS=1. "
                  "Ignoring it.", file=sys.stderr)

    # The crypto endpoint does not accept country/category filters.
    country = None if args.endpoint == "crypto" else args.country
    category = None if args.endpoint == "crypto" else args.category

    added = 0
    for article in client.fetch(
        q=args.query, country=country, language=args.language,
        category=category, max_pages=args.pages, extra_paid=extra_paid,
    ):
        if kg.add_article(article):
            added += 1

    if added == 0 and not kg.articles:
        print("No articles were returned. Try a broader --query or another "
              "--category.")
        return 0

    kg.save(GRAPH_PATH)
    print("Added {0} new articles. Graph now holds {1} articles, {2} entities, "
          "{3} links.".format(added, len(kg.articles),
                              kg.g.number_of_nodes(), kg.g.number_of_edges()))
    print("Saved to " + GRAPH_PATH)
    return 0


def cmd_ask(args):
    if not os.path.exists(GRAPH_PATH):
        print("No graph yet. Run `build` first.", file=sys.stderr)
        return 1
    kg = KnowledgeGraph.load(GRAPH_PATH)
    result = qa.answer(kg, args.question, max_hops=args.hops, top_k=args.top)

    print("Q: {0}\n".format(args.question))
    if result["message"]:
        print(result["message"])
        return 0
    if result["seeds"]:
        print("Matched entities: " + ", ".join(result["seeds"]))
    if result["bridges"]:
        print("Connected through: " + ", ".join(result["bridges"]))
    print()
    if not result["articles"]:
        print("No supporting articles found.")
        return 0
    print("Supporting articles:\n")
    for i, rec in enumerate(result["articles"], 1):
        print_article(rec, i)
    return 0


def cmd_stats(args):
    if not os.path.exists(GRAPH_PATH):
        print("No graph yet. Run `build` first.", file=sys.stderr)
        return 1
    kg = KnowledgeGraph.load(GRAPH_PATH)
    print("Articles: {0}".format(len(kg.articles)))
    print("Entities: {0}".format(kg.g.number_of_nodes()))
    print("Links:    {0}\n".format(kg.g.number_of_edges()))

    print("Top entities:")
    for label, count, types in kg.top_entities(limit=12):
        print("  {0:>4}  {1}  ({2})".format(count, label, ", ".join(types)))
    print()

    counts, labelled = kg.sentiment_breakdown()
    print("Sentiment breakdown:")
    if labelled:
        _print_sentiment(counts)
    else:
        _print_sentiment({"positive": 4, "neutral": 5, "negative": 2})
        print("  (sample — live per-article sentiment requires a paid "
              "newsdata.io plan; set ENABLE_PAID_PARAMS=1 with such a key)")
    return 0


def cmd_neighbors(args):
    if not os.path.exists(GRAPH_PATH):
        print("No graph yet. Run `build` first.", file=sys.stderr)
        return 1
    kg = KnowledgeGraph.load(GRAPH_PATH)
    target = normalize(args.entity)
    if target not in kg.g:
        matches = [n for n in kg.g if target and target in n]
        if not matches:
            print("No entity matching '{0}'.".format(args.entity))
            return 1
        target = matches[0]
    data = kg.g.nodes[target]
    print("{0}  (mentions: {1}, types: {2})\n".format(
        data["label"], data["count"], ", ".join(sorted(data["types"]))))
    neighbors = sorted(kg.g[target].items(),
                       key=lambda kv: kv[1]["weight"], reverse=True)
    if not neighbors:
        print("This entity has no links yet.")
        return 0
    print("Most connected entities:")
    for n, edge in neighbors[:args.top]:
        print("  {0:>3}  {1}".format(edge["weight"], kg.g.nodes[n]["label"]))
    return 0


def build_parser():
    p = argparse.ArgumentParser(
        prog="news-graphrag-explorer",
        description="Build a news knowledge graph and ask multi-hop questions.",
    )
    sub = p.add_subparsers(dest="command", required=True)

    b = sub.add_parser("build", help="fetch articles and build/update the graph")
    b.add_argument("-q", "--query", help="search term passed to newsdata.io")
    b.add_argument("--country", help="country code, e.g. us, gb, in")
    b.add_argument("--language", help="language code, e.g. en")
    b.add_argument("--category", help="category, e.g. business, technology")
    b.add_argument("--pages", type=int, default=2, help="pages to fetch (10/page)")
    b.add_argument("--endpoint", default="latest", choices=["latest", "crypto"])
    b.add_argument("--append", action="store_true", help="add to existing graph")
    b.add_argument("--sentiment", choices=["positive", "negative", "neutral"],
                   help="filter by sentiment (paid plan; needs ENABLE_PAID_PARAMS=1)")
    b.set_defaults(func=cmd_build)

    a = sub.add_parser("ask", help="ask a multi-hop question")
    a.add_argument("question")
    a.add_argument("--hops", type=int, default=3, help="max path length between entities")
    a.add_argument("--top", type=int, default=5, help="number of articles to show")
    a.set_defaults(func=cmd_ask)

    s = sub.add_parser("stats", help="show graph statistics")
    s.set_defaults(func=cmd_stats)

    n = sub.add_parser("neighbors", help="show entities linked to one entity")
    n.add_argument("entity")
    n.add_argument("--top", type=int, default=12)
    n.set_defaults(func=cmd_neighbors)
    return p


def main(argv=None):
    args = build_parser().parse_args(argv)
    try:
        return args.func(args)
    except NewsDataError as exc:
        print("error: {0}".format(exc), file=sys.stderr)
        return 1
    except KeyboardInterrupt:
        return 130


if __name__ == "__main__":
    sys.exit(main())
