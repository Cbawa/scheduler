# news-graphrag-explorer

Build a knowledge graph from recent news headlines and ask multi-hop
questions against it. Articles come from the newsdata.io news API
(https://newsdata.io) — grab a free API key to run it.

The idea borrows from GraphRAG: instead of searching article text directly,
the tool extracts entities from each article, links entities that appear
together, and answers a question by walking that graph. That lets it connect
two things the question mentions even when no single article covers both —
the multi-hop case that plain keyword search misses.

## How it works

1. `build` pulls articles from newsdata.io and extracts entities from each
   one. On a free key the entities come from the `keywords` field; on a paid
   key the `ai_tag`, `ai_org`, and `ai_region` fields are added automatically.
2. Entities that appear in the same article are linked, and the link weight
   grows each time they co-occur. The result is a co-occurrence graph stored
   in `data/graph.json`.
3. `ask` matches your question to entity nodes, finds the shortest paths that
   connect them, and ranks articles by how many of those entities they mention.

## Install

Python 3.9+.

```
git clone <your-fork-url>
cd news-graphrag-explorer
pip install -r requirements.txt
```

## API key

The tool reads the key from the `NEWSDATA_API_KEY` environment variable. Create
a free key at https://newsdata.io and export it:

```
export NEWSDATA_API_KEY=pub_xxxxxxxxxxxxxxxx
```

## Usage

Build a graph from recent headlines (two pages, ~20 articles):

```
python main.py build --query "climate" --language en --pages 2
```

Ask a question:

```
python main.py ask "How are oil prices connected to inflation?"
```

Sample output:

```
Q: How are oil prices connected to inflation?

Matched entities: oil prices, inflation
Connected through: federal reserve, energy costs

Supporting articles:

1. Oil edges higher as supply worries return
   reuters  2026-06-11 09:14:00  [= neutral]
   Brent crude rose on Wednesday as traders weighed tighter supply against
   weaker demand signals from major economies.
   #oil  #brent  #energy  #opec
   https://example.com/oil-edges-higher
```

Other commands:

```
python main.py stats                  # graph size, top entities, sentiment mix
python main.py neighbors "inflation"  # entities most linked to one entity
```

## Free vs. paid fields

Everything above works on a free newsdata.io key. A few fields only arrive on
paid plans and degrade quietly when absent:

- `sentiment` — shown as a badge per article and as a breakdown in `stats`.
  With a free key the breakdown shows a clearly labeled sample instead.
- `ai_tag`, `ai_org`, `ai_region`, `ai_summary` — folded into the graph and the
  article display when present.

These response fields populate automatically with a paid key — no flag needed.
To send a paid *query* filter (for example, only positive-sentiment articles),
set `ENABLE_PAID_PARAMS=1` and pass `--sentiment positive` to `build`; on a free
key the filter is skipped and you still get results.

## Layout

```
main.py              CLI: build / ask / stats / neighbors
newsdata_client.py   newsdata.io API client (pagination, error handling)
knowledge_graph.py   entity extraction + co-occurrence graph
qa.py                multi-hop question answering over the graph
```

## License

MIT
