#!/usr/bin/env python3
"""Command-line entry point: run the agent workflow and print a report."""
import argparse
import sys

import analysis
from agents import build_workflow
from news_client import NewsDataError

SENT_BADGE = {
    "positive": "[+ positive]",
    "neutral": "[= neutral ]",
    "negative": "[- negative]",
}


def _badge(article):
    s = (article.get("sentiment") or "").lower()
    return SENT_BADGE.get(s, "[  n/a   ]")


def _bar(n, total, width=24):
    if total <= 0:
        return ""
    filled = int(round(width * n / total))
    return "#" * filled + "." * (width - filled)


def render(state, query):
    articles = state.get("articles", [])
    print("=" * 70)
    print("News workflow report  ::  query = {!r}".format(query or "(latest headlines)"))
    print("=" * 70)
    if not articles:
        print("\nNo articles were returned. Try a different query, language or")
        print("category, or check that your free request quota has not run out.")
        return

    print("\nFetched {} article(s) from newsdata.io.\n".format(len(articles)))

    print("-" * 70)
    print("ARTICLES")
    print("-" * 70)
    any_ai = False
    for i, a in enumerate(articles, 1):
        print("{:>2}. {} {}".format(i, _badge(a), a.get("title") or "(untitled)"))
        meta = " ".join(x for x in [a.get("source_id"), a.get("pubDate")] if x)
        if meta:
            print("    {}".format(meta))
        if a.get("link"):
            print("    {}".format(a["link"]))
        kws = analysis.keywords_for_article(a)
        if kws:
            print("    keywords: {}".format(", ".join(kws)))
        ai = analysis.ai_fields(a)
        if ai["ai_summary"]:
            any_ai = True
            print("    ai summary: {}".format(ai["ai_summary"]))
        if ai["ai_tag"]:
            any_ai = True
            tag = ai["ai_tag"]
            if isinstance(tag, list):
                tag = ", ".join(str(t) for t in tag)
            print("    ai tags: {}".format(tag))
        print("")

    summary = state.get("summary", {})
    print("-" * 70)
    print("SUMMARY  (extractive, built by the Summarizer agent)")
    print("-" * 70)
    if summary.get("top_keywords"):
        print("top keywords: {}".format(", ".join(summary["top_keywords"])))
    print(summary.get("summary") or "(not enough text in the results to summarize)")
    print("")

    counts, present = analysis.sentiment_breakdown(articles)
    print("-" * 70)
    print("SENTIMENT BREAKDOWN")
    print("-" * 70)
    if present:
        total = sum(counts.values())
        for label in ("positive", "neutral", "negative"):
            print("  {:<9} {:>2}  {}".format(label, counts[label], _bar(counts[label], total)))
    else:
        sample = {"positive": 4, "neutral": 5, "negative": 1}
        total = sum(sample.values())
        for label in ("positive", "neutral", "negative"):
            print("  {:<9} {:>2}  {}".format(label, sample[label], _bar(sample[label], total)))
        print("  (sample values shown \u2014 live per-article sentiment requires a")
        print("   paid newsdata.io plan; on the free plan this field is empty)")
    print("")

    claims = state.get("claims", [])
    print("-" * 70)
    print("CROSS-SOURCE CHECK  (by the FactChecker agent)")
    print("-" * 70)
    for c in claims:
        flag = "ok " if c["status"] == "corroborated" else "!! "
        print("  {}{} other source(s)  {}".format(
            flag, c["corroborating_sources"], c["headline"][:60]))
    print("")
    if not any_ai:
        print("note: ai_summary / ai_tag fields were empty (free plan); they are")
        print("rendered per article automatically when a paid plan provides them.")


def main(argv=None):
    parser = argparse.ArgumentParser(
        description="Multi-agent news research / summary / fact-check over newsdata.io")
    parser.add_argument("query", nargs="?", default=None,
                        help="search terms; omit for the latest headlines")
    parser.add_argument("-l", "--language", default="en")
    parser.add_argument("-c", "--country", default=None)
    parser.add_argument("--category", default=None)
    parser.add_argument("-n", "--max-articles", type=int, default=10)
    args = parser.parse_args(argv)

    run = build_workflow()
    try:
        state = run(query=args.query, language=args.language,
                    country=args.country, category=args.category,
                    max_articles=args.max_articles)
    except NewsDataError as exc:
        print("error: {}".format(exc), file=sys.stderr)
        return 1
    render(state, args.query)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
