"""Deterministic analysis helpers used by the agents.

None of these need an LLM; they turn raw newsdata.io article dicts into
keywords, an extractive summary, a cross-source corroboration check and a
sentiment tally. Paid response fields (sentiment, ai_*) are read straight off
the article and treated as simply absent when missing.
"""
import re
from collections import Counter, defaultdict

STOPWORDS = {
    "the", "a", "an", "and", "or", "but", "of", "to", "in", "on", "for", "with",
    "without", "at", "by", "from", "as", "is", "are", "was", "were", "be", "been",
    "being", "it", "its", "this", "that", "these", "those", "has", "have", "had",
    "will", "would", "can", "could", "after", "before", "over", "into", "about",
    "says", "said", "new", "amid", "they", "their", "more", "than", "also",
}

WORD_RE = re.compile(r"[A-Za-z][A-Za-z'\-]+")
SENT_SPLIT_RE = re.compile(r"(?<=[.!?])\s+")


def tokenize(text):
    return [w.lower() for w in WORD_RE.findall(text or "")]


def keywords_for_article(article, limit=6):
    """Prefer the API's own keywords (a free field); fall back to local frequency."""
    api_kws = article.get("keywords")
    if api_kws:
        return [k for k in api_kws if k][:limit]
    text = "{} {}".format(article.get("title") or "", article.get("description") or "")
    counts = Counter(w for w in tokenize(text) if w not in STOPWORDS and len(w) > 3)
    return [w for w, _ in counts.most_common(limit)]


def _article_text(article):
    parts = [article.get("description"), article.get("content"), article.get("title")]
    return " ".join(p for p in parts if p)


def summarize_articles(articles, max_sentences=5):
    if not articles:
        return {"top_keywords": [], "summary": "", "article_count": 0}

    kw_counts = Counter()
    for a in articles:
        for k in keywords_for_article(a):
            kw_counts[k.lower()] += 1
    top_keywords = [k for k, _ in kw_counts.most_common(8)]
    weight = {k: (len(top_keywords) - i) for i, k in enumerate(top_keywords)}

    scored = []
    seen = set()
    for a in articles:
        for sentence in SENT_SPLIT_RE.split(_article_text(a)):
            s = sentence.strip()
            key = s.lower()
            if len(s) < 40 or key in seen:
                continue
            seen.add(key)
            score = sum(weight.get(w, 0) for w in tokenize(s))
            if score:
                scored.append((score, s))
    scored.sort(key=lambda x: x[0], reverse=True)
    summary = " ".join(s for _, s in scored[:max_sentences])
    return {
        "top_keywords": top_keywords,
        "summary": summary,
        "article_count": len(articles),
    }


def fact_check(articles):
    """Heuristic cross-source corroboration.

    Group articles by shared keywords and report, for each headline, how many
    other distinct sources are covering the same topic. This is a signal, not a
    truth oracle: single-source items are flagged for a closer look.
    """
    kw_sources = defaultdict(set)
    for a in articles:
        src = a.get("source_id") or a.get("source_name") or a.get("link") or "unknown"
        for k in keywords_for_article(a):
            kw_sources[k.lower()].add(src)

    claims = []
    for a in articles:
        src = a.get("source_id") or a.get("source_name") or "unknown"
        sources = set()
        for k in keywords_for_article(a):
            sources |= kw_sources[k.lower()]
        sources.discard(src)
        corroborating = len(sources)
        claims.append({
            "headline": a.get("title") or "(untitled)",
            "source": src,
            "corroborating_sources": corroborating,
            "status": "corroborated" if corroborating >= 1 else "single-source",
        })
    return claims


def sentiment_breakdown(articles):
    counts = {"positive": 0, "neutral": 0, "negative": 0}
    present = False
    for a in articles:
        s = (a.get("sentiment") or "").lower()
        if s in counts:
            counts[s] += 1
            present = True
    return counts, present


def ai_fields(article):
    return {
        "ai_summary": article.get("ai_summary"),
        "ai_tag": article.get("ai_tag"),
        "ai_region": article.get("ai_region"),
        "ai_org": article.get("ai_org"),
    }
