"""AutoGen agents and the orchestrator that wires them together.

Each agent is a ConversableAgent with a registered reply function, so no LLM
backend is required. They communicate by passing short JSON messages and share
the fetched articles through a per-run state dict.
"""
import json

from autogen import ConversableAgent

import analysis
from news_client import fetch_news


def _last_content(messages):
    if not messages:
        return "{}"
    return messages[-1].get("content", "{}")


def _agent(name):
    return ConversableAgent(
        name=name,
        llm_config=False,
        human_input_mode="NEVER",
        code_execution_config=False,
        default_auto_reply="",
    )


def build_workflow():
    """Return a run(...) callable that drives the three agents and returns state."""
    state = {}

    coordinator = _agent("Coordinator")
    researcher = _agent("Researcher")
    summarizer = _agent("Summarizer")
    factchecker = _agent("FactChecker")

    def researcher_reply(recipient, messages, sender, config):
        req = json.loads(_last_content(messages))
        articles, used_paid = fetch_news(
            query=req.get("query"),
            language=req.get("language", "en"),
            country=req.get("country"),
            category=req.get("category"),
            max_articles=req.get("max_articles", 10),
        )
        state["articles"] = articles
        state["used_paid"] = used_paid
        return True, json.dumps({"stage": "research", "count": len(articles)})

    def summarizer_reply(recipient, messages, sender, config):
        state["summary"] = analysis.summarize_articles(state.get("articles", []))
        return True, json.dumps({"stage": "summary", "ok": True})

    def factchecker_reply(recipient, messages, sender, config):
        state["claims"] = analysis.fact_check(state.get("articles", []))
        return True, json.dumps({"stage": "factcheck", "ok": True})

    researcher.register_reply([ConversableAgent, None], researcher_reply)
    summarizer.register_reply([ConversableAgent, None], summarizer_reply)
    factchecker.register_reply([ConversableAgent, None], factchecker_reply)

    def run(query=None, language="en", country=None, category=None, max_articles=10):
        state.clear()
        request = json.dumps({
            "query": query,
            "language": language,
            "country": country,
            "category": category,
            "max_articles": max_articles,
        })
        researcher.generate_reply(
            messages=[{"role": "user", "content": request}], sender=coordinator)
        summarizer.generate_reply(
            messages=[{"role": "user", "content": json.dumps({"stage": "research"})}],
            sender=coordinator)
        factchecker.generate_reply(
            messages=[{"role": "user", "content": json.dumps({"stage": "summary"})}],
            sender=coordinator)
        return state

    return run
