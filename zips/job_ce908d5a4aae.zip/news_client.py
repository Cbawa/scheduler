"""Thin newsdata.io client, written to stay inside the free tier.

Docs: https://newsdata.io/documentation
Only free-safe query parameters are sent by default. Paid query params (such as
full_content) are opt-in via env vars and, if the API rejects them, the request
is retried once without them so free keys still get results.
"""
import os
import time

import requests

API_BASE = "https://newsdata.io/api/1"


class NewsDataError(Exception):
    pass


class PaidParamError(NewsDataError):
    pass


def get_api_key():
    key = os.environ.get("NEWSDATA_API_KEY")
    if not key:
        raise NewsDataError(
            "NEWSDATA_API_KEY is not set. Get a free key at https://newsdata.io "
            "and export it, e.g.\n    export NEWSDATA_API_KEY=pub_xxxxxxxx")
    return key


def _truthy(name):
    return os.environ.get(name, "").lower() in ("1", "true", "yes", "on")


def _request(endpoint, params, allow_retry=True):
    resp = requests.get(API_BASE + endpoint, params=params, timeout=30)
    status = resp.status_code
    if status == 200:
        return resp.json()
    if status == 401:
        raise NewsDataError("Invalid API key (401). Check NEWSDATA_API_KEY.")
    if status == 429:
        if allow_retry:
            time.sleep(2)
            return _request(endpoint, params, allow_retry=False)
        raise NewsDataError("Rate limited (429). Wait a moment and try again.")
    if status in (403, 422):
        raise PaidParamError(
            "Request rejected ({}). A paid-only parameter was likely used.".format(status))
    raise NewsDataError("newsdata.io returned HTTP {}: {}".format(status, resp.text[:200]))


def fetch_news(query=None, language="en", country=None, category=None, max_articles=10):
    """Fetch up to max_articles from /latest, following the nextPage cursor.

    Returns (articles, used_paid_params).
    """
    key = get_api_key()
    base = {"apikey": key}
    if query:
        base["q"] = query
    if language:
        base["language"] = language
    if country:
        base["country"] = country
    if category:
        base["category"] = category

    paid = {}
    if _truthy("ENABLE_FULL_CONTENT"):
        paid["full_content"] = 1

    used_paid = bool(paid)
    results = []
    page = None
    while len(results) < max_articles:
        params = dict(base)
        params.update(paid)
        if page:
            params["page"] = page
        try:
            data = _request("/latest", params)
        except PaidParamError:
            if paid:
                # Drop paid params and retry so a free key still works.
                paid = {}
                used_paid = False
                continue
            raise
        batch = data.get("results") or []
        results.extend(batch)
        page = data.get("nextPage")
        if not page or not batch:
            break
    return results[:max_articles], used_paid
