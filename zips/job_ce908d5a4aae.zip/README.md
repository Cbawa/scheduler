# News research crew

A small command-line tool that runs three [AutoGen](https://microsoft.github.io/autogen/) agents over live news:

- a **Researcher** that pulls recent articles,
- a **Summarizer** that builds an extractive summary and pulls out keywords,
- a **FactChecker** that does a cross-source corroboration pass.

Headlines come from the newsdata.io news API (https://newsdata.io) — you only need a free API key to run it. The agents themselves don't require an LLM key: their logic is deterministic Python wired together with AutoGen's `ConversableAgent`, so the whole thing runs offline of any model provider.

## What it does

Given a query (or nothing, for the latest headlines) it fetches articles, then prints a single report with:

- each article with its source, link, keywords and a sentiment badge,
- an extractive summary and the top shared keywords across the batch,
- a sentiment breakdown chart,
- a cross-source check that flags single-source headlines.

It leans on the `keywords` field that newsdata.io returns on every plan, and reads the optional `sentiment`, `ai_summary` and `ai_tag` fields straight off each article when they're present. Those richer fields are only filled in on paid plans; on a free key they're simply empty and the report falls back to a clearly labeled placeholder rather than breaking.

## Requirements

- Python 3.9+
- A free newsdata.io API key (https://newsdata.io)

## Setup

```bash
pip install -r requirements.txt
export NEWSDATA_API_KEY=pub_xxxxxxxxxxxxxxxxxxxx
```

The key is read from the `NEWSDATA_API_KEY` environment variable only; it is never written to disk by this tool.

## Usage

```bash
# latest headlines
python main.py

# search
python main.py "renewable energy"

# narrow it down
python main.py "elections" --language en --country us -n 8
```

Options:

```
  query                  search terms; omit for the latest headlines
  -l, --language CODE    language code (default: en)
  -c, --country CODE     country code, e.g. us, gb, in
  --category NAME        e.g. business, technology, sports
  -n, --max-articles N   how many articles to pull (default: 10)
```

## Example

```
$ python main.py "mars rover" -n 3
======================================================================
News workflow report  ::  query = 'mars rover'
======================================================================

Fetched 3 article(s) from newsdata.io.

----------------------------------------------------------------------
ARTICLES
----------------------------------------------------------------------
 1. [  n/a   ] Rover sends back new images from the crater floor
    space-daily 2026-06-11 18:02:00
    https://example.com/rover-images
    keywords: rover, crater, samples, mission

 2. [  n/a   ] Team plans next drive across the dune field
    ...

----------------------------------------------------------------------
SUMMARY  (extractive, built by the Summarizer agent)
----------------------------------------------------------------------
top keywords: rover, mission, crater, samples, dune
The rover sent back new images from the crater floor this week. ...

----------------------------------------------------------------------
SENTIMENT BREAKDOWN
----------------------------------------------------------------------
  positive   4  ###########.............
  neutral    5  ##############..........
  negative   1  ###.....................
  (sample values shown — live per-article sentiment requires a
   paid newsdata.io plan; on the free plan this field is empty)

----------------------------------------------------------------------
CROSS-SOURCE CHECK  (by the FactChecker agent)
----------------------------------------------------------------------
  ok 2 other source(s)  Rover sends back new images from the crater floor
  !! 0 other source(s)  Team plans next drive across the dune field
```

## Optional configuration

These are off by default and not needed for normal use:

- `ENABLE_FULL_CONTENT=1` — request the `full_content` field. This is a paid newsdata.io parameter; if the API rejects it the request is retried once without it, so a free key still returns results.

The `sentiment`, `ai_summary` and `ai_tag` fields are read automatically whenever they appear in the response. They are populated on paid newsdata.io plans; nothing needs to be enabled here to display them.

## How it fits together

```
main.py        CLI + report rendering
agents.py      AutoGen ConversableAgents and the run() orchestrator
analysis.py    keyword extraction, extractive summary, cross-source check
news_client.py newsdata.io HTTP client (free-tier safe, paginates nextPage)
```

The agents pass short messages between each other and share fetched articles through a small state dict; each agent's reply is a registered Python function rather than a model call.

## Notes

- Pagination follows the `nextPage` cursor and stops when it's null.
- 401 (bad key), 429 (rate limit) and empty result sets are handled with a readable message instead of a traceback.
- The cross-source check is a heuristic signal based on shared keywords across distinct sources, not a verdict on whether a claim is true.

## License

MIT
