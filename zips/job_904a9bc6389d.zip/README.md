# news-dspy-pipeline

A small command-line tool that pulls recent headlines from the newsdata.io news
API (https://newsdata.io) and summarizes each story with a DSPy pipeline. Rather
than hand-tuning a summarization prompt, it uses DSPy's `BootstrapFewShot`
optimizer to assemble few-shot examples, scoring candidate summaries by how well
they cover an article's keywords while staying short.

It runs with just a free newsdata.io API key. If you point it at a language
model (via `DSPY_LM`), it compiles and runs the DSPy summarizer; without one, it
falls back to a keyword-ranked extractive summary so the pipeline still produces
output. Grab a free API key to run it.

## What it does

- Fetches latest news from newsdata.io (the free `/latest` endpoint; the
  `keywords` field is included on every plan).
- Builds a DSPy dataset from the fetched articles, using each article's
  `keywords` as a weak supervision signal.
- Optimizes the summarization prompt with `BootstrapFewShot` and reports the
  keyword-coverage score before vs. after optimization.
- Prints each article with its summary, keyword chips, and — when present in the
  API response — a sentiment badge, AI tags, and an AI-summary line.
- Shows a small sentiment breakdown of the batch.

## Requirements

- Python 3.10+
- A newsdata.io API key (free) — https://newsdata.io
- Optional: a language model for the DSPy pipeline (any LiteLLM-supported model)

## Setup

```
git clone <your-fork-url>
cd news-dspy-pipeline
pip install -r requirements.txt
export NEWSDATA_API_KEY=your_key_here
```

The variables can also go in a `.env` file in the project root; it is loaded
automatically on startup.

## Usage

Extractive mode (no language model needed):

```
python main.py --query "renewable energy" --language en
```

DSPy mode — set a model and the matching provider key:

```
export DSPY_LM=openai/gpt-4o-mini
export OPENAI_API_KEY=sk-...
python main.py --query "renewable energy"
```

`DSPY_LM` is a LiteLLM model string, for example `openai/gpt-4o-mini`,
`anthropic/claude-3-5-haiku-latest`, or `ollama/llama3.2` for a local model. The
provider's API key is read from the environment by LiteLLM.

Options:

```
-q, --query      search term (omit for general latest news)
-l, --language   language code (default: en)
-c, --country    2-letter country code, e.g. us
-n, --max        number of articles (default 10; free plans cap around 10)
--demos          few-shot demos for the optimizer (default 3)
```

### Sample output

```
$ python main.py -q "solar power"
DSPY_LM not set - using extractive summaries. Set DSPY_LM to enable the DSPy pipeline.

1. New solar farm to power 40,000 homes
   source: example-news   published: 2026-06-12 08:15:00
   summary: The 200 MW plant is expected to supply about 40,000 homes once it opens next year.
   keywords:  [solar] [energy] [grid]
   sentiment: n/a (paid plan)
   ai_tag:    n/a (paid plan)
   ai_summary: n/a (paid plan)
...
Sentiment breakdown
   positive  ######               3
   neutral   ##########           5
   negative  ####                 2
   (sample - live sentiment requires a paid newsdata.io plan)
```

With `DSPY_LM` set you also get a line like:

```
Keyword-coverage score on dev set: baseline 0.41 -> optimized 0.67
```

## Configuration notes

All configuration is through environment variables:

- `NEWSDATA_API_KEY` (required) — your newsdata.io key.
- `DSPY_LM` (optional) — LiteLLM model string. If unset, the tool uses
  extractive summaries instead of the DSPy pipeline.
- `DSPY_MAX_TOKENS`, `DSPY_TEMPERATURE` (optional) — generation settings for the
  DSPy language model.
- `NEWSDATA_PAID` (optional) — set to `1` to request `full_content`. This is a
  paid newsdata.io feature; on a free key the request is retried automatically
  without it.

The `sentiment`, `ai_tag`, and `ai_summary` values shown per article come
straight from the newsdata.io response. They are populated on paid plans; on a
free key they are absent and shown as `n/a`. The sentiment breakdown chart falls
back to a clearly labeled sample when no sentiment data is present.

## How the optimization works

newsdata.io returns a `keywords` list for each article on every plan. The DSPy
metric (`coverage_score` in `pipeline.py`) rewards a summary for containing those
keywords while keeping its length reasonable. `BootstrapFewShot` runs the
summarizer over the fetched articles, keeps the generated examples that score
well, and reuses them as few-shot demonstrations — so the prompt is tuned to the
current batch of news rather than fixed up front.

## Files

- `main.py` — CLI: fetch, build dataset, optimize, render results.
- `pipeline.py` — DSPy signature, module, metric, and LM configuration.
- `newsdata_client.py` — thin newsdata.io client with free-tier-safe defaults.

## License

MIT
