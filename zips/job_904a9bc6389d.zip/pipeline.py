"""DSPy modules and metric for news summarization.

The optimizer uses the article keywords returned by newsdata.io as a weak
supervision signal: a good summary should mention the key terms of the story
while staying short. No hand-written gold summaries are required.
"""
import os

import dspy


class SummarizeNews(dspy.Signature):
    """Write one factual sentence that summarizes a news article."""

    title = dspy.InputField(desc="the article headline")
    body = dspy.InputField(desc="article text or description")
    summary = dspy.OutputField(desc="a single concise, factual sentence")


class NewsSummarizer(dspy.Module):
    def __init__(self):
        super().__init__()
        self.summarize = dspy.ChainOfThought(SummarizeNews)

    def forward(self, title, body):
        return self.summarize(title=title, body=body)


def _keywords_for(example):
    kws = list(getattr(example, "keywords", None) or [])
    kws = [k for k in kws if k]
    if kws:
        return kws
    # Fall back to long-ish title tokens when keywords are absent (free key edge).
    tokens = (getattr(example, "title", "") or "").lower().split()
    return [t.strip(".,:;") for t in tokens if len(t) > 4]


def coverage_score(example, pred, trace=None):
    """Keyword coverage of the summary, with a length guard.

    Returns a float in [0, 1] for evaluation. When called by the DSPy optimizer
    (trace is not None) it returns a bool so demos can be accepted or rejected.
    """
    summary = (getattr(pred, "summary", "") or "").lower()
    kws = _keywords_for(example)
    if not kws or not summary:
        score = 0.0
    else:
        hits = sum(1 for k in kws if k.lower() in summary)
        coverage = hits / len(kws)
        words = len(summary.split())
        length_ok = 1.0 if 6 <= words <= 60 else 0.5
        score = coverage * length_ok
    if trace is not None:
        return score >= 0.34
    return score


def configure_lm():
    """Configure DSPy's language model from env, or return None if unset.

    DSPY_LM is a LiteLLM model string, e.g. 'openai/gpt-4o-mini',
    'anthropic/claude-3-5-haiku-latest', or 'ollama/llama3.2'. The matching
    provider API key (OPENAI_API_KEY, ANTHROPIC_API_KEY, ...) is read from the
    environment by LiteLLM.
    """
    model = os.environ.get("DSPY_LM")
    if not model:
        return None
    max_tokens = int(os.environ.get("DSPY_MAX_TOKENS", "512"))
    temperature = float(os.environ.get("DSPY_TEMPERATURE", "0.2"))
    lm = dspy.LM(model, max_tokens=max_tokens, temperature=temperature)
    dspy.configure(lm=lm)
    return lm
