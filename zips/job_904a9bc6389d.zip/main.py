"""news-dspy-pipeline.

Fetch recent headlines from the newsdata.io news API and summarize each story
with a DSPy pipeline whose prompt is optimized against the article keywords.

Runs with only NEWSDATA_API_KEY set (extractive summaries). Set DSPY_LM to a
LiteLLM model string to enable the DSPy summarizer and prompt optimization.
"""
import argparse
import os
import re
import sys

try:
    from dotenv import load_dotenv
    load_dotenv()
except Exception:
    pass

import dspy
from dspy.teleprompt import BootstrapFewShot

import pipeline as P
from newsdata_client import fetch_latest, NewsDataError

PLACEHOLDER_RE = re.compile(r"only available in (paid|professional|corporate)", re.I)
SENT_LABEL = {
    "positive": "+ positive",
    "negative": "- negative",
    "neutral": "= neutral",
}


def clean_text(value):
    if not value or not isinstance(value, str):
        return ""
    if PLACEHOLDER_RE.search(value):
        return ""
    return value.strip()


def article_body(a):
    for field in ("content", "description"):
        text = clean_text(a.get(field))
        if text:
            return text
    return clean_text(a.get("title"))


def to_example(a):
    return dspy.Example(
        title=clean_text(a.get("title")),
        body=article_body(a),
        keywords=a.get("keywords") or [],
    ).with_inputs("title", "body")


def extractive_summary(title, body, keywords):
    text = body or title or ""
    sentences = [s.strip() for s in re.split(r"(?<=[.!?])\s+", text) if s.strip()]
    if not sentences:
        return title or ""
    if keywords:
        def score(s):
            sl = s.lower()
            return sum(1 for k in keywords if k and k.lower() in sl)
        best = max(sentences, key=score)
        if score(best) > 0:
            return best
    return sentences[0]


def chips(items, empty="-"):
    if isinstance(items, str):
        items = [items]
    items = [str(i) for i in (items or []) if i]
    if not items:
        return empty
    return " ".join("[%s]" % i for i in items[:8])


def sentiment_badge(a):
    s = a.get("sentiment")
    if not s:
        return "n/a (paid plan)"
    return SENT_LABEL.get(str(s).lower(), str(s))


def render_article(idx, a, summary):
    print()
    print("%d. %s" % (idx, clean_text(a.get("title")) or "(untitled)"))
    src = a.get("source_id") or a.get("source_name") or "?"
    print("   source: %s   published: %s" % (src, a.get("pubDate", "?")))
    print("   summary: %s" % (summary or "(none)"))
    print("   keywords:  %s" % chips(a.get("keywords")))
    print("   sentiment: %s" % sentiment_badge(a))
    print("   ai_tag:    %s" % chips(a.get("ai_tag"), empty="n/a (paid plan)"))
    ai_sum = clean_text(a.get("ai_summary"))
    print("   ai_summary: %s" % (ai_sum or "n/a (paid plan)"))


def sentiment_breakdown(articles):
    counts = {"positive": 0, "neutral": 0, "negative": 0}
    have = False
    for a in articles:
        s = a.get("sentiment")
        if s and str(s).lower() in counts:
            counts[str(s).lower()] += 1
            have = True
    print()
    print("Sentiment breakdown")
    caption = None
    if not have:
        counts = {"positive": 3, "neutral": 5, "negative": 2}
        caption = "   (sample - live sentiment requires a paid newsdata.io plan)"
    total = sum(counts.values()) or 1
    for label in ("positive", "neutral", "negative"):
        n = counts[label]
        bar = "#" * int(round(20 * n / total))
        print("   %-9s %-20s %d" % (label, bar, n))
    if caption:
        print(caption)


def avg_score(module, examples):
    if not examples:
        return 0.0
    total = 0.0
    for ex in examples:
        try:
            pred = module(title=ex.title, body=ex.body)
            total += P.coverage_score(ex, pred)
        except Exception:
            pass
    return total / len(examples)


def run_with_dspy(examples, demos):
    summarizer = P.NewsSummarizer()
    n = len(examples)
    split = max(1, n // 2)
    train = examples[:split]
    dev = examples[split:] or examples[:split]

    baseline = avg_score(summarizer, dev)
    optimizer = BootstrapFewShot(
        metric=P.coverage_score,
        max_bootstrapped_demos=demos,
        max_labeled_demos=0,
    )
    compiled = optimizer.compile(summarizer, trainset=train)
    optimized = avg_score(compiled, dev)
    print()
    print(
        "Keyword-coverage score on dev set: baseline %.2f -> optimized %.2f"
        % (baseline, optimized)
    )
    return compiled


def main():
    ap = argparse.ArgumentParser(
        description="Summarize newsdata.io headlines with an optimized DSPy pipeline."
    )
    ap.add_argument("-q", "--query", help="search term (omit for general latest news)")
    ap.add_argument("-l", "--language", default="en", help="language code (default en)")
    ap.add_argument("-c", "--country", help="2-letter country code, e.g. us")
    ap.add_argument("-n", "--max", type=int, default=10,
                    help="max articles (free tier caps around 10)")
    ap.add_argument("--demos", type=int, default=3,
                    help="few-shot demos for the optimizer")
    args = ap.parse_args()

    paid = os.environ.get("NEWSDATA_PAID", "").lower() in ("1", "true", "yes")
    try:
        articles = fetch_latest(
            query=args.query,
            language=args.language,
            country=args.country,
            max_articles=args.max,
            paid=paid,
        )
    except NewsDataError as e:
        print("error: %s" % e, file=sys.stderr)
        return 1

    if not articles:
        print("No articles returned. Try a different query or language.")
        return 0

    examples = [to_example(a) for a in articles]
    usable = [e for e in examples if e.body]

    lm = P.configure_lm()
    summaries = {}

    if lm and usable:
        print("Using DSPy LM: %s  (%d usable articles)" % (os.environ["DSPY_LM"], len(usable)))
        try:
            compiled = run_with_dspy(usable, args.demos)
            for a, ex in zip(articles, examples):
                if not ex.body:
                    summaries[id(a)] = clean_text(a.get("title"))
                    continue
                pred = compiled(title=ex.title, body=ex.body)
                summaries[id(a)] = (pred.summary or "").strip()
        except Exception as e:
            print("DSPy run failed (%s); falling back to extractive summaries." % e,
                  file=sys.stderr)
            lm = None

    if not lm:
        if not os.environ.get("DSPY_LM"):
            print("DSPY_LM not set - using extractive summaries. "
                  "Set DSPY_LM to enable the DSPy pipeline.")
        for a, ex in zip(articles, examples):
            summaries[id(a)] = extractive_summary(ex.title, ex.body, a.get("keywords"))

    for i, a in enumerate(articles, 1):
        render_article(i, a, summaries.get(id(a), ""))
    sentiment_breakdown(articles)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
