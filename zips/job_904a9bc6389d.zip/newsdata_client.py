"""Minimal newsdata.io client.

Targets the free `/latest` endpoint and only sends parameters that work on a
free key by default. Paid query parameters (e.g. `full_content`) are opt-in via
the `paid` flag and, if rejected by the plan, the request is retried once
without them so free users still get results.
"""
import os
import time

import requests

BASE_URL = "https://newsdata.io/api/1"


class NewsDataError(Exception):
    pass


def _api_key():
    key = os.environ.get("NEWSDATA_API_KEY")
    if not key:
        raise NewsDataError(
            "NEWSDATA_API_KEY is not set. Get a free key at https://newsdata.io"
        )
    return key


def _request(session, params, paid_keys, retries=3):
    url = BASE_URL + "/latest"
    last_error = None
    for attempt in range(retries):
        resp = session.get(url, params=params, timeout=30)
        if resp.status_code == 200:
            data = resp.json()
            if data.get("status") == "success":
                return data
            raise NewsDataError(
                "API error: %s" % (data.get("message") or data.get("results") or data)
            )
        if resp.status_code == 401:
            raise NewsDataError("Invalid API key (401). Check NEWSDATA_API_KEY.")
        if resp.status_code == 429:
            last_error = "rate limited (429)"
            time.sleep(2 * (attempt + 1))
            continue
        if resp.status_code in (403, 422) and paid_keys:
            # Paid parameter rejected on this plan -> retry without it.
            for k in list(paid_keys):
                params.pop(k, None)
            paid_keys = set()
            continue
        raise NewsDataError(
            "newsdata.io returned %s: %s" % (resp.status_code, resp.text[:200])
        )
    raise NewsDataError(last_error or "request failed after retries")


def fetch_latest(query=None, language="en", country=None, max_articles=10,
                 paid=False, session=None):
    """Fetch up to `max_articles` recent articles, following the nextPage cursor."""
    key = _api_key()
    session = session or requests.Session()

    base = {"apikey": key}
    if language:
        base["language"] = language
    if query:
        base["q"] = query
    if country:
        base["country"] = country

    paid_keys = set()
    if paid:
        base["full_content"] = 1
        paid_keys = {"full_content"}

    articles = []
    page = None
    while len(articles) < max_articles:
        params = dict(base)
        if page:
            params["page"] = page
        data = _request(session, params, set(paid_keys))
        results = data.get("results") or []
        if not results:
            break
        articles.extend(results)
        page = data.get("nextPage")
        if not page:
            break
    return articles[:max_articles]
