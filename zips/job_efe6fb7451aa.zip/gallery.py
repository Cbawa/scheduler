"""Render a self-contained HTML gallery for the collected news articles."""
import html
from collections import Counter

SENTIMENT_COLORS = {
    "positive": "#2e7d32",
    "neutral": "#616161",
    "negative": "#c62828",
}

PAGE_CSS = """
* { box-sizing: border-box; }
body { margin:0; font-family:-apple-system,Segoe UI,Roboto,Helvetica,Arial,sans-serif;
       background:#0f0f10; color:#e8e8e8; }
header { padding:24px; border-bottom:1px solid #262626; }
h1 { margin:0 0 4px; font-size:22px; }
h2 { font-size:16px; margin:0 0 10px; }
.sub { color:#9a9a9a; font-size:14px; }
.wrap { padding:24px; max-width:1200px; margin:0 auto; }
.collage { width:100%; border-radius:10px; margin-bottom:28px; display:block; }
.bars { margin:0 0 28px; }
.bar-row { display:flex; align-items:center; gap:10px; margin:6px 0; }
.bar-label { width:80px; font-size:13px; text-transform:capitalize; }
.bar-track { flex:1; background:#1d1d1f; border-radius:6px; overflow:hidden; height:16px; }
.bar-fill { height:100%; }
.note { font-size:12px; color:#8a8a8a; font-style:italic; margin-top:6px; }
.grid { display:grid; grid-template-columns:repeat(auto-fill,minmax(280px,1fr)); gap:18px; }
.card { background:#161618; border:1px solid #262626; border-radius:10px;
        overflow:hidden; display:flex; flex-direction:column; }
.card img { width:100%; height:160px; object-fit:cover; background:#222; display:block; }
.card .noimg { width:100%; height:160px; background:#202024; }
.card .body { padding:12px; display:flex; flex-direction:column; gap:8px; }
.card h3 { margin:0; font-size:15px; line-height:1.3; }
.card a { color:#cfe3ff; text-decoration:none; }
.card a:hover { text-decoration:underline; }
.src { font-size:12px; color:#9a9a9a; }
.summary { font-size:13px; color:#c7c7c7; }
.chips { display:flex; flex-wrap:wrap; gap:6px; }
.chip { font-size:11px; padding:2px 8px; border-radius:999px; background:#23262b; color:#bcd; }
.chip.ai { background:#2a2030; color:#e3c7ff; }
.badge { align-self:flex-start; font-size:11px; padding:2px 8px; border-radius:6px; color:#fff;
         text-transform:capitalize; }
.placeholder { color:#777; font-style:italic; font-size:12px; }
footer { padding:20px 24px; color:#777; font-size:12px; border-top:1px solid #262626; }
"""


def _sentiment_distribution(articles):
    counts = Counter()
    for article in articles:
        value = (article.get("sentiment") or "").lower()
        if value in SENTIMENT_COLORS:
            counts[value] += 1
    return counts


def _bars_html(counts, is_sample):
    total = sum(counts.values()) or 1
    rows = []
    for label in ("positive", "neutral", "negative"):
        pct = round(100 * counts.get(label, 0) / total)
        color = SENTIMENT_COLORS[label]
        rows.append(
            '<div class="bar-row"><span class="bar-label">%s</span>'
            '<span class="bar-track"><span class="bar-fill" style="width:%d%%;background:%s"></span></span>'
            '<span class="src">%d%%</span></div>' % (label, pct, color, pct)
        )
    note = ""
    if is_sample:
        note = ('<div class="note">sample \u2014 live sentiment requires a paid '
                'newsdata.io plan</div>')
    return '<div class="bars"><h2>Sentiment breakdown</h2>' + "".join(rows) + note + "</div>"


def _as_list(value):
    if value is None:
        return []
    if isinstance(value, str):
        return [value]
    if isinstance(value, (list, tuple)):
        return list(value)
    return [value]


def _card_html(article):
    title = html.escape(article.get("title") or "Untitled")
    link = html.escape(article.get("link") or "#")
    source = html.escape(article.get("source_id") or article.get("source_name") or "unknown source")
    image = article.get("image_url")
    if image:
        media = '<img src="%s" alt="" loading="lazy">' % html.escape(image)
    else:
        media = '<div class="noimg"></div>'

    parts = []
    sentiment = (article.get("sentiment") or "").lower()
    if sentiment in SENTIMENT_COLORS:
        parts.append(
            '<span class="badge" style="background:%s">%s</span>'
            % (SENTIMENT_COLORS[sentiment], html.escape(sentiment))
        )

    summary = article.get("ai_summary")
    if summary:
        parts.append('<div class="summary">%s</div>' % html.escape(str(summary)))

    keywords = _as_list(article.get("keywords"))
    if keywords:
        chips = "".join('<span class="chip">%s</span>' % html.escape(str(k)) for k in keywords[:6])
        parts.append('<div class="chips">%s</div>' % chips)

    ai_tags = _as_list(article.get("ai_tag"))
    if ai_tags:
        chips = "".join('<span class="chip ai">%s</span>' % html.escape(str(t)) for t in ai_tags[:5])
        parts.append('<div class="chips">%s</div>' % chips)

    if not keywords and not ai_tags and not summary and sentiment not in SENTIMENT_COLORS:
        parts.append('<div class="placeholder">No keywords, sentiment, or AI tags for this article.</div>')

    body = (
        '<div class="body"><h3><a href="%s" target="_blank" rel="noopener">%s</a></h3>'
        '<div class="src">%s</div>%s</div>'
    ) % (link, title, source, "".join(parts))
    return '<div class="card">%s%s</div>' % (media, body)


def build_gallery(articles, collage_filename, out_path, title=None):
    """Write a complete HTML gallery to out_path and return the path."""
    title = title or "Daily News Collage"
    counts = _sentiment_distribution(articles)
    is_sample = sum(counts.values()) == 0
    if is_sample:
        counts = Counter({"positive": 5, "neutral": 4, "negative": 2})

    header = (
        '<header><h1>%s</h1>'
        '<div class="sub">%d articles from the newsdata.io news API</div></header>'
    ) % (html.escape(title), len(articles))

    collage_img = ""
    if collage_filename:
        collage_img = '<img class="collage" src="%s" alt="news collage">' % html.escape(collage_filename)

    cards = "".join(_card_html(a) for a in articles)

    document = (
        '<!doctype html><html lang="en"><head><meta charset="utf-8">'
        '<meta name="viewport" content="width=device-width, initial-scale=1">'
        '<title>%s</title><style>%s</style></head><body>%s'
        '<div class="wrap">%s%s<div class="grid">%s</div></div>'
        '<footer>Data from the newsdata.io news API (https://newsdata.io). '
        'Generated by news-image-collager.</footer></body></html>'
    ) % (
        html.escape(title),
        PAGE_CSS,
        header,
        collage_img,
        _bars_html(counts, is_sample),
        cards,
    )

    with open(out_path, "w", encoding="utf-8") as handle:
        handle.write(document)
    return out_path
