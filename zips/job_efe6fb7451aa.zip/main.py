#!/usr/bin/env python3
"""Build a daily news image collage and HTML gallery from newsdata.io."""
import argparse
import os
import sys
from datetime import datetime, timezone

from api import NewsDataClient, NewsDataError
from collage import build_collage, download_image
from gallery import build_gallery


def parse_args():
    parser = argparse.ArgumentParser(
        description="Download news images from newsdata.io and build a collage + HTML gallery."
    )
    parser.add_argument("-q", "--query", help="keyword to search for")
    parser.add_argument("-c", "--category", help="category, e.g. technology, sports, business")
    parser.add_argument("-l", "--language", default="en", help="language code (default: en)")
    parser.add_argument("--country", help="2-letter country code, e.g. us, gb")
    parser.add_argument("-n", "--num", type=int, default=12, help="images in the collage (default: 12)")
    parser.add_argument("--cols", type=int, default=4, help="collage columns (default: 4)")
    parser.add_argument("-o", "--outdir", default="output", help="output directory (default: output)")
    return parser.parse_args()


def main():
    args = parse_args()
    paid = os.environ.get("NEWSDATA_PAID", "").strip().lower() in ("1", "true", "yes")

    try:
        client = NewsDataClient(paid_mode=paid)
    except NewsDataError as exc:
        print("error: %s" % exc, file=sys.stderr)
        return 1

    print("Fetching headlines from newsdata.io ...")
    try:
        articles = client.fetch_articles(
            query=args.query,
            category=args.category,
            language=args.language,
            country=args.country,
            max_articles=max(args.num * 2, args.num + 6),
        )
    except NewsDataError as exc:
        print("error: %s" % exc, file=sys.stderr)
        return 1

    if not articles:
        print("No articles returned. Try a different query, category, or country.")
        return 0

    with_images = [a for a in articles if a.get("image_url")]
    print("Got %d articles, %d with images." % (len(articles), len(with_images)))

    os.makedirs(args.outdir, exist_ok=True)

    images = []
    used = []
    for article in with_images:
        if len(images) >= args.num:
            break
        img = download_image(article["image_url"])
        if img is not None:
            images.append(img)
            used.append(article)

    stamp = datetime.now(timezone.utc).strftime("%Y-%m-%d")
    collage_ref = ""
    if images:
        collage_name = "collage-%s.png" % stamp
        collage_path = os.path.join(args.outdir, collage_name)
        build_collage(images, cols=args.cols, out_path=collage_path)
        collage_ref = collage_name
        print("Wrote collage -> %s" % collage_path)
    else:
        print("Could not download any images; building the gallery without a collage.")

    gallery_articles = used or with_images or articles
    gallery_path = os.path.join(args.outdir, "index.html")
    build_gallery(
        gallery_articles,
        collage_ref,
        gallery_path,
        title="Daily News Collage \u2014 %s" % stamp,
    )
    print("Wrote gallery -> %s" % gallery_path)
    print("Open %s in a browser." % gallery_path)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
