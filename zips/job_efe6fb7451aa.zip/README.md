# news-image-collager

A small command-line tool that pulls recent headlines from the newsdata.io news
API (https://newsdata.io), downloads the article images, and stitches them into a
single daily collage PNG plus a self-contained HTML gallery.

The gallery lists each headline with its source and any keywords the API returns,
and — when your plan provides them — a sentiment badge, AI tags, and a short AI
summary. Grab a free API key at https://newsdata.io to run it.

## What it does

- Fetches the latest news through the newsdata.io `/latest` endpoint, following
  the `nextPage` cursor to gather enough articles.
- Builds a grid collage of the article images with Pillow.
- Writes `index.html`: a dark gallery with thumbnails, sources, keyword chips,
  and a sentiment breakdown chart.
- Reads `sentiment`, `ai_tag`, and `ai_summary` from each article when they are
  present and falls back to clearly labeled placeholders otherwise, so it runs
  unchanged on a free key.
- Filters by query, category, language, or country.

## Setup

Requires Python 3.9 or newer.

```
git clone <this repo>
cd news-image-collager
pip install -r requirements.txt
```

Set your newsdata.io API key (free keys work):

```
export NEWSDATA_API_KEY="your_key_here"
```

## Usage

```
python main.py                       # latest English headlines
python main.py -q "climate" -n 16    # 16 images about climate
python main.py -c technology --country us --cols 5
```

Options:

```
-q, --query      keyword to search for
-c, --category   category, e.g. technology, sports, business
-l, --language   language code (default: en)
    --country    2-letter country code, e.g. us, gb
-n, --num        number of images in the collage (default: 12)
    --cols       collage columns (default: 4)
-o, --outdir     output directory (default: output)
```

Output lands in `output/`:

```
output/
  collage-2026-06-11.png
  index.html
```

Open `output/index.html` in a browser to see the gallery.

### Example

```
$ export NEWSDATA_API_KEY=pub_xxx
$ python main.py -q "space" -n 9 --cols 3
Fetching headlines from newsdata.io ...
Got 18 articles, 12 with images.
Wrote collage -> output/collage-2026-06-11.png
Wrote gallery -> output/index.html
Open output/index.html in a browser.
```

## Optional: paid plan fields

The `sentiment`, `ai_tag`, `ai_org`, `ai_region`, and `ai_summary` values are only
returned on paid newsdata.io plans. The tool reads them automatically when they
are present; on a free key those areas show a labeled placeholder and the
sentiment chart shows a sample distribution so the layout stays intact.

If you have a paid plan and want larger result pages, set:

```
export NEWSDATA_PAID=1
```

This lets `--num` request more than 10 articles per page (`size` greater than 10
is a paid-only parameter). If a paid-only request is rejected, the client retries
once without those parameters so you still get results.

## Notes

- The API key is read only from `NEWSDATA_API_KEY` and is never written to disk.
- Image downloads that fail (dead links, non-image responses) are skipped.

## License

MIT
