"""Thin client for the newsdata.io news API (https://newsdata.io).

Reads the API key from the NEWSDATA_API_KEY environment variable and talks to the
/latest endpoint. Paid-only query parameters are only sent in paid mode, and a
rejected paid request is retried once without them so free keys still get results.
"""
import os

import requests

BASE_URL = "https://newsdata.io/api/1"
LATEST_ENDPOINT = BASE_URL + "/latest"

# Query parameters that error the whole request on a free plan.
PAID_PARAMS = {
    "sentiment",
    "sentiment_score",
    "tag",
    "region",
    "organization",
    "timeframe",
    "from_date",
    "to_date",
    "full_content",
    "size",
}


class NewsDataError(Exception):
    """Raised for any problem talking to newsdata.io."""


def _api_error_text(data):
    results = data.get("results")
    if isinstance(results, dict):
        return results.get("message") or str(results)
    return data.get("message") or str(data)[:200]


def _error_message(resp):
    try:
        return _api_error_text(resp.json())
    except ValueError:
        return resp.text[:200]


class NewsDataClient:
    def __init__(self, api_key=None, paid_mode=False, timeout=30):
        self.api_key = api_key or os.environ.get("NEWSDATA_API_KEY")
        if not self.api_key:
            raise NewsDataError(
                "NEWSDATA_API_KEY is not set. Get a free key at https://newsdata.io "
                "and export it, e.g. export NEWSDATA_API_KEY=your_key_here"
            )
        self.paid_mode = paid_mode
        self.timeout = timeout
        self.session = requests.Session()

    def _request(self, params, _retry_without_paid=True):
        query = dict(params)
        query["apikey"] = self.api_key
        try:
            resp = self.session.get(LATEST_ENDPOINT, params=query, timeout=self.timeout)
        except requests.RequestException as exc:
            raise NewsDataError("Network error talking to newsdata.io: %s" % exc)

        if resp.status_code == 401:
            raise NewsDataError(
                "401 Unauthorized \u2014 NEWSDATA_API_KEY is invalid. Check it at https://newsdata.io."
            )
        if resp.status_code == 429:
            raise NewsDataError(
                "429 Too Many Requests \u2014 the free-plan rate limit was hit. Wait a bit and retry."
            )
        if resp.status_code in (403, 422) and _retry_without_paid:
            stripped = {k: v for k, v in params.items() if k not in PAID_PARAMS}
            if stripped != dict(params):
                return self._request(stripped, _retry_without_paid=False)
        if resp.status_code != 200:
            raise NewsDataError(
                "newsdata.io returned HTTP %d: %s" % (resp.status_code, _error_message(resp))
            )

        try:
            data = resp.json()
        except ValueError:
            raise NewsDataError("newsdata.io returned a non-JSON response.")

        if data.get("status") == "error":
            raise NewsDataError("newsdata.io error: %s" % _api_error_text(data))
        return data

    def fetch_articles(self, query=None, category=None, language="en",
                       country=None, max_articles=24, max_pages=10):
        """Collect up to `max_articles` articles, following the nextPage cursor."""
        base = {}
        if language:
            base["language"] = language
        if query:
            base["q"] = query
        if category:
            base["category"] = category
        if country:
            base["country"] = country
        # size > 10 is a paid-only parameter; only send it in paid mode.
        if self.paid_mode and max_articles > 10:
            base["size"] = min(max_articles, 50)

        collected = []
        page = None
        pages = 0
        while len(collected) < max_articles and pages < max_pages:
            params = dict(base)
            if page:
                params["page"] = page
            data = self._request(params)
            results = data.get("results") or []
            collected.extend(results)
            pages += 1
            page = data.get("nextPage")
            if not page:
                break
        return collected[:max_articles]
