"""Download article images and assemble them into a grid collage (PNG)."""
import math
from io import BytesIO

import requests
from PIL import Image


def download_image(url, timeout=20):
    """Fetch one image URL and return an RGB PIL image, or None on failure."""
    try:
        resp = requests.get(url, timeout=timeout)
        resp.raise_for_status()
        return Image.open(BytesIO(resp.content)).convert("RGB")
    except Exception:
        return None


def _crop_square(img, size):
    width, height = img.size
    side = min(width, height)
    left = (width - side) // 2
    top = (height - side) // 2
    cropped = img.crop((left, top, left + side, top + side))
    return cropped.resize((size, size))


def build_collage(images, cols=4, cell=320, padding=8, bg=(18, 18, 18), out_path="collage.png"):
    """Tile square thumbnails of `images` into a grid and save as a PNG."""
    if not images:
        raise ValueError("No images supplied for the collage.")
    cols = max(1, min(cols, len(images)))
    rows = math.ceil(len(images) / cols)
    width = cols * cell + (cols + 1) * padding
    height = rows * cell + (rows + 1) * padding
    canvas = Image.new("RGB", (width, height), bg)
    for idx, img in enumerate(images):
        row, col = divmod(idx, cols)
        thumb = _crop_square(img, cell)
        x = padding + col * (cell + padding)
        y = padding + row * (cell + padding)
        canvas.paste(thumb, (x, y))
    canvas.save(out_path)
    return out_path
