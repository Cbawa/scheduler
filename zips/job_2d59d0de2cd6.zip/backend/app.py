'''Flask backend for the news Q&A app.

Serves the React single-page frontend and exposes POST /api/ask, which
retrieves headlines from the newsdata.io news API and returns a cited answer
plus the supporting articles and a sentiment breakdown.
'''
import os
from pathlib import Path

try:
    from dotenv import load_dotenv
    load_dotenv()
except Exception:
    pass

from flask import Flask, jsonify, request, send_from_directory

from newsdata_client import NewsDataError, fetch_articles
from synthesize import synthesize

FRONTEND_DIR = Path(__file__).resolve().parent.parent / 'frontend'

app = Flask(__name__, static_folder=None)


def _sentiment_breakdown(articles):
    counts = {'positive': 0, 'neutral': 0, 'negative': 0}
    have_real = False
    for a in articles:
        s = a.get('sentiment')
        if s in counts:
            counts[s] += 1
            have_real = True
    if have_real:
        return {'counts': counts, 'is_sample': False}
    # Free keys omit sentiment; show a clearly labeled sample distribution.
    return {'counts': {'positive': 4, 'neutral': 5, 'negative': 1}, 'is_sample': True}


def _clean_article(a):
    return {
        'title': a.get('title'),
        'link': a.get('link'),
        'source': a.get('source_id') or a.get('source_name'),
        'pubDate': a.get('pubDate'),
        'image': a.get('image_url'),
        'description': a.get('description'),
        'keywords': a.get('keywords') or [],   # free field
        'sentiment': a.get('sentiment'),        # paid field (may be None)
        'ai_tag': a.get('ai_tag'),              # paid field
        'ai_summary': a.get('ai_summary'),      # paid field
    }


@app.get('/')
def index():
    return send_from_directory(FRONTEND_DIR, 'index.html')


@app.post('/api/ask')
def ask():
    payload = request.get_json(silent=True) or {}
    question = (payload.get('question') or '').strip()
    language = (payload.get('language') or 'en').strip() or 'en'
    if not question:
        return jsonify({'error': 'Please provide a question.'}), 400
    try:
        articles = fetch_articles(question, language=language)
    except NewsDataError as exc:
        status = exc.status or 502
        code = status if status in (401, 429) else 502
        return jsonify({'error': str(exc)}), code

    result = synthesize(question, articles)
    return jsonify(
        {
            'question': question,
            'answer': result['answer'],
            'mode': result['mode'],
            'note': result.get('note'),
            'sources': result['sources'],
            'articles': [_clean_article(a) for a in articles],
            'sentiment': _sentiment_breakdown(articles),
        }
    )


def main():
    if not os.environ.get('NEWSDATA_API_KEY'):
        raise SystemExit(
            'NEWSDATA_API_KEY is not set. Get a free key at https://newsdata.io '
            'and export it, e.g. export NEWSDATA_API_KEY=pub_xxx'
        )
    port = int(os.environ.get('PORT', '5000'))
    app.run(host='127.0.0.1', port=port, debug=True)


if __name__ == '__main__':
    main()
