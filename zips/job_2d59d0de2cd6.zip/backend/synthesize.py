'''Turn retrieved articles into a short, cited answer.

If OPENAI_API_KEY is set, GPT writes the synthesis; otherwise a deterministic
extractive fallback stitches together the article summaries so the app still
answers without an OpenAI account.
'''
import os

SYSTEM_PROMPT = (
    'You answer questions using only the numbered news snippets provided. '
    'Write 2-4 sentences. Cite every claim with bracketed source numbers like '
    '[1] or [2][3]. Do not invent facts that are not in the snippets.'
)


def _source_list(articles):
    sources = []
    for i, a in enumerate(articles, start=1):
        sources.append(
            {
                'id': i,
                'title': a.get('title') or 'Untitled',
                'source': a.get('source_id') or a.get('source_name') or 'unknown',
                'link': a.get('link') or '',
            }
        )
    return sources


def _context(articles):
    blocks = []
    for i, a in enumerate(articles, start=1):
        snippet = a.get('description') or a.get('ai_summary') or a.get('title') or ''
        blocks.append('[%d] %s' % (i, snippet.strip()))
    return '\n\n'.join(blocks)


def _gpt_answer(question, articles):
    from openai import OpenAI

    client = OpenAI()
    model = os.environ.get('OPENAI_MODEL', 'gpt-4o')
    user = 'Question: %s\n\nSnippets:\n%s' % (question, _context(articles))
    resp = client.chat.completions.create(
        model=model,
        messages=[
            {'role': 'system', 'content': SYSTEM_PROMPT},
            {'role': 'user', 'content': user},
        ],
        temperature=0.2,
        max_tokens=400,
    )
    return resp.choices[0].message.content.strip()


def _extractive_answer(question, articles):
    parts = []
    for i, a in enumerate(articles[:3], start=1):
        snippet = a.get('description') or a.get('ai_summary') or a.get('title') or ''
        snippet = snippet.strip()
        if snippet:
            if len(snippet) > 240:
                snippet = snippet[:237].rstrip() + '...'
            parts.append('%s [%d]' % (snippet, i))
    if not parts:
        return 'The retrieved headlines did not contain enough detail to answer.'
    return ' '.join(parts)


def synthesize(question, articles):
    sources = _source_list(articles)
    if not articles:
        return {
            'answer': 'No recent articles matched that question. Try broader terms.',
            'sources': sources,
            'mode': 'empty',
        }
    if os.environ.get('OPENAI_API_KEY'):
        try:
            return {'answer': _gpt_answer(question, articles), 'sources': sources, 'mode': 'gpt'}
        except Exception as exc:  # fall back to extractive on any OpenAI error
            return {
                'answer': _extractive_answer(question, articles),
                'sources': sources,
                'mode': 'extractive',
                'note': 'OpenAI synthesis unavailable (%s); showing extractive answer.' % exc,
            }
    return {'answer': _extractive_answer(question, articles), 'sources': sources, 'mode': 'extractive'}
