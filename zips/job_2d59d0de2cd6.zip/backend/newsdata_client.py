'''Thin client for the newsdata.io news API.

Reads the API key from NEWSDATA_API_KEY. Uses the free-tier /latest endpoint
and paginates with the nextPage cursor. Paid query parameters are only sent
when ENABLE_PAID_PARAMS=1, and a paid-param rejection falls back to a plain
free-tier request so the caller always gets results.
'''
import os

import requests

BASE_URL = 'https://newsdata.io/api/1'
LATEST_ENDPOINT = BASE_URL + '/latest'

# Query params that require a paid plan; sending them on a free key errors the
# whole request, so we only add them in paid mode and strip them on failure.
PAID_PARAMS = ('full_content',)


class NewsDataError(Exception):
    def __init__(self, message, status=None):
        super().__init__(message)
        self.status = status


def _api_key():
    key = os.environ.get('NEWSDATA_API_KEY')
    if not key:
        raise NewsDataError(
            'NEWSDATA_API_KEY is not set. Get a free key at '
            'https://newsdata.io and export it before running.'
        )
    return key


def _paid_enabled():
    return os.environ.get('ENABLE_PAID_PARAMS') == '1'


def _build_params(query, language, page=None, paid=False):
    params = {'apikey': _api_key(), 'q': query, 'language': language}
    if page:
        params['page'] = page
    if paid:
        # Full article text is a paid feature; harmless to ask for when enabled.
        params['full_content'] = 1
    return params


def _strip_paid(params):
    return {k: v for k, v in params.items() if k not in PAID_PARAMS}


def _request(params):
    try:
        resp = requests.get(LATEST_ENDPOINT, params=params, timeout=30)
    except requests.RequestException as exc:
        raise NewsDataError('Network error contacting newsdata.io: %s' % exc)

    # A paid param on a free key returns 403/422 — retry once without it.
    if resp.status_code in (403, 422) and any(p in params for p in PAID_PARAMS):
        resp = requests.get(LATEST_ENDPOINT, params=_strip_paid(params), timeout=30)

    if resp.status_code == 401:
        raise NewsDataError('Invalid NEWSDATA_API_KEY (HTTP 401).', status=401)
    if resp.status_code == 429:
        raise NewsDataError(
            'newsdata.io rate limit reached (HTTP 429). Wait and try again.',
            status=429,
        )
    if resp.status_code != 200:
        msg = 'newsdata.io returned HTTP %s' % resp.status_code
        try:
            body = resp.json()
            if isinstance(body.get('results'), dict):
                msg = body['results'].get('message') or msg
            else:
                msg = body.get('message') or msg
        except ValueError:
            pass
        raise NewsDataError(msg, status=resp.status_code)

    data = resp.json()
    if data.get('status') == 'error':
        message = 'newsdata.io error'
        results = data.get('results')
        if isinstance(results, dict):
            message = results.get('message', message)
        raise NewsDataError(message)
    return data


def fetch_articles(query, language='en', max_pages=2, max_articles=10):
    '''Return a list of article dicts for a query, following nextPage.'''
    collected = []
    page = None
    for _ in range(max_pages):
        params = _build_params(query, language, page, paid=_paid_enabled())
        data = _request(params)
        results = data.get('results') or []
        collected.extend(results)
        page = data.get('nextPage')
        if not page or len(collected) >= max_articles:
            break
    return collected[:max_articles]
