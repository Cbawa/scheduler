# Cited News Q&A

Ask a question and get a short, sourced answer built from current news
headlines. Retrieval comes from the newsdata.io news API (https://newsdata.io);
an OpenAI model writes the synthesis when a key is available, and every sentence
in the answer carries a bracketed citation back to the article it came from.

The interface is a small React single-page app served by a Flask backend.

## How it works

1. You type a question in the browser.
2. The backend queries the newsdata.io `/latest` endpoint for matching headlines.
3. The articles are passed to GPT-4 (when `OPENAI_API_KEY` is set) to write a
   2-4 sentence answer with `[n]` citations. Without an OpenAI key it falls back
   to an extractive answer stitched from the article summaries, so the app still
   runs.
4. The answer, the cited sources, the matching articles, and a sentiment
   breakdown are rendered together.

## Features

- Cited answers with clickable `[n]` markers that link to each source.
- Article cards with keyword tags (always available on the free plan).
- Per-article sentiment badges and a sentiment breakdown bar.
- AI tag chips and an AI summary line per article.
- Runs without an OpenAI key via an extractive fallback.

The sentiment, AI tag, and AI summary fields are returned by newsdata.io only on
paid plans. On a free key those fields are absent, so the UI shows a clearly
labeled placeholder (and the sentiment bar shows a sample distribution) instead
of a blank widget.

## Requirements

- Python 3.10+
- A free newsdata.io API key — https://newsdata.io
- Optional: an OpenAI API key for GPT-written answers

## Setup

```bash
python -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt

export NEWSDATA_API_KEY=pub_xxxxxxxxxxxxxxxx   # required
export OPENAI_API_KEY=sk-...                    # optional
export OPENAI_MODEL=gpt-4o                       # optional, default gpt-4o

python backend/app.py
```

Then open http://127.0.0.1:5000 in a browser.

## Configuration

| Variable | Required | Default | Notes |
| --- | --- | --- | --- |
| `NEWSDATA_API_KEY` | yes | — | Free key from newsdata.io |
| `OPENAI_API_KEY` | no | — | Enables GPT synthesis; extractive fallback if unset |
| `OPENAI_MODEL` | no | `gpt-4o` | Any chat-completions model |
| `PORT` | no | `5000` | Backend port |
| `ENABLE_PAID_PARAMS` | no | `0` | Set to `1` to request full article content; requires a paid newsdata.io plan. A rejected paid request is retried once without the paid parameters. |

## Example

Call the API directly:

```bash
curl -s -X POST http://127.0.0.1:5000/api/ask \
  -H 'Content-Type: application/json' \
  -d '{"question": "What is happening with interest rates?"}'
```

Sample response (truncated):

```json
{
  "question": "What is happening with interest rates?",
  "mode": "gpt",
  "answer": "Several central banks held rates steady this week [1], while others signaled cuts later in the year [2].",
  "sources": [
    {"id": 1, "title": "Central bank holds rates", "source": "reuters", "link": "https://..."}
  ],
  "sentiment": {"counts": {"positive": 4, "neutral": 5, "negative": 1}, "is_sample": true}
}
```

When no OpenAI key is set, `mode` is `extractive` and the answer is assembled
directly from the article summaries.

## Notes

- The free newsdata.io plan returns up to 10 articles per request; the backend
  follows the `nextPage` cursor for a second page when one is available.
- 401 (invalid key), 429 (rate limit), and empty result sets are surfaced as
  plain messages rather than stack traces.
- Only free-tier query parameters are sent by default. Paid parameters are
  opt-in and degrade gracefully.

## Project layout

```
backend/app.py              Flask app + /api/ask endpoint
backend/newsdata_client.py  newsdata.io retrieval and pagination
backend/synthesize.py       GPT-4 synthesis with extractive fallback
frontend/index.html         React single-page UI
```

## License

MIT
