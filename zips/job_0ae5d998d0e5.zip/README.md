# Flutter NewsData App

A polished, cross-platform **Flutter** news reader powered by the [newsdata.io](https://newsdata.io) REST API.
Browse the latest headlines, filter by category with a horizontal chip bar, switch sections
with bottom navigation, and read full articles in an in-app WebView.

> Built as a free-tier-friendly showcase for the newsdata.io news API.

## Features

- 📰 **Latest news** from the newsdata.io `/news` endpoint
- 🧭 **Bottom navigation** — Headlines, Search, and About sections
- 🏷️ **Category filtering** — Top, World, Business, Technology, Sports, Science, Health, Entertainment
- 🔎 **Keyword search** with the free `q` parameter
- ♾️ **Infinite scroll** pagination using the `nextPage` token
- 🌐 **In-app WebView** to read the full article without leaving the app
- 🛟 **Graceful error handling** for invalid keys (401), rate limits (429), empty results, and paid-only upgrade prompts (403/422)

## Screenshots

_(Run the app to see it in action — Headlines feed, category chips, and the article WebView.)_

## Getting started

### 1. Prerequisites

- [Flutter SDK](https://docs.flutter.dev/get-started/install) 3.10 or newer (Dart 3.x)
- A free newsdata.io API key — grab one at <https://newsdata.io/register>

### 2. Install dependencies

```bash
flutter pub get
```

### 3. Provide your API key

The key is **never hardcoded**. It is injected at build/run time via Dart's
`--dart-define` mechanism and read in code through `String.fromEnvironment`.

The environment variable name is **`NEWSDATA_API_KEY`**.

Run the app, passing your key:

```bash
flutter run --dart-define=NEWSDATA_API_KEY=your_api_key_here
```

Build a release APK the same way:

```bash
flutter build apk --dart-define=NEWSDATA_API_KEY=your_api_key_here
```

If the key is missing, the app shows a clear, friendly message instead of crashing.

> 💡 **Tip:** To avoid retyping the flag, create a `dart_define.json` file and run
> `flutter run --dart-define-from-file=dart_define.json`. The file is gitignored.
>
> ```json
> { "NEWSDATA_API_KEY": "your_api_key_here" }
> ```

## Free tier vs. paid plan

This app is designed to run perfectly on the **free** newsdata.io plan. It only uses
free parameters on `/news`: `q`, `category`, `language`, and `page` (pagination via
the `nextPage` token).

The following newsdata.io capabilities require a **paid plan** and are intentionally
**not** part of the core flow:

- Sentiment analysis (`sentiment`)
- AI enrichment fields (`ai_tag`, `ai_region`, `ai_org`, `ai_summary`)
- The historical `/archive` endpoint and long date ranges
- Advanced full-text query operators

If the API ever returns a `403`/`422` "upgrade your plan" response for an optional
feature, the app detects it, skips that feature, and keeps working.

## Project structure

```
lib/
├── main.dart                       # App entry point & theme
├── models/
│   └── article.dart                # Article model (maps the /news response)
├── services/
│   └── news_service.dart           # newsdata.io REST client + error handling
└── screens/
    ├── home_screen.dart            # Bottom nav shell
    ├── headlines_screen.dart       # Feed + category chips + infinite scroll
    ├── search_screen.dart          # Keyword search
    ├── about_screen.dart           # Info & free-tier notes
    └── article_webview_screen.dart # In-app WebView reader
```

## License

MIT — free to use, learn from, and build on.
