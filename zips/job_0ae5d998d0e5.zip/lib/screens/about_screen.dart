import 'package:flutter/material.dart';

import '../services/news_service.dart';

class AboutScreen extends StatelessWidget {
  const AboutScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final hasKey = NewsService.hasApiKey;
    return Scaffold(
      appBar: AppBar(title: const Text('About')),
      body: ListView(
        padding: const EdgeInsets.all(20),
        children: [
          const Icon(Icons.public, size: 64, color: Color(0xFF1565C0)),
          const SizedBox(height: 16),
          Text(
            'NewsData Flutter',
            textAlign: TextAlign.center,
            style: Theme.of(context).textTheme.headlineSmall,
          ),
          const SizedBox(height: 8),
          const Text(
            'A demo news app powered by the newsdata.io REST API.',
            textAlign: TextAlign.center,
          ),
          const SizedBox(height: 24),
          Card(
            child: ListTile(
              leading: Icon(
                hasKey ? Icons.check_circle : Icons.warning_amber,
                color: hasKey ? Colors.green : Colors.orange,
              ),
              title: Text(hasKey ? 'API key detected' : 'No API key'),
              subtitle: Text(
                hasKey
                    ? 'Ready to fetch the latest news.'
                    : 'Run with --dart-define=NEWSDATA_API_KEY=your_key',
              ),
            ),
          ),
          const SizedBox(height: 16),
          const Text(
            'Free-tier friendly',
            style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16),
          ),
          const SizedBox(height: 8),
          const Text(
            'This app uses only free newsdata.io features: latest /news, '
            'category filtering, keyword search, and pagination.\n\n'
            'Paid-only features (sentiment, AI fields, the /archive endpoint, '
            'and advanced query operators) are intentionally left out and '
            'degrade gracefully if requested.',
          ),
          const SizedBox(height: 24),
          const Center(
            child: Text(
              'Learn more at newsdata.io',
              style: TextStyle(color: Colors.grey),
            ),
          ),
        ],
      ),
    );
  }
}
