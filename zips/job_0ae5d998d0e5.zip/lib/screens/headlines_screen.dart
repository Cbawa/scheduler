import 'package:flutter/material.dart';

import '../models/article.dart';
import '../services/news_service.dart';
import '../widgets/article_card.dart';

/// Category options available on the free plan.
const _categories = <String, String>{
  'top': 'Top',
  'world': 'World',
  'business': 'Business',
  'technology': 'Technology',
  'sports': 'Sports',
  'science': 'Science',
  'health': 'Health',
  'entertainment': 'Entertainment',
};

class HeadlinesScreen extends StatefulWidget {
  const HeadlinesScreen({super.key});

  @override
  State<HeadlinesScreen> createState() => _HeadlinesScreenState();
}

class _HeadlinesScreenState extends State<HeadlinesScreen> {
  final NewsService _service = NewsService();
  final ScrollController _scroll = ScrollController();

  final List<Article> _articles = [];
  String _category = 'top';
  String? _nextPage;
  bool _loading = false;
  bool _loadingMore = false;
  String? _error;

  @override
  void initState() {
    super.initState();
    _scroll.addListener(_onScroll);
    _load(reset: true);
  }

  @override
  void dispose() {
    _scroll.dispose();
    _service.dispose();
    super.dispose();
  }

  void _onScroll() {
    if (_scroll.position.pixels >=
            _scroll.position.maxScrollExtent - 400 &&
        !_loadingMore &&
        _nextPage != null) {
      _loadMore();
    }
  }

  Future<void> _load({required bool reset}) async {
    setState(() {
      _loading = true;
      _error = null;
      if (reset) {
        _articles.clear();
        _nextPage = null;
      }
    });

    try {
      final page = await _service.fetchNews(category: _category);
      if (!mounted) return;
      setState(() {
        _articles
          ..clear()
          ..addAll(page.articles);
        _nextPage = page.nextPage;
      });
    } on NewsApiException catch (e) {
      if (mounted) setState(() => _error = e.message);
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  Future<void> _loadMore() async {
    setState(() => _loadingMore = true);
    try {
      final page = await _service.fetchNews(
        category: _category,
        page: _nextPage,
      );
      if (!mounted) return;
      setState(() {
        _articles.addAll(page.articles);
        _nextPage = page.nextPage;
      });
    } on NewsApiException catch (e) {
      // Pagination beyond the free limit can return 422 — stop quietly.
      if (mounted) {
        _nextPage = null;
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text(e.message)),
        );
      }
    } finally {
      if (mounted) setState(() => _loadingMore = false);
    }
  }

  void _selectCategory(String key) {
    if (key == _category) return;
    setState(() => _category = key);
    _load(reset: true);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Headlines'),
        bottom: PreferredSize(
          preferredSize: const Size.fromHeight(52),
          child: SizedBox(
            height: 52,
            child: ListView(
              scrollDirection: Axis.horizontal,
              padding: const EdgeInsets.symmetric(horizontal: 12),
              children: _categories.entries.map((e) {
                final selected = e.key == _category;
                return Padding(
                  padding: const EdgeInsets.symmetric(
                      horizontal: 4, vertical: 8),
                  child: ChoiceChip(
                    label: Text(e.value),
                    selected: selected,
                    onSelected: (_) => _selectCategory(e.key),
                  ),
                );
              }).toList(),
            ),
          ),
        ),
      ),
      body: RefreshIndicator(
        onRefresh: () => _load(reset: true),
        child: _buildBody(),
      ),
    );
  }

  Widget _buildBody() {
    if (_loading && _articles.isEmpty) {
      return const Center(child: CircularProgressIndicator());
    }
    if (_error != null && _articles.isEmpty) {
      return _MessageView(
        icon: Icons.error_outline,
        message: _error!,
        onRetry: () => _load(reset: true),
      );
    }
    if (_articles.isEmpty) {
      return const _MessageView(
        icon: Icons.inbox_outlined,
        message: 'No articles found for this category.',
      );
    }
    return ListView.builder(
      controller: _scroll,
      physics: const AlwaysScrollableScrollPhysics(),
      itemCount: _articles.length + (_nextPage != null ? 1 : 0),
      itemBuilder: (context, i) {
        if (i >= _articles.length) {
          return const Padding(
            padding: EdgeInsets.all(16),
            child: Center(child: CircularProgressIndicator()),
          );
        }
        return ArticleCard(article: _articles[i]);
      },
    );
  }
}

class _MessageView extends StatelessWidget {
  final IconData icon;
  final String message;
  final VoidCallback? onRetry;

  const _MessageView({
    required this.icon,
    required this.message,
    this.onRetry,
  });

  @override
  Widget build(BuildContext context) {
    return ListView(
      children: [
        const SizedBox(height: 120),
        Icon(icon, size: 56, color: Colors.grey),
        const SizedBox(height: 16),
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 32),
          child: Text(
            message,
            textAlign: TextAlign.center,
            style: const TextStyle(fontSize: 16),
          ),
        ),
        if (onRetry != null) ...[
          const SizedBox(height: 16),
          Center(
            child: FilledButton.tonal(
              onPressed: onRetry,
              child: const Text('Retry'),
            ),
          ),
        ],
      ],
    );
  }
}
