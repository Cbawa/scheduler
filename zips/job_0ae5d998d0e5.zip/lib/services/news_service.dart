import 'dart:convert';

import 'package:http/http.dart' as http;

import '../models/article.dart';

/// Thrown for any handled API condition so the UI can show a friendly message.
class NewsApiException implements Exception {
  final String message;
  const NewsApiException(this.message);

  @override
  String toString() => message;
}

/// A page of results plus the pagination token returned by newsdata.io.
class NewsPage {
  final List<Article> articles;
  final String? nextPage;
  const NewsPage({required this.articles, this.nextPage});
}

/// A thin REST client for the newsdata.io `/news` endpoint (free tier).
class NewsService {
  NewsService({http.Client? client}) : _client = client ?? http.Client();

  final http.Client _client;

  static const String _baseUrl = 'https://newsdata.io/api/1';

  /// The API key is read from the NEWSDATA_API_KEY environment variable,
  /// injected at build time via --dart-define. It is never hardcoded.
  static const String apiKey =
      String.fromEnvironment('NEWSDATA_API_KEY', defaultValue: '');

  static bool get hasApiKey => apiKey.isNotEmpty;

  /// Fetch the latest news. All parameters here are available on the free plan.
  ///
  /// - [category]: a single newsdata.io category (e.g. 'technology').
  /// - [query]: free-text keyword search (`q`).
  /// - [page]: the `nextPage` token from a previous response.
  Future<NewsPage> fetchNews({
    String? category,
    String? query,
    String language = 'en',
    String? page,
  }) async {
    if (!hasApiKey) {
      throw const NewsApiException(
        'No API key found. Run with:\n'
        'flutter run --dart-define=NEWSDATA_API_KEY=your_key',
      );
    }

    final params = <String, String>{
      'apikey': apiKey,
      'language': language,
    };
    if (category != null && category.isNotEmpty && category != 'top') {
      params['category'] = category;
    }
    if (query != null && query.trim().isNotEmpty) {
      params['q'] = query.trim();
    }
    if (page != null && page.isNotEmpty) {
      params['page'] = page;
    }

    final uri = Uri.parse('$_baseUrl/news').replace(queryParameters: params);

    http.Response res;
    try {
      res = await _client
          .get(uri)
          .timeout(const Duration(seconds: 20));
    } catch (_) {
      throw const NewsApiException(
        'Network error. Please check your connection and try again.',
      );
    }

    return _parse(res);
  }

  NewsPage _parse(http.Response res) {
    // Handle the well-known status codes without crashing.
    switch (res.statusCode) {
      case 200:
        break;
      case 401:
        throw const NewsApiException(
          'Invalid API key (401). Double-check your NEWSDATA_API_KEY.',
        );
      case 429:
        throw const NewsApiException(
          'Rate limit reached (429). Please wait a moment and try again.',
        );
      case 403:
      case 422:
        // Often a paid-only feature on the free plan. Degrade gracefully.
        throw const NewsApiException(
          'This request needs a paid newsdata.io plan. '
          'Showing only free-tier features.',
        );
      default:
        throw NewsApiException(
          'Unexpected error (${res.statusCode}). Please try again later.',
        );
    }

    Map<String, dynamic> body;
    try {
      body = jsonDecode(res.body) as Map<String, dynamic>;
    } catch (_) {
      throw const NewsApiException('Could not read the API response.');
    }

    if (body['status'] == 'error') {
      final msg = (body['results'] is Map &&
              (body['results'] as Map)['message'] != null)
          ? (body['results'] as Map)['message'].toString()
          : 'The API returned an error.';
      throw NewsApiException(msg);
    }

    final results = (body['results'] as List?) ?? const [];
    final articles = results
        .whereType<Map<String, dynamic>>()
        .map(Article.fromJson)
        .toList();

    return NewsPage(
      articles: articles,
      nextPage: body['nextPage'] as String?,
    );
  }

  void dispose() => _client.close();
}
