/// A single news article mapped from the newsdata.io `/news` response.
///
/// Only free-tier fields are used. Paid-only fields such as `sentiment`,
/// `ai_tag`, `ai_summary`, etc. are intentionally ignored.
class Article {
  final String title;
  final String? link;
  final String? description;
  final String? imageUrl;
  final String? sourceId;
  final String? pubDate;
  final List<String> categories;

  const Article({
    required this.title,
    this.link,
    this.description,
    this.imageUrl,
    this.sourceId,
    this.pubDate,
    this.categories = const [],
  });

  factory Article.fromJson(Map<String, dynamic> json) {
    return Article(
      title: (json['title'] as String?)?.trim().isNotEmpty == true
          ? json['title'] as String
          : 'Untitled',
      link: json['link'] as String?,
      description: json['description'] as String?,
      imageUrl: json['image_url'] as String?,
      sourceId: json['source_id'] as String?,
      pubDate: json['pubDate'] as String?,
      categories: (json['category'] as List?)
              ?.map((e) => e.toString())
              .toList() ??
          const [],
    );
  }
}
