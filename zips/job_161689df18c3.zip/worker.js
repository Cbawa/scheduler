// Cloudflare Worker entry point. Shares its core logic with the Express server.
import { buildFeedResponse, indexPage } from "./src/feed.js";

export default {
  async fetch(request, env) {
    const url = new URL(request.url);
    const apiKey = env.NEWSDATA_API_KEY;
    const paid = env.ENABLE_PAID === "1";
    const siteUrl = url.origin;

    if (request.method !== "GET") {
      return new Response("Method not allowed", { status: 405 });
    }

    if (url.pathname === "/" || url.pathname === "") {
      return new Response(indexPage({ siteUrl, paid }), {
        headers: { "Content-Type": "text/html; charset=utf-8" },
      });
    }

    if (url.pathname === "/healthz") {
      return new Response("ok", { headers: { "Content-Type": "text/plain" } });
    }

    if (url.pathname === "/feed.xml" || url.pathname === "/feed") {
      if (!apiKey) {
        return new Response("NEWSDATA_API_KEY is not configured for this Worker.", {
          status: 500,
        });
      }
      const query = Object.fromEntries(url.searchParams.entries());
      const result = await buildFeedResponse({ query, apiKey, paid, siteUrl });
      return new Response(result.body, { status: result.status, headers: result.headers });
    }

    return new Response("Not found", { status: 404 });
  },
};
