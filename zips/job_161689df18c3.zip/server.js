// Express entry point. Shares its core logic with the Cloudflare Worker in src/.
import express from "express";
import { buildFeedResponse, indexPage } from "./src/feed.js";

const PORT = process.env.PORT || 3000;
const API_KEY = process.env.NEWSDATA_API_KEY;
const PAID = process.env.ENABLE_PAID === "1";

if (!API_KEY) {
  console.error(
    "Error: NEWSDATA_API_KEY is not set.\n" +
      "Get a free key at https://newsdata.io and export it before starting:\n" +
      "  export NEWSDATA_API_KEY=your_key_here"
  );
  process.exit(1);
}

const app = express();

function siteUrl(req) {
  const proto = req.headers["x-forwarded-proto"] || req.protocol;
  return `${proto}://${req.get("host")}`;
}

app.get("/", (req, res) => {
  res.type("html").send(indexPage({ siteUrl: siteUrl(req), paid: PAID }));
});

app.get(["/feed.xml", "/feed"], async (req, res) => {
  const result = await buildFeedResponse({
    query: req.query,
    apiKey: API_KEY,
    paid: PAID,
    siteUrl: siteUrl(req),
  });
  res.status(result.status).set(result.headers).send(result.body);
});

app.get("/healthz", (req, res) => res.type("text").send("ok"));

app.listen(PORT, () => {
  console.log(`news-rss-generator listening on http://localhost:${PORT}`);
  console.log(`Paid enrichment params: ${PAID ? "enabled" : "disabled (free tier)"}`);
});
