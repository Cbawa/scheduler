// Thin client for the newsdata.io news API (https://newsdata.io).
// Uses the free-tier /1/latest endpoint and paginates with the nextPage cursor.

const BASE_URL = "https://newsdata.io/api/1";

// Query params that only work on a paid newsdata.io plan. Sending any of these on a
// free key fails the whole request, so they are stripped unless paid mode is on.
const PAID_QUERY_PARAMS = [
  "sentiment",
  "tag",
  "timeframe",
  "from_date",
  "to_date",
  "full_content",
];

export class NewsdataError extends Error {
  constructor(message, status) {
    super(message);
    this.name = "NewsdataError";
    this.status = status;
  }
}

function buildUrl(params, apiKey) {
  const url = new URL(`${BASE_URL}/latest`);
  url.searchParams.set("apikey", apiKey);
  for (const [key, value] of Object.entries(params)) {
    if (value !== undefined && value !== null && value !== "") {
      url.searchParams.set(key, String(value));
    }
  }
  return url;
}

async function requestOnce(params, apiKey) {
  const url = buildUrl(params, apiKey);
  let res;
  try {
    res = await fetch(url, { headers: { Accept: "application/json" } });
  } catch (err) {
    throw new NewsdataError(`Network error contacting newsdata.io: ${err.message}`, 0);
  }

  let body = {};
  try {
    body = await res.json();
  } catch {
    body = {};
  }

  if (!res.ok) {
    const raw = body?.results?.message || body?.message || `HTTP ${res.status}`;
    const msg = typeof raw === "string" ? raw : JSON.stringify(raw);
    throw new NewsdataError(msg, res.status);
  }
  return body;
}

// Fetch up to `maxArticles` articles, following nextPage until exhausted.
export async function fetchArticles({ apiKey, query = {}, paid = false, maxArticles = 20 }) {
  if (!apiKey) {
    throw new NewsdataError("Missing NEWSDATA_API_KEY", 401);
  }

  const base = { ...query };
  let usePaid = paid;
  if (!usePaid) {
    for (const p of PAID_QUERY_PARAMS) delete base[p];
  }

  const articles = [];
  let page = null;

  while (articles.length < maxArticles) {
    const params = { ...base };
    if (page) params.page = page;

    let data;
    try {
      data = await requestOnce(params, apiKey);
    } catch (err) {
      // A paid query param slipped through on a free key — retry once without them.
      if (usePaid && (err.status === 403 || err.status === 422)) {
        usePaid = false;
        for (const p of PAID_QUERY_PARAMS) delete base[p];
        page = null;
        continue;
      }
      throw err;
    }

    const results = Array.isArray(data.results) ? data.results : [];
    for (const article of results) {
      articles.push(article);
      if (articles.length >= maxArticles) break;
    }

    page = data.nextPage || null;
    if (!page) break;
  }

  return articles;
}
