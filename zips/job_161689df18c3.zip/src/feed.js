// Shared core: pick query params, fetch articles, and render an RSS 2.0 feed.
// Imported by both the Express server (server.js) and the Worker (worker.js).

import { fetchArticles, NewsdataError } from "./newsdata.js";

// Incoming query params forwarded to newsdata.io. Paid-only params are kept separate
// and only forwarded when paid mode is enabled.
const FREE_PARAMS = [
  "q",
  "qInTitle",
  "qInMeta",
  "country",
  "category",
  "language",
  "domain",
  "domainurl",
  "prioritydomain",
  "image",
  "video",
  "removeduplicate",
];
const PAID_PARAMS = ["sentiment", "tag", "timeframe", "from_date", "to_date", "full_content"];

export function pickQuery(raw = {}, paid = false) {
  const allowed = paid ? [...FREE_PARAMS, ...PAID_PARAMS] : FREE_PARAMS;
  const out = {};
  for (const key of allowed) {
    const value = raw[key];
    if (value !== undefined && value !== null && String(value).length > 0) {
      out[key] = String(value);
    }
  }
  return out;
}

function escapeXml(value) {
  return String(value ?? "")
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&apos;");
}

function escapeForHtml(value) {
  return String(value ?? "")
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;");
}

function cdata(value) {
  return `<![CDATA[${String(value ?? "").replace(/]]>/g, "]]]]><![CDATA[>")}]]>`;
}

function toRfc822(value) {
  if (!value) return null;
  // newsdata.io returns UTC timestamps like "2024-05-01 13:45:00".
  const str = String(value);
  const iso = str.includes("T") ? str : str.replace(" ", "T") + "Z";
  const date = new Date(iso);
  return Number.isNaN(date.getTime()) ? null : date.toUTCString();
}

function asArray(value) {
  if (Array.isArray(value)) return value.filter(Boolean);
  if (value === undefined || value === null || value === "") return [];
  return [value];
}

function feedTitle(query) {
  const parts = [];
  if (query.q) parts.push(`"${query.q}"`);
  if (query.category) parts.push(query.category);
  if (query.country) parts.push(String(query.country).toUpperCase());
  return parts.length ? `NewsData.io feed: ${parts.join(" \u00b7 ")}` : "NewsData.io latest headlines";
}

function renderItem(article) {
  const link = article.link || "";
  const title = article.title || "(untitled)";
  const guid = article.article_id || link || title;
  const pub = toRfc822(article.pubDate);
  const keywords = asArray(article.keywords);
  const aiTags = asArray(article.ai_tag);
  const creators = asArray(article.creator);
  const sentiment = typeof article.sentiment === "string" ? article.sentiment : null;
  const aiSummary = typeof article.ai_summary === "string" ? article.ai_summary : null;

  const descParts = [];
  if (article.description) descParts.push(`<p>${escapeForHtml(article.description)}</p>`);
  if (aiSummary) descParts.push(`<p><strong>AI summary:</strong> ${escapeForHtml(aiSummary)}</p>`);
  if (sentiment) descParts.push(`<p><strong>Sentiment:</strong> ${escapeForHtml(sentiment)}</p>`);
  if (keywords.length) {
    descParts.push(`<p><strong>Keywords:</strong> ${keywords.map(escapeForHtml).join(", ")}</p>`);
  }
  if (link) descParts.push(`<p><a href="${escapeForHtml(link)}">Read full article</a></p>`);
  if (!descParts.length) descParts.push("<p>(no description)</p>");

  const categories = [...new Set([...keywords, ...aiTags])]
    .map((c) => `      <category>${escapeXml(c)}</category>`)
    .join("\n");

  const lines = [];
  lines.push("    <item>");
  lines.push(`      <title>${escapeXml(title)}</title>`);
  if (link) lines.push(`      <link>${escapeXml(link)}</link>`);
  lines.push(`      <guid isPermaLink="false">${escapeXml(guid)}</guid>`);
  if (pub) lines.push(`      <pubDate>${pub}</pubDate>`);
  for (const creator of creators) lines.push(`      <dc:creator>${escapeXml(creator)}</dc:creator>`);
  if (article.source_name || article.source_id) {
    const srcUrl = article.source_url || link || "";
    lines.push(
      `      <source url="${escapeXml(srcUrl)}">${escapeXml(article.source_name || article.source_id)}</source>`
    );
  }
  if (article.image_url) {
    lines.push(`      <media:content url="${escapeXml(article.image_url)}" medium="image" />`);
  }
  if (categories) lines.push(categories);
  lines.push(`      <description>${cdata(descParts.join("\n"))}</description>`);
  lines.push("    </item>");
  return lines.join("\n");
}

export function buildRss({ articles, query, siteUrl = "" }) {
  const now = new Date().toUTCString();
  const title = feedTitle(query);
  const selfUrl = `${siteUrl}/feed.xml`;
  const items = articles.map(renderItem).join("\n");
  const desc = articles.length
    ? "Latest headlines from the newsdata.io news API"
    : "Latest headlines from the newsdata.io news API (no matching articles right now)";

  return [
    '<?xml version="1.0" encoding="UTF-8"?>',
    '<rss version="2.0" xmlns:dc="http://purl.org/dc/elements/1.1/" xmlns:atom="http://www.w3.org/2005/Atom" xmlns:media="http://search.yahoo.com/mrss/">',
    "  <channel>",
    `    <title>${escapeXml(title)}</title>`,
    `    <link>${escapeXml(siteUrl || "")}</link>`,
    `    <atom:link href="${escapeXml(selfUrl)}" rel="self" type="application/rss+xml" />`,
    `    <description>${escapeXml(desc)}</description>`,
    "    <generator>news-rss-generator</generator>",
    `    <lastBuildDate>${now}</lastBuildDate>`,
    "    <ttl>30</ttl>",
    items,
    "  </channel>",
    "</rss>",
  ]
    .filter((line) => line !== "")
    .join("\n");
}

export async function buildFeedResponse({ query, apiKey, paid = false, siteUrl = "" }) {
  const feedQuery = pickQuery(query, paid);
  try {
    const articles = await fetchArticles({ apiKey, query: feedQuery, paid, maxArticles: 20 });
    const xml = buildRss({ articles, query: feedQuery, siteUrl });
    return {
      status: 200,
      headers: {
        "Content-Type": "application/rss+xml; charset=utf-8",
        "Cache-Control": "public, max-age=300",
      },
      body: xml,
    };
  } catch (err) {
    const code = err instanceof NewsdataError ? err.status : 0;
    const status = code === 401 ? 401 : code === 429 ? 429 : 502;
    const message =
      status === 401
        ? "Invalid or missing newsdata.io API key."
        : status === 429
        ? "newsdata.io rate limit reached. Try again shortly."
        : `Could not fetch news: ${err.message}`;
    const xml = [
      '<?xml version="1.0" encoding="UTF-8"?>',
      '<rss version="2.0"><channel>',
      "  <title>news-rss-generator error</title>",
      `  <description>${escapeXml(message)}</description>`,
      "</channel></rss>",
    ].join("\n");
    return {
      status,
      headers: { "Content-Type": "application/rss+xml; charset=utf-8" },
      body: xml,
    };
  }
}

export function indexPage({ siteUrl = "", paid = false } = {}) {
  const base = siteUrl || "";
  const example = (qs) => `${base}/feed.xml?${qs}`;
  return `<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1" />
<title>news-rss-generator</title>
<style>
  body { font: 16px/1.5 system-ui, sans-serif; max-width: 760px; margin: 2rem auto; padding: 0 1rem; color: #1b1b1b; }
  code, pre { background: #f4f4f5; border-radius: 4px; }
  code { padding: 0.1rem 0.3rem; }
  input, select, button { font: inherit; padding: 0.4rem; margin: 0.2rem 0; }
  .row { display: flex; gap: 0.5rem; flex-wrap: wrap; align-items: center; }
  .bar { display: flex; height: 18px; border-radius: 4px; overflow: hidden; max-width: 320px; }
  .bar span { display: block; }
  .pos { background: #4caf50; } .neu { background: #bdbdbd; } .neg { background: #e53935; }
  .muted { color: #666; font-size: 0.85rem; }
  a { color: #0b62c4; }
</style>
</head>
<body>
  <h1>news-rss-generator</h1>
  <p>Turn a NewsData.io query into an RSS 2.0 feed. Headlines come from the
     <a href="https://newsdata.io">newsdata.io</a> news API.</p>

  <h2>Build a feed</h2>
  <form onsubmit="event.preventDefault(); go();">
    <div class="row">
      <input id="q" placeholder="keywords (e.g. climate)" />
      <input id="country" placeholder="country (e.g. us)" size="10" />
      <input id="language" placeholder="language (e.g. en)" size="10" />
    </div>
    <div class="row">
      <select id="category">
        <option value="">any category</option>
        <option>business</option><option>technology</option><option>sports</option>
        <option>science</option><option>health</option><option>world</option>
      </select>
      <button type="submit">Get feed URL</button>
    </div>
  </form>
  <p>Feed URL: <code id="out">${escapeForHtml(base)}/feed.xml</code></p>

  <h2>Examples</h2>
  <ul>
    <li><a href="${example("q=technology&language=en")}">Technology, English</a></li>
    <li><a href="${example("country=us&category=business")}">US business</a></li>
    <li><a href="${example("q=climate%20change")}">Climate change</a></li>
  </ul>

  <h2>Enrichment fields</h2>
  <p>Each feed item carries the article's <code>keywords</code> as
     <code>&lt;category&gt;</code> tags, which are available on the free plan. When the
     API key has access, per-article <code>sentiment</code>, <code>ai_tag</code> and
     <code>ai_summary</code> are added to the item too.</p>
  <div class="bar" aria-hidden="true">
    <span class="pos" style="width:55%"></span>
    <span class="neu" style="width:30%"></span>
    <span class="neg" style="width:15%"></span>
  </div>
  <p class="muted">Sample sentiment split \u2014 live sentiment requires a paid newsdata.io
     plan (${paid ? "paid mode is on" : "set ENABLE_PAID=1"}).</p>

<script>
  function go() {
    var params = new URLSearchParams();
    ["q", "country", "language", "category"].forEach(function (field) {
      var el = document.getElementById(field);
      if (el && el.value.trim()) params.set(field, el.value.trim());
    });
    var qs = params.toString();
    var url = ${JSON.stringify(base)} + "/feed.xml" + (qs ? "?" + qs : "");
    document.getElementById("out").textContent = url;
  }
</script>
</body>
</html>`;
}
