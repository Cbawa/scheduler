# news-rss-generator

Generate RSS 2.0 feeds from NewsData.io news queries. Run it as a small Express
server or deploy it as a Cloudflare Worker, then point any RSS reader at a feed URL
to follow a topic, country, or keyword search.

Headlines come from the newsdata.io news API (https://newsdata.io) — grab a free
API key to run it.

## What it does

- Turns a query (keywords, country, language, category) into a valid RSS 2.0 feed.
- Includes each article's keywords as `<category>` tags so readers can filter.
- When the API key has access, adds per-article `sentiment`, `ai_tag`, and
  `ai_summary` to the item description.
- Follows the `nextPage` cursor to gather a couple of pages per feed.
- Runs unchanged on Node (Express) or Cloudflare Workers from the same `src/` core.

## Requirements

- Node.js 18 or newer (it uses the built-in `fetch`).
- A NewsData.io API key. The free plan is enough for the default feeds.

## Setup

```
git clone <your fork>
cd news-rss-generator
npm install
export NEWSDATA_API_KEY=your_key_here
npm start
```

The server listens on port 3000 by default (override with `PORT`). Open
http://localhost:3000 for a small page that builds feed URLs, or request a feed
directly:

```
curl "http://localhost:3000/feed.xml?q=technology&language=en"
```

### Sample output

```
<?xml version="1.0" encoding="UTF-8"?>
<rss version="2.0" xmlns:dc="http://purl.org/dc/elements/1.1/" ...>
  <channel>
    <title>NewsData.io feed: "technology"</title>
    <link>http://localhost:3000</link>
    <description>Latest headlines from the newsdata.io news API</description>
    <item>
      <title>New chip pushes on-device models further</title>
      <link>https://example.com/article</link>
      <guid isPermaLink="false">abc123</guid>
      <pubDate>Wed, 11 Jun 2025 09:30:00 GMT</pubDate>
      <category>semiconductors</category>
      <category>ai</category>
      <description><![CDATA[<p>Lead paragraph...</p><p><strong>Keywords:</strong> semiconductors, ai</p>]]></description>
    </item>
  </channel>
</rss>
```

## Feed parameters

Pass these as query-string parameters on `/feed.xml`:

| Param | Example | Notes |
| --- | --- | --- |
| `q` | `q=climate` | Keyword search |
| `country` | `country=us` | Two-letter code |
| `language` | `language=en` | Two-letter code |
| `category` | `category=business` | Single category |

Empty parameters are ignored, and an empty query returns the latest headlines.

## Optional: paid NewsData.io fields

The `sentiment`, `ai_tag`, `ai_summary` (and full `content`) fields require a paid
newsdata.io plan. They are read straight from the response when present, so on a free
key the feed simply omits them. A few query filters (sentiment, tag, timeframe, date
ranges) also require a paid plan; they are stripped from requests unless you opt in:

```
export ENABLE_PAID=1
```

If a paid filter is rejected, the request is retried once without it so you still get
free results.

## Deploy as a Cloudflare Worker

The Worker entry point is `worker.js`; it shares the same code under `src/`.

```
npm install
npx wrangler secret put NEWSDATA_API_KEY
npx wrangler deploy
```

To enable paid fields on the Worker, add `ENABLE_PAID = "1"` to the `[vars]` block in
`wrangler.toml`.

## Endpoints

- `GET /` — HTML page to build feed URLs.
- `GET /feed.xml` — the RSS feed (also reachable at `/feed`).
- `GET /healthz` — readiness check.

## License

MIT
