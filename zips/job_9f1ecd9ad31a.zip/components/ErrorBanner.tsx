import { NewsDataError } from "@/lib/newsdata";

export default function ErrorBanner({ error }: { error: unknown }) {
  let message = "Something went wrong while loading the news.";
  let hint: string | null = null;

  if (error instanceof NewsDataError) {
    message = error.message;
    if (error.status === 0 || error.status === 401) {
      hint = "Set a valid NEWSDATA_API_KEY in .env.local. Get a free key at newsdata.io.";
    } else if (error.status === 429) {
      hint = "You have hit the free-plan rate limit. Wait a moment and refresh.";
    } else if (error.status === 403 || error.status === 422) {
      hint = "This feature requires a paid newsdata.io plan.";
    }
  }

  return (
    <div className="error-banner" role="alert">
      <strong>{message}</strong>
      {hint && <p>{hint}</p>}
    </div>
  );
}
