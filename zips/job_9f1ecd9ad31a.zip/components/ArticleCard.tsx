import { Article } from "@/lib/newsdata";

function formatDate(pubDate: string | null): string {
  if (!pubDate) return "";
  // newsdata.io returns dates like "2024-01-31 12:34:56" (UTC).
  const d = new Date(pubDate.replace(" ", "T") + "Z");
  if (isNaN(d.getTime())) return pubDate;
  return d.toLocaleDateString("en-US", {
    year: "numeric",
    month: "short",
    day: "numeric",
  });
}

export default function ArticleCard({ article }: { article: Article }) {
  return (
    <article className="card">
      {article.image_url ? (
        // Using a plain <img> keeps setup zero-config (no remote image domains).
        // eslint-disable-next-line @next/next/no-img-element
        <img className="card-img" src={article.image_url} alt={article.title} loading="lazy" />
      ) : (
        <div className="card-img card-img--placeholder">newsdata.io</div>
      )}
      <div className="card-body">
        <span className="card-source">{article.source_id}</span>
        <h2 className="card-title">
          <a href={article.link} target="_blank" rel="noopener noreferrer">
            {article.title}
          </a>
        </h2>
        {article.description && <p className="card-desc">{article.description}</p>}
        {article.pubDate && <time className="card-date">{formatDate(article.pubDate)}</time>}
      </div>
    </article>
  );
}
