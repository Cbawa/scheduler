import Link from "next/link";
import { CATEGORIES } from "@/lib/newsdata";

export default function Header() {
  return (
    <header className="site-header">
      <div className="container header-inner">
        <Link href="/" className="brand">
          📰 NewsPortal
        </Link>
        <nav className="nav">
          {CATEGORIES.map((c) => (
            <Link key={c.slug} href={`/category/${c.slug}`} className="nav-link">
              {c.label}
            </Link>
          ))}
        </nav>
      </div>
    </header>
  );
}
