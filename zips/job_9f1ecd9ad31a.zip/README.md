# Next.js News Portal

A polished **Next.js 14** (App Router) + **TypeScript** news portal that renders
live headlines on the server and exposes **dynamic category routes**. All data
comes from the [newsdata.io](https://newsdata.io) news API.

> Built as an open showcase of how easy it is to build a real product on top of
> the newsdata.io REST API — and it works out of the box on the **FREE plan**.

## Features

- ⚡ **Server-side rendering** of articles via React Server Components (`fetch` with revalidation).
- 🗂️ **Dynamic category routes** at `/category/[category]` (Top, World, Business, Technology, Science, Health, Sports, Entertainment, Politics).
- 🔎 Keyword **search** on the homepage (`/?q=...`).
- 📄 **Pagination** using the `nextPage` token returned by the API.
- 🛟 Graceful handling of missing keys, invalid keys (401), rate limits (429), paid-only features (403/422) and empty result sets — the app never crashes.
- 🎨 Zero-dependency styling (plain CSS), responsive card grid.

## Tech stack

- Next.js 14 (App Router)
- TypeScript
- React 18 Server Components

## Getting started

### 1. Get a free API key

Register at [newsdata.io](https://newsdata.io/register) and copy your API key.

### 2. Configure the environment

The key is read from the `NEWSDATA_API_KEY` environment variable. **It is never
hardcoded.**

```bash
cp .env.example .env.local
# then edit .env.local and set NEWSDATA_API_KEY=...
```

You can also export it in your shell instead:

```bash
export NEWSDATA_API_KEY="your_key_here"
```

### 3. Install and run

```bash
npm install
npm run dev
```

Open [http://localhost:3000](http://localhost:3000).

### 4. Production build

```bash
npm run build
npm start
```

## Project structure

```
app/
  layout.tsx                  # Root layout, header + footer
  page.tsx                    # Homepage: latest headlines + search
  globals.css                 # Styles
  category/[category]/page.tsx# Dynamic category pages (SSR)
components/
  Header.tsx                  # Brand + category navigation
  ArticleCard.tsx             # Single article card
  ErrorBanner.tsx             # Friendly error / empty states
lib/
  newsdata.ts                 # Typed newsdata.io client + helpers
```

## Free plan vs. paid plan

This project is designed to run entirely on the **free** newsdata.io tier. It only
uses the `/news` endpoint with free parameters: `q`, `country`, `language`,
`category` and `page` (pagination via `nextPage`).

The following features are **paid-only** and are intentionally **not** used in the
core flow:

- Sentiment analysis
- AI fields (`ai_tag`, `ai_region`, `ai_org`, `ai_summary`)
- The historical `/archive` endpoint and long date ranges
- Advanced full-text query operators

If the API ever responds with a `403`/`422` "upgrade your plan" error, the app
detects it and shows a friendly message instead of breaking.

## How the API is called

See [`lib/newsdata.ts`](lib/newsdata.ts). In short:

```
GET https://newsdata.io/api/1/news?apikey=YOUR_KEY&language=en&category=technology
```

Responses look like:

```json
{
  "status": "success",
  "totalResults": 1234,
  "results": [
    { "title": "...", "link": "...", "description": "...", "pubDate": "...", "source_id": "..." }
  ],
  "nextPage": "token"
}
```

## License

MIT — free to use, fork and learn from.
