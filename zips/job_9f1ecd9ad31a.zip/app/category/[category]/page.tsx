import { fetchNews, buildHref, CATEGORIES, CATEGORY_SLUGS } from "@/lib/newsdata";
import ArticleCard from "@/components/ArticleCard";
import ErrorBanner from "@/components/ErrorBanner";
import { notFound } from "next/navigation";
import type { Metadata } from "next";

export const revalidate = 600;

export function generateStaticParams() {
  return CATEGORY_SLUGS.map((slug) => ({ category: slug }));
}

export function generateMetadata({
  params,
}: {
  params: { category: string };
}): Metadata {
  const cat = CATEGORIES.find((c) => c.slug === params.category);
  const label = cat?.label ?? params.category;
  return {
    title: `${label} News — newsdata.io portal`,
    description: `Latest ${label} headlines powered by the newsdata.io news API.`,
  };
}

interface CategoryPageProps {
  params: { category: string };
  searchParams: { page?: string };
}

export default async function CategoryPage({ params, searchParams }: CategoryPageProps) {
  const cat = CATEGORIES.find((c) => c.slug === params.category);
  if (!cat) {
    notFound();
  }

  const page = searchParams.page;
  let content: React.ReactNode;

  try {
    const data = await fetchNews({
      category: cat.slug,
      language: "en",
      page,
    });

    if (data.results.length === 0) {
      content = <p className="message">No {cat.label.toLowerCase()} articles available right now.</p>;
    } else {
      content = (
        <>
          <div className="grid">
            {data.results.map((a) => (
              <ArticleCard key={a.article_id || a.link} article={a} />
            ))}
          </div>
          {data.nextPage && (
            <div className="pagination">
              <a
                className="btn"
                href={buildHref(`/category/${cat.slug}`, { page: data.nextPage })}
              >
                Load more →
              </a>
            </div>
          )}
        </>
      );
    }
  } catch (err) {
    content = <ErrorBanner error={err} />;
  }

  return (
    <section>
      <h1 className="page-title">{cat.label} News</h1>
      {content}
    </section>
  );
}
