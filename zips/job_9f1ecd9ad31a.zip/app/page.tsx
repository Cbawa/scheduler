import { fetchNews, buildHref } from "@/lib/newsdata";
import ArticleCard from "@/components/ArticleCard";
import ErrorBanner from "@/components/ErrorBanner";

export const revalidate = 600;

interface HomeProps {
  searchParams: { q?: string; page?: string };
}

export default async function Home({ searchParams }: HomeProps) {
  const q = (searchParams.q ?? "").trim();
  const page = searchParams.page;

  let content: React.ReactNode;

  try {
    const data = await fetchNews({
      q: q || undefined,
      language: "en",
      page,
    });

    if (data.results.length === 0) {
      content = (
        <p className="message">
          No articles found{q ? ` for “${q}”` : ""}. Try a different search.
        </p>
      );
    } else {
      content = (
        <>
          <div className="grid">
            {data.results.map((a) => (
              <ArticleCard key={a.article_id || a.link} article={a} />
            ))}
          </div>
          {data.nextPage && (
            <div className="pagination">
              <a
                className="btn"
                href={buildHref("/", { q: q || undefined, page: data.nextPage })}
              >
                Load more →
              </a>
            </div>
          )}
        </>
      );
    }
  } catch (err) {
    content = <ErrorBanner error={err} />;
  }

  return (
    <section>
      <h1 className="page-title">{q ? `Search: ${q}` : "Latest Headlines"}</h1>

      <form className="search" action="/" method="get">
        <input
          className="search-input"
          type="text"
          name="q"
          placeholder="Search news…"
          defaultValue={q}
          aria-label="Search news"
        />
        <button className="btn" type="submit">
          Search
        </button>
      </form>

      {content}
    </section>
  );
}
