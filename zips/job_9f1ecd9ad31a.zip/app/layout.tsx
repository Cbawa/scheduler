import type { Metadata } from "next";
import "./globals.css";
import Header from "@/components/Header";

export const metadata: Metadata = {
  title: "Next.js News Portal — powered by newsdata.io",
  description:
    "A Next.js 14 news portal with server-side rendering and dynamic category routes, powered by the newsdata.io news API.",
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body>
        <Header />
        <main className="container main">{children}</main>
        <footer className="site-footer">
          <div className="container">
            Data provided by{" "}
            <a href="https://newsdata.io" target="_blank" rel="noopener noreferrer">
              newsdata.io
            </a>
          </div>
        </footer>
      </body>
    </html>
  );
}
