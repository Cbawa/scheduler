const BASE_URL = "https://newsdata.io/api/1";

export interface Article {
  article_id?: string;
  title: string;
  link: string;
  description: string | null;
  content?: string | null;
  pubDate: string | null;
  image_url: string | null;
  source_id: string;
  category?: string[];
  country?: string[];
  language?: string;
}

export interface NewsResponse {
  status: string;
  totalResults: number;
  results: Article[];
  nextPage: string | null;
}

export interface NewsQuery {
  q?: string;
  country?: string;
  language?: string;
  category?: string;
  page?: string;
}

export interface Category {
  slug: string;
  label: string;
}

// Free-tier categories supported by newsdata.io /news.
export const CATEGORIES: Category[] = [
  { slug: "top", label: "Top" },
  { slug: "world", label: "World" },
  { slug: "business", label: "Business" },
  { slug: "technology", label: "Technology" },
  { slug: "science", label: "Science" },
  { slug: "health", label: "Health" },
  { slug: "sports", label: "Sports" },
  { slug: "entertainment", label: "Entertainment" },
  { slug: "politics", label: "Politics" },
];

export const CATEGORY_SLUGS = CATEGORIES.map((c) => c.slug);

/**
 * Custom error that carries the HTTP status so the UI can react
 * (invalid key, rate limit, paid-only feature, etc.).
 */
export class NewsDataError extends Error {
  status: number;
  constructor(message: string, status: number) {
    super(message);
    this.status = status;
    this.name = "NewsDataError";
  }
}

function getApiKey(): string {
  const key = process.env.NEWSDATA_API_KEY;
  if (!key) {
    throw new NewsDataError(
      "NEWSDATA_API_KEY is not set. Create a .env.local file with your free newsdata.io key.",
      0,
    );
  }
  return key;
}

/**
 * Fetch the latest news from the free /news endpoint.
 * Only free-tier parameters are used (q, country, language, category, page).
 */
export async function fetchNews(query: NewsQuery = {}): Promise<NewsResponse> {
  const apiKey = getApiKey();

  const params = new URLSearchParams({ apikey: apiKey });
  if (query.q) params.set("q", query.q);
  if (query.country) params.set("country", query.country);
  if (query.language) params.set("language", query.language);
  if (query.category) params.set("category", query.category);
  if (query.page) params.set("page", query.page);

  const url = `${BASE_URL}/news?${params.toString()}`;

  let res: Response;
  try {
    // Cache on the server and revalidate every 10 minutes to stay
    // comfortably within the free-plan request budget.
    res = await fetch(url, { next: { revalidate: 600 } });
  } catch {
    throw new NewsDataError("Network error while contacting newsdata.io.", 0);
  }

  if (res.status === 401) {
    throw new NewsDataError("Invalid API key (401). Check your NEWSDATA_API_KEY.", 401);
  }
  if (res.status === 429) {
    throw new NewsDataError(
      "Rate limit reached (429). The free plan has a limited number of requests — please wait and retry.",
      429,
    );
  }
  if (res.status === 403 || res.status === 422) {
    // Typically returned when a paid-only feature/parameter is requested.
    throw new NewsDataError(
      "This request used a feature that is not available on the free newsdata.io plan.",
      res.status,
    );
  }
  if (!res.ok) {
    throw new NewsDataError(`Unexpected response from newsdata.io (${res.status}).`, res.status);
  }

  const data = (await res.json()) as Partial<NewsResponse>;

  return {
    status: data.status ?? "success",
    totalResults: data.totalResults ?? 0,
    results: Array.isArray(data.results) ? data.results : [],
    nextPage: data.nextPage ?? null,
  };
}

/** Build a relative URL with the given (defined) query params. */
export function buildHref(base: string, params: Record<string, string | undefined>): string {
  const sp = new URLSearchParams();
  for (const [key, value] of Object.entries(params)) {
    if (value) sp.set(key, value);
  }
  const qs = sp.toString();
  return qs ? `${base}?${qs}` : base;
}
