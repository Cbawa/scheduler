import { useEffect, useMemo, useState } from 'react'
import { motion } from 'framer-motion'

const CATEGORIES = [
  { id: 'top', label: 'Top' },
  { id: 'technology', label: 'Technology' },
  { id: 'business', label: 'Business' },
  { id: 'science', label: 'Science' },
  { id: 'world', label: 'World' },
  { id: 'health', label: 'Health' },
]

// Shown when there is no API key or no live results. Clearly labeled in the UI as sample.
const SAMPLE_ARTICLES = [
  { article_id: 's1', title: 'City transit pilots a fare-free morning commute', description: 'A three-month trial drops fares before 9am to ease downtown congestion.', source_name: 'Sample News', pubDate: '2026-06-11 07:45:00', link: 'https://newsdata.io', image_url: '', keywords: ['transit', 'cities'], sentiment: 'positive', ai_tag: ['transport'], ai_summary: 'An early-morning fare-free transit pilot aims to cut city traffic.' },
  { article_id: 's2', title: 'Regulators open review of data-portability rules', description: 'The consultation could reshape how platforms hand user data between services.', source_name: 'Sample Wire', pubDate: '2026-06-11 06:30:00', link: 'https://newsdata.io', image_url: '', keywords: ['policy', 'data'], sentiment: 'neutral', ai_tag: ['technology'], ai_summary: 'A regulator begins reviewing data-portability requirements for platforms.' },
  { article_id: 's3', title: 'Coastal towns brace for an active storm season', description: 'Forecasters point to warmer waters as a driver of stronger early-season systems.', source_name: 'Sample Daily', pubDate: '2026-06-10 22:10:00', link: 'https://newsdata.io', image_url: '', keywords: ['weather', 'climate'], sentiment: 'negative', ai_tag: ['environment'], ai_summary: 'Warmer seas raise the odds of a more active storm season for the coast.' },
  { article_id: 's4', title: 'Small studios lead a quiet jobs rebound in games', description: 'Independent teams report steady hiring even as larger publishers stay cautious.', source_name: 'Sample Times', pubDate: '2026-06-10 18:05:00', link: 'https://newsdata.io', image_url: '', keywords: ['games', 'jobs'], sentiment: 'positive', ai_tag: ['business'], ai_summary: 'Independent game studios are hiring while big publishers hold back.' },
  { article_id: 's5', title: 'Researchers map shifts in deep-ocean currents', description: 'New buoy data fills long-standing gaps in models of ocean heat transport.', source_name: 'Sample Journal', pubDate: '2026-06-10 15:40:00', link: 'https://newsdata.io', image_url: '', keywords: ['oceans', 'science'], sentiment: 'neutral', ai_tag: ['science'], ai_summary: 'Fresh buoy data improves models of how oceans move heat.' },
  { article_id: 's6', title: 'Community clinics expand evening hours', description: 'A funding round lets several clinics stay open later for shift workers.', source_name: 'Sample Post', pubDate: '2026-06-10 12:15:00', link: 'https://newsdata.io', image_url: '', keywords: ['health', 'community'], sentiment: 'positive', ai_tag: ['health'], ai_summary: 'New funding extends clinic hours to better serve shift workers.' },
]

function formatDate(value) {
  if (!value) return ''
  const d = new Date(String(value).replace(' ', 'T') + 'Z')
  if (isNaN(d.getTime())) return String(value)
  return d.toLocaleString(undefined, { dateStyle: 'medium', timeStyle: 'short' })
}

function SentimentBadge({ value }) {
  const s = typeof value === 'string' ? value.toLowerCase() : null
  const known = s === 'positive' || s === 'negative' || s === 'neutral'
  const label = known ? s : 'n/a'
  return <span className={'badge sentiment-' + (known ? s : 'unknown')}>sentiment: {label}</span>
}

function ArticleCard({ article, index }) {
  const keywords = Array.isArray(article.keywords) ? article.keywords.slice(0, 4) : []
  const aiTags = Array.isArray(article.ai_tag)
    ? article.ai_tag
    : article.ai_tag
    ? [String(article.ai_tag)]
    : []
  const summary =
    typeof article.ai_summary === 'string' && article.ai_summary.trim() ? article.ai_summary : null
  const [imgOk, setImgOk] = useState(true)

  return (
    <motion.article
      className='card'
      initial={{ opacity: 0, y: 16 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, margin: '-40px' }}
      transition={{ duration: 0.4, delay: Math.min(index * 0.04, 0.3) }}
    >
      {article.image_url && imgOk && (
        <img
          className='card-img'
          src={article.image_url}
          alt=''
          loading='lazy'
          onError={() => setImgOk(false)}
        />
      )}
      <div className='card-body'>
        <div className='card-meta'>
          <span className='source'>{article.source_name || article.source_id || 'Unknown source'}</span>
          <span className='dot'>·</span>
          <span>{formatDate(article.pubDate)}</span>
        </div>
        <h3 className='card-title'>{article.title || 'Untitled'}</h3>
        {article.description && <p className='card-desc'>{article.description}</p>}
        <div className='chips'>
          {keywords.length > 0 ? (
            keywords.map((k) => (
              <span key={k} className='chip'>{k}</span>
            ))
          ) : (
            <span className='chip muted'>no keywords</span>
          )}
        </div>
        {aiTags.length > 0 && (
          <div className='chips'>
            {aiTags.slice(0, 4).map((t) => (
              <span key={t} className='chip ai'>{t}</span>
            ))}
          </div>
        )}
        <div className='card-footer'>
          <SentimentBadge value={article.sentiment} />
          {article.link && (
            <a className='read' href={article.link} target='_blank' rel='noreferrer'>Read</a>
          )}
        </div>
        <p className={'ai-summary' + (summary ? '' : ' muted')}>
          {summary ? summary : 'AI summary not included in this response.'}
        </p>
      </div>
    </motion.article>
  )
}

function SentimentBar({ articles }) {
  const data = useMemo(() => {
    const counts = { positive: 0, neutral: 0, negative: 0 }
    let have = 0
    for (const a of articles) {
      const s = typeof a.sentiment === 'string' ? a.sentiment.toLowerCase() : null
      if (s && counts[s] !== undefined) {
        counts[s] += 1
        have += 1
      }
    }
    if (have === 0) return { counts: { positive: 5, neutral: 8, negative: 3 }, total: 16, sample: true }
    return { counts, total: have, sample: false }
  }, [articles])

  const rows = [
    { key: 'positive', label: 'Positive' },
    { key: 'neutral', label: 'Neutral' },
    { key: 'negative', label: 'Negative' },
  ]

  return (
    <div className='sentiment-card'>
      <h4>Sentiment breakdown</h4>
      {rows.map((r) => {
        const value = data.counts[r.key]
        const pct = data.total ? Math.round((value / data.total) * 100) : 0
        return (
          <div className='bar-row' key={r.key}>
            <span className='bar-label'>{r.label}</span>
            <div className='bar-track'>
              <motion.div
                className={'bar-fill bar-' + r.key}
                initial={{ width: 0 }}
                whileInView={{ width: pct + '%' }}
                viewport={{ once: true }}
                transition={{ duration: 0.6 }}
              />
            </div>
            <span className='bar-value'>{pct}%</span>
          </div>
        )
      })}
      {data.sample && (
        <p className='caption'>Sample distribution — live sentiment requires a paid newsdata.io plan.</p>
      )}
    </div>
  )
}

export default function App() {
  const [articles, setArticles] = useState([])
  const [nextPage, setNextPage] = useState(null)
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState(null)
  const [sampleReason, setSampleReason] = useState(null)
  const [category, setCategory] = useState('top')
  const [query, setQuery] = useState('')
  const [inputValue, setInputValue] = useState('')

  async function fetchPage({ q, cat, page, append }) {
    setLoading(true)
    setError(null)
    try {
      const params = new URLSearchParams()
      if (q) params.set('q', q)
      if (cat) params.set('category', cat)
      if (page) params.set('page', page)
      const res = await fetch('/api/news?' + params.toString())
      const data = await res.json()
      if (!res.ok) throw new Error(data.error || 'Request failed (' + res.status + ')')

      const results = Array.isArray(data.results) ? data.results : []
      if (data.sample) {
        setArticles(SAMPLE_ARTICLES)
        setSampleReason('nokey')
        setNextPage(null)
        return
      }
      if (results.length === 0 && !append) {
        setArticles(SAMPLE_ARTICLES)
        setSampleReason('empty')
        setNextPage(null)
        return
      }
      setSampleReason(null)
      setNextPage(data.nextPage || null)
      setArticles((prev) => (append ? prev.concat(results) : results))
    } catch (e) {
      setError(e.message || 'Something went wrong.')
      if (!append) {
        setArticles(SAMPLE_ARTICLES)
        setSampleReason('error')
        setNextPage(null)
      }
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => {
    fetchPage({ q: '', cat: 'top' })
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [])

  function onSelectCategory(id) {
    setCategory(id)
    fetchPage({ q: query, cat: id })
  }

  function onSubmit(e) {
    e.preventDefault()
    const q = inputValue.trim()
    setQuery(q)
    fetchPage({ q, cat: category })
  }

  const banner =
    sampleReason === 'nokey'
      ? 'Showing sample articles. Add NEWSDATA_API_KEY to your .env to load live headlines from newsdata.io.'
      : sampleReason === 'empty'
      ? 'No live results for this query right now — showing sample articles.'
      : sampleReason === 'error'
      ? 'Could not load live headlines — showing sample articles.'
      : null

  return (
    <div className='page'>
      <header className='nav'>
        <div className='brand'>Daily&nbsp;Brief</div>
        <a className='nav-link' href='#demo'>Live demo</a>
      </header>

      <section className='hero'>
        <motion.div
          className='hero-inner'
          initial={{ opacity: 0, y: 24 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
        >
          <p className='kicker'>News briefings, on autopilot</p>
          <h1>A short, current read on the stories you follow.</h1>
          <p className='lede'>
            Daily Brief assembles headlines into a scannable briefing. The live demo below pulls
            current articles from the newsdata.io news API and tags them with keywords and sentiment.
          </p>
          <div className='hero-cta'>
            <a className='btn primary' href='#demo'>Try the live demo</a>
            <a className='btn ghost' href='https://newsdata.io' target='_blank' rel='noreferrer'>Get a free API key</a>
          </div>
        </motion.div>
      </section>

      <section className='features'>
        {[
          { t: 'Scannable cards', d: 'Each story shows its source, time, and a one-line summary so you can skim fast.' },
          { t: 'Keyword tags', d: 'Articles carry keyword tags from the API, so topics are easy to spot and filter.' },
          { t: 'Sentiment at a glance', d: 'A per-article badge and an aggregate bar show the mood across the current set.' },
        ].map((f, i) => (
          <motion.div
            className='feature'
            key={f.t}
            initial={{ opacity: 0, y: 16 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.4, delay: i * 0.08 }}
          >
            <h3>{f.t}</h3>
            <p>{f.d}</p>
          </motion.div>
        ))}
      </section>

      <section className='demo' id='demo'>
        <div className='demo-head'>
          <h2>Live briefing</h2>
          <p>Search a topic or pick a category. Headlines come from newsdata.io.</p>
        </div>

        <form className='controls' onSubmit={onSubmit}>
          <input
            className='search'
            type='text'
            placeholder='Search headlines (e.g. climate, markets)'
            value={inputValue}
            onChange={(e) => setInputValue(e.target.value)}
          />
          <button className='btn primary' type='submit'>Search</button>
        </form>

        <div className='cats'>
          {CATEGORIES.map((c) => (
            <button
              key={c.id}
              className={'cat' + (c.id === category ? ' active' : '')}
              onClick={() => onSelectCategory(c.id)}
              type='button'
            >
              {c.label}
            </button>
          ))}
        </div>

        {banner && <div className='notice'>{banner}</div>}
        {error && <div className='notice error'>{error}</div>}

        <div className='demo-grid'>
          <div className='grid'>
            {articles.map((a, i) => (
              <ArticleCard key={a.article_id || a.link || i} article={a} index={i} />
            ))}
          </div>
          <aside className='sidebar'>
            <SentimentBar articles={articles} />
          </aside>
        </div>

        <div className='more'>
          {loading && <span className='muted'>Loading…</span>}
          {!loading && nextPage && (
            <button
              className='btn ghost'
              type='button'
              onClick={() => fetchPage({ q: query, cat: category, page: nextPage, append: true })}
            >
              Load more
            </button>
          )}
        </div>
      </section>

      <footer className='foot'>
        <span>Daily Brief — a demo UI.</span>
        <span>
          Headlines from <a href='https://newsdata.io' target='_blank' rel='noreferrer'>newsdata.io</a>.
        </span>
      </footer>
    </div>
  )
}
