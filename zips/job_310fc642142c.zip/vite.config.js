import { defineConfig, loadEnv } from 'vite'
import react from '@vitejs/plugin-react'

const LATEST_URL = 'https://newsdata.io/api/1/latest'

// Free tier returns the latest endpoint only, up to 10 results, with the basic
// query params. Paid-only query params are sent solely when ENABLE_PAID=1, and the
// request is retried without them if the upstream rejects them.
function createHandler(env) {
  const apiKey = env.NEWSDATA_API_KEY || ''
  const paidMode = (env.ENABLE_PAID || '') === '1'

  return async function handler(req, res, next) {
    if (!req.url || !req.url.startsWith('/api/news')) return next()

    const send = (status, body) => {
      res.statusCode = status
      res.setHeader('Content-Type', 'application/json')
      res.end(JSON.stringify(body))
    }

    if (!apiKey) {
      // No key: tell the client to show clearly-labeled sample data.
      return send(200, { sample: true, reason: 'missing-key', results: [], nextPage: null })
    }

    try {
      const incoming = new URL(req.url, 'http://localhost')
      const base = new URLSearchParams()
      base.set('apikey', apiKey)
      base.set('language', incoming.searchParams.get('language') || 'en')
      for (const key of ['q', 'category', 'country', 'page']) {
        const val = incoming.searchParams.get(key)
        if (val) base.set(key, val)
      }

      const attempt = (withPaid) => {
        const params = new URLSearchParams(base)
        if (withPaid) params.set('full_content', '1')
        return fetch(`${LATEST_URL}?${params.toString()}`)
      }

      let upstream = await attempt(paidMode)
      if (paidMode && (upstream.status === 403 || upstream.status === 422)) {
        // Paid param rejected on this key — retry with free params only.
        upstream = await attempt(false)
      }

      if (upstream.status === 401) {
        return send(401, { error: 'Invalid newsdata.io API key (401). Check NEWSDATA_API_KEY.' })
      }
      if (upstream.status === 429) {
        return send(429, { error: 'newsdata.io rate limit reached (429). Wait a moment and retry.' })
      }

      const raw = await upstream.text()
      let data = null
      try {
        data = JSON.parse(raw)
      } catch (_) {
        data = null
      }

      if (!upstream.ok || !data || data.status === 'error') {
        const message =
          (data && data.results && data.results.message) ||
          (data && data.message) ||
          `Upstream error (${upstream.status}).`
        return send(upstream.status >= 400 ? upstream.status : 502, { error: message })
      }

      return send(200, {
        results: Array.isArray(data.results) ? data.results : [],
        nextPage: data.nextPage || null,
        totalResults: typeof data.totalResults === 'number' ? data.totalResults : null,
      })
    } catch (err) {
      const reason = err && err.message ? err.message : 'unknown error'
      return send(502, { error: 'Could not reach newsdata.io: ' + reason })
    }
  }
}

function newsdataProxy(env) {
  return {
    name: 'newsdata-proxy',
    configureServer(server) {
      server.middlewares.use(createHandler(env))
    },
    configurePreviewServer(server) {
      server.middlewares.use(createHandler(env))
    },
  }
}

export default defineConfig(({ mode }) => {
  // Empty prefix loads every var (including NEWSDATA_API_KEY) from .env and the shell.
  const env = loadEnv(mode, process.cwd(), '')
  return {
    plugins: [react(), newsdataProxy(env)],
  }
})
