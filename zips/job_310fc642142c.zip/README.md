# Daily Brief

A one-page React landing page with a live news-briefing demo. The demo pulls current
headlines from the newsdata.io news API (https://newsdata.io) and renders them as cards
with keyword tags, a sentiment badge, and an aggregate sentiment bar — grab a free API
key to run it.

The page is built with React and Framer Motion. A small dev-server proxy keeps your API
key on the server side instead of shipping it to the browser.

## Features

- Animated hero, feature, and demo sections (Framer Motion).
- Live headline grid with source, image, publish time, and a link to each article.
- Keyword tag chips taken from every article (returned on all plans).
- A per-article sentiment badge and an aggregate sentiment breakdown bar.
- Search box and category filters (top, technology, business, science, world, health).
- "Load more" pagination using the API's `nextPage` cursor.
- Works without a key: shows clearly-labeled sample articles so the layout is never blank.

## Setup

1. Install dependencies:

   ```
   npm install
   ```

2. Get a free API key from https://newsdata.io and create a `.env` file in the project root:

   ```
   NEWSDATA_API_KEY=your_key_here
   ```

3. Start the dev server:

   ```
   npm run dev
   ```

4. Open the printed URL (default http://localhost:5173).

The key is read from `NEWSDATA_API_KEY` by the Vite dev/preview proxy and is never bundled
into the client. If the variable is unset, the demo falls back to sample data.

## Optional configuration

- `ENABLE_PAID=1` — request richer fields (for example full article content) that require a
  paid newsdata.io plan. On a free key the proxy automatically retries the request without
  those parameters, so the demo keeps working. Paid response fields such as `sentiment` and
  `ai_summary` are simply absent on the free tier; the UI shows a labeled placeholder in that
  case.

## Usage example

Search the grid from the UI, or call the proxy directly:

```
curl 'http://localhost:5173/api/news?q=climate&category=science'
```

Sample output (trimmed):

```
{
  "results": [
    {
      "title": "Researchers map shifts in deep-ocean currents",
      "source_name": "Example Journal",
      "pubDate": "2026-06-11 08:20:00",
      "keywords": ["climate", "oceans"],
      "sentiment": "neutral"
    }
  ],
  "nextPage": "1718091600"
}
```

## How it works

- `vite.config.js` adds a `/api/news` route to the dev and preview servers. It calls
  `https://newsdata.io/api/1/latest` with your key, forwards `q`, `category`, `country`,
  `language`, and `page`, stays within the free-tier result size, and maps 401, 429, and
  empty responses to clean JSON the UI can display.
- `src/App.jsx` renders the page and the demo, guarding every optional field so a missing
  value becomes a placeholder rather than a crash.

## Notes

- The free plan returns up to 10 articles per request from the latest endpoint; the proxy
  stays within those limits by default.
- Headlines and data come from newsdata.io.

## License

MIT
