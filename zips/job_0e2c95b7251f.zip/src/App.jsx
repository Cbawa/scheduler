import { useState, useEffect, useCallback } from 'react'

// newsdata.io crypto news endpoint (works on the FREE plan)
const API_BASE = 'https://newsdata.io/api/1/crypto'
// Vite exposes only env vars prefixed with VITE_ to the browser.
const API_KEY = import.meta.env.VITE_NEWSDATA_API_KEY

const COINS = ['Bitcoin', 'Ethereum', 'Solana', 'XRP', 'Regulation', 'DeFi']

function timeAgo(dateStr) {
  if (!dateStr) return ''
  // newsdata pubDate looks like "2024-01-02 13:45:00" (UTC)
  const d = new Date(dateStr.replace(' ', 'T') + 'Z')
  const diff = Math.floor((Date.now() - d.getTime()) / 1000)
  if (isNaN(diff)) return dateStr
  if (diff < 60) return 'just now'
  if (diff < 3600) return Math.floor(diff / 60) + 'm ago'
  if (diff < 86400) return Math.floor(diff / 3600) + 'h ago'
  return Math.floor(diff / 86400) + 'd ago'
}

export default function App() {
  const [query, setQuery] = useState('')
  const [activeQuery, setActiveQuery] = useState('')
  const [articles, setArticles] = useState([])
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState('')
  const [notice, setNotice] = useState('')
  const [nextPage, setNextPage] = useState(null)
  const [total, setTotal] = useState(0)

  const fetchNews = useCallback(
    async (token, append) => {
      if (!API_KEY) {
        setError(
          'Missing API key. Add VITE_NEWSDATA_API_KEY to a .env file (see .env.example) and restart the dev server.'
        )
        return
      }
      setLoading(true)
      setError('')
      try {
        const params = new URLSearchParams({ apikey: API_KEY, language: 'en' })
        if (activeQuery.trim()) params.set('q', activeQuery.trim())
        if (token) params.set('page', token)

        const res = await fetch(`${API_BASE}?${params.toString()}`)
        const data = await res.json().catch(() => ({}))

        if (!res.ok || data.status === 'error') {
          const msg = (data.results && data.results.message) || data.message || ''
          if (res.status === 401) throw new Error('Invalid API key (401). Check VITE_NEWSDATA_API_KEY.')
          if (res.status === 429) throw new Error('Rate limit reached (429). Please wait a moment and try again.')
          if (res.status === 403 || res.status === 422) {
            setNotice('Some advanced filters require a paid plan and were skipped — showing free-tier results.')
            throw new Error(msg || 'That request used a feature not available on the free plan.')
          }
          throw new Error(msg || `Request failed (${res.status}).`)
        }

        const results = Array.isArray(data.results) ? data.results : []
        setArticles((prev) => (append ? [...prev, ...results] : results))
        setNextPage(data.nextPage || null)
        setTotal(typeof data.totalResults === 'number' ? data.totalResults : results.length)
      } catch (e) {
        setError(e.message || 'Something went wrong while fetching news.')
        if (!append) setArticles([])
      } finally {
        setLoading(false)
      }
    },
    [activeQuery]
  )

  useEffect(() => {
    fetchNews(null, false)
  }, [fetchNews])

  const onSubmit = (e) => {
    e.preventDefault()
    setActiveQuery(query)
  }

  const pickCoin = (coin) => {
    setQuery(coin)
    setActiveQuery(coin)
  }

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100">
      {/* Header */}
      <header className="bg-gradient-to-br from-indigo-600 via-violet-600 to-fuchsia-600">
        <div className="mx-auto max-w-5xl px-4 py-10">
          <h1 className="flex items-center gap-3 text-3xl font-bold tracking-tight sm:text-4xl">
            <span>🪙</span> Crypto News Tracker
          </h1>
          <p className="mt-2 max-w-2xl text-violet-100">
            Live cryptocurrency headlines from global sources, with keyword filtering. Powered by{' '}
            <a href="https://newsdata.io" className="font-semibold underline decoration-violet-300 underline-offset-2" target="_blank" rel="noreferrer">
              newsdata.io
            </a>
            .
          </p>

          {/* Search */}
          <form onSubmit={onSubmit} className="mt-6 flex gap-2">
            <input
              type="text"
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder="Search crypto news — e.g. bitcoin, ETF, halving…"
              className="w-full rounded-xl border border-white/20 bg-white/10 px-4 py-3 text-white placeholder-violet-200 outline-none focus:border-white/60"
            />
            <button
              type="submit"
              className="rounded-xl bg-white px-5 py-3 font-semibold text-violet-700 transition hover:bg-violet-50"
            >
              Search
            </button>
          </form>

          {/* Quick chips */}
          <div className="mt-4 flex flex-wrap gap-2">
            {COINS.map((coin) => (
              <button
                key={coin}
                onClick={() => pickCoin(coin)}
                className={`rounded-full px-3 py-1 text-sm transition ${
                  activeQuery.toLowerCase() === coin.toLowerCase()
                    ? 'bg-white text-violet-700'
                    : 'bg-white/15 text-white hover:bg-white/25'
                }`}
              >
                {coin}
              </button>
            ))}
            <button
              onClick={() => pickCoin('')}
              className="rounded-full bg-white/15 px-3 py-1 text-sm text-white transition hover:bg-white/25"
            >
              All
            </button>
          </div>
        </div>
      </header>

      {/* Body */}
      <main className="mx-auto max-w-5xl px-4 py-8">
        <div className="mb-4 flex items-center justify-between text-sm text-slate-400">
          <span>
            {activeQuery ? `Results for "${activeQuery}"` : 'Latest crypto news'}
            {total ? ` · ${total.toLocaleString()} total` : ''}
          </span>
        </div>

        {notice && (
          <div className="mb-4 rounded-lg border border-amber-500/30 bg-amber-500/10 px-4 py-3 text-sm text-amber-200">
            {notice}
          </div>
        )}

        {error && (
          <div className="mb-4 rounded-lg border border-rose-500/30 bg-rose-500/10 px-4 py-3 text-sm text-rose-200">
            {error}
          </div>
        )}

        {/* Empty state */}
        {!loading && !error && articles.length === 0 && (
          <div className="rounded-xl border border-slate-800 bg-slate-900 px-6 py-12 text-center text-slate-400">
            No articles found. Try a different keyword.
          </div>
        )}

        {/* Cards */}
        <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
          {articles.map((a, i) => (
            <article
              key={(a.article_id || a.link || 'a') + i}
              className="flex flex-col rounded-xl border border-slate-800 bg-slate-900 p-5 transition hover:border-violet-500/50"
            >
              <div className="mb-2 flex items-center gap-2 text-xs text-slate-400">
                <span className="rounded bg-violet-500/15 px-2 py-0.5 font-medium text-violet-300">
                  {a.source_id || 'source'}
                </span>
                <span>{timeAgo(a.pubDate)}</span>
              </div>
              <h2 className="text-base font-semibold leading-snug text-slate-100">
                {a.title || 'Untitled'}
              </h2>
              {a.description && (
                <p className="mt-2 line-clamp-3 text-sm text-slate-400">{a.description}</p>
              )}
              <a
                href={a.link}
                target="_blank"
                rel="noreferrer"
                className="mt-4 inline-flex items-center gap-1 text-sm font-medium text-violet-400 hover:text-violet-300"
              >
                Read full story →
              </a>
            </article>
          ))}
        </div>

        {/* Loading / Load more */}
        <div className="mt-8 flex justify-center">
          {loading ? (
            <span className="text-slate-400">Loading…</span>
          ) : (
            nextPage && (
              <button
                onClick={() => fetchNews(nextPage, true)}
                className="rounded-xl border border-violet-500/40 bg-violet-500/10 px-6 py-3 font-semibold text-violet-200 transition hover:bg-violet-500/20"
              >
                Load more
              </button>
            )
          )}
        </div>
      </main>

      <footer className="border-t border-slate-800 py-6 text-center text-sm text-slate-500">
        News data by{' '}
        <a href="https://newsdata.io" target="_blank" rel="noreferrer" className="text-violet-400 hover:text-violet-300">
          newsdata.io
        </a>{' '}
        · Built with React &amp; Tailwind CSS
      </footer>
    </div>
  )
}
