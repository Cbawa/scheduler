# 🪙 Crypto News Tracker

A clean, responsive dashboard for tracking **cryptocurrency news** from global sources in real time. Search by keyword (Bitcoin, Ethereum, regulation, DeFi…), browse rich article cards, and page through results — all powered by the [newsdata.io](https://newsdata.io) news API.

Built with **React**, **Vite**, and **Tailwind CSS**.

![Stack](https://img.shields.io/badge/React-18-61dafb) ![Stack](https://img.shields.io/badge/Vite-5-646cff) ![Stack](https://img.shields.io/badge/TailwindCSS-3-38bdf8)

---

## ✨ Features

- 🔎 **Keyword filtering** — search crypto headlines by any term using the `q` parameter
- ⚡ **Quick coin chips** — one-tap filters for Bitcoin, Ethereum, Solana, and more
- 📰 **Rich article cards** — source, relative timestamp, description, and a link to the original story
- 📄 **Pagination** — "Load more" uses the `nextPage` token returned by the API
- 🛡️ **Free-tier safe** — gracefully handles invalid keys (401), rate limits (429), empty results, and paid-only features

---

## 🚀 Getting started

### 1. Get a free API key

Sign up at **<https://newsdata.io/register>** and copy your API key from the dashboard. The free plan is all you need to run this project.

### 2. Install dependencies

```bash
npm install
```

### 3. Configure your API key

This is a Vite app, so the key is read from an environment variable that **must** be prefixed with `VITE_` to be exposed to the browser.

Copy the example file and add your key:

```bash
cp .env.example .env
```

Then edit `.env`:

```bash
VITE_NEWSDATA_API_KEY=your_api_key_here
```

> The app never hardcodes the key. If `VITE_NEWSDATA_API_KEY` is missing, it shows a clear in-app message instead of crashing.

### 4. Run the dev server

```bash
npm run dev
```

Open the printed URL (usually <http://localhost:5173>).

### 5. Build for production

```bash
npm run build
npm run preview
```

---

## 🔌 How it works

The app calls the newsdata.io **crypto news** endpoint:

```
GET https://newsdata.io/api/1/crypto?apikey=YOUR_KEY&language=en&q=bitcoin
```

The response shape:

```json
{
  "status": "success",
  "totalResults": 1234,
  "results": [
    { "title": "...", "link": "...", "description": "...", "pubDate": "...", "source_id": "..." }
  ],
  "nextPage": "token"
}
```

Pagination is handled by passing the `nextPage` token back as the `page` query parameter.

---

## 💳 Free plan vs. paid plan

This project is built to run entirely on the **free tier**. The following newsdata.io features are **paid-only** and are intentionally *not* part of the core flow:

| Feature | Plan |
|---|---|
| `sentiment` analysis | Paid |
| AI fields (`ai_tag`, `ai_region`, `ai_org`, `ai_summary`) | Paid |
| Historical `/archive` endpoint & long date ranges | Paid |
| Advanced full-text query operators | Paid |

If the API returns a `403`/`422` "upgrade your plan" response, the app shows a small notice and keeps working with the free-tier results.

---

## 🗂️ Project structure

```
crypto-news-tracker/
├── index.html          # Loads Tailwind (CDN) + the React entry point
├── vite.config.js      # Vite + React plugin
├── src/
│   ├── main.jsx        # React root
│   └── App.jsx         # All UI + newsdata.io fetching logic
├── .env.example        # Template for your API key
└── package.json
```

---

## 📄 License

MIT — free to use, learn from, and build on.

News data provided by [newsdata.io](https://newsdata.io).
