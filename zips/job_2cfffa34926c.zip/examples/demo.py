"""Runnable demo of the NewsAPI.org -> newsdata.io migration.

Run it:
    export NEWSDATA_API_KEY="your_free_key"
    python -m examples.demo

It shows that code written for the NewsAPI.org client keeps working unchanged
after swapping in ``newsdata_compat.NewsDataClient``.
"""
import sys

from newsdata_compat import NewsDataClient, NewsDataException


def main():
    try:
        client = NewsDataClient()  # reads NEWSDATA_API_KEY
    except ValueError as exc:
        print(f"Configuration error: {exc}")
        return 1

    try:
        print("=== get_top_headlines(q='technology', language='en') ===")
        resp = client.get_top_headlines(q="technology", language="en")
        print(f"totalResults: {resp['totalResults']}")
        if not resp["articles"]:
            print("No articles returned (this is handled gracefully).")
        for article in resp["articles"][:5]:
            source = article["source"]["name"] or "unknown source"
            print(f"  - {article['title']}  [{source}]")

        print("\n=== get_everything(q='climate change') page 1 ===")
        page = client.get_everything(q="climate change")
        for article in page["articles"][:3]:
            print(f"  - {article['title']}")
        if page.get("nextPage"):
            print(f"  (next page token: {page['nextPage']})")

        print("\n=== get_sources(language='en') ===")
        sources = client.get_sources(language="en")
        for s in sources["sources"][:5]:
            print(f"  - {s['name']} ({s.get('url')})")

    except NewsDataException as exc:
        print(f"\nAPI error ({exc.status_code}): {exc.message}")
        return 1

    print("\nDone. Your NewsAPI.org code now runs on newsdata.io.")
    return 0


if __name__ == "__main__":
    sys.exit(main())
