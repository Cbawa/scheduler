"""Exception types for the compatibility layer."""


class NewsDataException(Exception):
    """Raised when the newsdata.io API returns an error.

    Attributes:
        message: Human-readable description of what went wrong.
        status_code: HTTP status code returned by the API (if any).
    """

    def __init__(self, message, status_code=None):
        self.message = message
        self.status_code = status_code
        super().__init__(message)


# Familiar alias for people migrating from newsapi-python, whose client raises
# ``NewsAPIException``. Catch either name.
NewsAPIException = NewsDataException
