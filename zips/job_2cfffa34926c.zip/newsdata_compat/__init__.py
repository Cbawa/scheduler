"""newsdata_compat — a drop-in replacement for the NewsAPI.org Python client
that talks to the newsdata.io REST API.

Usage:
    from newsdata_compat import NewsDataClient
    client = NewsDataClient()  # reads NEWSDATA_API_KEY from the environment
    resp = client.get_top_headlines(q="bitcoin", language="en")
"""
from .client import NewsDataClient
from .errors import NewsDataException, NewsAPIException

__all__ = ["NewsDataClient", "NewsDataException", "NewsAPIException"]
__version__ = "1.0.0"
