"""Drop-in NewsAPI.org-compatible client backed by newsdata.io.

The public methods mirror ``newsapi.NewsApiClient`` so existing code keeps
working with minimal changes, while the responses are translated from the
newsdata.io format back into the NewsAPI.org shape your code already expects.

Designed and tested for the newsdata.io FREE tier.
"""
import logging
import os

import requests

from .errors import NewsDataException

BASE_URL = "https://newsdata.io/api/1"
DEFAULT_TIMEOUT = 30

# Feature flags below require a PAID newsdata.io plan. They are accepted but
# dropped (with a warning) on a 403/422 "upgrade your plan" response.
PAID_ONLY_PARAMS = ("sentiment", "full_content")

logger = logging.getLogger("newsdata_compat")


class NewsDataClient:
    """NewsAPI.org-compatible client for newsdata.io.

    Args:
        api_key: Your newsdata.io API key. If omitted, read from the
            ``NEWSDATA_API_KEY`` environment variable.
        session: Optional pre-configured ``requests.Session``.
    """

    def __init__(self, api_key=None, session=None):
        self.api_key = api_key or os.environ.get("NEWSDATA_API_KEY")
        if not self.api_key:
            raise ValueError(
                "No newsdata.io API key found. Pass api_key=... or set the "
                "NEWSDATA_API_KEY environment variable. Get a free key at "
                "https://newsdata.io/register"
            )
        self._session = session or requests.Session()

    # ------------------------------------------------------------------
    # Public, NewsAPI.org-compatible methods
    # ------------------------------------------------------------------
    def get_top_headlines(
        self,
        q=None,
        sources=None,
        category=None,
        language=None,
        country=None,
        page=None,
        **extra,
    ):
        """Equivalent of ``NewsApiClient.get_top_headlines``.

        Maps to ``GET /news`` on newsdata.io. Returns a dict shaped like a
        NewsAPI.org response: ``{status, totalResults, articles, nextPage}``.
        """
        params = {
            "q": q,
            "category": category,
            "language": language,
            "country": country,
            "domain": sources,
        }
        params.update(self._page_param(page))
        params.update(extra)
        raw = self._request("/news", params)
        return self._to_newsapi_response(raw)

    def get_everything(
        self,
        q=None,
        sources=None,
        domains=None,
        language=None,
        sort_by=None,  # accepted for compatibility; newsdata.io free tier ignores it
        page=None,
        **extra,
    ):
        """Equivalent of ``NewsApiClient.get_everything``.

        newsdata.io serves both "headlines" and "everything" from the same
        ``/news`` endpoint, so this maps there too.
        """
        params = {
            "q": q,
            "language": language,
            "domain": domains or sources,
        }
        params.update(self._page_param(page))
        params.update(extra)
        raw = self._request("/news", params)
        return self._to_newsapi_response(raw)

    def get_sources(self, category=None, language=None, country=None, **extra):
        """Equivalent of ``NewsApiClient.get_sources``.

        Maps to ``GET /sources`` and returns ``{status, sources: [...]}``.
        """
        params = {
            "category": category,
            "language": language,
            "country": country,
        }
        params.update(extra)
        raw = self._request("/sources", params)
        sources = []
        for s in raw.get("results", []) or []:
            sources.append(
                {
                    "id": s.get("id") or s.get("source_id"),
                    "name": s.get("name"),
                    "description": s.get("description", ""),
                    "url": s.get("url"),
                    "category": (s.get("category") or [None])[0]
                    if isinstance(s.get("category"), list)
                    else s.get("category"),
                    "language": (s.get("language") or [None])[0]
                    if isinstance(s.get("language"), list)
                    else s.get("language"),
                    "country": (s.get("country") or [None])[0]
                    if isinstance(s.get("country"), list)
                    else s.get("country"),
                }
            )
        return {"status": "ok", "sources": sources}

    # ------------------------------------------------------------------
    # Internals
    # ------------------------------------------------------------------
    @staticmethod
    def _page_param(page):
        """newsdata.io paginates with an opaque ``page`` token (``nextPage``).

        We accept whatever the caller passes through verbatim.
        """
        if page is None or page == "":
            return {}
        return {"page": page}

    def _request(self, path, params, _retry_without_paid=True):
        """Perform a GET against newsdata.io and return the parsed JSON.

        Handles auth, rate-limit and paid-feature errors gracefully.
        """
        query = {"apikey": self.api_key}
        # Drop None values so we only send meaningful filters.
        query.update({k: v for k, v in params.items() if v is not None})

        try:
            resp = self._session.get(
                BASE_URL + path, params=query, timeout=DEFAULT_TIMEOUT
            )
        except requests.RequestException as exc:
            raise NewsDataException(f"Network error contacting newsdata.io: {exc}")

        if resp.status_code == 200:
            return resp.json()

        message = self._error_message(resp)

        if resp.status_code == 401:
            raise NewsDataException(
                "Invalid newsdata.io API key (401). Check NEWSDATA_API_KEY.",
                status_code=401,
            )
        if resp.status_code == 429:
            raise NewsDataException(
                "Rate limit reached (429). Slow down or upgrade your plan.",
                status_code=429,
            )
        if resp.status_code in (403, 422):
            # Likely a paid-only parameter on a free key. Strip them and retry
            # once so the app keeps working instead of crashing.
            stripped = {k: v for k, v in params.items() if k not in PAID_ONLY_PARAMS}
            if _retry_without_paid and stripped.keys() != params.keys():
                logger.warning(
                    "newsdata.io rejected a paid-only feature (%s): %s. "
                    "Retrying without it.",
                    resp.status_code,
                    message,
                )
                return self._request(path, stripped, _retry_without_paid=False)
            raise NewsDataException(
                f"Request rejected ({resp.status_code}). This may require a paid "
                f"plan: {message}",
                status_code=resp.status_code,
            )

        raise NewsDataException(
            f"newsdata.io error {resp.status_code}: {message}",
            status_code=resp.status_code,
        )

    @staticmethod
    def _error_message(resp):
        try:
            body = resp.json()
        except ValueError:
            return resp.text[:200] or "unknown error"
        results = body.get("results")
        if isinstance(results, dict):
            return results.get("message") or str(results)
        return body.get("message") or str(body)[:200]

    @classmethod
    def _to_newsapi_response(cls, raw):
        """Translate a newsdata.io ``/news`` payload into NewsAPI.org shape."""
        results = raw.get("results") or []
        articles = [cls._to_newsapi_article(item) for item in results]
        return {
            "status": "ok" if raw.get("status") == "success" else "error",
            "totalResults": raw.get("totalResults", len(articles)),
            "articles": articles,
            # Surface the newsdata.io pagination token for callers who want it.
            "nextPage": raw.get("nextPage"),
        }

    @staticmethod
    def _to_newsapi_article(item):
        """Map a single newsdata.io result to a NewsAPI.org article dict."""
        creators = item.get("creator")
        author = creators[0] if isinstance(creators, list) and creators else None
        return {
            "source": {
                "id": item.get("source_id"),
                "name": item.get("source_id"),
            },
            "author": author,
            "title": item.get("title"),
            "description": item.get("description"),
            "url": item.get("link"),
            "urlToImage": item.get("image_url"),
            "publishedAt": item.get("pubDate"),
            "content": item.get("content"),
        }
