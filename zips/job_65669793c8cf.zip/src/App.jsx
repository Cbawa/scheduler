import { useCallback, useEffect, useState } from 'react'
import { fetchNews, hasApiKey } from './api/newsdata.js'

const CATEGORIES = ['', 'top', 'business', 'technology', 'sports', 'science', 'health', 'world']

export default function App() {
  const [query, setQuery] = useState('')
  const [submittedQuery, setSubmittedQuery] = useState('')
  const [category, setCategory] = useState('')
  const [articles, setArticles] = useState([])
  const [nextPage, setNextPage] = useState(null)
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState(null)

  const load = useCallback(async ({ q, cat, page = null, append = false }) => {
    setLoading(true)
    setError(null)
    try {
      const res = await fetchNews({ q, category: cat, page })
      setArticles((prev) => (append ? [...prev, ...res.articles] : res.articles))
      setNextPage(res.nextPage)
    } catch (err) {
      setError(err.message)
      if (!append) setArticles([])
    } finally {
      setLoading(false)
    }
  }, [])

  useEffect(() => {
    if (hasApiKey()) load({ q: submittedQuery, cat: category })
  }, [submittedQuery, category, load])

  const onSearch = (e) => {
    e.preventDefault()
    setSubmittedQuery(query.trim())
  }

  return (
    <div style={styles.page}>
      <header style={styles.header}>
        <h1 style={styles.h1}>📰 NewsAPI.org → newsdata.io</h1>
        <p style={styles.sub}>
          A React migration demo powered by the newsdata.io <code>/news</code> endpoint.
        </p>
      </header>

      {!hasApiKey() && (
        <div style={styles.banner}>
          <strong>No API key found.</strong> Create a <code>.env</code> file with{' '}
          <code>NEWSDATA_API_KEY=your_key</code> and restart <code>npm run dev</code>. Get a free
          key at{' '}
          <a href="https://newsdata.io/register" target="_blank" rel="noreferrer">
            newsdata.io/register
          </a>
          .
        </div>
      )}

      <form onSubmit={onSearch} style={styles.controls}>
        <input
          style={styles.input}
          placeholder="Search news (e.g. technology)"
          value={query}
          onChange={(e) => setQuery(e.target.value)}
        />
        <select
          style={styles.select}
          value={category}
          onChange={(e) => setCategory(e.target.value)}
        >
          {CATEGORIES.map((c) => (
            <option key={c || 'all'} value={c}>
              {c ? c[0].toUpperCase() + c.slice(1) : 'All categories'}
            </option>
          ))}
        </select>
        <button style={styles.button} type="submit">
          Search
        </button>
      </form>

      {error && <div style={styles.error}>⚠️ {error}</div>}

      {!error && !loading && articles.length === 0 && hasApiKey() && (
        <p style={styles.empty}>No articles found. Try another search term or category.</p>
      )}

      <div style={styles.grid}>
        {articles.map((a) => (
          <article key={a.id} style={styles.card}>
            {a.imageUrl && (
              <img src={a.imageUrl} alt="" style={styles.img} loading="lazy" />
            )}
            <div style={styles.cardBody}>
              <span style={styles.source}>{a.source}</span>
              <h2 style={styles.title}>
                <a href={a.url} target="_blank" rel="noreferrer" style={styles.link}>
                  {a.title}
                </a>
              </h2>
              {a.description && <p style={styles.desc}>{a.description}</p>}
              {a.publishedAt && <time style={styles.time}>{a.publishedAt}</time>}
            </div>
          </article>
        ))}
      </div>

      {loading && <p style={styles.loading}>Loading…</p>}

      {!loading && nextPage && (
        <div style={styles.center}>
          <button
            style={styles.button}
            onClick={() =>
              load({ q: submittedQuery, cat: category, page: nextPage, append: true })
            }
          >
            Load more
          </button>
        </div>
      )}

      <footer style={styles.footer}>
        Built with{' '}
        <a href="https://newsdata.io" target="_blank" rel="noreferrer">
          newsdata.io
        </a>{' '}
        · Free-tier friendly
      </footer>
    </div>
  )
}

const styles = {
  page: {
    maxWidth: 960,
    margin: '0 auto',
    padding: '24px 16px 64px',
    fontFamily: 'system-ui, -apple-system, Segoe UI, Roboto, sans-serif',
    color: '#1a1a2e',
  },
  header: { textAlign: 'center', marginBottom: 24 },
  h1: { fontSize: 28, margin: '0 0 8px' },
  sub: { color: '#555', margin: 0 },
  banner: {
    background: '#fff7e6',
    border: '1px solid #ffd591',
    borderRadius: 8,
    padding: '12px 16px',
    marginBottom: 16,
    lineHeight: 1.5,
  },
  controls: { display: 'flex', gap: 8, flexWrap: 'wrap', marginBottom: 20 },
  input: {
    flex: '1 1 220px',
    padding: '10px 12px',
    borderRadius: 8,
    border: '1px solid #ccc',
    fontSize: 15,
  },
  select: { padding: '10px 12px', borderRadius: 8, border: '1px solid #ccc', fontSize: 15 },
  button: {
    padding: '10px 18px',
    borderRadius: 8,
    border: 'none',
    background: '#3454d1',
    color: '#fff',
    fontSize: 15,
    cursor: 'pointer',
  },
  error: {
    background: '#fff1f0',
    border: '1px solid #ffa39e',
    color: '#a8071a',
    borderRadius: 8,
    padding: '12px 16px',
    marginBottom: 16,
  },
  empty: { textAlign: 'center', color: '#888' },
  grid: {
    display: 'grid',
    gridTemplateColumns: 'repeat(auto-fill, minmax(260px, 1fr))',
    gap: 16,
  },
  card: {
    border: '1px solid #eee',
    borderRadius: 12,
    overflow: 'hidden',
    background: '#fff',
    display: 'flex',
    flexDirection: 'column',
    boxShadow: '0 1px 3px rgba(0,0,0,0.06)',
  },
  img: { width: '100%', height: 150, objectFit: 'cover' },
  cardBody: { padding: 14, display: 'flex', flexDirection: 'column', gap: 8 },
  source: { fontSize: 12, textTransform: 'uppercase', color: '#3454d1', fontWeight: 600 },
  title: { fontSize: 16, margin: 0, lineHeight: 1.3 },
  link: { color: '#1a1a2e', textDecoration: 'none' },
  desc: { fontSize: 14, color: '#555', margin: 0 },
  time: { fontSize: 12, color: '#999' },
  loading: { textAlign: 'center', color: '#555' },
  center: { textAlign: 'center', marginTop: 24 },
  footer: { textAlign: 'center', marginTop: 40, color: '#888', fontSize: 14 },
}
