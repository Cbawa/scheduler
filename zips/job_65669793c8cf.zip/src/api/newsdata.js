// newsdata.io API client for the React migration demo.
//
// Migration summary vs NewsAPI.org:
//   - base URL:   https://newsapi.org/v2  ->  https://newsdata.io/api/1
//   - endpoint:   /everything|/top-headlines  ->  /news
//   - auth param: apiKey  ->  apikey
//   - results:    data.articles  ->  data.results
//   - pagination: numeric page  ->  opaque `nextPage` token

const BASE_URL = 'https://newsdata.io/api/1'

// Read the key from the environment. NEVER hardcode it.
const API_KEY = import.meta.env.NEWSDATA_API_KEY

export class NewsDataError extends Error {
  constructor(message, { code, isPlanLimit = false } = {}) {
    super(message)
    this.name = 'NewsDataError'
    this.code = code
    this.isPlanLimit = isPlanLimit
  }
}

export function hasApiKey() {
  return Boolean(API_KEY)
}

// newsdata.io `results[]` items use different field names than NewsAPI.org
// `articles[]`. This adapter maps them to a single shape the UI consumes, so
// the React components did not have to change during the migration.
export function normalizeArticle(item) {
  return {
    id: item.article_id || item.link,
    title: item.title || 'Untitled',
    description: item.description || '',
    url: item.link, //                 NewsAPI.org: article.url
    imageUrl: item.image_url || null, // NewsAPI.org: article.urlToImage
    source: item.source_id || 'unknown', // NewsAPI.org: article.source.name
    publishedAt: item.pubDate || null, // NewsAPI.org: article.publishedAt
  }
}

// Fetch the latest news. Only free-tier params are used: q, country,
// language, category, page (the nextPage token).
export async function fetchNews({
  q = '',
  country = '',
  language = 'en',
  category = '',
  page = null,
} = {}) {
  if (!API_KEY) {
    throw new NewsDataError(
      'Missing NEWSDATA_API_KEY. Create a .env file with NEWSDATA_API_KEY=your_key and restart the dev server.',
      { code: 'NO_KEY' },
    )
  }

  const params = new URLSearchParams({ apikey: API_KEY, language })
  if (q) params.set('q', q)
  if (country) params.set('country', country)
  if (category) params.set('category', category)
  if (page) params.set('page', page) // nextPage token, NOT an integer offset

  let response
  try {
    response = await fetch(`${BASE_URL}/news?${params.toString()}`)
  } catch (networkErr) {
    throw new NewsDataError(
      'Network error reaching newsdata.io. Check your connection and try again.',
      { code: 'NETWORK' },
    )
  }

  if (response.status === 401) {
    throw new NewsDataError('Invalid API key (401). Double-check NEWSDATA_API_KEY.', {
      code: 401,
    })
  }
  if (response.status === 429) {
    throw new NewsDataError(
      'Rate limit reached (429). The free plan is rate-limited — wait a moment and retry.',
      { code: 429 },
    )
  }
  // 403/422 usually mean a paid-only parameter was sent on a free key.
  if (response.status === 403 || response.status === 422) {
    throw new NewsDataError(
      'This request used a feature not available on the free plan. Remove paid-only params (sentiment, ai_* fields, archive) and retry.',
      { code: response.status, isPlanLimit: true },
    )
  }

  const data = await response.json().catch(() => ({}))

  if (!response.ok || data.status === 'error') {
    const msg =
      data?.results?.message || data?.message || `Request failed (${response.status}).`
    throw new NewsDataError(msg, { code: response.status })
  }

  const results = Array.isArray(data.results) ? data.results : []
  return {
    articles: results.map(normalizeArticle),
    nextPage: data.nextPage || null, // pass back as `page` for the next page
    totalResults: data.totalResults || results.length,
  }
}
