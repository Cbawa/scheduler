# react-newsapi-migration

> Step-by-step guide **and** a working React demo for migrating from [NewsAPI.org](https://newsapi.org) to [**newsdata.io**](https://newsdata.io).

If you have a React app built on NewsAPI.org and want to switch to newsdata.io, this repo gives you:

1. A **field + endpoint mapping** so you know exactly what changes.
2. **Before / after** code samples.
3. A small, runnable Vite + React app that calls the newsdata.io `/news` endpoint and renders results — designed to work on the **free plan**.

---

## Quick start

```bash
# 1. Install dependencies
npm install

# 2. Add your free newsdata.io API key (get one at https://newsdata.io/register)
#    Create a .env file in the project root:
echo "NEWSDATA_API_KEY=your_api_key_here" > .env

# 3. Run the dev server
npm run dev
```

Then open the printed local URL (usually http://localhost:5173).

### The `NEWSDATA_API_KEY` environment variable

The app reads your key from the `NEWSDATA_API_KEY` environment variable — it is **never hardcoded**. `vite.config.js` adds the `NEWSDATA_` prefix to Vite's exposed env vars so `import.meta.env.NEWSDATA_API_KEY` is available in the client. Restart the dev server after changing `.env`.

> ⚠️ Client-side keys are visible in the browser. For production, proxy requests through a small backend so the key stays server-side. This demo keeps it client-side purely to keep the migration example focused.

---

## Migration in 4 steps

### Step 1 — Swap the base URL and auth

| | NewsAPI.org | newsdata.io |
|---|---|---|
| Base URL | `https://newsapi.org/v2` | `https://newsdata.io/api/1` |
| Main endpoint | `/top-headlines`, `/everything` | `/news` |
| Auth param | `apiKey` (or `X-Api-Key` header) | `apikey` (query param) |

### Step 2 — Update query parameters

| Purpose | NewsAPI.org | newsdata.io |
|---|---|---|
| Keyword search | `q` | `q` |
| Country | `country` (e.g. `us`) | `country` (e.g. `us`) |
| Language | `language` | `language` |
| Category | `category` | `category` |
| Pagination | `page` + `pageSize` (integers) | `page` (a **`nextPage` token**, not a number) |

**Key difference:** newsdata.io pagination uses an opaque `nextPage` token returned in each response. You pass it back as `page` to fetch the next page — there are no numeric page offsets.

### Step 3 — Remap the response fields

NewsAPI.org returns `articles[]`; newsdata.io returns `results[]` with different field names:

| UI needs | NewsAPI.org (`article.*`) | newsdata.io (`result.*`) |
|---|---|---|
| Title | `title` | `title` |
| Summary | `description` | `description` |
| Article URL | `url` | `link` |
| Image | `urlToImage` | `image_url` |
| Source name | `source.name` | `source_id` |
| Published date | `publishedAt` | `pubDate` |
| Unique id | _(none)_ | `article_id` |

This repo isolates that mapping in `src/api/newsdata.js` (`normalizeArticle`), so your React components don't need to change.

### Step 4 — Handle errors and the free tier

The client handles `401` (invalid key), `429` (rate limit), `403/422` (paid-only feature on a free key), and empty `results` without crashing.

---

## Before / After

**Before — NewsAPI.org**

```js
const res = await fetch(
  `https://newsapi.org/v2/everything?q=${q}&language=en&apiKey=${KEY}`
);
const data = await res.json();
const items = data.articles.map((a) => ({
  title: a.title,
  url: a.url,
  image: a.urlToImage,
  source: a.source.name,
  date: a.publishedAt,
}));
```

**After — newsdata.io**

```js
const res = await fetch(
  `https://newsdata.io/api/1/news?q=${q}&language=en&apikey=${KEY}`
);
const data = await res.json();
const items = data.results.map((r) => ({
  title: r.title,
  url: r.link,          // url -> link
  image: r.image_url,   // urlToImage -> image_url
  source: r.source_id,  // source.name -> source_id
  date: r.pubDate,      // publishedAt -> pubDate
}));
// data.nextPage is the token for the next page
```

---

## Free-tier notes (important)

This demo only uses parameters available on the **free** newsdata.io plan: `q`, `country`, `language`, `category`, and `page`.

The following are **paid-only** and are intentionally **not** used in the core flow:

- `sentiment` / sentiment analysis
- AI fields: `ai_tag`, `ai_region`, `ai_org`, `ai_summary`
- the historical `/archive` endpoint and long date ranges
- advanced full-text query operators

If you add any of these, the client already detects `403/422` "upgrade your plan" responses and surfaces a friendly message instead of crashing — keep such features optional so free users still get a working app.

---

## Project structure

```
.
├── index.html
├── package.json
├── vite.config.js
├── src
│   ├── main.jsx          # React entry
│   ├── App.jsx           # UI: search, categories, pagination, error states
│   └── api
│       └── newsdata.js   # newsdata.io client + field mapping + error handling
└── README.md
```

## License

MIT — use it as a starting point for your own migration.
