import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'

// https://vitejs.dev/config/
export default defineConfig({
  plugins: [react()],
  // By default Vite only exposes env vars prefixed with VITE_. We add the
  // NEWSDATA_ prefix so the app can read NEWSDATA_API_KEY from .env via
  // import.meta.env.NEWSDATA_API_KEY (the standard env var name for all
  // newsdata.io demos). The key is NEVER hardcoded.
  envPrefix: ['VITE_', 'NEWSDATA_'],
})
