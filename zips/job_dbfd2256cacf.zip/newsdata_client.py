"""Small client for the newsdata.io REST API.

Only what a free API key can call sits on the default path. Anything that needs
a paid plan is opt-in and falls back cleanly if the API refuses it.
"""

from __future__ import annotations

import os
import time
from typing import Any, Callable, Dict, Iterator, List, Optional

import requests

BASE_URL = "https://newsdata.io/api/1"

# A free key may not ask for more than 10 results in one request.
FREE_MAX_SIZE = 10

# Query parameters a free key may not send. One of these in the query string
# fails the whole request, so they are only attached in paid mode.
PAID_QUERY_PARAMS = frozenset(
    {
        "timeframe",
        "from_date",
        "to_date",
        "full_content",
        "sentiment",
        "sentiment_score",
        "tag",
        "region",
        "organization",
    }
)


class NewsdataError(RuntimeError):
    """Anything that went wrong talking to newsdata.io."""


class MissingApiKey(NewsdataError):
    """NEWSDATA_API_KEY is not set."""


class AuthError(NewsdataError):
    """HTTP 401 - the key was rejected."""


class RateLimited(NewsdataError):
    """HTTP 429 - too many requests for this key."""


class PlanError(NewsdataError):
    """HTTP 403/422 - the request asked for something the plan does not cover."""


def api_key_from_env(var: str = "NEWSDATA_API_KEY") -> str:
    key = (os.environ.get(var) or "").strip()
    if not key:
        raise MissingApiKey(
            var
            + " is not set.\n"
            + "Get a key from https://newsdata.io and export it before running:\n"
            + "    export "
            + var
            + "='your-key-here'"
        )
    return key


def _error_text(payload: Any) -> str:
    """Pull the human-readable bit out of an error body."""
    if isinstance(payload, dict):
        results = payload.get("results")
        if isinstance(results, dict):
            message = results.get("message") or results.get("code")
            if message:
                return str(message)
        for key in ("message", "error"):
            if payload.get(key):
                return str(payload[key])
    return "unexpected response from newsdata.io"


def _response_message(response: requests.Response) -> str:
    try:
        return _error_text(response.json())
    except ValueError:
        return (response.text or "").strip()[:200] or "no response body"


def _retry_after(response: requests.Response, fallback: float) -> float:
    raw = response.headers.get("Retry-After")
    try:
        return max(1.0, min(60.0, float(raw)))
    except (TypeError, ValueError):
        return fallback


class NewsdataClient:
    """Blocking client. One instance per script run is plenty."""

    def __init__(
        self,
        api_key: Optional[str] = None,
        base_url: str = BASE_URL,
        timeout: float = 20.0,
        max_retries: int = 2,
        session: Optional[requests.Session] = None,
    ) -> None:
        self.api_key = api_key or api_key_from_env()
        self.base_url = base_url.rstrip("/")
        self.timeout = timeout
        self.max_retries = max_retries
        self.session = session or requests.Session()

    def get(self, path: str, params: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        url = self.base_url + path
        query = {k: v for k, v in (params or {}).items() if v not in (None, "", [])}
        # The key travels in a header so it never lands in a URL or a log line.
        headers = {"X-ACCESS-KEY": self.api_key, "Accept": "application/json"}
        delay = 2.0

        for attempt in range(self.max_retries + 1):
            try:
                response = self.session.get(
                    url, params=query, headers=headers, timeout=self.timeout
                )
            except requests.RequestException as exc:
                if attempt < self.max_retries:
                    time.sleep(delay)
                    delay *= 2
                    continue
                raise NewsdataError("could not reach newsdata.io: " + str(exc)) from exc

            if response.status_code == 429:
                if attempt < self.max_retries:
                    time.sleep(_retry_after(response, delay))
                    delay *= 2
                    continue
                raise RateLimited(
                    "rate limited by newsdata.io (HTTP 429). Free keys get a limited "
                    "number of requests per 15 minutes - wait a moment, or run the "
                    "automation less often."
                )
            if response.status_code == 401:
                raise AuthError(
                    "newsdata.io rejected the API key (HTTP 401). Check NEWSDATA_API_KEY."
                )
            if response.status_code in (403, 422):
                raise PlanError(
                    "HTTP " + str(response.status_code) + ": " + _response_message(response)
                )
            if response.status_code >= 400:
                raise NewsdataError(
                    "HTTP " + str(response.status_code) + ": " + _response_message(response)
                )

            try:
                payload = response.json()
            except ValueError as exc:
                raise NewsdataError("newsdata.io returned a non-JSON response") from exc

            if not isinstance(payload, dict):
                raise NewsdataError("newsdata.io returned an unexpected payload type")
            if payload.get("status") == "error":
                raise NewsdataError(_error_text(payload))
            return payload

        raise NewsdataError("request to newsdata.io failed")

    def latest(self, **params: Any) -> Dict[str, Any]:
        """GET /1/latest with the given parameters."""
        return self.get("/latest", params)


def iter_articles(
    client: NewsdataClient,
    params: Dict[str, Any],
    max_pages: int = 1,
    limit: Optional[int] = None,
) -> Iterator[Dict[str, Any]]:
    """Yield article dicts, following the nextPage cursor until it is null."""
    page: Optional[str] = None
    produced = 0

    for _ in range(max(1, max_pages)):
        query = dict(params)
        if page:
            query["page"] = page
        payload = client.get("/latest", query)
        results = payload.get("results") or []
        if not isinstance(results, list):
            return
        for article in results:
            if not isinstance(article, dict):
                continue
            yield article
            produced += 1
            if limit and produced >= limit:
                return
        page = payload.get("nextPage")
        if not page:
            return


def fetch_articles(
    client: NewsdataClient,
    params: Dict[str, Any],
    paid_params: Optional[Dict[str, Any]] = None,
    max_pages: int = 1,
    limit: Optional[int] = None,
    notice: Optional[Callable[[str], None]] = None,
) -> List[Dict[str, Any]]:
    """Fetch articles; if paid-only params are refused, retry once without them."""

    def announce(text: str) -> None:
        if notice:
            notice(text)

    attempts = []
    if paid_params:
        merged = dict(params)
        merged.update(paid_params)
        attempts.append((merged, True))
    attempts.append((dict(params), False))

    last: Optional[NewsdataError] = None
    for query, is_paid in attempts:
        try:
            return list(iter_articles(client, query, max_pages=max_pages, limit=limit))
        except PlanError as exc:
            last = exc
            if not is_paid:
                raise
            announce(
                "newsdata.io refused the paid parameters ("
                + str(exc)
                + ") - retrying without "
                + ", ".join(sorted(paid_params or {}))
            )
    raise last or NewsdataError("no request was attempted")
