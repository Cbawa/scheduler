#!/usr/bin/env python3
"""Test-drive the newsdata.io request behind the Zapier / Make templates.

    python run_template.py check
    python run_template.py preview --q "electric vehicles" --limit 5
    python run_template.py preview --q bitcoin --format webhook --json
    python run_template.py send --q bitcoin --format slack --state crypto --webhook-url ...
    python run_template.py templates
"""

from __future__ import annotations

import argparse
import json
import os
import sys
from pathlib import Path
from typing import Any, Dict, List

import requests

import transform
from newsdata_client import (
    FREE_MAX_SIZE,
    AuthError,
    MissingApiKey,
    NewsdataClient,
    NewsdataError,
    RateLimited,
    fetch_articles,
)

ROOT = Path(__file__).resolve().parent
TEMPLATE_DIR = ROOT / "templates"
STATE_DIR = Path(os.environ.get("NEWSDATA_STATE_DIR") or (ROOT / ".state"))
FORMATS = ("slack", "sheets", "webhook", "text")

TEMPLATE_NOTES = {
    "templates/zapier/code_step.js": (
        "Code by Zapier (JavaScript): calls /latest and returns one object per article."
    ),
    "templates/make/slack-alert.blueprint.json": (
        "Make blueprint: HTTP GET -> iterator over results -> POST to a Slack webhook."
    ),
}


def warn(message: str) -> None:
    print("! " + message, file=sys.stderr)


# --------------------------------------------------------------------------- query


def paid_mode_enabled(args: argparse.Namespace) -> bool:
    if getattr(args, "paid", False):
        return True
    flag = (os.environ.get("ENABLE_PAID_PARAMS") or "").strip().lower()
    return flag in ("1", "true", "yes", "on")


def build_params(args: argparse.Namespace) -> Dict[str, Any]:
    """Only free-plan query parameters live here."""
    size = min(max(int(args.limit), 1), FREE_MAX_SIZE)
    params = {
        "q": args.q,
        "language": args.language,
        "country": args.country,
        "category": args.category,
        "domain": args.domain,
        "size": size,
    }
    return {k: v for k, v in params.items() if v}


def build_paid_params(args: argparse.Namespace, enabled: bool) -> Dict[str, Any]:
    wanted: Dict[str, Any] = {}
    if getattr(args, "timeframe", None):
        wanted["timeframe"] = args.timeframe
    if getattr(args, "sentiment", None):
        wanted["sentiment"] = args.sentiment
    if getattr(args, "tag", None):
        wanted["tag"] = args.tag
    if getattr(args, "full_content", False):
        wanted["full_content"] = 1

    if not wanted:
        return {}
    if not enabled:
        warn(
            "ignoring "
            + ", ".join(sorted(wanted))
            + ": those query parameters need a paid newsdata.io plan. "
            + "Add --paid (or set ENABLE_PAID_PARAMS=1) to send them anyway."
        )
        return {}
    return wanted


def describe_query(args: argparse.Namespace) -> str:
    bits = []
    for name in ("q", "language", "country", "category", "domain"):
        value = getattr(args, name, None)
        if value:
            bits.append(name + "=" + str(value))
    return " ".join(bits) or "latest news, no filters"


def collect(args: argparse.Namespace) -> List[Dict[str, Any]]:
    client = NewsdataClient()
    paid = build_paid_params(args, paid_mode_enabled(args))
    raw = fetch_articles(
        client,
        build_params(args),
        paid_params=paid,
        max_pages=args.max_pages,
        limit=args.limit,
        notice=warn,
    )
    return transform.normalize_all(raw)


# --------------------------------------------------------------------------- payloads


def default_title(args: argparse.Namespace, articles: List[Dict[str, Any]]) -> str:
    if getattr(args, "q", None):
        return str(len(articles)) + " headlines for " + str(args.q)
    return str(len(articles)) + " latest headlines"


def build_payload(fmt: str, articles: List[Dict[str, Any]], args: argparse.Namespace) -> Any:
    title = getattr(args, "title", None) or default_title(args, articles)
    if fmt == "slack":
        return transform.slack_payload(articles, title=title)
    if fmt == "sheets":
        return {
            "columns": transform.SHEET_COLUMNS,
            "rows": transform.sheet_rows(articles),
            "found": len(articles),
        }
    if fmt == "text":
        return {"text": transform.render_preview(articles, header=title)}
    return transform.webhook_payload(
        articles, query=describe_query(args), template=getattr(args, "state", "") or ""
    )


def post_json(url: str, payload: Any, timeout: float = 20.0):
    try:
        response = requests.post(url, json=payload, timeout=timeout)
    except requests.RequestException as exc:
        return False, "could not reach the webhook: " + str(exc)
    body = (response.text or "").strip()[:200]
    if response.status_code >= 400:
        return False, "HTTP " + str(response.status_code) + " " + body
    return True, ("HTTP " + str(response.status_code) + (" " + body if body else ""))


# --------------------------------------------------------------------------- state


def _state_path(name: str) -> Path:
    safe = "".join(c for c in name if c.isalnum() or c in ("-", "_")) or "default"
    return STATE_DIR / (safe + ".json")


def load_seen(name: str) -> List[str]:
    try:
        data = json.loads(_state_path(name).read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return []
    seen = data.get("seen")
    return [str(item) for item in seen] if isinstance(seen, list) else []


def save_seen(name: str, ids: List[str], cap: int = 500) -> None:
    path = _state_path(name)
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(".tmp")
    tmp.write_text(json.dumps({"seen": ids[-cap:]}, indent=2), encoding="utf-8")
    tmp.replace(path)


# --------------------------------------------------------------------------- commands


def cmd_check(args: argparse.Namespace) -> int:
    client = NewsdataClient()
    payload = client.get("/latest", {"language": "en", "size": 1})
    results = [r for r in (payload.get("results") or []) if isinstance(r, dict)]

    print("key accepted by newsdata.io")
    print("totalResults on a bare /latest call: " + str(payload.get("totalResults", "?")))
    if not results:
        print("the call worked but returned no articles - unusual, try again in a minute")
        return 0

    raw = results[0]
    article = transform.normalize(raw)
    print("newest article: " + article["title"][:72])
    print("               " + (article["source"] or "unknown source") + " | " + article["published"])
    print("")
    print("response fields on this key:")
    print(
        "  {:<20}{}".format(
            "keywords", "present" if article["keywords"] else "empty on this article"
        )
    )
    for field, present in transform.paid_field_report(raw).items():
        print("  {:<20}{}".format(field, "present" if present else "empty (paid plan field)"))
    print("")
    print(
        "Empty paid fields are expected on the free plan; the templates show a labelled\n"
        "placeholder for them."
    )
    return 0


def cmd_preview(args: argparse.Namespace) -> int:
    articles = collect(args)
    if args.json:
        print(json.dumps(build_payload(args.format, articles, args), indent=2, ensure_ascii=False))
        return 0
    header = "query: " + describe_query(args) + "  |  " + str(len(articles)) + " articles"
    print(transform.render_preview(articles, header=header))
    return 0


def cmd_send(args: argparse.Namespace) -> int:
    articles = collect(args)
    if not articles:
        print("no articles matched - nothing to send")
        return 0

    seen: List[str] = load_seen(args.state) if args.state else []
    known = set(seen)
    fresh = [a for a in articles if a["id"] not in known] if args.state else articles
    if not fresh:
        print("nothing new (" + str(len(articles)) + " fetched, all seen before)")
        return 0

    payload = build_payload(args.format, fresh, args)
    url = args.webhook_url or os.environ.get("WEBHOOK_URL", "")
    if not url:
        print(json.dumps(payload, indent=2, ensure_ascii=False))
        warn("no --webhook-url given: printed the payload instead, state not updated")
        return 0

    ok, detail = post_json(url, payload, timeout=args.timeout)
    if not ok:
        print("delivery failed: " + detail, file=sys.stderr)
        return 1

    print("sent " + str(len(fresh)) + " article(s) to the webhook (" + detail + ")")
    if args.state:
        save_seen(args.state, seen + [a["id"] for a in fresh])
    return 0


def cmd_templates(args: argparse.Namespace) -> int:
    if not TEMPLATE_DIR.is_dir():
        print("no templates/ directory next to run_template.py", file=sys.stderr)
        return 1
    for path in sorted(TEMPLATE_DIR.rglob("*")):
        if path.is_file():
            rel = path.relative_to(ROOT).as_posix()
            note = TEMPLATE_NOTES.get(rel, "")
            print(rel + ("  -  " + note if note else ""))
    print("")
    print("Import the .json blueprint in Make (Scenarios > Create > ... > Import Blueprint).")
    print("Paste the .js file into a Code by Zapier step. Both need your own key filled in.")
    return 0


# --------------------------------------------------------------------------- parser


def add_query_args(parser: argparse.ArgumentParser) -> None:
    parser.add_argument("--q", help="search term, for example: electric vehicles")
    parser.add_argument("--language", default="en", help="language code (default: en)")
    parser.add_argument("--country", help="country code, e.g. us")
    parser.add_argument("--category", help="category, e.g. technology")
    parser.add_argument("--domain", help="restrict to a source domain id")
    parser.add_argument(
        "--limit", type=int, default=10, help="max articles to keep (default: 10)"
    )
    parser.add_argument(
        "--max-pages",
        dest="max_pages",
        type=int,
        default=1,
        help="how many nextPage cursors to follow (default: 1)",
    )
    paid = parser.add_argument_group("paid plan only")
    paid.add_argument(
        "--paid", action="store_true", help="allow paid-only query parameters to be sent"
    )
    paid.add_argument("--timeframe", help="e.g. 6 for the last 6 hours")
    paid.add_argument("--sentiment", choices=("positive", "neutral", "negative"))
    paid.add_argument("--tag", help="AI tag filter")
    paid.add_argument(
        "--full-content", dest="full_content", action="store_true", help="request full content"
    )


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="run_template.py",
        description="Test the newsdata.io query behind the Zapier / Make templates.",
    )
    subparsers = parser.add_subparsers(dest="command")

    check = subparsers.add_parser("check", help="verify the API key and list available fields")
    check.set_defaults(func=cmd_check)

    preview = subparsers.add_parser("preview", help="fetch and print articles")
    add_query_args(preview)
    preview.add_argument("--format", choices=FORMATS, default="text")
    preview.add_argument("--json", action="store_true", help="print the raw payload instead")
    preview.set_defaults(func=cmd_preview)

    send = subparsers.add_parser("send", help="fetch and POST to a webhook")
    add_query_args(send)
    send.add_argument("--format", choices=FORMATS, default="webhook")
    send.add_argument("--webhook-url", dest="webhook_url", help="defaults to $WEBHOOK_URL")
    send.add_argument("--state", help="name of the dedupe file under .state/")
    send.add_argument("--title", help="override the message title")
    send.add_argument("--timeout", type=float, default=20.0)
    send.set_defaults(func=cmd_send)

    templates = subparsers.add_parser("templates", help="list the bundled templates")
    templates.set_defaults(func=cmd_templates)

    return parser


def main(argv=None) -> int:
    parser = build_parser()
    args = parser.parse_args(argv)
    if not getattr(args, "func", None):
        parser.print_help()
        return 0
    try:
        return args.func(args)
    except (MissingApiKey, AuthError) as exc:
        print(str(exc), file=sys.stderr)
        return 2
    except RateLimited as exc:
        print(str(exc), file=sys.stderr)
        return 3
    except NewsdataError as exc:
        print("newsdata.io request failed: " + str(exc), file=sys.stderr)
        return 1
    except KeyboardInterrupt:
        return 130


if __name__ == "__main__":
    sys.exit(main())
