/**
 * Code by Zapier -> Run JavaScript
 *
 * Input Data fields to add in the step (name on the left, value on the right):
 *   apiKey    your newsdata.io API key             (required)
 *   q         search term, e.g. electric vehicles  (optional)
 *   language  two-letter code, e.g. en             (optional)
 *   country   two-letter code, e.g. us             (optional)
 *   category  e.g. technology                      (optional)
 *   domain    source domain id                     (optional)
 *
 * Returns one object per article, so the actions after this step run once per
 * headline. Every object also carries `found` (how many articles came back), so
 * a Filter step set to "found greater than 0" stops empty runs cleanly.
 */

const PAID_PLACEHOLDER = /only available in|upgrade|paid plan/i;

// Paid-plan response fields arrive empty, or as a notice string, on a free key.
// Turn both into an empty string so nothing odd shows up in Slack or a sheet.
function planField(value) {
  if (!value) return '';
  if (Array.isArray(value)) {
    return value
      .filter(
        (item) =>
          typeof item === 'string' &&
          item.trim() &&
          !PAID_PLACEHOLDER.test(item) &&
          item.toLowerCase() !== 'none'
      )
      .join(', ');
  }
  if (typeof value !== 'string') return '';
  const text = value.trim();
  if (!text || text.toLowerCase() === 'none' || PAID_PLACEHOLDER.test(text)) return '';
  return text;
}

function joinList(value) {
  if (Array.isArray(value)) return value.filter(Boolean).join(', ');
  return typeof value === 'string' ? value : '';
}

const apiKey = String(inputData.apiKey || '').trim();
if (!apiKey) {
  throw new Error('Add an Input Data field called apiKey and paste your newsdata.io key into it.');
}

const params = new URLSearchParams({ apikey: apiKey });
['q', 'language', 'country', 'category', 'domain'].forEach((name) => {
  const value = String(inputData[name] || '').trim();
  if (value) params.set(name, value);
});

// A free key caps size at 10. Asking for more fails the whole request, and so do
// timeframe / from_date / to_date / full_content / sentiment / tag / region.
params.set('size', '10');

const response = await fetch('https://newsdata.io/api/1/latest?' + params.toString());

if (response.status === 401) {
  throw new Error('newsdata.io rejected the API key (401). Check the apiKey input field.');
}
if (response.status === 429) {
  throw new Error('newsdata.io rate limit reached (429). Run this Zap on a slower schedule.');
}
if (response.status === 403 || response.status === 422) {
  const detail = (await response.text()).slice(0, 200);
  throw new Error(
    'newsdata.io refused the request (' +
      response.status +
      '). Usually a parameter that needs a paid plan: ' +
      detail
  );
}
if (!response.ok) {
  const detail = (await response.text()).slice(0, 200);
  throw new Error('newsdata.io returned HTTP ' + response.status + ': ' + detail);
}

const body = await response.json();
const results = Array.isArray(body.results) ? body.results : [];

output = results.map((article) => ({
  found: results.length,
  id: article.article_id || article.link || '',
  title: article.title || '(untitled)',
  link: article.link || '',
  description: article.description || '',
  source: article.source_name || article.source_id || '',
  published: article.pubDate || '',
  image: article.image_url || '',
  language: article.language || '',
  country: joinList(article.country),
  category: joinList(article.category),
  // keywords are available on the free plan - good for tags and filters
  keywords: joinList(article.keywords),
  // the rest need a paid plan; they come through as '' until then
  sentiment: planField(article.sentiment),
  ai_tag: planField(article.ai_tag),
  ai_region: planField(article.ai_region),
  ai_org: planField(article.ai_org),
  ai_summary: planField(article.ai_summary),
}));

if (output.length === 0) {
  // Keep the field shape stable so the Filter step can still read `found`.
  output = [{ found: 0, title: '', link: '', message: 'no articles matched this query' }];
}
