"""Turn newsdata.io results into payloads Zapier and Make can consume.

Free API keys leave the paid response fields (sentiment, ai_tag, ai_summary, ...)
empty, or fill them with a notice string such as
"ONLY AVAILABLE IN PROFESSIONAL AND CORPORATE PLANS". Everything here treats
those as missing and renders a labelled empty state rather than breaking or
leaking the notice into a Slack message.
"""

from __future__ import annotations

from datetime import datetime, timezone
from typing import Any, Dict, List, Optional

SENTIMENTS = ("positive", "neutral", "negative")
SENTIMENT_ICON = {"positive": "[+]", "neutral": "[=]", "negative": "[-]"}

MAX_CHIPS = 6
SLACK_MAX_ARTICLES = 20
SLACK_MAX_BLOCKS = 50

PLACEHOLDER_MARKERS = ("only available in", "upgrade", "paid plan")

# Response fields that only carry data on a paid newsdata.io plan.
PAID_FIELDS = (
    "sentiment",
    "sentiment_stats",
    "ai_tag",
    "ai_region",
    "ai_org",
    "ai_summary",
    "content",
)

SHEET_COLUMNS = [
    "published",
    "title",
    "source",
    "link",
    "categories",
    "keywords",
    "sentiment",
    "ai_tags",
    "ai_summary",
]

# Only ever shown when a key returns no sentiment at all, and always labelled.
SAMPLE_BREAKDOWN = {"positive": 8, "neutral": 12, "negative": 5}
SAMPLE_NOTE = "sample - live sentiment requires a paid newsdata.io plan"


def _looks_like_placeholder(text: str) -> bool:
    low = text.strip().lower()
    if low in ("", "none", "null", "n/a"):
        return True
    return any(marker in low for marker in PLACEHOLDER_MARKERS)


def paid_value(value: Any) -> Any:
    """Return the value, or None when the field is not populated on this plan."""
    if value is None:
        return None
    if isinstance(value, str):
        return None if _looks_like_placeholder(value) else value.strip()
    if isinstance(value, (list, tuple)):
        items = [paid_value(item) for item in value]
        items = [item for item in items if item]
        return items or None
    if isinstance(value, dict):
        return value or None
    return value


def text_list(value: Any) -> List[str]:
    """Normalise a string / list / null field into a list of clean strings."""
    if value is None:
        return []
    if isinstance(value, str):
        return [] if _looks_like_placeholder(value) else [value.strip()]
    if isinstance(value, (list, tuple)):
        out: List[str] = []
        for item in value:
            out.extend(text_list(item))
        return out
    return [str(value)]


def _clean_summary(value: Any) -> str:
    summary = paid_value(value)
    if isinstance(summary, (list, tuple)):
        summary = " ".join(str(part) for part in summary)
    if not isinstance(summary, str):
        return ""
    return summary.strip()


def normalize(article: Dict[str, Any]) -> Dict[str, Any]:
    """One raw newsdata.io result -> a predictable dict with no None values."""
    title = (article.get("title") or "").strip() or "(untitled)"
    link = (article.get("link") or "").strip()

    sentiment = paid_value(article.get("sentiment"))
    sentiment = sentiment.lower() if isinstance(sentiment, str) else None
    if sentiment not in SENTIMENTS:
        sentiment = None

    stats = paid_value(article.get("sentiment_stats"))
    if not isinstance(stats, dict):
        stats = None

    return {
        "id": (article.get("article_id") or link or title),
        "title": title,
        "link": link,
        "description": (article.get("description") or "").strip(),
        "source": (article.get("source_name") or article.get("source_id") or "").strip(),
        "source_url": (article.get("source_url") or "").strip(),
        "published": (article.get("pubDate") or "").strip(),
        "image": (article.get("image_url") or "").strip(),
        "language": (article.get("language") or "").strip(),
        "countries": text_list(article.get("country")),
        "categories": text_list(article.get("category")),
        "creators": text_list(article.get("creator")),
        # keywords are on the free plan - the tag chips lean on them
        "keywords": text_list(article.get("keywords"))[:MAX_CHIPS],
        "sentiment": sentiment,
        "sentiment_stats": stats,
        "ai_tags": text_list(paid_value(article.get("ai_tag")))[:MAX_CHIPS],
        "ai_regions": text_list(paid_value(article.get("ai_region")))[:MAX_CHIPS],
        "ai_orgs": text_list(paid_value(article.get("ai_org")))[:MAX_CHIPS],
        "ai_summary": _clean_summary(article.get("ai_summary")),
        "duplicate": bool(article.get("duplicate")),
    }


def normalize_all(articles: Any) -> List[Dict[str, Any]]:
    return [normalize(a) for a in (articles or []) if isinstance(a, dict)]


def paid_field_report(raw_article: Dict[str, Any]) -> Dict[str, bool]:
    """Which paid response fields actually carry data on this key."""
    return {name: paid_value(raw_article.get(name)) is not None for name in PAID_FIELDS}


def chips(article: Dict[str, Any]) -> List[str]:
    """Keyword + AI-tag chips, de-duplicated, keywords first."""
    out = list(article.get("keywords") or [])
    for tag in article.get("ai_tags") or []:
        if tag.lower() not in {c.lower() for c in out}:
            out.append(tag)
    return out[:MAX_CHIPS]


def sentiment_badge(article: Dict[str, Any]) -> str:
    value = article.get("sentiment")
    if not value:
        return ""
    return SENTIMENT_ICON.get(value, "") + " " + value


def sentiment_breakdown(articles: List[Dict[str, Any]]) -> Dict[str, Any]:
    """Counts per sentiment, or a clearly-labelled sample when none are present."""
    counts = {name: 0 for name in SENTIMENTS}
    for article in articles:
        value = article.get("sentiment")
        if value in counts:
            counts[value] += 1

    total = sum(counts.values())
    if total:
        return {
            "live": True,
            "counts": counts,
            "total": total,
            "note": "from " + str(total) + " of " + str(len(articles)) + " articles",
        }
    return {
        "live": False,
        "counts": dict(SAMPLE_BREAKDOWN),
        "total": sum(SAMPLE_BREAKDOWN.values()),
        "note": SAMPLE_NOTE,
    }


def render_breakdown(breakdown: Dict[str, Any], width: int = 20) -> str:
    counts = breakdown["counts"]
    top = max(counts.values()) or 1
    lines = ["sentiment mix (" + breakdown["note"] + ")"]
    for name in SENTIMENTS:
        value = counts.get(name, 0)
        bar = "\u2588" * int(round(value / top * width))
        lines.append("  {:<9}{:<{w}} {:>2}".format(name, bar, value, w=width))
    return "\n".join(lines)


def render_preview(articles: List[Dict[str, Any]], header: Optional[str] = None) -> str:
    """Human-readable dump used by `run_template.py preview`."""
    lines: List[str] = []
    if header:
        lines.append(header)
        lines.append("")

    if not articles:
        lines.append(
            "No articles matched. Try a broader --q, drop --country, or check the spelling."
        )
        return "\n".join(lines)

    for index, article in enumerate(articles, 1):
        lines.append(str(index) + ". " + article["title"])
        meta = " | ".join(x for x in (article["source"], article["published"]) if x)
        if meta:
            lines.append("   " + meta)
        if article["link"]:
            lines.append("   " + article["link"])
        lines.append("   keywords: " + (", ".join(article["keywords"]) or "none listed"))
        badge = sentiment_badge(article) or "n/a (paid field)"
        tags = ", ".join(article["ai_tags"]) or "n/a (paid field)"
        lines.append("   sentiment: " + badge + "   ai tags: " + tags)
        if article["ai_summary"]:
            lines.append("   summary: " + article["ai_summary"][:160])
        lines.append("")

    lines.append(render_breakdown(sentiment_breakdown(articles)))
    return "\n".join(lines)


def _slack_escape(text: str) -> str:
    return text.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")


def slack_payload(
    articles: List[Dict[str, Any]],
    title: str = "Latest headlines",
    context_note: Optional[str] = None,
) -> Dict[str, Any]:
    """Slack Block Kit body. Post it to an incoming webhook as-is."""
    shown = articles[:SLACK_MAX_ARTICLES]
    blocks: List[Dict[str, Any]] = [
        {"type": "header", "text": {"type": "plain_text", "text": title[:150], "emoji": True}}
    ]

    for article in shown:
        headline = _slack_escape(article["title"])
        if article["link"]:
            headline = "*<" + article["link"] + "|" + headline + ">*"
        else:
            headline = "*" + headline + "*"

        body = [headline]
        meta = " \u00b7 ".join(
            x for x in (article["source"], article["published"], sentiment_badge(article)) if x
        )
        if meta:
            body.append(meta)
        blurb = article["ai_summary"] or article["description"]
        if blurb:
            body.append(_slack_escape(blurb[:280]))

        blocks.append(
            {"type": "section", "text": {"type": "mrkdwn", "text": "\n".join(body)[:2900]}}
        )

        tags = chips(article)
        if tags:
            blocks.append(
                {
                    "type": "context",
                    "elements": [
                        {
                            "type": "mrkdwn",
                            "text": " ".join("`" + _slack_escape(t) + "`" for t in tags),
                        }
                    ],
                }
            )

    breakdown = sentiment_breakdown(articles)
    mix = " \u00b7 ".join(
        name + " " + str(breakdown["counts"].get(name, 0)) for name in SENTIMENTS
    )
    blocks.append(
        {
            "type": "context",
            "elements": [
                {"type": "mrkdwn", "text": "sentiment " + mix + "  (" + breakdown["note"] + ")"}
            ],
        }
    )
    blocks.append(
        {
            "type": "context",
            "elements": [{"type": "mrkdwn", "text": context_note or "headlines via newsdata.io"}],
        }
    )

    return {
        "text": title + " (" + str(len(shown)) + " articles)",
        "blocks": blocks[:SLACK_MAX_BLOCKS],
    }


def sheet_row(article: Dict[str, Any]) -> Dict[str, str]:
    return {
        "published": article["published"],
        "title": article["title"],
        "source": article["source"],
        "link": article["link"],
        "categories": ", ".join(article["categories"]),
        "keywords": ", ".join(article["keywords"]),
        "sentiment": article["sentiment"] or "",
        "ai_tags": ", ".join(article["ai_tags"]),
        "ai_summary": article["ai_summary"],
    }


def sheet_rows(articles: List[Dict[str, Any]]) -> List[Dict[str, str]]:
    return [sheet_row(article) for article in articles]


def flat_article(article: Dict[str, Any]) -> Dict[str, Any]:
    """Flat, mapping-friendly object: no nesting, no nulls."""
    row: Dict[str, Any] = dict(sheet_row(article))
    row.update(
        {
            "id": article["id"],
            "description": article["description"],
            "image": article["image"],
            "language": article["language"],
            "countries": ", ".join(article["countries"]),
            "creators": ", ".join(article["creators"]),
            "ai_regions": ", ".join(article["ai_regions"]),
            "ai_orgs": ", ".join(article["ai_orgs"]),
            "has_sentiment": bool(article["sentiment"]),
            "has_ai_fields": bool(article["ai_tags"] or article["ai_summary"]),
        }
    )
    return row


def webhook_payload(
    articles: List[Dict[str, Any]], query: str = "", template: str = ""
) -> Dict[str, Any]:
    """Generic body for a Zapier Catch Hook or a Make custom webhook."""
    breakdown = sentiment_breakdown(articles)
    summary = {"live": breakdown["live"], "note": breakdown["note"]}
    summary.update(breakdown["counts"])
    return {
        "template": template,
        "query": query,
        "source": "newsdata.io",
        "generated_at": datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ"),
        # `found` doubles as the filter field in the Zapier template
        "found": len(articles),
        "count": len(articles),
        "sentiment_breakdown": summary,
        "articles": [flat_article(article) for article in articles],
    }
