# newsdata-zapier-make-templates

Drop-in Zapier and Make (Integromat) steps that push newsdata.io headlines into Slack, a
Google Sheet, or any webhook — plus a small Python CLI for sanity-checking the query
before you wire it into a scenario.

Articles come from the newsdata.io news API (https://newsdata.io); a free API key covers
everything on the default path.

## Contents

| Path | What it is |
| --- | --- |
| `templates/zapier/code_step.js` | Code by Zapier (JavaScript) step: calls `/latest`, flattens each article for the next action |
| `templates/make/slack-alert.blueprint.json` | Importable Make scenario: HTTP GET → iterator → POST to a Slack incoming webhook |
| `run_template.py` | CLI with four commands: `check`, `preview`, `send`, `templates` |
| `transform.py` | The payload shapes (Slack Block Kit, sheet rows, generic webhook JSON) |
| `newsdata_client.py` | The HTTP layer: auth, pagination, 401/429/403 handling |

## Why there is code in a no-code repo

Building the scenario in the browser and *then* discovering the query returns `422` or an
empty `results` array is the slow way round. `run_template.py` fires the same request the
Zap or Make module will fire, prints what came back, and can dump the finished payload as
JSON so field mapping in the visual editor is a copy-paste job.

## Setup

Python 3.8 or newer.

```bash
git clone https://github.com/YOUR-USERNAME/newsdata-zapier-make-templates.git
cd newsdata-zapier-make-templates
python3 -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt
export NEWSDATA_API_KEY="your-key-here"
```

The key is read from `NEWSDATA_API_KEY` and sent as an `X-ACCESS-KEY` header, so it never
shows up in a URL or a log line. Get one from https://newsdata.io — the free tier is
enough to run every command below.

## Checking the key

```console
$ python run_template.py check
key accepted by newsdata.io
totalResults on a bare /latest call: 148291
newest article: Grid operators warn of tight evening margins as the heatwave holds
               Reuters | 2026-08-31 08:05:00

response fields on this key:
  keywords            present
  sentiment           empty (paid plan field)
  sentiment_stats     empty (paid plan field)
  ai_tag              empty (paid plan field)
  ai_region           empty (paid plan field)
  ai_org              empty (paid plan field)
  ai_summary          empty (paid plan field)
  content             empty (paid plan field)

Empty paid fields are expected on the free plan; the templates show a labelled
placeholder for them.
```

## Previewing a query

```console
$ python run_template.py preview --q "electric vehicles" --limit 3
query: q=electric vehicles language=en  |  3 articles

1. Ford delays its next-generation electric truck to 2028
   Reuters | 2026-08-31 06:12:00
   https://www.reuters.com/business/autos-transportation/ford-delays-truck
   keywords: ford, electric vehicles, ev production
   sentiment: n/a (paid field)   ai tags: n/a (paid field)

2. China's EV price war spills into the used-car market
   Nikkei Asia | 2026-08-31 05:40:00
   https://asia.nikkei.com/business/automobiles/ev-price-war-used-cars
   keywords: china, ev, used cars, byd
   sentiment: n/a (paid field)   ai tags: n/a (paid field)

3. Norway crosses 95% share of new cars sold as electric
   The Guardian | 2026-08-31 04:58:00
   https://www.theguardian.com/environment/2026/aug/31/norway-ev-share
   keywords: norway, electric vehicles, policy
   sentiment: n/a (paid field)   ai tags: n/a (paid field)

sentiment mix (sample - live sentiment requires a paid newsdata.io plan)
  positive █████████████         8
  neutral  ████████████████████ 12
  negative ████████              5
```

The keyword line is real free-plan data. The sentiment bar is drawn from sample counts
and says so; on a paid key it switches to the real per-article `sentiment` values and the
caption changes to `from 7 of 10 articles`.

To get the exact JSON your scenario will receive:

```bash
python run_template.py preview --q bitcoin --format webhook --json > sample-payload.json
```

Paste that into Make's *Run once* input or Zapier's test payload and every field lines up
for mapping.

## Sending it somewhere

```console
$ python run_template.py send --q "electric vehicles" --format slack --state ev-desk \
    --webhook-url "$SLACK_WEBHOOK_URL"
sent 4 article(s) to the webhook (HTTP 200 ok)
```

- `--format` is one of `slack` (Block Kit), `sheets` (`{columns, rows}`), `webhook`
  (flat article objects), `text` (`{text}`).
- `--state ev-desk` records article ids in `.state/ev-desk.json`, so a repeat run only
  sends what is new. State is written only after a successful delivery.
- With no `--webhook-url` (and no `WEBHOOK_URL` env var) the payload is printed and state
  is left untouched — a dry run.

A Slack incoming webhook, a Zapier *Catch Hook*, and a Make *Custom webhook* all accept
the same POST, so this doubles as the trigger for either platform if you would rather run
the fetch on your own box.

## Wiring it into Zapier

1. New Zap, trigger **Schedule by Zapier** (hourly is comfortable on a free key).
2. Action → **Code by Zapier → Run JavaScript**.
3. Under *Input Data* add `apiKey` (your key), `q` (search term), `language` (`en`).
4. Paste `templates/zapier/code_step.js` into the code box and run the test.
5. Action → **Filter by Zapier**: continue only if `found` is greater than `0`.
6. Action → Slack *Send Channel Message*, or Google Sheets *Create Spreadsheet Row*, and
   map `title`, `link`, `source`, `published`, `keywords`.

The code step returns one object per article, so steps 5 and 6 run once per headline.
`sentiment`, `ai_tag` and `ai_summary` are returned as fields too — they map like anything
else and arrive as empty strings on a free key.

If you would rather avoid the code step entirely, **Webhooks by Zapier → GET** against
`https://newsdata.io/api/1/latest` with query params `apikey`, `q`, `language`, `size=10`
works, but you then map from `results__0__title`, `results__1__title`, … one index at a
time. That awkwardness is the reason the code step exists.

## Wiring it into Make

1. Scenarios → *Create a new scenario* → the ⋯ menu → **Import Blueprint**, and upload
   `templates/make/slack-alert.blueprint.json`.
2. Open module 1 and replace `PUT_YOUR_NEWSDATA_API_KEY_HERE` in the `X-ACCESS-KEY`
   header.
3. Open module 3 and replace `PUT_YOUR_SLACK_INCOMING_WEBHOOK_URL_HERE`.
4. Edit the `q` / `language` query strings in module 1, then hit **Run once**.
5. Schedule the scenario at 15 minutes or slower.

Module 2 is an iterator over `results`, so module 3 runs once per article. Make's importer
occasionally rejects a module version from an older blueprint; if that happens, delete the
complaining module and add HTTP → *Make a request* manually with the same settings shown
in the file.

For de-duplication inside Make, add a Data Store keyed on `article_id` between the
iterator and the Slack post; the CLI's `--state` flag does the same thing locally.

## Paid-plan configuration

Nothing here requires a paid plan. Two things change if you have one:

- The response fields `sentiment`, `sentiment_stats`, `ai_tag`, `ai_region`, `ai_org` and
  `ai_summary` start arriving with values. The Slack blocks, sheet rows and sentiment bar
  pick them up on their own — no configuration.
- The query parameters `timeframe`, `sentiment`, `tag` and `full_content` become usable.
  They break the request on a free key, so the CLI only sends them when you ask:

  ```bash
  ENABLE_PAID_PARAMS=1 python run_template.py preview --q bitcoin --timeframe 6 --sentiment negative
  ```

  or per-run with `--paid`. If the API refuses them anyway, the request is retried once
  without them and a warning goes to stderr, so you still get results.

## Environment variables

| Variable | Purpose |
| --- | --- |
| `NEWSDATA_API_KEY` | Required. Your newsdata.io key. |
| `WEBHOOK_URL` | Default target for `send` when `--webhook-url` is omitted. |
| `ENABLE_PAID_PARAMS` | `1` to allow paid-only query parameters. |
| `NEWSDATA_STATE_DIR` | Where dedupe state lives. Defaults to `.state/`. |

## Exit codes

`0` fine · `1` API or delivery error · `2` missing or rejected key · `3` rate limited.
Useful if you run `send` from cron and want the failure to be visible.

## Free-tier things worth knowing

- `size` is capped at 10 per request; the CLI clamps `--limit` accordingly and pages with
  the `nextPage` cursor when you pass `--max-pages 2` or more.
- Paid response fields sometimes come back as the string
  `ONLY AVAILABLE IN PROFESSIONAL AND CORPORATE PLANS` rather than `null`. Both the Python
  and the JavaScript template treat that as "missing" so the placeholder text shows up
  instead of a notice string leaking into your Slack message.
- `/archive` and `/count` need a paid plan and are not used anywhere in this repo.
- Rate limits on a free key are per 15 minutes; a scenario running every 15 minutes with a
  single request is fine, one running every minute is not.

## License

MIT.
