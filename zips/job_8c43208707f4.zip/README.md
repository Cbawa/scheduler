# News Persona Feed

A small React app that builds a personalized news feed from interests you define.
Add a few topics (say "space", "elections", "football"), optionally pick a category
and language, and the app pulls matching headlines from the
[newsdata.io](https://newsdata.io) news API. Your persona is saved in the browser's
localStorage, so the feed is the same the next time you open it — there's no account
and no backend.

Grab a free newsdata.io API key to run it.

## Features

- Define a persona: a list of interest keywords plus an optional category and language.
- Preferences persist in `localStorage` — no sign-in, no server.
- Latest headlines from the newsdata.io `/latest` endpoint, with "Load more" pagination
  driven by the API's `nextPage` cursor.
- Per-article keyword tags (available on the free tier).
- Sentiment badges, AI-tag chips and an AI summary line per article when your key returns them.
- A sentiment breakdown for the current feed.

## Requirements

- Node.js 18 or newer.
- A newsdata.io API key. The free tier is enough — sign up at https://newsdata.io and copy your key.

## Setup

```bash
git clone <this-repo>
cd news-persona-feed
npm install
cp .env.example .env
```

Open `.env` and set your key:

```
VITE_NEWSDATA_API_KEY=pub_xxxxxxxxxxxxxxxxxxxxxxxx
```

Vite only exposes variables prefixed with `VITE_` to the browser, which is why the
variable uses that name. Because this is a client-side app, the key is included in the
built bundle — fine for local use or a personal deploy, but don't treat it as a secret.
If you need to keep it private, put a small proxy in front of the API.

## Run

```bash
npm run dev
```

Open the URL Vite prints (usually http://localhost:5173).

Production build:

```bash
npm run build
npm run preview
```

## Usage

1. In the sidebar, add a few interests — for example `ai`, `climate`, `space`.
2. Optionally choose a category and a language.
3. Click **Save & refresh feed**.

The feed reloads with headlines matching `ai OR climate OR space`. Each card shows the
source, date and keyword tags, plus a sentiment badge and AI tags when your key provides
them.

A trimmed example of an article the API returns:

```json
{
  "title": "Researchers map a new climate feedback loop",
  "link": "https://example.com/article",
  "source_name": "Example Science",
  "pubDate": "2026-06-11 09:30:00",
  "keywords": ["climate", "research", "oceans"],
  "sentiment": "neutral",
  "ai_tag": ["science"]
}
```

On a free key, `sentiment`, `ai_tag` and `ai_summary` come back empty; the app hides
those parts and keeps the keyword tags. The sentiment chart shows a clearly-labeled
sample until your key returns real sentiment values.

## Notes on the free tier

The app only sends parameters that work on a free newsdata.io key (`q`, `category`,
`language`, and the `page` cursor), so the core flow works with a brand-new free key.
It does not send paid-only query parameters such as `sentiment=`, `from_date=`, or
`timeframe=`.

The richer response fields — `sentiment`, `ai_tag`, `ai_region`, `ai_org`, `ai_summary` —
are read straight from each article when present. They require a paid newsdata.io plan;
without one they're simply absent, and the UI falls back to the free fields.

## How it works

- `src/api.js` builds the request, joins interests into a single `q` expression, and maps
  HTTP/API errors (invalid key, rate limit, parse failure) to clear messages.
- `src/App.jsx` holds the persona state, reads and writes `localStorage`, and renders the feed.
- Pagination uses the `nextPage` cursor returned by the API, passed back as `page`, and stops
  when it is `null`.

## License

MIT
