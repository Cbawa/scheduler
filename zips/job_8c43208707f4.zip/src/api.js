// Thin wrapper around the newsdata.io news API (https://newsdata.io).
// Only free-tier-safe parameters are sent, so a brand-new free key works.

const BASE_URL = 'https://newsdata.io/api/1'
const API_KEY = import.meta.env.VITE_NEWSDATA_API_KEY

export class NewsApiError extends Error {
  constructor(code, message) {
    super(message)
    this.name = 'NewsApiError'
    this.code = code
  }
}

export function hasApiKey() {
  return Boolean(API_KEY && String(API_KEY).trim() && API_KEY !== 'your_api_key_here')
}

// Turn a list of interests into a single q expression, e.g. ["ai","space"] -> "ai OR space".
// Multi-word interests are quoted. The free tier caps q at 100 characters.
export function buildQuery(interests) {
  const cleaned = (interests || []).map((s) => String(s).trim()).filter(Boolean)
  if (cleaned.length === 0) return ''
  const expr = cleaned.map((s) => (s.includes(' ') ? `"${s}"` : s)).join(' OR ')
  return expr.slice(0, 100)
}

export async function fetchFeed({ interests = [], category = '', language = 'en', page = null } = {}) {
  if (!hasApiKey()) {
    throw new NewsApiError('no-key', 'Missing API key. Set VITE_NEWSDATA_API_KEY in your .env file.')
  }

  const params = new URLSearchParams()
  params.set('apikey', API_KEY)
  const q = buildQuery(interests)
  if (q) params.set('q', q)
  if (category) params.set('category', category)
  if (language) params.set('language', language)
  if (page) params.set('page', page)

  let res
  try {
    res = await fetch(`${BASE_URL}/latest?${params.toString()}`)
  } catch {
    throw new NewsApiError('network', 'Network error — check your connection and try again.')
  }

  if (res.status === 401) {
    throw new NewsApiError('unauthorized', 'Invalid API key (401). Double-check VITE_NEWSDATA_API_KEY.')
  }
  if (res.status === 429) {
    throw new NewsApiError('rate-limit', 'Rate limit reached (429). Wait a moment and try again.')
  }

  let data
  try {
    data = await res.json()
  } catch {
    throw new NewsApiError('bad-response', 'Could not read the API response.')
  }

  if (!res.ok || data.status === 'error') {
    const raw = data && data.results && data.results.message ? data.results.message : data && data.message
    const message = typeof raw === 'string' ? raw : `Request failed (${res.status}).`
    throw new NewsApiError('api-error', message)
  }

  return {
    articles: Array.isArray(data.results) ? data.results : [],
    nextPage: data.nextPage || null,
    totalResults: typeof data.totalResults === 'number' ? data.totalResults : null,
  }
}
