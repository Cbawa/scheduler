import { useEffect, useState } from 'react'
import { fetchFeed, hasApiKey, NewsApiError } from './api.js'

const STORAGE_KEY = 'news-persona-feed:persona'

const CATEGORIES = [
  '', 'business', 'entertainment', 'environment', 'food', 'health',
  'politics', 'science', 'sports', 'technology', 'top', 'world',
]

const LANGUAGES = [
  ['en', 'English'], ['es', 'Spanish'], ['fr', 'French'], ['de', 'German'],
  ['hi', 'Hindi'], ['pt', 'Portuguese'], ['ar', 'Arabic'], ['it', 'Italian'],
]

const DEFAULT_PERSONA = {
  name: 'My Feed',
  interests: ['technology', 'climate'],
  category: '',
  language: 'en',
}

function loadPersona() {
  try {
    const raw = localStorage.getItem(STORAGE_KEY)
    if (!raw) return DEFAULT_PERSONA
    const p = JSON.parse(raw)
    return {
      name: typeof p.name === 'string' && p.name.trim() ? p.name : DEFAULT_PERSONA.name,
      interests: Array.isArray(p.interests) ? p.interests.filter((x) => typeof x === 'string') : [],
      category: typeof p.category === 'string' ? p.category : '',
      language: typeof p.language === 'string' ? p.language : 'en',
    }
  } catch {
    return DEFAULT_PERSONA
  }
}

function toList(v) {
  if (Array.isArray(v)) return v.filter((x) => typeof x === 'string' && x.trim())
  if (typeof v === 'string' && v.trim()) return [v.trim()]
  return []
}

// Paid response fields are absent on a free key; some endpoints return a
// placeholder string instead of null. Treat both as empty.
function cleanText(v) {
  if (typeof v !== 'string') return ''
  const t = v.trim()
  if (!t || t.toUpperCase().includes('ONLY AVAILABLE')) return ''
  return t
}

function cleanList(v) {
  return toList(v).filter((x) => !x.toUpperCase().includes('ONLY AVAILABLE'))
}

function fmtDate(s) {
  if (!s) return ''
  const d = new Date(String(s).replace(' ', 'T') + 'Z')
  if (Number.isNaN(d.getTime())) return s
  return d.toLocaleDateString(undefined, { month: 'short', day: 'numeric', year: 'numeric' })
}

function sentimentBreakdown(articles) {
  const counts = { positive: 0, neutral: 0, negative: 0 }
  let withData = 0
  for (const a of articles) {
    const s = (a.sentiment || '').toLowerCase()
    if (s in counts) {
      counts[s] += 1
      withData += 1
    }
  }
  return { counts, withData }
}

const SAMPLE_SENTIMENT = { positive: 6, neutral: 11, negative: 3 }

function SentimentChart({ articles }) {
  const { counts, withData } = sentimentBreakdown(articles)
  const isSample = withData === 0
  const data = isSample ? SAMPLE_SENTIMENT : counts
  const total = data.positive + data.neutral + data.negative || 1
  const rows = [
    ['positive', '#2e7d57'],
    ['neutral', '#64748b'],
    ['negative', '#c0392b'],
  ]
  return (
    <section className="panel">
      <h2 className="panel-title">Sentiment mix</h2>
      <div className="sentiment-chart">
        {rows.map(([key, color]) => {
          const value = data[key]
          const pct = Math.round((value / total) * 100)
          return (
            <div className="sent-row" key={key}>
              <span className="sent-label">{key}</span>
              <div className="sent-track">
                <div className="sent-fill" style={{ width: pct + '%', background: color }} />
              </div>
              <span className="sent-pct">{pct}%</span>
            </div>
          )
        })}
      </div>
      {isSample ? (
        <p className="caption">
          Sample data — live sentiment requires a paid newsdata.io plan. Real values appear here
          automatically when your key returns them.
        </p>
      ) : (
        <p className="caption">Based on {withData} article{withData === 1 ? '' : 's'} in this feed.</p>
      )}
    </section>
  )
}

function ArticleCard({ article }) {
  const title = cleanText(article.title) || 'Untitled'
  const link = article.link || article.source_url || '#'
  const source = cleanText(article.source_name) || cleanText(article.source_id) || 'Unknown source'
  const date = fmtDate(article.pubDate)
  const image = article.image_url
  const summary = cleanText(article.ai_summary)
  const description = cleanText(article.description)
  const sentiment = (article.sentiment || '').toLowerCase()
  const validSentiment = ['positive', 'neutral', 'negative'].includes(sentiment) ? sentiment : ''
  const aiTags = cleanList(article.ai_tag).slice(0, 5)
  const keywords = cleanList(article.keywords).slice(0, 6)

  return (
    <article className="card">
      {image && (
        <img
          className="card-img"
          src={image}
          alt=""
          loading="lazy"
          onError={(e) => {
            e.currentTarget.style.display = 'none'
          }}
        />
      )}
      <div className="card-body">
        <div className="card-meta">
          <span className="source">{source}</span>
          {date && <span className="meta-date">{date}</span>}
          {validSentiment && <span className={'badge sent-' + validSentiment}>{validSentiment}</span>}
        </div>
        <h3 className="card-title">
          <a href={link} target="_blank" rel="noreferrer">{title}</a>
        </h3>
        {summary ? (
          <p className="card-text">{summary}</p>
        ) : (
          description && <p className="card-text">{description}</p>
        )}
        {aiTags.length > 0 && (
          <div className="chips">
            {aiTags.map((t) => (
              <span className="chip chip-ai" key={t}>{t}</span>
            ))}
          </div>
        )}
        {keywords.length > 0 && (
          <div className="chips">
            {keywords.map((k) => (
              <span className="chip" key={k}>#{k}</span>
            ))}
          </div>
        )}
      </div>
    </article>
  )
}

function PersonaEditor({ persona, onSave }) {
  const [draft, setDraft] = useState(persona)
  const [input, setInput] = useState('')

  function addInterest(e) {
    e.preventDefault()
    const v = input.trim().toLowerCase()
    if (!v || draft.interests.includes(v) || draft.interests.length >= 8) {
      setInput('')
      return
    }
    setDraft({ ...draft, interests: [...draft.interests, v] })
    setInput('')
  }

  function removeInterest(name) {
    setDraft({ ...draft, interests: draft.interests.filter((i) => i !== name) })
  }

  return (
    <section className="panel">
      <h2 className="panel-title">Your persona</h2>

      <label className="field">
        <span>Feed name</span>
        <input
          type="text"
          value={draft.name}
          onChange={(e) => setDraft({ ...draft, name: e.target.value })}
          placeholder="My Feed"
        />
      </label>

      <div className="field">
        <span>Interests</span>
        <div className="chips editable">
          {draft.interests.length === 0 && (
            <span className="muted">No interests yet — add a few below.</span>
          )}
          {draft.interests.map((i) => (
            <button type="button" className="chip removable" key={i} onClick={() => removeInterest(i)}>
              {i} ×
            </button>
          ))}
        </div>
        <form className="add-row" onSubmit={addInterest}>
          <input
            type="text"
            value={input}
            onChange={(e) => setInput(e.target.value)}
            placeholder="e.g. space, elections, football"
          />
          <button type="submit">Add</button>
        </form>
      </div>

      <label className="field">
        <span>Category (optional)</span>
        <select value={draft.category} onChange={(e) => setDraft({ ...draft, category: e.target.value })}>
          {CATEGORIES.map((c) => (
            <option key={c || 'any'} value={c}>{c ? c : 'Any'}</option>
          ))}
        </select>
      </label>

      <label className="field">
        <span>Language</span>
        <select value={draft.language} onChange={(e) => setDraft({ ...draft, language: e.target.value })}>
          {LANGUAGES.map(([code, label]) => (
            <option key={code} value={code}>{label}</option>
          ))}
        </select>
      </label>

      <button className="primary" type="button" onClick={() => onSave(draft)}>
        Save &amp; refresh feed
      </button>
    </section>
  )
}

export default function App() {
  const [persona, setPersona] = useState(loadPersona)
  const [articles, setArticles] = useState([])
  const [nextPage, setNextPage] = useState(null)
  const [total, setTotal] = useState(null)
  const [loading, setLoading] = useState(false)
  const [loadingMore, setLoadingMore] = useState(false)
  const [error, setError] = useState(null)
  const keyMissing = !hasApiKey()

  useEffect(() => {
    if (keyMissing) return
    let cancelled = false
    setLoading(true)
    setError(null)
    setArticles([])
    fetchFeed({
      interests: persona.interests,
      category: persona.category,
      language: persona.language,
      page: null,
    })
      .then((res) => {
        if (cancelled) return
        setArticles(res.articles)
        setNextPage(res.nextPage)
        setTotal(res.totalResults)
      })
      .catch((err) => {
        if (cancelled) return
        setError(err instanceof NewsApiError ? err.message : 'Something went wrong.')
        setNextPage(null)
        setTotal(null)
      })
      .finally(() => {
        if (!cancelled) setLoading(false)
      })
    return () => {
      cancelled = true
    }
  }, [persona, keyMissing])

  async function loadMore() {
    if (!nextPage || loadingMore) return
    setLoadingMore(true)
    setError(null)
    try {
      const res = await fetchFeed({
        interests: persona.interests,
        category: persona.category,
        language: persona.language,
        page: nextPage,
      })
      setArticles((prev) => [...prev, ...res.articles])
      setNextPage(res.nextPage)
    } catch (err) {
      setError(err instanceof NewsApiError ? err.message : 'Something went wrong.')
    } finally {
      setLoadingMore(false)
    }
  }

  function savePersona(next) {
    const cleaned = {
      ...next,
      name: next.name.trim() || 'My Feed',
      interests: next.interests.map((i) => i.trim().toLowerCase()).filter(Boolean),
    }
    setPersona(cleaned)
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(cleaned))
    } catch {
      /* localStorage may be unavailable; the feed still works for this session. */
    }
  }

  return (
    <div className="app">
      <header className="topbar">
        <h1>News Persona Feed</h1>
        <p className="tagline">Headlines tuned to the interests you save.</p>
      </header>

      {keyMissing && (
        <div className="banner error">
          Set <code>VITE_NEWSDATA_API_KEY</code> in a <code>.env</code> file (copy{' '}
          <code>.env.example</code>) and restart the dev server. A free newsdata.io key works.
        </div>
      )}

      <div className="layout">
        <aside className="sidebar">
          <PersonaEditor persona={persona} onSave={savePersona} />
          <SentimentChart articles={articles} />
        </aside>

        <main className="feed">
          <div className="feed-head">
            <h2>{persona.name}</h2>
            {total != null && <span className="muted">{total} matching articles</span>}
          </div>

          {error && <div className="banner error">{error}</div>}

          {loading && <div className="state">Loading your feed…</div>}

          {!loading && !error && articles.length === 0 && !keyMissing && (
            <div className="state">
              No articles matched this persona. Try broadening your interests or clearing the category.
            </div>
          )}

          <div className="cards">
            {articles.map((a, idx) => (
              <ArticleCard key={(a.article_id || a.link || 'a') + idx} article={a} />
            ))}
          </div>

          {nextPage && !loading && (
            <button className="primary load-more" type="button" onClick={loadMore} disabled={loadingMore}>
              {loadingMore ? 'Loading…' : 'Load more'}
            </button>
          )}
        </main>
      </div>

      <footer className="footer">
        <p>
          News data from the{' '}
          <a href="https://newsdata.io" target="_blank" rel="noreferrer">newsdata.io</a> news API.
          Preferences are stored in your browser&apos;s localStorage.
        </p>
      </footer>
    </div>
  )
}
