#!/usr/bin/env python3
"""newsdata-openai-realtime — voice-driven news queries and briefings.

Headlines come from the newsdata.io news API; the optional `ask` and `voice`
commands drive a conversation through the OpenAI Realtime API, which calls
newsdata.io as a tool.
"""
import argparse
import os
import sys

import display
from newsdata_client import (
    AuthError,
    MissingKeyError,
    NewsdataClient,
    NewsdataError,
    RateLimitError,
)


def cmd_headlines(args):
    if args.paid:
        os.environ["ENABLE_PAID_PARAMS"] = "1"
    client = NewsdataClient()
    articles = list(
        client.iter_articles(
            max_articles=args.max,
            query=args.query,
            country=args.country,
            language=args.language,
            category=args.category,
        )
    )
    if not articles:
        print("No articles found for that query.")
        return 0
    for i, art in enumerate(articles, 1):
        print(display.render_article(i, art))
        print()
    print(display.sentiment_breakdown(articles))
    return 0


def cmd_ask(args):
    from realtime import ask_once

    prompt = " ".join(args.prompt).strip()
    if not prompt:
        print('Provide a question, e.g. ask "what is happening with bitcoin"')
        return 2
    ask_once(prompt, speak=args.speak)
    return 0


def cmd_voice(args):
    from realtime import voice_loop

    voice_loop()
    return 0


def build_parser():
    parser = argparse.ArgumentParser(
        prog="newsdata-openai-realtime",
        description="Voice-driven news queries and briefings backed by newsdata.io.",
    )
    sub = parser.add_subparsers(dest="command")

    h = sub.add_parser("headlines", help="Print latest headlines (no OpenAI key needed).")
    h.add_argument("-q", "--query", help="Keywords to search for.")
    h.add_argument("-c", "--country", help="2-letter country code, e.g. us.")
    h.add_argument("-l", "--language", default="en", help="2-letter language code (default en).")
    h.add_argument("--category", help="Category, e.g. business, technology.")
    h.add_argument("-n", "--max", type=int, default=10, help="Max articles to show (default 10).")
    h.add_argument("--paid", action="store_true", help="Allow paid-only query params (paid plan).")
    h.set_defaults(func=cmd_headlines)

    a = sub.add_parser("ask", help="Ask a question; answered via the OpenAI Realtime API.")
    a.add_argument("prompt", nargs="+", help="The question to ask.")
    a.add_argument("--speak", action="store_true", help="Play the spoken audio answer.")
    a.set_defaults(func=cmd_ask)

    v = sub.add_parser("voice", help="Live microphone conversation (needs sounddevice).")
    v.set_defaults(func=cmd_voice)
    return parser


def main():
    parser = build_parser()
    args = parser.parse_args()
    if not getattr(args, "func", None):
        parser.print_help()
        return 1
    try:
        return args.func(args)
    except (MissingKeyError, AuthError) as exc:
        print(exc, file=sys.stderr)
        return 2
    except RateLimitError as exc:
        print(exc, file=sys.stderr)
        return 1
    except NewsdataError as exc:
        print(f"newsdata.io error: {exc}", file=sys.stderr)
        return 1
    except RuntimeError as exc:
        print(exc, file=sys.stderr)
        return 2
    except KeyboardInterrupt:
        print()
        return 130


if __name__ == "__main__":
    sys.exit(main())
