"""Client for the newsdata.io news API.

The API key is read from NEWSDATA_API_KEY. Only free-tier query parameters are
sent by default; paid-only query parameters are sent only when paid mode is
enabled and are automatically dropped (with one retry) if the API rejects them.
Paid *response* fields (sentiment, ai_*, ...) are simply read from each result
when present, so they are safe to request on a free key.
"""
from __future__ import annotations

import os
import time

import requests

BASE_URL = "https://newsdata.io/api/1"
DEFAULT_TIMEOUT = 30


class NewsdataError(Exception):
    """Base error for newsdata.io problems."""


class MissingKeyError(NewsdataError):
    """Raised when NEWSDATA_API_KEY is not set."""


class AuthError(NewsdataError):
    """Raised on a 401 from the API."""


class RateLimitError(NewsdataError):
    """Raised on a 429 from the API."""


class PaidParamError(NewsdataError):
    """Raised when the API rejects a request that used a paid-only parameter."""


def _truthy(value):
    return (value or "").strip().lower() in ("1", "true", "yes", "on")


class NewsdataClient:
    def __init__(self, api_key=None, timeout=DEFAULT_TIMEOUT, paid_mode=None):
        self.api_key = api_key or os.environ.get("NEWSDATA_API_KEY")
        if not self.api_key:
            raise MissingKeyError(
                "NEWSDATA_API_KEY is not set. Create a free key at "
                "https://newsdata.io and export NEWSDATA_API_KEY."
            )
        self.timeout = timeout
        if paid_mode is None:
            paid_mode = _truthy(os.environ.get("ENABLE_PAID_PARAMS"))
        self.paid_mode = paid_mode
        self.session = requests.Session()

    def _request(self, endpoint, params):
        query = {k: v for k, v in params.items() if v is not None and v != ""}
        query["apikey"] = self.api_key
        url = f"{BASE_URL}/{endpoint}"
        try:
            resp = self.session.get(url, params=query, timeout=self.timeout)
        except requests.RequestException as exc:
            raise NewsdataError(f"Network error talking to newsdata.io: {exc}") from exc

        if resp.status_code == 401:
            raise AuthError("newsdata.io rejected the API key (401). Check NEWSDATA_API_KEY.")
        if resp.status_code == 429:
            raise RateLimitError("Rate limit reached (429). Wait a moment and try again.")
        if resp.status_code in (403, 422):
            raise PaidParamError(
                f"newsdata.io rejected the request ({resp.status_code}); "
                "likely a paid-only parameter used on a free key."
            )

        try:
            payload = resp.json()
        except ValueError as exc:
            raise NewsdataError(
                f"Unexpected non-JSON response ({resp.status_code})."
            ) from exc

        if isinstance(payload, dict) and payload.get("status") == "error":
            message = ""
            results = payload.get("results")
            if isinstance(results, dict):
                message = results.get("message", "")
            raise NewsdataError(message or "newsdata.io returned an error.")
        return payload

    def fetch(self, endpoint, free_params=None, paid_params=None):
        """Fetch one page. Paid params are only sent in paid mode, and the
        request is retried once without them if the API rejects them."""
        free_params = free_params or {}
        paid_params = paid_params or {}
        params = dict(free_params)
        sent_paid = False
        if self.paid_mode and paid_params:
            params.update({k: v for k, v in paid_params.items() if v is not None})
            sent_paid = True
        try:
            return self._request(endpoint, params)
        except PaidParamError:
            if sent_paid:
                return self._request(endpoint, free_params)
            raise

    def latest(self, query=None, country=None, language=None, category=None, page=None):
        free = {
            "q": query,
            "country": country,
            "language": language,
            "category": category,
            "page": page,
        }
        paid = {}
        if _truthy(os.environ.get("ENABLE_FULL_CONTENT")):
            paid["full_content"] = 1
        return self.fetch("latest", free, paid)

    def iter_articles(self, max_articles=20, **kwargs):
        """Yield up to ``max_articles`` results, following the nextPage cursor."""
        collected = 0
        page = kwargs.pop("page", None)
        while True:
            payload = self.latest(page=page, **kwargs)
            results = payload.get("results") or []
            for article in results:
                yield article
                collected += 1
                if collected >= max_articles:
                    return
            page = payload.get("nextPage")
            if not page:
                return
            time.sleep(0.3)
