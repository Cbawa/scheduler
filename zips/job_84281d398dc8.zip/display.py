"""Terminal rendering for newsdata.io articles.

Paid response fields (sentiment, ai_tag, ai_summary, ...) are absent on a free
key, so every accessor falls back to a clearly labelled placeholder instead of
crashing or leaving an empty widget.
"""
from __future__ import annotations

RESET = "\033[0m"
BOLD = "\033[1m"
DIM = "\033[2m"
GREEN = "\033[32m"
RED = "\033[31m"
YELLOW = "\033[33m"
CYAN = "\033[36m"
GREY = "\033[90m"

SENTIMENT_COLORS = {"positive": GREEN, "neutral": YELLOW, "negative": RED}


def _as_list(value):
    if not value:
        return []
    if isinstance(value, list):
        return [str(v) for v in value if v]
    return [str(value)]


def sentiment_badge(article):
    sentiment = article.get("sentiment")
    if not sentiment:
        return f"{GREY}[sentiment n/a]{RESET}"
    color = SENTIMENT_COLORS.get(str(sentiment).lower(), CYAN)
    return f"{color}[{sentiment}]{RESET}"


def keyword_chips(article, limit=6):
    keywords = _as_list(article.get("keywords"))[:limit]
    if not keywords:
        return f"{GREY}(no keywords){RESET}"
    return " ".join(f"{CYAN}#{kw}{RESET}" for kw in keywords)


def ai_chips(article):
    parts = []
    for label, key in (("tag", "ai_tag"), ("region", "ai_region"), ("org", "ai_org")):
        for item in _as_list(article.get(key)):
            if item and item.lower() != "null":
                parts.append(f"{label}:{item}")
    if not parts:
        return f"{GREY}ai tags require a paid newsdata.io plan{RESET}"
    return " ".join(f"{YELLOW}<{p}>{RESET}" for p in parts)


def render_article(index, article):
    title = article.get("title") or "(untitled)"
    source = article.get("source_id") or "unknown source"
    published = article.get("pubDate") or ""
    link = article.get("link") or ""
    lines = [f"{BOLD}{index}. {title}{RESET} {sentiment_badge(article)}"]
    lines.append(f"   {DIM}{source} \u00b7 {published}{RESET}")
    summary = article.get("ai_summary") or article.get("description")
    if summary:
        text = " ".join(str(summary).split())
        if len(text) > 220:
            text = text[:217] + "..."
        lines.append(f"   {text}")
    else:
        lines.append(f"   {GREY}(no summary available){RESET}")
    lines.append(f"   {keyword_chips(article)}")
    lines.append(f"   {ai_chips(article)}")
    if link:
        lines.append(f"   {DIM}{link}{RESET}")
    return "\n".join(lines)


def sentiment_breakdown(articles):
    counts = {"positive": 0, "neutral": 0, "negative": 0}
    have_real = False
    for art in articles:
        label = (art.get("sentiment") or "").lower()
        if label in counts:
            counts[label] += 1
            have_real = True
    if have_real:
        caption = f"{DIM}based on {sum(counts.values())} article(s) with sentiment data{RESET}"
    else:
        counts = {"positive": 4, "neutral": 5, "negative": 3}
        caption = f"{GREY}sample \u2014 live sentiment requires a paid newsdata.io plan{RESET}"
    total = sum(counts.values()) or 1
    lines = [f"{BOLD}Sentiment breakdown{RESET}"]
    for label in ("positive", "neutral", "negative"):
        n = counts[label]
        bar = "\u2588" * int(round(20 * n / total))
        color = SENTIMENT_COLORS[label]
        lines.append(f"  {color}{label:<9}{RESET} {bar:<20} {n}")
    lines.append("  " + caption)
    return "\n".join(lines)
