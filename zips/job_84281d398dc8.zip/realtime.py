"""OpenAI Realtime API session wired to newsdata.io as a tool.

The model is given a ``search_news`` function backed by NewsdataClient. Two
entry points are exposed:

- ``ask_once`` — send one text prompt, stream the answer's transcript, and
  optionally play the spoken audio.
- ``voice_loop`` — a live microphone conversation using server-side VAD.

Audio capture/playback uses sounddevice, imported lazily so the rest of the app
runs without the PortAudio system dependency.
"""
from __future__ import annotations

import asyncio
import base64
import json
import os
import sys

import websockets

from newsdata_client import NewsdataClient

REALTIME_MODEL = os.environ.get(
    "OPENAI_REALTIME_MODEL", "gpt-4o-realtime-preview-2024-12-17"
)
REALTIME_URL = "wss://api.openai.com/v1/realtime"
SAMPLE_RATE = 24000

SEARCH_NEWS_TOOL = {
    "type": "function",
    "name": "search_news",
    "description": "Fetch current news headlines from the newsdata.io news API.",
    "parameters": {
        "type": "object",
        "properties": {
            "query": {
                "type": "string",
                "description": "Keywords to search for, e.g. 'bitcoin'.",
            },
            "country": {
                "type": "string",
                "description": "Optional 2-letter country code, e.g. 'us'.",
            },
            "language": {
                "type": "string",
                "description": "Optional 2-letter language code, e.g. 'en'.",
            },
        },
        "required": ["query"],
    },
}

INSTRUCTIONS = (
    "You are a concise news briefing assistant. When the user asks about news, "
    "call the search_news function, then summarise the top headlines in a few "
    "spoken sentences. Name the source for notable claims. If no articles are "
    "found, say so plainly."
)


def _stream_print(text):
    sys.stdout.write(text)
    sys.stdout.flush()


class _AudioPlayer:
    """Plays back PCM16 audio via sounddevice if it is available."""

    def __init__(self):
        self._stream = None

    def start(self):
        try:
            import sounddevice as sd
        except Exception as exc:  # noqa: BLE001 - optional dependency
            print(f"[audio playback unavailable: {exc}]", file=sys.stderr)
            return
        self._stream = sd.RawOutputStream(
            samplerate=SAMPLE_RATE, channels=1, dtype="int16"
        )
        self._stream.start()

    def write(self, pcm_bytes):
        if self._stream is not None and pcm_bytes:
            self._stream.write(pcm_bytes)

    def stop(self):
        if self._stream is not None:
            self._stream.stop()
            self._stream.close()
            self._stream = None


def _format_results(payload):
    results = payload.get("results") or []
    if not results:
        return {"articles": [], "note": "No articles found."}
    articles = []
    for art in results[:5]:
        articles.append(
            {
                "title": art.get("title"),
                "source": art.get("source_id"),
                "published": art.get("pubDate"),
                "summary": art.get("ai_summary") or art.get("description"),
                "keywords": art.get("keywords") or [],
                "sentiment": art.get("sentiment"),
            }
        )
    return {"articles": articles}


def _require_openai_key():
    key = os.environ.get("OPENAI_API_KEY")
    if not key:
        raise RuntimeError(
            "OPENAI_API_KEY is not set. The ask/voice features use the OpenAI "
            "Realtime API; export OPENAI_API_KEY to enable them."
        )
    return key


async def _connect(api_key):
    url = f"{REALTIME_URL}?model={REALTIME_MODEL}"
    headers = {
        "Authorization": f"Bearer {api_key}",
        "OpenAI-Beta": "realtime=v1",
    }
    return await websockets.connect(url, extra_headers=headers, max_size=None)


async def _run_tool(news, name, arguments):
    if name != "search_news":
        return {"error": f"unknown tool {name}"}
    try:
        args = json.loads(arguments or "{}")
    except json.JSONDecodeError:
        args = {}
    payload = news.latest(
        query=args.get("query"),
        country=args.get("country"),
        language=args.get("language"),
    )
    return _format_results(payload)


async def _send_tool_output(ws, call_id, result):
    await ws.send(
        json.dumps(
            {
                "type": "conversation.item.create",
                "item": {
                    "type": "function_call_output",
                    "call_id": call_id,
                    "output": json.dumps(result),
                },
            }
        )
    )
    await ws.send(json.dumps({"type": "response.create"}))


async def _pump_events(ws, news, on_text, audio_sink=None):
    """Consume events until the model's response (incl. tool follow-ups) ends."""
    transcript = []
    pending = 1
    while True:
        event = json.loads(await ws.recv())
        etype = event.get("type", "")
        if etype in (
            "response.text.delta",
            "response.output_text.delta",
            "response.audio_transcript.delta",
        ):
            delta = event.get("delta", "")
            transcript.append(delta)
            on_text(delta)
        elif etype == "response.audio.delta" and audio_sink is not None:
            audio_sink(base64.b64decode(event.get("delta", "")))
        elif etype == "response.function_call_arguments.done":
            result = await _run_tool(news, event.get("name"), event.get("arguments"))
            await _send_tool_output(ws, event.get("call_id"), result)
            pending += 1
        elif etype == "error":
            err = event.get("error", {})
            raise RuntimeError(f"Realtime API error: {err.get('message', err)}")
        elif etype == "response.done":
            pending -= 1
            if pending <= 0:
                return "".join(transcript)


async def _ask_once_async(prompt, speak=False):
    api_key = _require_openai_key()
    news = NewsdataClient()
    modalities = ["text", "audio"] if speak else ["text"]
    player = None
    audio_sink = None
    if speak:
        player = _AudioPlayer()
        player.start()
        audio_sink = player.write
    ws = await _connect(api_key)
    try:
        await ws.send(
            json.dumps(
                {
                    "type": "session.update",
                    "session": {
                        "modalities": modalities,
                        "instructions": INSTRUCTIONS,
                        "tools": [SEARCH_NEWS_TOOL],
                        "tool_choice": "auto",
                        "voice": "alloy",
                        "output_audio_format": "pcm16",
                    },
                }
            )
        )
        await ws.send(
            json.dumps(
                {
                    "type": "conversation.item.create",
                    "item": {
                        "type": "message",
                        "role": "user",
                        "content": [{"type": "input_text", "text": prompt}],
                    },
                }
            )
        )
        await ws.send(json.dumps({"type": "response.create"}))
        transcript = await _pump_events(ws, news, _stream_print, audio_sink)
        print()
        return transcript
    finally:
        await ws.close()
        if player is not None:
            player.stop()


def ask_once(prompt, speak=False):
    return asyncio.run(_ask_once_async(prompt, speak=speak))


async def _voice_loop_async():
    api_key = _require_openai_key()
    try:
        import sounddevice as sd
    except Exception as exc:  # noqa: BLE001 - optional dependency
        raise RuntimeError(
            f"Voice mode needs sounddevice + PortAudio: {exc}. Try: pip install sounddevice"
        )
    news = NewsdataClient()
    player = _AudioPlayer()
    player.start()
    ws = await _connect(api_key)
    loop = asyncio.get_running_loop()

    def mic_callback(indata, frames, time_info, status):
        chunk = base64.b64encode(bytes(indata)).decode()
        asyncio.run_coroutine_threadsafe(
            ws.send(json.dumps({"type": "input_audio_buffer.append", "audio": chunk})),
            loop,
        )

    await ws.send(
        json.dumps(
            {
                "type": "session.update",
                "session": {
                    "modalities": ["text", "audio"],
                    "instructions": INSTRUCTIONS,
                    "tools": [SEARCH_NEWS_TOOL],
                    "tool_choice": "auto",
                    "voice": "alloy",
                    "input_audio_format": "pcm16",
                    "output_audio_format": "pcm16",
                    "turn_detection": {"type": "server_vad"},
                },
            }
        )
    )
    stream = sd.RawInputStream(
        samplerate=SAMPLE_RATE,
        channels=1,
        dtype="int16",
        blocksize=2400,
        callback=mic_callback,
    )
    stream.start()
    print("Listening... ask about the news, or press Ctrl+C to stop.")
    try:
        while True:
            event = json.loads(await ws.recv())
            etype = event.get("type", "")
            if etype == "response.audio.delta":
                player.write(base64.b64decode(event.get("delta", "")))
            elif etype == "response.audio_transcript.delta":
                _stream_print(event.get("delta", ""))
            elif etype == "response.audio_transcript.done":
                print()
            elif etype == "response.function_call_arguments.done":
                result = await _run_tool(news, event.get("name"), event.get("arguments"))
                await _send_tool_output(ws, event.get("call_id"), result)
            elif etype == "error":
                err = event.get("error", {})
                print(f"\n[error] {err.get('message', err)}", file=sys.stderr)
    finally:
        stream.stop()
        stream.close()
        player.stop()
        await ws.close()


def voice_loop():
    try:
        asyncio.run(_voice_loop_async())
    except KeyboardInterrupt:
        print("\nStopped.")
