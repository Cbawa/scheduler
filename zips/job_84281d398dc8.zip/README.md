# newsdata-openai-realtime

Ask for the news out loud and hear a short briefing back. Headlines are pulled
from the newsdata.io news API (https://newsdata.io); the optional voice layer
runs through the OpenAI Realtime API, which calls newsdata.io as a tool to
answer spoken questions.

You can run it three ways:

- `headlines` — print the latest headlines in your terminal. Only needs a
  newsdata.io key.
- `ask "..."` — type a question and get a spoken-style briefing back (OpenAI
  Realtime API, text or audio).
- `voice` — hold a live microphone conversation.

## What you get

- Latest headlines with source, publish time, and a link.
- Keyword tags for each article (these come back on the free newsdata.io plan).
- A per-article sentiment badge and a sentiment breakdown bar.
- AI tag / region / organisation chips and an AI summary line when your plan
  provides them; otherwise the widgets show a clearly labelled placeholder.

The `sentiment`, `ai_tag`, `ai_region`, `ai_org` and `ai_summary` fields are
only filled in on a paid newsdata.io plan. On a free key they come back empty
and the app shows a labelled placeholder instead of breaking the layout.

## Setup

1. Python 3.9+.
2. Install dependencies:

       pip install -r requirements.txt

3. Get a free API key from https://newsdata.io and export it:

       export NEWSDATA_API_KEY=your_key_here

4. (Optional) For the `ask` and `voice` commands, set an OpenAI key:

       export OPENAI_API_KEY=sk-...

5. (Optional) For microphone capture and audio playback, install sounddevice
   (it needs the PortAudio system library):

       pip install sounddevice

## Usage

Print the latest technology headlines:

    python main.py headlines --category technology --language en

Search for a topic:

    python main.py headlines --query "crypto" --max 5

Ask a question (uses the OpenAI Realtime API, which fetches news as a tool call):

    python main.py ask "what's the latest on bitcoin?"

Add `--speak` to also play the audio answer, or start a live voice session:

    python main.py voice

### Sample output

    $ python main.py headlines --query bitcoin --max 2

    1. Bitcoin steadies after a volatile week [neutral]
       coindesk · 2026-06-12 09:14:00
       Prices held near recent levels after a choppy few sessions of trading.
       #bitcoin #markets #crypto
       ai tags require a paid newsdata.io plan
       https://example.com/article

    2. Miners report higher costs heading into summer [sentiment n/a]
       reuters · 2026-06-12 08:02:00
       (no summary available)
       #bitcoin #mining #energy
       ai tags require a paid newsdata.io plan
       https://example.com/article-2

    Sentiment breakdown
      positive  ████████             4
      neutral   ██████████           5
      negative  ██████               3
      sample — live sentiment requires a paid newsdata.io plan

The sentiment numbers above are a labelled sample because the free plan does
not return the `sentiment` field; with a paid plan the chart reflects the real
values attached to each article.

## Configuration

Environment variables:

- `NEWSDATA_API_KEY` (required) — your newsdata.io key.
- `OPENAI_API_KEY` — required only for `ask` and `voice`.
- `OPENAI_REALTIME_MODEL` — override the Realtime model id.
- `ENABLE_PAID_PARAMS=1` — allow paid-only query parameters (paid newsdata.io
  plan). Without it the app sends only free-tier parameters. You can also pass
  `--paid` to the `headlines` command. If the API rejects a paid parameter the
  request is retried once without it so you still get free results.
- `ENABLE_FULL_CONTENT=1` — request full article content (paid plan).

## Notes

- Pagination uses newsdata.io's `nextPage` cursor and stops when it is null.
- 401 (invalid key), 429 (rate limit), and empty result sets are reported with
  a plain message rather than a traceback.
- The `ask` and `voice` commands register a `search_news` function with the
  Realtime model; the model decides when to call it and the app answers with
  live headlines from newsdata.io.

## License

MIT
