# Crypto News (Flutter)

A small cross-platform Flutter app for reading cryptocurrency headlines. It pulls
live articles from the newsdata.io news API (https://newsdata.io) — grab a free API
key to run it — and shows them as a scrollable feed with per-token tags, a sentiment
summary, and a simple keyword alert.

## Features

- Live crypto news feed (newsdata.io `/crypto` endpoint), with pull-to-refresh and
  infinite scroll using the `nextPage` cursor.
- Free-text search across headlines.
- Token cards: a "trending tokens" strip built from the coins each article mentions,
  with a per-token headline count.
- Per-article keyword chips (always available) plus AI tag chips and an AI summary
  line when your plan returns them.
- Sentiment badge per article and an aggregate sentiment breakdown at the top of the
  feed. On a free key these fields are absent, so the chart shows a clearly labeled
  sample instead of leaving the space blank.
- Keyword alert: set a word (e.g. `bitcoin`) and get an in-app alert when a refresh
  brings in new matching headlines.

## Requirements

- Flutter 3.10 or newer (Dart 3).
- A newsdata.io API key. The free tier covers everything above; create a key at
  https://newsdata.io.

## Setup

1. Install dependencies:

   ```
   flutter pub get
   ```

2. Put your key in an environment variable:

   ```
   export NEWSDATA_API_KEY=your_key_here
   ```

3. Run the app, forwarding the key into the build with `--dart-define`:

   ```
   flutter run --dart-define=NEWSDATA_API_KEY=$NEWSDATA_API_KEY
   ```

The key is read at build time from the `NEWSDATA_API_KEY` define and is never
hardcoded. If it is missing, the app shows an error explaining how to pass it.

## Optional configuration

- `ENABLE_PAID_MODE` — when set to `true`, the app requests larger result pages
  (a `size` above 10). That query parameter requires a paid newsdata.io plan; on a
  free key the request is automatically retried without it, so you still get results.

  ```
  flutter run \
    --dart-define=NEWSDATA_API_KEY=$NEWSDATA_API_KEY \
    --dart-define=ENABLE_PAID_MODE=true
  ```

  Sentiment and the `ai_*` values are response fields, not query parameters — they
  arrive automatically in each article when your plan includes them, and the UI
  renders them when present.

## Project layout

- `lib/main.dart` — app shell, feed screen, search, alerts, trending strip.
- `lib/services/news_service.dart` — newsdata.io client and error handling.
- `lib/models/article.dart` — article model and safe parsing of optional fields.
- `lib/widgets/article_card.dart` — a single article card.
- `lib/widgets/sentiment_bar.dart` — the sentiment breakdown widget.

## Example

Searching for `etf` and refreshing produces a feed like:

```
Headline sentiment
  Positive  ########..  6
  Neutral   ####......  3
  Negative  ##........  2
  Sample — live sentiment requires a paid newsdata.io plan.

Trending tokens:  BTC · 5   ETH · 3   SOL · 2

Spot Bitcoin ETF inflows climb for a third week
CoinDesk · 2h ago
#bitcoin  #etf  #markets   [BTC]
```

## Notes

- Network errors, an invalid key (HTTP 401), rate limiting (HTTP 429), and empty
  result sets are all handled with a message rather than a crash.
- newsdata.io does not provide live price quotes, so the token strip reflects how
  often each coin appears in the current headlines rather than market prices.

## License

MIT
