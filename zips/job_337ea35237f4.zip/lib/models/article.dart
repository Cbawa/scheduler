/// A single news article from newsdata.io.
///
/// Fields that only exist on paid plans (sentiment, sentiment_stats, ai_tag,
/// ai_summary) are simply absent on a free key, so every one is nullable and
/// parsed defensively — a missing value becomes an empty/placeholder state in
/// the UI rather than a crash.
class Article {
  final String? articleId;
  final String title;
  final String? description;
  final String? link;
  final String? imageUrl;
  final String? sourceName;
  final String? pubDate;
  final List<String> keywords;
  final List<String> coins;

  // Paid response fields (null/empty on a free key).
  final String? sentiment;
  final SentimentStats? sentimentStats;
  final List<String> aiTags;
  final String? aiSummary;

  Article({
    this.articleId,
    required this.title,
    this.description,
    this.link,
    this.imageUrl,
    this.sourceName,
    this.pubDate,
    this.keywords = const [],
    this.coins = const [],
    this.sentiment,
    this.sentimentStats,
    this.aiTags = const [],
    this.aiSummary,
  });

  static List<String> _stringList(dynamic v) {
    if (v is List) {
      return v
          .where((e) => e != null)
          .map((e) => e.toString())
          .where((e) => e.isNotEmpty && e.toLowerCase() != 'null')
          .toList();
    }
    if (v is String && v.isNotEmpty && v.toLowerCase() != 'null') return [v];
    return const [];
  }

  static String? _cleanString(dynamic v) {
    if (v is String && v.trim().isNotEmpty && v.toLowerCase() != 'null') {
      return v;
    }
    return null;
  }

  factory Article.fromJson(Map<String, dynamic> j) {
    final title = _cleanString(j['title']) ?? 'Untitled';
    return Article(
      articleId: j['article_id'] as String?,
      title: title,
      description: _cleanString(j['description']),
      link: j['link'] as String?,
      imageUrl: _cleanString(j['image_url']),
      sourceName: _cleanString(j['source_name']) ??
          _cleanString(j['source_id']),
      pubDate: j['pubDate'] as String?,
      keywords: _stringList(j['keywords']),
      coins: _stringList(j['coin']),
      sentiment: _cleanString(j['sentiment']),
      sentimentStats: SentimentStats.tryParse(j['sentiment_stats']),
      aiTags: _stringList(j['ai_tag']),
      aiSummary: _cleanString(j['ai_summary']),
    );
  }

  bool get hasSentiment => sentiment != null && sentiment!.isNotEmpty;
}

class SentimentStats {
  final double positive;
  final double neutral;
  final double negative;

  const SentimentStats({
    required this.positive,
    required this.neutral,
    required this.negative,
  });

  static SentimentStats? tryParse(dynamic v) {
    if (v is Map) {
      double pick(String k) {
        final x = v[k];
        if (x is num) return x.toDouble();
        if (x is String) return double.tryParse(x) ?? 0;
        return 0;
      }

      return SentimentStats(
        positive: pick('positive'),
        neutral: pick('neutral'),
        negative: pick('negative'),
      );
    }
    return null;
  }
}
