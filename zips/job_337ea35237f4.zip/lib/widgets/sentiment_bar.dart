import 'package:flutter/material.dart';

/// Aggregate sentiment breakdown shown at the top of the feed.
///
/// On a free key the per-article `sentiment` field is absent, so the caller
/// passes [isSample] = true and this widget renders a clearly labeled sample
/// instead of leaving the area blank.
class SentimentBreakdown extends StatelessWidget {
  final int positive;
  final int neutral;
  final int negative;
  final bool isSample;

  const SentimentBreakdown({
    super.key,
    required this.positive,
    required this.neutral,
    required this.negative,
    required this.isSample,
  });

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final total = positive + neutral + negative;
    final t = total == 0 ? 1 : total;
    return Card(
      margin: const EdgeInsets.fromLTRB(12, 12, 12, 4),
      child: Padding(
        padding: const EdgeInsets.all(14),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                const Icon(Icons.insights, size: 18),
                const SizedBox(width: 6),
                Text('Headline sentiment', style: theme.textTheme.titleSmall),
              ],
            ),
            const SizedBox(height: 10),
            _bar(context, 'Positive', positive, t, Colors.green),
            _bar(context, 'Neutral', neutral, t, Colors.blueGrey),
            _bar(context, 'Negative', negative, t, Colors.red),
            if (isSample) ...[
              const SizedBox(height: 8),
              Text(
                'Sample — live sentiment requires a paid newsdata.io plan.',
                style: theme.textTheme.bodySmall?.copyWith(
                  fontStyle: FontStyle.italic,
                  color: theme.hintColor,
                ),
              ),
            ],
          ],
        ),
      ),
    );
  }

  Widget _bar(
    BuildContext context,
    String label,
    int value,
    int total,
    Color color,
  ) {
    final frac = (value / total).clamp(0.0, 1.0);
    final style = Theme.of(context).textTheme.bodySmall;
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 4),
      child: Row(
        children: [
          SizedBox(width: 64, child: Text(label, style: style)),
          Expanded(
            child: ClipRRect(
              borderRadius: BorderRadius.circular(6),
              child: LinearProgressIndicator(
                value: frac,
                minHeight: 10,
                backgroundColor: color.withOpacity(0.15),
                valueColor: AlwaysStoppedAnimation<Color>(color),
              ),
            ),
          ),
          const SizedBox(width: 8),
          SizedBox(
            width: 28,
            child: Text('$value', textAlign: TextAlign.right, style: style),
          ),
        ],
      ),
    );
  }
}
