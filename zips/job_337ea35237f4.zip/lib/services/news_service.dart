import 'dart:convert';

import 'package:http/http.dart' as http;

import '../models/article.dart';

/// One page of results plus the cursor for the next page (null when finished).
class NewsResult {
  final List<Article> articles;
  final String? nextPage;
  const NewsResult(this.articles, this.nextPage);
}

class NewsException implements Exception {
  final String message;
  NewsException(this.message);
  @override
  String toString() => message;
}

/// Thin client for the newsdata.io crypto news endpoint.
///
/// The API key is read at build time from the NEWSDATA_API_KEY define and is
/// never hardcoded. Paid-only query parameters are off by default so a brand-new
/// free key works end to end; they are sent only when [ENABLE_PAID_MODE] is set,
/// and the request is retried without them if the server rejects them.
class NewsService {
  static const String _base = 'https://newsdata.io/api/1';

  static const String apiKey = String.fromEnvironment('NEWSDATA_API_KEY');

  static const bool enablePaidMode =
      bool.fromEnvironment('ENABLE_PAID_MODE', defaultValue: false);

  final http.Client _client;
  NewsService({http.Client? client}) : _client = client ?? http.Client();

  bool get hasApiKey => apiKey.isNotEmpty;

  Future<NewsResult> fetchCryptoNews({
    String? query,
    String? coin,
    String? page,
    bool paid = false,
  }) async {
    if (apiKey.isEmpty) {
      throw NewsException(
        'NEWSDATA_API_KEY is not set. Run with '
        '--dart-define=NEWSDATA_API_KEY=your_key',
      );
    }

    final params = <String, String>{
      'apikey': apiKey,
      'language': 'en',
    };
    final q = query?.trim() ?? '';
    if (q.isNotEmpty) params['q'] = q;
    final c = coin?.trim() ?? '';
    if (c.isNotEmpty) params['coin'] = c.toLowerCase();
    if (page != null && page.isNotEmpty) params['page'] = page;

    // Paid-only query param. Free keys reject size > 10, so only request it when
    // the user explicitly opts in, and fall back gracefully below.
    final usePaid = paid && enablePaidMode;
    if (usePaid) params['size'] = '25';

    var resp = await _get(params);

    if (usePaid && (resp.statusCode == 403 || resp.statusCode == 422)) {
      params.remove('size');
      resp = await _get(params);
    }

    return _handle(resp);
  }

  Future<http.Response> _get(Map<String, String> params) async {
    final uri = Uri.parse('$_base/crypto').replace(queryParameters: params);
    try {
      return await _client.get(uri);
    } catch (e) {
      throw NewsException('Network error: $e');
    }
  }

  NewsResult _handle(http.Response resp) {
    switch (resp.statusCode) {
      case 200:
        break;
      case 401:
        throw NewsException('Invalid API key (401). Check NEWSDATA_API_KEY.');
      case 429:
        throw NewsException('Rate limit reached (429). Wait and try again.');
      default:
        throw NewsException('Request failed (HTTP ${resp.statusCode}).');
    }

    Map<String, dynamic> body;
    try {
      body = json.decode(resp.body) as Map<String, dynamic>;
    } catch (_) {
      throw NewsException('Could not parse the API response.');
    }

    if (body['status'] == 'error') {
      final results = body['results'];
      final msg = (results is Map && results['message'] != null)
          ? results['message'].toString()
          : 'Unknown API error';
      throw NewsException(msg);
    }

    final rawList = (body['results'] as List?) ?? const [];
    final articles = rawList
        .whereType<Map<String, dynamic>>()
        .map(Article.fromJson)
        .toList();
    final next = body['nextPage'] as String?;
    return NewsResult(articles, next);
  }

  void dispose() => _client.close();
}
