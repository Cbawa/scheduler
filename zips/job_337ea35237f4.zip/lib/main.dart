import 'package:flutter/material.dart';

import 'models/article.dart';
import 'services/news_service.dart';
import 'widgets/article_card.dart';
import 'widgets/sentiment_bar.dart';

void main() => runApp(const CryptoNewsApp());

class CryptoNewsApp extends StatelessWidget {
  const CryptoNewsApp({super.key});

  @override
  Widget build(BuildContext context) {
    final scheme = ColorScheme.fromSeed(
      seedColor: const Color(0xFFF7931A),
      brightness: Brightness.dark,
    );
    return MaterialApp(
      title: 'Crypto News',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(colorScheme: scheme, useMaterial3: true),
      home: const HomePage(),
    );
  }
}

class HomePage extends StatefulWidget {
  const HomePage({super.key});

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  final NewsService _service = NewsService();
  final ScrollController _scroll = ScrollController();
  final TextEditingController _search = TextEditingController();

  final List<Article> _articles = [];
  String? _nextPage;
  bool _loading = false;
  bool _loadingMore = false;
  String? _error;
  String _query = '';
  String _alertKeyword = '';

  @override
  void initState() {
    super.initState();
    _scroll.addListener(_onScroll);
    _refresh();
  }

  @override
  void dispose() {
    _scroll.removeListener(_onScroll);
    _scroll.dispose();
    _search.dispose();
    _service.dispose();
    super.dispose();
  }

  String _idOf(Article a) => a.articleId ?? a.link ?? a.title;

  void _onScroll() {
    if (_scroll.position.pixels >= _scroll.position.maxScrollExtent - 400) {
      _loadMore();
    }
  }

  Future<void> _refresh() async {
    setState(() {
      _loading = true;
      _error = null;
    });
    final previous = _articles.map(_idOf).toSet();
    try {
      final res = await _service.fetchCryptoNews(query: _query, paid: true);
      setState(() {
        _articles
          ..clear()
          ..addAll(res.articles);
        _nextPage = res.nextPage;
        _loading = false;
      });
      _maybeAlert(res.articles, previous);
    } on NewsException catch (e) {
      setState(() {
        _error = e.message;
        _loading = false;
      });
    } catch (e) {
      setState(() {
        _error = 'Unexpected error: $e';
        _loading = false;
      });
    }
  }

  Future<void> _loadMore() async {
    if (_loadingMore || _loading || _nextPage == null) return;
    setState(() => _loadingMore = true);
    try {
      final res = await _service.fetchCryptoNews(
        query: _query,
        page: _nextPage,
        paid: true,
      );
      setState(() {
        final existing = _articles.map(_idOf).toSet();
        for (final a in res.articles) {
          if (existing.add(_idOf(a))) _articles.add(a);
        }
        _nextPage = res.nextPage;
        _loadingMore = false;
      });
    } on NewsException catch (e) {
      setState(() => _loadingMore = false);
      if (mounted) {
        ScaffoldMessenger.of(context)
            .showSnackBar(SnackBar(content: Text(e.message)));
      }
    } catch (_) {
      setState(() => _loadingMore = false);
    }
  }

  void _maybeAlert(List<Article> articles, Set<String> previous) {
    final kw = _alertKeyword.trim().toLowerCase();
    if (kw.isEmpty) return;
    final matches = articles.where((a) {
      if (previous.contains(_idOf(a))) return false;
      final hay = [
        a.title,
        a.description ?? '',
        ...a.keywords,
        ...a.coins,
      ].join(' ').toLowerCase();
      return hay.contains(kw);
    }).length;
    if (matches > 0 && mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content:
              Text('Alert: $matches new headline(s) matching "$_alertKeyword"'),
        ),
      );
    }
  }

  Map<String, int> _trendingTokens() {
    final counts = <String, int>{};
    for (final a in _articles) {
      for (final c in a.coins) {
        final key = c.trim().toUpperCase();
        if (key.isEmpty) continue;
        counts[key] = (counts[key] ?? 0) + 1;
      }
    }
    final entries = counts.entries.toList()
      ..sort((a, b) => b.value.compareTo(a.value));
    return Map.fromEntries(entries.take(12));
  }

  SentimentBreakdown _buildSentiment() {
    int pos = 0, neu = 0, neg = 0;
    for (final a in _articles) {
      switch (a.sentiment?.toLowerCase()) {
        case 'positive':
          pos++;
          break;
        case 'negative':
          neg++;
          break;
        case 'neutral':
          neu++;
          break;
      }
    }
    if (pos + neu + neg > 0) {
      return SentimentBreakdown(
        positive: pos,
        neutral: neu,
        negative: neg,
        isSample: false,
      );
    }
    // Free key: no sentiment field present. Show a clearly labeled sample so the
    // capability stays visible and the layout is not blank.
    return const SentimentBreakdown(
      positive: 6,
      neutral: 3,
      negative: 2,
      isSample: true,
    );
  }

  Future<void> _showAlertDialog() async {
    final controller = TextEditingController(text: _alertKeyword);
    final result = await showDialog<String>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Keyword alert'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Text(
                'Get an in-app alert when a refresh brings in new headlines that mention this word.'),
            const SizedBox(height: 12),
            TextField(
              controller: controller,
              autofocus: true,
              decoration: const InputDecoration(hintText: 'e.g. bitcoin'),
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx, ''),
            child: const Text('Clear'),
          ),
          FilledButton(
            onPressed: () => Navigator.pop(ctx, controller.text.trim()),
            child: const Text('Save'),
          ),
        ],
      ),
    );
    if (result != null) {
      setState(() => _alertKeyword = result);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Crypto News'),
        actions: [
          IconButton(
            tooltip: 'Keyword alert',
            icon: Icon(_alertKeyword.isEmpty
                ? Icons.notifications_none
                : Icons.notifications_active),
            onPressed: _showAlertDialog,
          ),
        ],
        bottom: PreferredSize(
          preferredSize: const Size.fromHeight(56),
          child: Padding(
            padding: const EdgeInsets.fromLTRB(12, 0, 12, 8),
            child: TextField(
              controller: _search,
              textInputAction: TextInputAction.search,
              decoration: InputDecoration(
                hintText: 'Search crypto news (e.g. bitcoin, ETF)…',
                isDense: true,
                filled: true,
                prefixIcon: const Icon(Icons.search),
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(24),
                  borderSide: BorderSide.none,
                ),
              ),
              onSubmitted: (v) {
                setState(() => _query = v.trim());
                _refresh();
              },
            ),
          ),
        ),
      ),
      body: RefreshIndicator(
        onRefresh: _refresh,
        child: _buildBody(),
      ),
    );
  }

  Widget _buildBody() {
    if (_loading && _articles.isEmpty) {
      return const Center(child: CircularProgressIndicator());
    }
    if (_error != null && _articles.isEmpty) {
      return _ErrorView(message: _error!, onRetry: _refresh);
    }
    final tokens = _trendingTokens();
    return ListView.builder(
      controller: _scroll,
      physics: const AlwaysScrollableScrollPhysics(),
      itemCount: _articles.length + 2,
      itemBuilder: (context, index) {
        if (index == 0) {
          return Column(
            children: [
              _buildSentiment(),
              if (tokens.isNotEmpty) _TrendingStrip(tokens: tokens),
            ],
          );
        }
        final i = index - 1;
        if (i < _articles.length) {
          return ArticleCard(article: _articles[i]);
        }
        if (_articles.isEmpty) {
          return const Padding(
            padding: EdgeInsets.all(32),
            child: Center(child: Text('No articles found.')),
          );
        }
        return Padding(
          padding: const EdgeInsets.all(16),
          child: Center(
            child: _nextPage == null
                ? Text('— end of results —',
                    style: Theme.of(context).textTheme.bodySmall)
                : (_loadingMore
                    ? const CircularProgressIndicator()
                    : const SizedBox.shrink()),
          ),
        );
      },
    );
  }
}

class _TrendingStrip extends StatelessWidget {
  final Map<String, int> tokens;
  const _TrendingStrip({required this.tokens});

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final entries = tokens.entries.toList();
    return SizedBox(
      height: 40,
      child: ListView.separated(
        scrollDirection: Axis.horizontal,
        padding: const EdgeInsets.symmetric(horizontal: 12),
        itemCount: entries.length + 1,
        separatorBuilder: (_, __) => const SizedBox(width: 8),
        itemBuilder: (context, i) {
          if (i == 0) {
            return Center(
              child: Text('Trending tokens',
                  style: theme.textTheme.labelMedium
                      ?.copyWith(color: theme.hintColor)),
            );
          }
          final e = entries[i - 1];
          return Center(
            child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
              decoration: BoxDecoration(
                color: theme.colorScheme.primaryContainer,
                borderRadius: BorderRadius.circular(20),
              ),
              child: Text(
                '${e.key} · ${e.value}',
                style: theme.textTheme.labelMedium?.copyWith(
                  color: theme.colorScheme.onPrimaryContainer,
                  fontWeight: FontWeight.w600,
                ),
              ),
            ),
          );
        },
      ),
    );
  }
}

class _ErrorView extends StatelessWidget {
  final String message;
  final Future<void> Function() onRetry;
  const _ErrorView({required this.message, required this.onRetry});

  @override
  Widget build(BuildContext context) {
    return ListView(
      physics: const AlwaysScrollableScrollPhysics(),
      children: [
        const SizedBox(height: 80),
        const Icon(Icons.error_outline, size: 48),
        const SizedBox(height: 12),
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 32),
          child: Text(message, textAlign: TextAlign.center),
        ),
        const SizedBox(height: 16),
        Center(
          child: FilledButton(onPressed: onRetry, child: const Text('Retry')),
        ),
      ],
    );
  }
}
